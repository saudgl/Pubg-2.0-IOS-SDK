#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class ActorSequence.ActorSequence
// Size: 0x308 // Inherited bytes: 0x2e0
struct UActorSequence : UMovieSceneSequence {
	// Fields
	struct UMovieScene* MovieScene; // Offset: 0x2e0 // Size: 0x08
	struct FActorSequenceObjectReferenceMap ObjectReferences; // Offset: 0x2e8 // Size: 0x20
};

// Object Name: Class ActorSequence.ActorSequenceComponent
// Size: 0x150 // Inherited bytes: 0x110
struct UActorSequenceComponent : UActorComponent {
	// Fields
	struct FMovieSceneSequencePlaybackSettings PlaybackSettings; // Offset: 0x110 // Size: 0x28
	struct UActorSequence* Sequence; // Offset: 0x138 // Size: 0x08
	struct UActorSequencePlayer* SequencePlayer; // Offset: 0x140 // Size: 0x08
	bool bAutoPlay; // Offset: 0x148 // Size: 0x01
	bool bRunOnServer; // Offset: 0x149 // Size: 0x01
	bool bEnableOptimize; // Offset: 0x14a // Size: 0x01
	char pad_0x14B[0x5]; // Offset: 0x14b // Size: 0x05

	// Functions

	// Object Name: Function ActorSequence.ActorSequenceComponent.StopPlay
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StopPlay(); // Offset: 0x1026839bc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ActorSequence.ActorSequenceComponent.StartPlay
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StartPlay(float StartTime); // Offset: 0x102683940 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function ActorSequence.ActorSequenceComponent.OnStopOrFinsh
	// Flags: [Final|Native|Private]
	void OnStopOrFinsh(); // Offset: 0x10268392c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ActorSequence.ActorSequenceComponent.GetLength
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetLength(); // Offset: 0x1026838f8 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class ActorSequence.ActorSequencePlayer
// Size: 0x768 // Inherited bytes: 0x768
struct UActorSequencePlayer : UMovieSceneSequencePlayer {
};

