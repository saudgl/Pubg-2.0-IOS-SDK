#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class AkAudio.AkAcousticPortal
// Size: 0x410 // Inherited bytes: 0x400
struct AAkAcousticPortal : AVolume {
	// Fields
	float Gain; // Offset: 0x400 // Size: 0x04
	enum class AkAcousticPortalState InitialState; // Offset: 0x404 // Size: 0x01
	char pad_0x405[0xb]; // Offset: 0x405 // Size: 0x0b

	// Functions

	// Object Name: Function AkAudio.AkAcousticPortal.OpenPortal
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OpenPortal(); // Offset: 0x10223b344 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkAcousticPortal.GetCurrentState
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class AkAcousticPortalState GetCurrentState(); // Offset: 0x10223b310 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AkAudio.AkAcousticPortal.ClosePortal
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClosePortal(); // Offset: 0x10223b2fc // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class AkAudio.AkAcousticTexture
// Size: 0x28 // Inherited bytes: 0x28
struct UAkAcousticTexture : UObject {
};

// Object Name: Class AkAudio.AkAmbientSound
// Size: 0x420 // Inherited bytes: 0x3c8
struct AAkAmbientSound : AActor {
	// Fields
	struct UAkAudioEvent* AkAudioEvent; // Offset: 0x3c8 // Size: 0x08
	struct UAkComponent* AkComponent; // Offset: 0x3d0 // Size: 0x08
	bool StopWhenOwnerIsDestroyed; // Offset: 0x3d8 // Size: 0x01
	bool AutoPost; // Offset: 0x3d9 // Size: 0x01
	char pad_0x3DA[0x46]; // Offset: 0x3da // Size: 0x46

	// Functions

	// Object Name: Function AkAudio.AkAmbientSound.StopAmbientSound
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void StopAmbientSound(); // Offset: 0x10223b6fc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkAmbientSound.StartAmbientSound
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void StartAmbientSound(); // Offset: 0x10223b6e8 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class AkAudio.AkAreaCheckComponent
// Size: 0x160 // Inherited bytes: 0x110
struct UAkAreaCheckComponent : UActorComponent {
	// Fields
	char pad_0x110[0x50]; // Offset: 0x110 // Size: 0x50

	// Functions

	// Object Name: Function AkAudio.AkAreaCheckComponent.CheckVoiceAvailable
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	bool CheckVoiceAvailable(struct FVector& VoicePostion); // Offset: 0x10223ba08 // Return & Params: Num(2) Size(0xd)
};

// Object Name: Class AkAudio.AkAreaCheckVolume
// Size: 0x3f0 // Inherited bytes: 0x3c8
struct AAkAreaCheckVolume : AActor {
	// Fields
	enum class ECustomAKAreaType AKAreaType; // Offset: 0x3c8 // Size: 0x01
	char pad_0x3C9[0x3]; // Offset: 0x3c9 // Size: 0x03
	struct FBox AreaBox; // Offset: 0x3cc // Size: 0x1c
	struct UBoxComponent* CollisionComponent; // Offset: 0x3e8 // Size: 0x08

	// Functions

	// Object Name: Function AkAudio.AkAreaCheckVolume.IsInsideVolume
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	bool IsInsideVolume(struct FVector& OrignPosition); // Offset: 0x10223bc1c // Return & Params: Num(2) Size(0xd)

	// Object Name: Function AkAudio.AkAreaCheckVolume.GetAKAreaType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	enum class ECustomAKAreaType GetAKAreaType(); // Offset: 0x10223bc00 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class AkAudio.AkAudioBank
// Size: 0x40 // Inherited bytes: 0x28
struct UAkAudioBank : UObject {
	// Fields
	bool AutoLoad; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x17]; // Offset: 0x29 // Size: 0x17
};

// Object Name: Class AkAudio.AkAudioDeviceSettings
// Size: 0x58 // Inherited bytes: 0x28
struct UAkAudioDeviceSettings : UObject {
	// Fields
	int SuperHighDefaultPoolSize; // Offset: 0x28 // Size: 0x04
	int SuperHighEngineDefaultPoolSize; // Offset: 0x2c // Size: 0x04
	int HighDefaultPoolSize; // Offset: 0x30 // Size: 0x04
	int HighEngineDefaultPoolSize; // Offset: 0x34 // Size: 0x04
	int LowDefaultPoolSize; // Offset: 0x38 // Size: 0x04
	int LowEngineDefaultPoolSize; // Offset: 0x3c // Size: 0x04
	int DefaultCommandQueueSize; // Offset: 0x40 // Size: 0x04
	int DefaultBluetoothDelay; // Offset: 0x44 // Size: 0x04
	float DefaultBluetoothErrThres; // Offset: 0x48 // Size: 0x04
	float DefaultBluetoothErrRatio; // Offset: 0x4c // Size: 0x04
	float DefaultBluetoothMaxTime; // Offset: 0x50 // Size: 0x04
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04

	// Functions

	// Object Name: Function AkAudio.AkAudioDeviceSettings.InitConfig
	// Flags: [Final|Native|Public]
	void InitConfig(); // Offset: 0x10223bf54 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class AkAudio.AkAudioEvent
// Size: 0x40 // Inherited bytes: 0x28
struct UAkAudioEvent : UObject {
	// Fields
	struct UAkAudioBank* RequiredBank; // Offset: 0x28 // Size: 0x08
	float MaxAttenuationRadius; // Offset: 0x30 // Size: 0x04
	bool IsInfinite; // Offset: 0x34 // Size: 0x01
	char pad_0x35[0x3]; // Offset: 0x35 // Size: 0x03
	float MinimumDuration; // Offset: 0x38 // Size: 0x04
	float MaximumDuration; // Offset: 0x3c // Size: 0x04
};

// Object Name: Class AkAudio.AkAudioVisualComponent
// Size: 0x1350 // Inherited bytes: 0x2d0
struct UAkAudioVisualComponent : USceneComponent {
	// Fields
	struct FString BankName; // Offset: 0x2d0 // Size: 0x10
	struct FString EventName; // Offset: 0x2e0 // Size: 0x10
	enum class EFrequencyRange RangeType; // Offset: 0x2f0 // Size: 0x01
	char pad_0x2F1[0x3]; // Offset: 0x2f1 // Size: 0x03
	int BinNumber; // Offset: 0x2f4 // Size: 0x04
	char pad_0x2F8[0x1010]; // Offset: 0x2f8 // Size: 0x1010
	bool UseOfflineData; // Offset: 0x1308 // Size: 0x01
	char pad_0x1309[0x7]; // Offset: 0x1309 // Size: 0x07
	struct TArray<struct FAudioOfflineVisualBeatData> OfflineData; // Offset: 0x1310 // Size: 0x10
	char pad_0x1320[0x30]; // Offset: 0x1320 // Size: 0x30

	// Functions

	// Object Name: Function AkAudio.AkAudioVisualComponent.StartOfflineTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StartOfflineTime(); // Offset: 0x10223c56c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkAudioVisualComponent.ResetOfflineTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ResetOfflineTime(); // Offset: 0x10223c558 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkAudioVisualComponent.OnTickVisualInfo
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	void OnTickVisualInfo(struct TArray<float>& VisualInfo); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkAudioVisualComponent.OnTickOfflineVisualInfo
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	void OnTickOfflineVisualInfo(struct FAudioOfflineVisualBeatData& VisualInfo); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function AkAudio.AkAudioVisualComponent.InitOfflineDataWithBeatTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void InitOfflineDataWithBeatTime(struct TArray<float> Datas); // Offset: 0x10223c474 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkAudioVisualComponent.InitOfflineData
	// Flags: [Final|Native|Public|BlueprintCallable]
	void InitOfflineData(struct TArray<struct FAudioOfflineVisualBeatData> Datas); // Offset: 0x10223c390 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkAudioVisualComponent.GetCurrentBeat
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool GetCurrentBeat(struct FAudioOfflineVisualBeatData& Result); // Offset: 0x10223c2d0 // Return & Params: Num(2) Size(0x19)
};

// Object Name: Class AkAudio.AkAuxBus
// Size: 0x38 // Inherited bytes: 0x28
struct UAkAuxBus : UObject {
	// Fields
	struct UAkAudioBank* RequiredBank; // Offset: 0x28 // Size: 0x08
	char pad_0x30[0x8]; // Offset: 0x30 // Size: 0x08
};

// Object Name: Class AkAudio.AkComponent
// Size: 0x520 // Inherited bytes: 0x2d0
struct UAkComponent : USceneComponent {
	// Fields
	struct UAkAuxBus* EarlyReflectionAuxBus; // Offset: 0x2d0 // Size: 0x08
	struct FString EarlyReflectionAuxBusName; // Offset: 0x2d8 // Size: 0x10
	int EarlyReflectionOrder; // Offset: 0x2e8 // Size: 0x04
	float EarlyReflectionBusSendGain; // Offset: 0x2ec // Size: 0x04
	float EarlyReflectionMaxPathLength; // Offset: 0x2f0 // Size: 0x04
	char pad_0x2F4[0x4]; // Offset: 0x2f4 // Size: 0x04
	char EnableSpotReflectors : 1; // Offset: 0x2f8 // Size: 0x01
	char DrawFirstOrderReflections : 1; // Offset: 0x2f8 // Size: 0x01
	char DrawSecondOrderReflections : 1; // Offset: 0x2f8 // Size: 0x01
	char DrawHigherOrderReflections : 1; // Offset: 0x2f8 // Size: 0x01
	char pad_0x2F8_4 : 4; // Offset: 0x2f8 // Size: 0x01
	bool StopWhenOwnerDestroyed; // Offset: 0x2f9 // Size: 0x01
	char bIsUpdateEmmiterTransform : 1; // Offset: 0x2fa // Size: 0x01
	char bAllIsInstanceSound : 1; // Offset: 0x2fa // Size: 0x01
	char pad_0x2FA_2 : 6; // Offset: 0x2fa // Size: 0x01
	char pad_0x2FB[0x1]; // Offset: 0x2fb // Size: 0x01
	float AttenuationScalingFactor; // Offset: 0x2fc // Size: 0x04
	float OcclusionRefreshInterval; // Offset: 0x300 // Size: 0x04
	char pad_0x304[0x4]; // Offset: 0x304 // Size: 0x04
	struct UAkAudioEvent* AkAudioEvent; // Offset: 0x308 // Size: 0x08
	struct FString EventName; // Offset: 0x310 // Size: 0x10
	char pad_0x320[0x200]; // Offset: 0x320 // Size: 0x200

	// Functions

	// Object Name: Function AkAudio.AkComponent.UseReverbVolumes
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void UseReverbVolumes(bool inUseReverbVolumes); // Offset: 0x10223d7c4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AkAudio.AkComponent.UseEarlyReflections
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UseEarlyReflections(struct UAkAuxBus* AuxBus, bool Left, bool Right, bool floor, bool Ceiling, bool Back, bool Front, bool SpotReflectors, struct FString AuxBusName); // Offset: 0x10223d4ec // Return & Params: Num(9) Size(0x20)

	// Object Name: Function AkAudio.AkComponent.StopPlayingID
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void StopPlayingID(int StopEventID); // Offset: 0x10223d470 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AkAudio.AkComponent.Stop
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void Stop(); // Offset: 0x10223d45c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkComponent.SetSwitch
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	int SetSwitch(struct FString SwitchGroup, struct FString SwitchState); // Offset: 0x10223d318 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function AkAudio.AkComponent.SetStopWhenOwnerDestroyed
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void SetStopWhenOwnerDestroyed(bool bStopWhenOwnerDestroyed); // Offset: 0x10223d294 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AkAudio.AkComponent.SetRTPCValueGlobally
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void SetRTPCValueGlobally(struct FString RTPC, float Value); // Offset: 0x10223d198 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function AkAudio.AkComponent.SetRTPCValue
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void SetRTPCValue(struct FString RTPC, float Value, int InterpolationTimeMs); // Offset: 0x10223d05c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function AkAudio.AkComponent.SetOutputBusVolume
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void SetOutputBusVolume(float BusVolume); // Offset: 0x10223cfe0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AkAudio.AkComponent.SetListeners
	// Flags: [Final|BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable]
	void SetListeners(struct TArray<struct UAkComponent*>& Listeners); // Offset: 0x10223cf38 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkComponent.SetEarlyReflectionOrder
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetEarlyReflectionOrder(int NewEarlyReflectionOrder); // Offset: 0x10223cebc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AkAudio.AkComponent.SetAutoDestroy
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void SetAutoDestroy(bool in_AutoDestroy); // Offset: 0x10223ce3c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AkAudio.AkComponent.SetAttenuationScalingFactor
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void SetAttenuationScalingFactor(float Value); // Offset: 0x10223cdc0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AkAudio.AkComponent.SeekOnEvent
	// Flags: [Final|Native|Public]
	int SeekOnEvent(struct FString in_EventName, int in_iPosition); // Offset: 0x10223ccd8 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function AkAudio.AkComponent.PostTrigger
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void PostTrigger(struct FString Trigger); // Offset: 0x10223cc1c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkComponent.PostAssociatedAkEvent
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	int PostAssociatedAkEvent(); // Offset: 0x10223cbe8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AkAudio.AkComponent.PostAkEventByName
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	int PostAkEventByName(struct FString in_EventName); // Offset: 0x10223cb40 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function AkAudio.AkComponent.PostAkEvent
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	int PostAkEvent(struct UAkAudioEvent* AkEvent, struct FString in_EventName); // Offset: 0x10223ca5c // Return & Params: Num(3) Size(0x1c)

	// Object Name: Function AkAudio.AkComponent.GetAttenuationRadius
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetAttenuationRadius(); // Offset: 0x10223ca28 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class AkAudio.AkGameplayStatics
// Size: 0x28 // Inherited bytes: 0x28
struct UAkGameplayStatics : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function AkAudio.AkGameplayStatics.WakeupFromSuspend
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void WakeupFromSuspend(); // Offset: 0x10224049c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkGameplayStatics.UseReverbVolumes
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void UseReverbVolumes(bool inUseReverbVolumes, struct AActor* Actor); // Offset: 0x1022403e4 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function AkAudio.AkGameplayStatics.UseEarlyReflections
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void UseEarlyReflections(struct AActor* Actor, struct UAkAuxBus* AuxBus, bool Left, bool Right, bool floor, bool Ceiling, bool Back, bool Front, bool SpotReflectors, struct FString AuxBusName); // Offset: 0x1022400e4 // Return & Params: Num(10) Size(0x28)

	// Object Name: Function AkAudio.AkGameplayStatics.UnloadBankByName
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void UnloadBankByName(struct FString BankName); // Offset: 0x102240054 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkGameplayStatics.UnloadBank
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void UnloadBank(struct UAkAudioBank* Bank, struct FString BankName); // Offset: 0x10223ff88 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function AkAudio.AkGameplayStatics.Suspend
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void Suspend(); // Offset: 0x10223ff74 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkGameplayStatics.StopProfilerCapture
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void StopProfilerCapture(); // Offset: 0x10223ff60 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkGameplayStatics.StopPlayingID
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void StopPlayingID(int PlayingID); // Offset: 0x10223feec // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AkAudio.AkGameplayStatics.StopOutputCapture
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void StopOutputCapture(); // Offset: 0x10223fed8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkGameplayStatics.StopAllAmbientSounds
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void StopAllAmbientSounds(struct UObject* WorldContextObject); // Offset: 0x10223fe64 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function AkAudio.AkGameplayStatics.StopAll
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void StopAll(); // Offset: 0x10223fe50 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkGameplayStatics.StopAkEventByID
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void StopAkEventByID(int ID); // Offset: 0x10223fddc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AkAudio.AkGameplayStatics.StopActor
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void StopActor(struct AActor* Actor); // Offset: 0x10223fd68 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function AkAudio.AkGameplayStatics.StartProfilerCapture
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void StartProfilerCapture(struct FString Filename); // Offset: 0x10223fcd8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkGameplayStatics.StartOutputCapture
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void StartOutputCapture(struct FString Filename); // Offset: 0x10223fc48 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkGameplayStatics.StartAllAmbientSounds
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void StartAllAmbientSounds(struct UObject* WorldContextObject); // Offset: 0x10223fbd4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function AkAudio.AkGameplayStatics.SpawnAkComponentAtLocation
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasDefaults|BlueprintCallable]
	struct UAkComponent* SpawnAkComponentAtLocation(struct UObject* WorldContextObject, struct UAkAudioEvent* AkEvent, struct UAkAuxBus* EarlyReflectionsBus, struct FVector Location, struct FRotator Orientation, bool AutoPost, struct FString EventName, struct FString EarlyReflectionsBusName, bool AutoDestroy); // Offset: 0x10223f92c // Return & Params: Num(10) Size(0x68)

	// Object Name: Function AkAudio.AkGameplayStatics.ShowAKComponentPosition
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ShowAKComponentPosition(bool _IsShow); // Offset: 0x10223f8b0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AkAudio.AkGameplayStatics.ShouldPostEvent
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	bool ShouldPostEvent(struct UObject* WorldContext, struct FVector& VoicePosition); // Offset: 0x10223f7ec // Return & Params: Num(3) Size(0x15)

	// Object Name: Function AkAudio.AkGameplayStatics.SetSwitchWithDummyActor
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void SetSwitchWithDummyActor(struct FName SwitchGroup, struct FName SwitchState); // Offset: 0x10223f740 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function AkAudio.AkGameplayStatics.SetSwitch
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void SetSwitch(struct FName SwitchGroup, struct FName SwitchState, struct AActor* Actor); // Offset: 0x10223f658 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function AkAudio.AkGameplayStatics.SetState
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	int SetState(struct FName StateGroup, struct FName State); // Offset: 0x10223f5a4 // Return & Params: Num(3) Size(0x14)

	// Object Name: Function AkAudio.AkGameplayStatics.SetRTPCValue
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void SetRTPCValue(struct FName RTPC, float Value, int InterpolationTimeMs, struct AActor* Actor); // Offset: 0x10223f47c // Return & Params: Num(4) Size(0x18)

	// Object Name: Function AkAudio.AkGameplayStatics.SetPanningRule
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetPanningRule(enum class PanningRule PanRule); // Offset: 0x10223f408 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AkAudio.AkGameplayStatics.SetOutputBusVolume
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void SetOutputBusVolume(float BusVolume, struct AActor* Actor); // Offset: 0x10223f358 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function AkAudio.AkGameplayStatics.SetOcclusionScalingFactor
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetOcclusionScalingFactor(float ScalingFactor); // Offset: 0x10223f2dc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AkAudio.AkGameplayStatics.SetOcclusionRefreshInterval
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void SetOcclusionRefreshInterval(float RefreshInterval, struct AActor* Actor); // Offset: 0x10223f22c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function AkAudio.AkGameplayStatics.SetBusConfig
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetBusConfig(struct FString BusName, enum class AkChannelConfiguration ChannelConfiguration); // Offset: 0x10223f15c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function AkAudio.AkGameplayStatics.SeekOnEvent
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	int SeekOnEvent(struct UAkAudioEvent* in_pAkEvent, struct AActor* in_pActor, int in_iPosition, struct FString EventName, bool in_bSeekToNearestMarker); // Offset: 0x10223ef8c // Return & Params: Num(6) Size(0x30)

	// Object Name: Function AkAudio.AkGameplayStatics.RefreshModDirectories
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void RefreshModDirectories(); // Offset: 0x10223ef78 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkGameplayStatics.PostTrigger
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void PostTrigger(struct FName Trigger, struct AActor* Actor); // Offset: 0x10223eecc // Return & Params: Num(2) Size(0x10)

	// Object Name: Function AkAudio.AkGameplayStatics.PostEventWithDummyActor
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	int PostEventWithDummyActor(struct UAkAudioEvent* AkEvent, struct FString EventName, struct UObject* WorldContextObject); // Offset: 0x10223ed90 // Return & Params: Num(4) Size(0x24)

	// Object Name: Function AkAudio.AkGameplayStatics.PostEventByName
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void PostEventByName(struct FString EventName, struct AActor* Actor, bool bStopWhenAttachedToDestroyed); // Offset: 0x10223ec78 // Return & Params: Num(3) Size(0x19)

	// Object Name: Function AkAudio.AkGameplayStatics.PostEventAttached
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	int PostEventAttached(struct UAkAudioEvent* AkEvent, struct AActor* Actor, struct FName AttachPointName, bool bStopWhenAttachedToDestroyed, struct FString EventName); // Offset: 0x10223eaac // Return & Params: Num(6) Size(0x34)

	// Object Name: Function AkAudio.AkGameplayStatics.PostEventAtLocationByName
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasDefaults|BlueprintCallable]
	void PostEventAtLocationByName(struct FString EventName, struct FVector Location, struct FRotator Orientation, struct UObject* WorldContextObject); // Offset: 0x10223e95c // Return & Params: Num(4) Size(0x30)

	// Object Name: Function AkAudio.AkGameplayStatics.PostEventAtLocation
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasDefaults|BlueprintCallable]
	int PostEventAtLocation(struct UAkAudioEvent* AkEvent, struct FVector Location, struct FRotator Orientation, struct FString EventName, struct UObject* WorldContextObject); // Offset: 0x10223e7d0 // Return & Params: Num(6) Size(0x3c)

	// Object Name: Function AkAudio.AkGameplayStatics.PostEvent
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	int PostEvent(struct UAkAudioEvent* AkEvent, struct AActor* Actor, bool bStopWhenAttachedToDestroyed, struct FString EventName); // Offset: 0x10223e648 // Return & Params: Num(5) Size(0x2c)

	// Object Name: Function AkAudio.AkGameplayStatics.LoadInitBank
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void LoadInitBank(); // Offset: 0x10223e634 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkGameplayStatics.LoadBanks
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable]
	void LoadBanks(struct TArray<struct UAkAudioBank*>& SoundBanks, bool SynchronizeSoundBanks); // Offset: 0x10223e548 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function AkAudio.AkGameplayStatics.LoadBankByName
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void LoadBankByName(struct FString BankName); // Offset: 0x10223e4b8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkGameplayStatics.LoadBank
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void LoadBank(struct UAkAudioBank* Bank, struct FString BankName); // Offset: 0x10223e3ec // Return & Params: Num(2) Size(0x18)

	// Object Name: Function AkAudio.AkGameplayStatics.IsGame
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsGame(struct UObject* WorldContextObject); // Offset: 0x10223e370 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function AkAudio.AkGameplayStatics.IsEditor
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsEditor(); // Offset: 0x10223e33c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AkAudio.AkGameplayStatics.GetOcclusionScalingFactor
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	float GetOcclusionScalingFactor(); // Offset: 0x10223e318 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AkAudio.AkGameplayStatics.GetAkComponent
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	struct UAkComponent* GetAkComponent(struct USceneComponent* AttachToComponent, struct FName AttachPointName, struct FVector Location, enum class EAttachLocation LocationType); // Offset: 0x10223e1e8 // Return & Params: Num(5) Size(0x28)

	// Object Name: Function AkAudio.AkGameplayStatics.ClearBanks
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void ClearBanks(); // Offset: 0x10223e1d4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkGameplayStatics.AKSetRTPCValue
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void AKSetRTPCValue(struct FString RTPC, float Value, bool in_bBypassInternalValueInterpolation); // Offset: 0x10223e098 // Return & Params: Num(3) Size(0x15)

	// Object Name: Function AkAudio.AkGameplayStatics.AddOutputCaptureMarker
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void AddOutputCaptureMarker(struct FString MarkerText); // Offset: 0x10223e008 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class AkAudio.AkLateReverbComponent
// Size: 0x310 // Inherited bytes: 0x2d0
struct UAkLateReverbComponent : USceneComponent {
	// Fields
	char bEnable : 1; // Offset: 0x2c9 // Size: 0x01
	struct UAkAuxBus* AuxBus; // Offset: 0x2d0 // Size: 0x08
	struct FString AuxBusName; // Offset: 0x2d8 // Size: 0x10
	float SendLevel; // Offset: 0x2e8 // Size: 0x04
	float FadeRate; // Offset: 0x2ec // Size: 0x04
	float Priority; // Offset: 0x2f0 // Size: 0x04
	char pad_0x2F4_1 : 7; // Offset: 0x2f4 // Size: 0x01
	char pad_0x2F5[0x1b]; // Offset: 0x2f5 // Size: 0x1b
};

// Object Name: Class AkAudio.AkReverbVolume
// Size: 0x438 // Inherited bytes: 0x400
struct AAkReverbVolume : AVolume {
	// Fields
	char bEnabled : 1; // Offset: 0x400 // Size: 0x01
	char pad_0x400_1 : 7; // Offset: 0x400 // Size: 0x01
	char pad_0x401[0x7]; // Offset: 0x401 // Size: 0x07
	struct UAkAuxBus* AuxBus; // Offset: 0x408 // Size: 0x08
	struct FString AuxBusName; // Offset: 0x410 // Size: 0x10
	float SendLevel; // Offset: 0x420 // Size: 0x04
	float FadeRate; // Offset: 0x424 // Size: 0x04
	float Priority; // Offset: 0x428 // Size: 0x04
	char pad_0x42C[0x4]; // Offset: 0x42c // Size: 0x04
	struct UAkLateReverbComponent* LateReverbComponent; // Offset: 0x430 // Size: 0x08
};

// Object Name: Class AkAudio.AkRoomComponent
// Size: 0x2f0 // Inherited bytes: 0x2d0
struct UAkRoomComponent : USceneComponent {
	// Fields
	char bEnable : 1; // Offset: 0x2c9 // Size: 0x01
	char pad_0x2D0_1 : 7; // Offset: 0x2d0 // Size: 0x01
	char pad_0x2D1[0x7]; // Offset: 0x2d1 // Size: 0x07
	float Priority; // Offset: 0x2d8 // Size: 0x04
	char pad_0x2DC[0x14]; // Offset: 0x2dc // Size: 0x14

	// Functions

	// Object Name: Function AkAudio.AkRoomComponent.RemoveSpatialAudioRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RemoveSpatialAudioRoom(); // Offset: 0x1022414dc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkRoomComponent.AddSpatialAudioRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddSpatialAudioRoom(); // Offset: 0x1022414c8 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class AkAudio.AkSettings
// Size: 0xa0 // Inherited bytes: 0x28
struct UAkSettings : UObject {
	// Fields
	char MaxSimultaneousReverbVolumes; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
	struct FFilePath WwiseProjectPath; // Offset: 0x30 // Size: 0x10
	struct FDirectoryPath WwiseWindowsInstallationPath; // Offset: 0x40 // Size: 0x10
	struct FFilePath WwiseMacInstallationPath; // Offset: 0x50 // Size: 0x10
	bool SuppressWwiseProjectPathWarnings; // Offset: 0x60 // Size: 0x01
	bool UseAlternateObstructionOcclusionFeature; // Offset: 0x61 // Size: 0x01
	char pad_0x62[0x3e]; // Offset: 0x62 // Size: 0x3e
};

// Object Name: Class AkAudio.AkSpatialAudioVolume
// Size: 0x418 // Inherited bytes: 0x400
struct AAkSpatialAudioVolume : AVolume {
	// Fields
	struct UAkSurfaceReflectorSetComponent* SurfaceReflectorSet; // Offset: 0x400 // Size: 0x08
	struct UAkLateReverbComponent* LateReverb; // Offset: 0x408 // Size: 0x08
	struct UAkRoomComponent* Room; // Offset: 0x410 // Size: 0x08
};

// Object Name: Class AkAudio.AkSpotReflector
// Size: 0x3f8 // Inherited bytes: 0x3c8
struct AAkSpotReflector : AActor {
	// Fields
	struct UAkAuxBus* AuxBus; // Offset: 0x3c8 // Size: 0x08
	struct FString AuxBusName; // Offset: 0x3d0 // Size: 0x10
	struct UAkAcousticTexture* AcousticTexture; // Offset: 0x3e0 // Size: 0x08
	float DistanceScalingFactor; // Offset: 0x3e8 // Size: 0x04
	float Level; // Offset: 0x3ec // Size: 0x04
	char pad_0x3F0[0x8]; // Offset: 0x3f0 // Size: 0x08
};

// Object Name: Class AkAudio.AkSurfaceReflectorSetComponent
// Size: 0x2f0 // Inherited bytes: 0x2d0
struct UAkSurfaceReflectorSetComponent : USceneComponent {
	// Fields
	char bEnableSurfaceReflectors : 1; // Offset: 0x2c9 // Size: 0x01
	struct TArray<struct FAkPoly> AcousticPolys; // Offset: 0x2d0 // Size: 0x10
	char pad_0x2E0_1 : 7; // Offset: 0x2e0 // Size: 0x01
	char pad_0x2E1[0xf]; // Offset: 0x2e1 // Size: 0x0f

	// Functions

	// Object Name: Function AkAudio.AkSurfaceReflectorSetComponent.UpdateSurfaceReflectorSet
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UpdateSurfaceReflectorSet(); // Offset: 0x102241a8c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkSurfaceReflectorSetComponent.SendSurfaceReflectorSet
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SendSurfaceReflectorSet(); // Offset: 0x102241a78 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkSurfaceReflectorSetComponent.RemoveSurfaceReflectorSet
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RemoveSurfaceReflectorSet(); // Offset: 0x102241a64 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class AkAudio.AudioOfflineDataRecorder
// Size: 0x1340 // Inherited bytes: 0x2d0
struct UAudioOfflineDataRecorder : USceneComponent {
	// Fields
	struct FString BankName; // Offset: 0x2d0 // Size: 0x10
	struct FString EventName; // Offset: 0x2e0 // Size: 0x10
	enum class EFrequencyRange RangeType; // Offset: 0x2f0 // Size: 0x01
	char pad_0x2F1[0x3]; // Offset: 0x2f1 // Size: 0x03
	int BinNumber; // Offset: 0x2f4 // Size: 0x04
	struct TArray<float> BeatTimeArray; // Offset: 0x2f8 // Size: 0x10
	struct TArray<struct FAudioOfflineVisualBeatData> Result; // Offset: 0x308 // Size: 0x10
	char pad_0x318[0x1028]; // Offset: 0x318 // Size: 0x1028
};

// Object Name: Class AkAudio.AudioOfflineVisual
// Size: 0x48 // Inherited bytes: 0x28
struct UAudioOfflineVisual : UObject {
	// Fields
	struct TArray<struct FAudioOfflineVisualBeatData> OfflineData; // Offset: 0x28 // Size: 0x10
	char pad_0x38[0x10]; // Offset: 0x38 // Size: 0x10

	// Functions

	// Object Name: Function AkAudio.AudioOfflineVisual.StartBeatOffset
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StartBeatOffset(float Offset); // Offset: 0x1022421a8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AkAudio.AudioOfflineVisual.StartBeat
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StartBeat(); // Offset: 0x102242194 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AudioOfflineVisual.ResetBeatTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ResetBeatTime(); // Offset: 0x102242180 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AudioOfflineVisual.InitWithBeatTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void InitWithBeatTime(struct TArray<float> Datas); // Offset: 0x10224209c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AudioOfflineVisual.Init
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Init(struct TArray<struct FAudioOfflineVisualBeatData> Datas); // Offset: 0x102241fb8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AudioOfflineVisual.GetCurrentBeatByCustomTime
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool GetCurrentBeatByCustomTime(float InBeatSecondTime, struct FAudioOfflineVisualBeatData& Result); // Offset: 0x102241ebc // Return & Params: Num(3) Size(0x21)

	// Object Name: Function AkAudio.AudioOfflineVisual.GetCurrentBeat
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool GetCurrentBeat(struct FAudioOfflineVisualBeatData& Result); // Offset: 0x102241dfc // Return & Params: Num(2) Size(0x19)
};

// Object Name: Class AkAudio.AudioVisual
// Size: 0x1028 // Inherited bytes: 0x28
struct UAudioVisual : UObject {
	// Fields
	char pad_0x28[0x1000]; // Offset: 0x28 // Size: 0x1000

	// Functions

	// Object Name: Function AkAudio.AudioVisual.TryInit
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool TryInit(); // Offset: 0x102244b8c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AkAudio.AudioVisual.Reset
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Reset(); // Offset: 0x102244b78 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AudioVisual.IsInited
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsInited(); // Offset: 0x102244b44 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AkAudio.AudioVisual.GetRMS
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetRMS(); // Offset: 0x102244b10 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AkAudio.AudioVisual.GetInstantEnergy
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetInstantEnergy(); // Offset: 0x102244adc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AkAudio.AudioVisual.GetFrequencyVol
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetFrequencyVol(enum class EFrequencyRange freqRange); // Offset: 0x102244a50 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function AkAudio.AudioVisual.GetFrequencyDataWithBin
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	int GetFrequencyDataWithBin(struct TArray<float>& pFreqData, enum class EFrequencyRange freqRange, int nBin, bool bAbsolute); // Offset: 0x1022448d0 // Return & Params: Num(5) Size(0x20)

	// Object Name: Function AkAudio.AudioVisual.GetFrequencyData
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	int GetFrequencyData(struct TArray<float>& pFreqData, enum class EFrequencyRange freqRange); // Offset: 0x1022447d4 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function AkAudio.AudioVisual.GetAudioSamplesWithBin
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	int GetAudioSamplesWithBin(struct TArray<float>& pAudioData, int nBin, bool bAbsolute); // Offset: 0x102244694 // Return & Params: Num(4) Size(0x1c)

	// Object Name: Function AkAudio.AudioVisual.GetAudioSamples
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	int GetAudioSamples(struct TArray<float>& pAudioData); // Offset: 0x1022445dc // Return & Params: Num(2) Size(0x14)
};

// Object Name: Class AkAudio.AudioVisualBlueprintLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UAudioVisualBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function AkAudio.AudioVisualBlueprintLibrary.GetAudioVisual
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAudioVisual* GetAudioVisual(struct UObject* Outer); // Offset: 0x102244ffc // Return & Params: Num(2) Size(0x10)

	// Object Name: Function AkAudio.AudioVisualBlueprintLibrary.GetAudioOfflineVisual
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAudioOfflineVisual* GetAudioOfflineVisual(struct UObject* Outer); // Offset: 0x102244f80 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class AkAudio.InterpTrackAkAudioEvent
// Size: 0xa8 // Inherited bytes: 0x90
struct UInterpTrackAkAudioEvent : UInterpTrackVectorBase {
	// Fields
	struct TArray<struct FAkAudioEventTrackKey> Events; // Offset: 0x90 // Size: 0x10
	char bContinueEventOnMatineeEnd : 1; // Offset: 0xa0 // Size: 0x01
	char pad_0xA0_1 : 7; // Offset: 0xa0 // Size: 0x01
	char pad_0xA1[0x7]; // Offset: 0xa1 // Size: 0x07
};

// Object Name: Class AkAudio.InterpTrackAkAudioRTPC
// Size: 0xa8 // Inherited bytes: 0x90
struct UInterpTrackAkAudioRTPC : UInterpTrackFloatBase {
	// Fields
	struct FString Param; // Offset: 0x90 // Size: 0x10
	char bPlayOnReverse : 1; // Offset: 0xa0 // Size: 0x01
	char bContinueRTPCOnMatineeEnd : 1; // Offset: 0xa0 // Size: 0x01
	char pad_0xA0_2 : 6; // Offset: 0xa0 // Size: 0x01
	char pad_0xA1[0x7]; // Offset: 0xa1 // Size: 0x07
};

// Object Name: Class AkAudio.InterpTrackInstAkAudioEvent
// Size: 0x30 // Inherited bytes: 0x28
struct UInterpTrackInstAkAudioEvent : UInterpTrackInst {
	// Fields
	float LastUpdatePosition; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
};

// Object Name: Class AkAudio.InterpTrackInstAkAudioRTPC
// Size: 0x30 // Inherited bytes: 0x28
struct UInterpTrackInstAkAudioRTPC : UInterpTrackInst {
	// Fields
	float LastUpdatePosition; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
};

// Object Name: Class AkAudio.MovieSceneAkAudioEventSection
// Size: 0xd0 // Inherited bytes: 0xb0
struct UMovieSceneAkAudioEventSection : UMovieSceneSection {
	// Fields
	struct UAkAudioEvent* Event; // Offset: 0xb0 // Size: 0x08
	bool StopAtSectionEnd; // Offset: 0xb8 // Size: 0x01
	char pad_0xB9[0x7]; // Offset: 0xb9 // Size: 0x07
	struct FString EventName; // Offset: 0xc0 // Size: 0x10
};

// Object Name: Class AkAudio.MovieSceneAkTrack
// Size: 0x70 // Inherited bytes: 0x58
struct UMovieSceneAkTrack : UMovieSceneTrack {
	// Fields
	struct TArray<struct UMovieSceneSection*> Sections; // Offset: 0x58 // Size: 0x10
	char bIsAMasterTrack : 1; // Offset: 0x68 // Size: 0x01
	char pad_0x68_1 : 7; // Offset: 0x68 // Size: 0x01
	char pad_0x69[0x7]; // Offset: 0x69 // Size: 0x07
};

// Object Name: Class AkAudio.MovieSceneAkAudioEventTrack
// Size: 0x70 // Inherited bytes: 0x70
struct UMovieSceneAkAudioEventTrack : UMovieSceneAkTrack {
};

// Object Name: Class AkAudio.MovieSceneAkAudioRTPCSection
// Size: 0x138 // Inherited bytes: 0xb0
struct UMovieSceneAkAudioRTPCSection : UMovieSceneSection {
	// Fields
	char pad_0xB0[0x8]; // Offset: 0xb0 // Size: 0x08
	struct FString Name; // Offset: 0xb8 // Size: 0x10
	struct FRichCurve FloatCurve; // Offset: 0xc8 // Size: 0x70
};

// Object Name: Class AkAudio.MovieSceneAkAudioRTPCTrack
// Size: 0x70 // Inherited bytes: 0x70
struct UMovieSceneAkAudioRTPCTrack : UMovieSceneAkTrack {
};

