#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class ApexDestruction.DestructibleActor
// Size: 0x3e8 // Inherited bytes: 0x3c8
struct ADestructibleActor : AActor {
	// Fields
	struct UDestructibleComponent* DestructibleComponent; // Offset: 0x3c8 // Size: 0x08
	char bAffectNavigation : 1; // Offset: 0x3d0 // Size: 0x01
	char pad_0x3D0_1 : 7; // Offset: 0x3d0 // Size: 0x01
	char pad_0x3D1[0x7]; // Offset: 0x3d1 // Size: 0x07
	struct FScriptMulticastDelegate OnActorFracture; // Offset: 0x3d8 // Size: 0x10
};

// Object Name: Class ApexDestruction.DestructibleComponent
// Size: 0x980 // Inherited bytes: 0x8a0
struct UDestructibleComponent : USkinnedMeshComponent {
	// Fields
	char pad_0x8A0[0x8]; // Offset: 0x8a0 // Size: 0x08
	char bFractureEffectOverride : 1; // Offset: 0x8a8 // Size: 0x01
	char pad_0x8A8_1 : 7; // Offset: 0x8a8 // Size: 0x01
	char pad_0x8A9[0x7]; // Offset: 0x8a9 // Size: 0x07
	struct TArray<struct FFractureEffect> FractureEffects; // Offset: 0x8b0 // Size: 0x10
	bool bEnableHardSleeping; // Offset: 0x8c0 // Size: 0x01
	char pad_0x8C1[0x3]; // Offset: 0x8c1 // Size: 0x03
	float LargeChunkThreshold; // Offset: 0x8c4 // Size: 0x04
	char pad_0x8C8[0x10]; // Offset: 0x8c8 // Size: 0x10
	struct FScriptMulticastDelegate OnComponentFracture; // Offset: 0x8d8 // Size: 0x10
	char pad_0x8E8[0x98]; // Offset: 0x8e8 // Size: 0x98

	// Functions

	// Object Name: Function ApexDestruction.DestructibleComponent.SetDestructibleMesh
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDestructibleMesh(struct UDestructibleMesh* NewMesh); // Offset: 0x10227b828 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function ApexDestruction.DestructibleComponent.GetDestructibleMesh
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UDestructibleMesh* GetDestructibleMesh(); // Offset: 0x10227b7f4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function ApexDestruction.DestructibleComponent.ApplyRadiusDamage
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void ApplyRadiusDamage(float BaseDamage, struct FVector& HurtOrigin, float DamageRadius, float ImpulseStrength, bool bFullDamage); // Offset: 0x10227b668 // Return & Params: Num(5) Size(0x19)

	// Object Name: Function ApexDestruction.DestructibleComponent.ApplyDamage
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void ApplyDamage(float DamageAmount, struct FVector& HitLocation, struct FVector& ImpulseDir, float ImpulseStrength); // Offset: 0x10227b510 // Return & Params: Num(4) Size(0x20)
};

// Object Name: Class ApexDestruction.DestructibleFractureSettings
// Size: 0x90 // Inherited bytes: 0x28
struct UDestructibleFractureSettings : UObject {
	// Fields
	int CellSiteCount; // Offset: 0x28 // Size: 0x04
	struct FFractureMaterial FractureMaterialDesc; // Offset: 0x2c // Size: 0x24
	int RandomSeed; // Offset: 0x50 // Size: 0x04
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
	struct TArray<struct FVector> VoronoiSites; // Offset: 0x58 // Size: 0x10
	int OriginalSubmeshCount; // Offset: 0x68 // Size: 0x04
	char pad_0x6C[0x4]; // Offset: 0x6c // Size: 0x04
	struct TArray<struct UMaterialInterface*> Materials; // Offset: 0x70 // Size: 0x10
	struct TArray<struct FDestructibleChunkParameters> ChunkParameters; // Offset: 0x80 // Size: 0x10
};

// Object Name: Class ApexDestruction.DestructibleMesh
// Size: 0x3f0 // Inherited bytes: 0x358
struct UDestructibleMesh : USkeletalMesh {
	// Fields
	struct FDestructibleParameters DefaultDestructibleParameters; // Offset: 0x358 // Size: 0x88
	struct TArray<struct FFractureEffect> FractureEffects; // Offset: 0x3e0 // Size: 0x10
};

