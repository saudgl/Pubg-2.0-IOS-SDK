#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass AvatarCustomParticle_BP.AvatarCustomParticle_BP_C
// Size: 0x90 // Inherited bytes: 0x90
struct UAvatarCustomParticle_BP_C : UAvatarCustomParticle {
};

