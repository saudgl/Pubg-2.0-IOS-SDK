#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass AvatarItemDownloadPuffer_BP.AvatarItemDownloadPuffer_BP_C
// Size: 0x30 // Inherited bytes: 0x30
struct UAvatarItemDownloadPuffer_BP_C : UAvatarItemDownloadPuffer {
};

