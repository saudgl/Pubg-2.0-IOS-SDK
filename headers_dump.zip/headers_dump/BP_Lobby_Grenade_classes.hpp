#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_Lobby_Grenade.BP_Lobby_Grenade_C
// Size: 0x3e0 // Inherited bytes: 0x3c8
struct ABP_Lobby_Grenade_C : AActor {
	// Fields
	struct UGrenadeAvatarComponent_BP_C* GrenadeAvatarComponent_BP; // Offset: 0x3c8 // Size: 0x08
	struct UStaticMeshComponent* StaticMesh; // Offset: 0x3d0 // Size: 0x08
	bool IsAvatarReady; // Offset: 0x3d8 // Size: 0x01
	char pad_0x3D9[0x3]; // Offset: 0x3d9 // Size: 0x03
	int grenadeResId; // Offset: 0x3dc // Size: 0x04

	// Functions

	// Object Name: Function BP_Lobby_Grenade.BP_Lobby_Grenade_C.SetAvatarReady
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetAvatarReady(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Lobby_Grenade.BP_Lobby_Grenade_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)
};

