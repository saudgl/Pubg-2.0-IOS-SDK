#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_MiniTVSpline.BP_MiniTVSpline_C
// Size: 0x3d1 // Inherited bytes: 0x3c8
struct ABP_MiniTVSpline_C : AActor {
	// Fields
	struct USplineComponent* Spline; // Offset: 0x3c8 // Size: 0x08
	bool MoveActor; // Offset: 0x3d0 // Size: 0x01

	// Functions

	// Object Name: Function BP_MiniTVSpline.BP_MiniTVSpline_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)
};

