#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_OBEffectBullet.BP_OBEffectBullet_C
// Size: 0x438 // Inherited bytes: 0x428
struct ABP_OBEffectBullet_C : AOBEffectBullet {
	// Fields
	struct UParticleSystemComponent* P_signal_bullet_01; // Offset: 0x428 // Size: 0x08
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x430 // Size: 0x08

	// Functions

	// Object Name: Function BP_OBEffectBullet.BP_OBEffectBullet_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)
};

