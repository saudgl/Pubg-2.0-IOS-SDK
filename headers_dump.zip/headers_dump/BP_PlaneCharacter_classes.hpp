#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_PlaneCharacter.BP_PlaneCharacter_C
// Size: 0xa64 // Inherited bytes: 0x9b0
struct ABP_PlaneCharacter_C : APlaneCharacter {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x9b0 // Size: 0x08
	struct UWingPlaneComponent_BP_C* WingPlaneComponent_BP; // Offset: 0x9b8 // Size: 0x08
	struct UPlaneAvatarComponent_BP_C* PlaneAvatarComponent_BP; // Offset: 0x9c0 // Size: 0x08
	struct USceneComponent* Scene; // Offset: 0x9c8 // Size: 0x08
	struct UCameraComponent* PlaneCamera; // Offset: 0x9d0 // Size: 0x08
	struct USpringArmComponent* PlaneSpringArm; // Offset: 0x9d8 // Size: 0x08
	struct UStaticMeshComponent* StaticMesh; // Offset: 0x9e0 // Size: 0x08
	struct UParticleSystemComponent* ParticleSystem7; // Offset: 0x9e8 // Size: 0x08
	struct UParticleSystemComponent* ParticleSystem6; // Offset: 0x9f0 // Size: 0x08
	struct UParticleSystemComponent* ParticleSystem5; // Offset: 0x9f8 // Size: 0x08
	struct UParticleSystemComponent* ParticleSystem4; // Offset: 0xa00 // Size: 0x08
	struct UParticleSystemComponent* ParticleSystem3; // Offset: 0xa08 // Size: 0x08
	struct UParticleSystemComponent* P_Plan_tail_01; // Offset: 0xa10 // Size: 0x08
	struct UParticleSystemComponent* P_Plan_light_green_01; // Offset: 0xa18 // Size: 0x08
	struct UParticleSystemComponent* P_Plan_light_red_02; // Offset: 0xa20 // Size: 0x08
	struct UParticleSystemComponent* P_Plan_light_red_01; // Offset: 0xa28 // Size: 0x08
	struct UParticleSystemComponent* P_Plan_light_blue_01; // Offset: 0xa30 // Size: 0x08
	struct UParticleSystemComponent* ParticleSystem2; // Offset: 0xa38 // Size: 0x08
	struct UParticleSystemComponent* ParticleSystem1; // Offset: 0xa40 // Size: 0x08
	struct UParticleSystemComponent* ParticleSystem; // Offset: 0xa48 // Size: 0x08
	struct UParticleSystemComponent* P_Plan_Propeller_01; // Offset: 0xa50 // Size: 0x08
	struct UAkComponent* Ak; // Offset: 0xa58 // Size: 0x08
	int planeResId; // Offset: 0xa60 // Size: 0x04

	// Functions

	// Object Name: Function BP_PlaneCharacter.BP_PlaneCharacter_C.AsyncChangePlaneAvatar
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void AsyncChangePlaneAvatar(int InItemID); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_PlaneCharacter.BP_PlaneCharacter_C.ChangePlaneAvatar
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ChangePlaneAvatar(int InItemID); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_PlaneCharacter.BP_PlaneCharacter_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_PlaneCharacter.BP_PlaneCharacter_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveBeginPlay(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_PlaneCharacter.BP_PlaneCharacter_C.ExecuteUbergraph_BP_PlaneCharacter
	// Flags: [None]
	void ExecuteUbergraph_BP_PlaneCharacter(int EntryPoint); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x4)
};

