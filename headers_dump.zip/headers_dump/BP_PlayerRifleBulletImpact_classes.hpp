#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_PlayerRifleBulletImpact.BP_PlayerRifleBulletImpact_C
// Size: 0xb48 // Inherited bytes: 0xb30
struct ABP_PlayerRifleBulletImpact_C : ASTEShootWeaponBulletImpactEffect {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0xb30 // Size: 0x08
	struct TArray<struct UTexture2D*> CrossHairRefTexture; // Offset: 0xb38 // Size: 0x10

	// Functions

	// Object Name: Function BP_PlayerRifleBulletImpact.BP_PlayerRifleBulletImpact_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)
};

