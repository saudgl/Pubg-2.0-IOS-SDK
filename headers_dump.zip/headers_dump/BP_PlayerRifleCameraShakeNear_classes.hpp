#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_PlayerRifleCameraShakeNear.BP_PlayerRifleCameraShakeNear_C
// Size: 0x160 // Inherited bytes: 0x160
struct UBP_PlayerRifleCameraShakeNear_C : UCameraShake {
};

