#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_Rifle_M416_10001.BP_Rifle_M416_10000_C
// Size: 0xb18 // Inherited bytes: 0xb10
struct ABP_Rifle_M416_10000_C : ABP_LobbyWeapon_C {
	// Fields
	struct ULobbyWeaponAnimList_Rifle_C* LobbyWeaponAnimList_Rifle; // Offset: 0xb10 // Size: 0x08

	// Functions

	// Object Name: Function BP_Rifle_M416_10001.BP_Rifle_M416_10000_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)
};

