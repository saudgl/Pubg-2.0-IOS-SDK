#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_Rifle_M416_Wrapper.BP_Rifle_M416_Wrapper_C
// Size: 0x818 // Inherited bytes: 0x800
struct ABP_Rifle_M416_Wrapper_C : APickUpWrapperActor {
	// Fields
	struct UStaticMeshComponent* Mag; // Offset: 0x800 // Size: 0x08
	struct UStaticMeshComponent* ST_WEP_M416_Lod; // Offset: 0x808 // Size: 0x08
	struct UStaticMeshComponent* SM_M416; // Offset: 0x810 // Size: 0x08

	// Functions

	// Object Name: Function BP_Rifle_M416_Wrapper.BP_Rifle_M416_Wrapper_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)
};

