#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_Rifle_M416.BP_Rifle_M416_C
// Size: 0x1254 // Inherited bytes: 0x122d
struct ABP_Rifle_M416_C : ABP_ShootWeaponBase_C {
	// Fields
	char pad_0x122D[0x3]; // Offset: 0x122d // Size: 0x03
	struct UWeaponAnimList_Rifle_M416_C* WeaponAnimList_Rifle_M416; // Offset: 0x1230 // Size: 0x08
	bool bUseIdleAnim_1; // Offset: 0x1238 // Size: 0x01
	char pad_0x1239[0x3]; // Offset: 0x1239 // Size: 0x03
	struct FRotator OffsetRotation; // Offset: 0x123c // Size: 0x0c
	struct FVector OffsetLocation; // Offset: 0x1248 // Size: 0x0c

	// Functions

	// Object Name: Function BP_Rifle_M416.BP_Rifle_M416_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)
};

