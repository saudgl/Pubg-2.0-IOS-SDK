#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_AchievementCfg_type.BP_STRUCT_AchievementCfg_type
// Size: 0x140 // Inherited bytes: 0x00
struct FBP_STRUCT_AchievementCfg_type {
	// Fields
	int GroupID_0_4F922A4044C2DC6979A00278059C47F4; // Offset: 0x00 // Size: 0x04
	int ID_1_7351E7006854F6DA5A56C5E300A83264; // Offset: 0x04 // Size: 0x04
	int Score_2_031022C01413878178E803610332AC05; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct FString Conditions_3_7947CA4006B92CDF326163050338D4B3; // Offset: 0x10 // Size: 0x10
	int PreID_4_036B90C03CD25507215EAE0A033C8354; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
	struct FString Name_6_648064002AD77CC64EDFFC050833F895; // Offset: 0x28 // Size: 0x10
	int ShareFlag_7_0188BF0072A7DCF82A7E2432020B0097; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
	struct FString Desc_8_2AA0638048DCB1804EDA334B08321C33; // Offset: 0x40 // Size: 0x10
	struct FString ImgUrl_9_23FCB7C0657CBE9F0E739322025364BC; // Offset: 0x50 // Size: 0x10
	struct FString BigImgUrl_10_35D63C4057FBCD336D04AF7B0180EF7C; // Offset: 0x60 // Size: 0x10
	int ShowType_11_2B7F348001E5E2DC6F13FEDF0FC49345; // Offset: 0x70 // Size: 0x04
	int AwardNum_12_2C130B8036D732E27947FE4B0D20C78D; // Offset: 0x74 // Size: 0x04
	int AwardID_13_34E0A2C07EF201FD123719F003D20BF4; // Offset: 0x78 // Size: 0x04
	int MultiLvGroupID_14_4AFB3D8046E4BA8E3A0AF81A02243484; // Offset: 0x7c // Size: 0x04
	int AwardNum2_15_7C7758002CAD6D841E16376F020C79D2; // Offset: 0x80 // Size: 0x04
	int AwardID2_16_696D4F40693FEE0579461D5E0D20BF42; // Offset: 0x84 // Size: 0x04
	struct FString MultiLvGroupTitle_17_530A7AC0068E99D523CA185503602965; // Offset: 0x88 // Size: 0x10
	int MultiLvGroupNum_18_090C464078CE785775EB2BD10243509D; // Offset: 0x98 // Size: 0x04
	bool JPKREnable_20_6646E3403A54C9FF30EA4A060E963E85; // Offset: 0x9c // Size: 0x01
	bool GlobalEnable_21_16CA69C03694BEC51276707E02D78975; // Offset: 0x9d // Size: 0x01
	char pad_0x9E[0x2]; // Offset: 0x9e // Size: 0x02
	struct FString Version_22_3FF35D403CA2850151A0EFEE07C31D6E; // Offset: 0xa0 // Size: 0x10
	struct FString Material_23_00A62F8053E43A522E177BC60804BCFC; // Offset: 0xb0 // Size: 0x10
	struct FString Model_24_54FC000058126054216CA3260339503C; // Offset: 0xc0 // Size: 0x10
	struct FString Texture_25_1BF120003C34427E418AE1AE01C53FB5; // Offset: 0xd0 // Size: 0x10
	int AchType_26_22A8CF40410AEDA15F1880130C974345; // Offset: 0xe0 // Size: 0x04
	char pad_0xE4[0x4]; // Offset: 0xe4 // Size: 0x04
	struct FString OutPrintTime_29_1DCA58C060D6909161CFFCE90D859185; // Offset: 0xe8 // Size: 0x10
	struct FString JumpUrl_30_080B978006594FD81A19FB130ACEDFBC; // Offset: 0xf8 // Size: 0x10
	struct FString EndUrlTime_32_70AD5A0059F3BEF4434F742304C3BC05; // Offset: 0x108 // Size: 0x10
	struct FString StartUrlTime_33_141837C07450722D0642A49B0FAB8F95; // Offset: 0x118 // Size: 0x10
	bool BLUEHOLEEnable_34_22746980289BA7E876B9748608967BC5; // Offset: 0x128 // Size: 0x01
	char pad_0x129[0x7]; // Offset: 0x129 // Size: 0x07
	struct FString ClientShowTime_35_6E0BA7800F1D5C482C85DDAD0D38C595; // Offset: 0x130 // Size: 0x10
};

