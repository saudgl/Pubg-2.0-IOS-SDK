#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_AchievementScoreCfg_type.BP_STRUCT_AchievementScoreCfg_type
// Size: 0x18 // Inherited bytes: 0x00
struct FBP_STRUCT_AchievementScoreCfg_type {
	// Fields
	int ID_0_1D04860037C2F19801F8719800D4A974; // Offset: 0x00 // Size: 0x04
	int Score_1_2BE441C049060135224681660A83ABC5; // Offset: 0x04 // Size: 0x04
	struct FString Awards_2_40981B40486492E721888F9F092D5C13; // Offset: 0x08 // Size: 0x10
};

