#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_BPIDReuseMap_type.BP_STRUCT_BPIDReuseMap_type
// Size: 0x08 // Inherited bytes: 0x00
struct FBP_STRUCT_BPIDReuseMap_type {
	// Fields
	int BPID_0_5A377D80314217626ED8281902773264; // Offset: 0x00 // Size: 0x04
	int ReuseID_1_0BD67A00095DAF70463F3A450CA7BEB4; // Offset: 0x04 // Size: 0x04
};

