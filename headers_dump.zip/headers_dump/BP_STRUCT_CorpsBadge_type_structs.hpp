#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_CorpsBadge_type.BP_STRUCT_CorpsBadge_type
// Size: 0x40 // Inherited bytes: 0x00
struct FBP_STRUCT_CorpsBadge_type {
	// Fields
	struct FString BigIconPath_0_10CC26002C2272C4426923F90B6405C8; // Offset: 0x00 // Size: 0x10
	int ID_1_5727FF4053D9C66568AE85A909693024; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FString IconPath_2_038F818050E2694643DA924F014A58A8; // Offset: 0x18 // Size: 0x10
	struct FString Name_3_56563C4042608BF33377F2DB0931BF55; // Offset: 0x28 // Size: 0x10
	int TabPosi_4_17AFE880638188BE77062DBF05E20589; // Offset: 0x38 // Size: 0x04
	int UnLockLv_5_04857F8051FE2B7A53B16D630C5CAF66; // Offset: 0x3c // Size: 0x04
};

