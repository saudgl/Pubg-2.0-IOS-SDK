#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_CorpsConfig_type.BP_STRUCT_CorpsConfig_type
// Size: 0x20 // Inherited bytes: 0x00
struct FBP_STRUCT_CorpsConfig_type {
	// Fields
	struct FString ConfigValue_0_306151800211D5305EAE9A9700E1D6A5; // Offset: 0x00 // Size: 0x10
	struct FString ConfigName_1_72343280216367E6602CC642010A9D65; // Offset: 0x10 // Size: 0x10
};

