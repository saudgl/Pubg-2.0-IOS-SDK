#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_DrinkCompoundConfig_type.BP_STRUCT_DrinkCompoundConfig_type
// Size: 0x68 // Inherited bytes: 0x00
struct FBP_STRUCT_DrinkCompoundConfig_type {
	// Fields
	int awardID_0_2BBEB1403F5A9B0B0EB1D00709609964; // Offset: 0x00 // Size: 0x04
	int awardNum_1_37D1DA0026A0923C7757AA8B0609AE2D; // Offset: 0x04 // Size: 0x04
	int descID_2_1FD235403A90703F024A7AEA0BB716C4; // Offset: 0x08 // Size: 0x04
	int ID_3_2F902D8037E77FA46237D6880B8119C4; // Offset: 0x0c // Size: 0x04
	int isMayCarry_4_2AB2AB40581603397B72EE3809C59429; // Offset: 0x10 // Size: 0x04
	int JpKrAwardID_5_49A847000D2541FE5295535A097982A4; // Offset: 0x14 // Size: 0x04
	int JpKrAwardNum_6_2ECC8FC045A856D735DAF8570798322D; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct FString Name_7_3AE82A806F13962C42B917EB011A5DB5; // Offset: 0x20 // Size: 0x10
	struct FString solt_8_7F0FFAC007CB390F4285A58D011A9FB4; // Offset: 0x30 // Size: 0x10
	int EmoteID_9_4C84EC007C583218352536360B9EB844; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
	struct FString PhizExplain_10_2575C54064E510CF536AC4300D724F0E; // Offset: 0x48 // Size: 0x10
	struct FString EmoteVoiceName_11_60ECC6803A15389C4AA097EC0673F2D5; // Offset: 0x58 // Size: 0x10
};

