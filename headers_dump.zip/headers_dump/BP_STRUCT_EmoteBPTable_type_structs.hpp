#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_EmoteBPTable_type.BP_STRUCT_EmoteBPTable_type
// Size: 0x58 // Inherited bytes: 0x00
struct FBP_STRUCT_EmoteBPTable_type {
	// Fields
	struct FString Path_0_247605C000C1809320361CC70BC26958; // Offset: 0x00 // Size: 0x10
	struct FString CName_1_20BFF38058E1993E3181765E0C385985; // Offset: 0x10 // Size: 0x10
	int ID_2_6D1FE5C03D4B9B6365DA363A01FBC3D4; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
	struct FString LobbyPath_3_17CBE3C0186812E1377BBB6D07222BE8; // Offset: 0x28 // Size: 0x10
	struct FString LobbyEmoteAdapt_4_6274998039C4B44E5D4A1AFE0DB5A954; // Offset: 0x38 // Size: 0x10
	struct FString BattleLowPath_5_4F3B89400282AC756B607A450BF84618; // Offset: 0x48 // Size: 0x10
};

