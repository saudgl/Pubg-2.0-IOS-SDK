#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_GlobalHelpTips_Pos.BP_STRUCT_GlobalHelpTips_Pos
// Size: 0x08 // Inherited bytes: 0x00
struct FBP_STRUCT_GlobalHelpTips_Pos {
	// Fields
	int y_0_4DBA1E404EED75A173CEF46903C67CB9; // Offset: 0x00 // Size: 0x04
	int x_1_4DB91E004EED75A073CEF46803C67CB8; // Offset: 0x04 // Size: 0x04
};

