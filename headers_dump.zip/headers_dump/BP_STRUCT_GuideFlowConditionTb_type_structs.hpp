#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_GuideFlowConditionTb_type.BP_STRUCT_GuideFlowConditionTb_type
// Size: 0x48 // Inherited bytes: 0x00
struct FBP_STRUCT_GuideFlowConditionTb_type {
	// Fields
	struct FString condition_0_35DED0000732F4FE3912570F034E7F5E; // Offset: 0x00 // Size: 0x10
	int ID_1_63220180623D0050435280110A79EEB4; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FString param1_2_0C9CEEC011DC6A33276069EB0D02FFE1; // Offset: 0x18 // Size: 0x10
	struct FString param2_3_0C9DEF0011DC6A34276069E80D02FFE2; // Offset: 0x28 // Size: 0x10
	struct FString param3_4_0C9EEF4011DC6A35276069E90D02FFE3; // Offset: 0x38 // Size: 0x10
};

