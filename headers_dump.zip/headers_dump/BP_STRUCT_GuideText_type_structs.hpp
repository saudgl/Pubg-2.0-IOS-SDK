#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_GuideText_type.BP_STRUCT_GuideText_type
// Size: 0x5c // Inherited bytes: 0x00
struct FBP_STRUCT_GuideText_type {
	// Fields
	int GuideID_0_A5FF72E542F02CBBCE5E2696B9B5AE1E; // Offset: 0x00 // Size: 0x04
	int TriggerTimes_1_092A596A4CD84CDBCEAB7CAC1E5C6784; // Offset: 0x04 // Size: 0x04
	struct FString text4_2_0681BED6478BF4BE2672C1B126FF6E1E; // Offset: 0x08 // Size: 0x10
	struct FString text1_3_0B618F7F449909BFB58A3E98E3DB73DE; // Offset: 0x18 // Size: 0x10
	struct FString text2_4_F5471C1F44A2ADB1B71AD3A2991F2C29; // Offset: 0x28 // Size: 0x10
	struct FString text3_5_5E534A744DCD782353B99F94D72CF42E; // Offset: 0x38 // Size: 0x10
	int IsFloat_7_5631F6C015B003AF4D2C60B3037F0B64; // Offset: 0x48 // Size: 0x04
	int ShapeType_8_6317EF000ACBA582315244FA09B48A85; // Offset: 0x4c // Size: 0x04
	int XOffset_10_1D6AFA00689E1E0E6D67A078005D0714; // Offset: 0x50 // Size: 0x04
	int YOffset_11_5C733A401ADE00450611FA950F5D0704; // Offset: 0x54 // Size: 0x04
	int OutOffset_12_336A92002DF8BFBC469DDB2F0A823C04; // Offset: 0x58 // Size: 0x04
};

