#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_GuidonConfig_type.BP_STRUCT_GuidonConfig_type
// Size: 0x50 // Inherited bytes: 0x00
struct FBP_STRUCT_GuidonConfig_type {
	// Fields
	struct FString GuidonName_0_12040E4023B2EFCB0015324407013B95; // Offset: 0x00 // Size: 0x10
	struct FString res_path_1_72570A001B373E7865688B400AE9C9B8; // Offset: 0x10 // Size: 0x10
	struct FString GuidonCode_2_2297CCC0696BD0B30003ADC60700F805; // Offset: 0x20 // Size: 0x10
	struct FString sort_key_3_6754908048CFD4FA607F307D00C800D9; // Offset: 0x30 // Size: 0x10
	struct FString res_path_small_4_259E2800594CF13823821BA90881FF9C; // Offset: 0x40 // Size: 0x10
};

