#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_InFillingBPTable_type.BP_STRUCT_InFillingBPTable_type
// Size: 0x38 // Inherited bytes: 0x00
struct FBP_STRUCT_InFillingBPTable_type {
	// Fields
	struct FString CName_0_0FEB140031B746EE57576036054ADAB5; // Offset: 0x00 // Size: 0x10
	int ID_1_2AA3C640595906337FE75E5E09E85434; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FString Path_2_484966400B8C53E31A22A3DB08558148; // Offset: 0x18 // Size: 0x10
	struct FString Wrapper_3_467E5B40009CAA6B663AE8D80016F392; // Offset: 0x28 // Size: 0x10
};

