#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_ItemUpgradeUnLockConfig_type.BP_STRUCT_ItemUpgradeUnLockConfig_type
// Size: 0x14 // Inherited bytes: 0x00
struct FBP_STRUCT_ItemUpgradeUnLockConfig_type {
	// Fields
	int CostId_0_40B075400720914F338B21630836A664; // Offset: 0x00 // Size: 0x04
	int CostNum_1_078596002C3FF6502DCDCA64036A7C3D; // Offset: 0x04 // Size: 0x04
	int GroupID_2_28884A400FB528EF5FAA0AD805962D54; // Offset: 0x08 // Size: 0x04
	int ID_3_019807003046E3FC627D6444000E9864; // Offset: 0x0c // Size: 0x04
	int PartId_4_6975B4C027089FA77ADB2D5709D89664; // Offset: 0x10 // Size: 0x04
};

