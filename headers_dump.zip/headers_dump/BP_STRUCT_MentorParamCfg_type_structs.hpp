#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_MentorParamCfg_type.BP_STRUCT_MentorParamCfg_type
// Size: 0x14 // Inherited bytes: 0x00
struct FBP_STRUCT_MentorParamCfg_type {
	// Fields
	struct FString ParamName_0_16CA3F807FC6F8D61FBB79B10149F525; // Offset: 0x00 // Size: 0x10
	int ParamValue_1_50C0DE806406DA001958089E04B752A5; // Offset: 0x10 // Size: 0x04
};

