#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_ModeShowConfig_type.BP_STRUCT_ModeShowConfig_type
// Size: 0xf8 // Inherited bytes: 0x00
struct FBP_STRUCT_ModeShowConfig_type {
	// Fields
	int TabID_0_3FF86D805791D4244C52BCEA0B72D544; // Offset: 0x00 // Size: 0x04
	int Sort_1_10D18E8074FE5F84377358C409B72CA4; // Offset: 0x04 // Size: 0x04
	int ID_2_5C8AC7C05B03156D3E9B03390A39B654; // Offset: 0x08 // Size: 0x04
	int FPPViewID_3_383AC80012BAA1141A580FAE0654A824; // Offset: 0x0c // Size: 0x04
	int TPPViewID_4_427ACB801CBFDA6257CE70D40654BA24; // Offset: 0x10 // Size: 0x04
	int HideAutoMatch_5_5A90448075F187407D8A3A0C0D7A8938; // Offset: 0x14 // Size: 0x04
	struct FString MapUseDesc_6_5A62D700158F02826CAA5697052E1EF3; // Offset: 0x18 // Size: 0x10
	struct FString ModeIconPath_8_519F0B4019764D0D33647FED0FACF8E8; // Offset: 0x28 // Size: 0x10
	struct FString Desc_9_204084407DE8A2A5377331E809B626A3; // Offset: 0x38 // Size: 0x10
	struct FString MapImageInLobby_10_7AD5908032547556282EF0DF096B5E29; // Offset: 0x48 // Size: 0x10
	struct FString MapImage_11_615664C0042405ED2098120A02778065; // Offset: 0x58 // Size: 0x10
	struct FString Name_12_5A2084C05FE36DEB3775BE5E09B7CE05; // Offset: 0x68 // Size: 0x10
	struct FString MapBg_13_454056401F79CDC34BD58E1A0B7B2717; // Offset: 0x78 // Size: 0x10
	struct FString BgEffect_14_3A0B020009C6754C31DB909301857DA4; // Offset: 0x88 // Size: 0x10
	int ShowDescInLobby_15_79F9784014A34F5323E0FBAD0B14E0B9; // Offset: 0x98 // Size: 0x04
	char pad_0x9C[0x4]; // Offset: 0x9c // Size: 0x04
	struct FString RecruitArrowPath_19_472A0200465BD9DE3BA42C1F097BE1A8; // Offset: 0xa0 // Size: 0x10
	struct FString RecruitBarBgPath_20_2E1EEEC0633C8443397FAC59069BE1B8; // Offset: 0xb0 // Size: 0x10
	struct FString RecruitIconPath_21_364681803C3E984A4C6CC5AC01621048; // Offset: 0xc0 // Size: 0x10
	int IsShowMap_22_1FE283403ACCB73D1DB6A57C0A8DDBA0; // Offset: 0xd0 // Size: 0x04
	char pad_0xD4[0x4]; // Offset: 0xd4 // Size: 0x04
	struct FString ModeIcon_23_037E68001A580C62429819070F904F9E; // Offset: 0xd8 // Size: 0x10
	int IsNew_24_3032BE0011ADC07A4C9AC7510B78E757; // Offset: 0xe8 // Size: 0x04
	int EventViewBelong_25_6EADA18069C4519270241107024A9FE7; // Offset: 0xec // Size: 0x04
	int IsBeta_26_0B2EB2805B7D7F9E0A0E7134078DB511; // Offset: 0xf0 // Size: 0x04
	int IsClassic_27_32DD0400171AC0AC5D94BB820BB3D123; // Offset: 0xf4 // Size: 0x04
};

