#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_RankIntegralLevel_type.BP_STRUCT_RankIntegralLevel_type
// Size: 0xe1 // Inherited bytes: 0x00
struct FBP_STRUCT_RankIntegralLevel_type {
	// Fields
	int IntegralType_0_5DB652C74A6C2C5E4B1123A62ADC38A8; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString IntegralTypeName_1_37066B404ACB346A9C01D683DD3A29FB; // Offset: 0x08 // Size: 0x10
	struct FString FrameID_2_FA51FC0F47FB8AEB41067AB1A00E044D; // Offset: 0x18 // Size: 0x10
	int MinIntegral_3_8BCC404B4E31165611A2F3A5DCA7F9EB; // Offset: 0x28 // Size: 0x04
	int Level_4_4248BF2F4F85F33AF1FFF8B269550E92; // Offset: 0x2c // Size: 0x04
	int IntegralTypeOrder_5_E1D966464BA0136A4682EA8533722D30; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
	struct FString Name_6_B98FA8AA4955E5E532285FA0BC38606D; // Offset: 0x38 // Size: 0x10
	int NextIntegralScore_7_194CC840003BFCBD1B7B7E14029BE565; // Offset: 0x48 // Size: 0x04
	int StarNum_8_045B8680677A2C3C3C50D91C069A9F6D; // Offset: 0x4c // Size: 0x04
	struct FString BigIcon_9_55E7FAC04C1A035F0AEAB48904C9149E; // Offset: 0x50 // Size: 0x10
	struct FString SmallIcon_10_3B6D3480778CAC664F339B4106DA305E; // Offset: 0x60 // Size: 0x10
	struct FString SubIcon_11_5BB640C031E57E65018BD3BD0684148E; // Offset: 0x70 // Size: 0x10
	int NextSeasonIntegralScore_12_010B22802CC106BA61EB81370B236155; // Offset: 0x80 // Size: 0x04
	char pad_0x84[0x4]; // Offset: 0x84 // Size: 0x04
	struct FString BigMesh_13_2B197BC07A689F070AE3691404CAD658; // Offset: 0x88 // Size: 0x10
	struct FString SubMaterial_14_0B216A40672064491BC4738C027A0AAC; // Offset: 0x98 // Size: 0x10
	struct FString SubMesh_15_30E7C1C060341A0D018996830685D648; // Offset: 0xa8 // Size: 0x10
	int IntegralTypeNew_18_76AFF480454B93902AC82C870452E0B7; // Offset: 0xb8 // Size: 0x04
	char pad_0xBC[0x4]; // Offset: 0xbc // Size: 0x04
	struct FString JoinTeamLimitType_19_2FA6420071F62D9A08E21DFC04624C55; // Offset: 0xc0 // Size: 0x10
	struct FString SmallIcon128_20_03BF1B4074ADDC5B1E97EFE8030679F8; // Offset: 0xd0 // Size: 0x10
	bool IsRankInvalid_21_628357C030E06F636C88358004E6ECD4; // Offset: 0xe0 // Size: 0x01
};

