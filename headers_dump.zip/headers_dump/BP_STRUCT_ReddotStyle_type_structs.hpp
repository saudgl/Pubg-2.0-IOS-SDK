#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_ReddotStyle_type.BP_STRUCT_ReddotStyle_type
// Size: 0x28 // Inherited bytes: 0x00
struct FBP_STRUCT_ReddotStyle_type {
	// Fields
	int ID_0_74F6A58049A834103E3B1D30013AE7E4; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString Name_1_26D6A28054D141E055A57F1B0AE87705; // Offset: 0x08 // Size: 0x10
	struct FString Path_2_62750580417D3A10561B39950AE65998; // Offset: 0x18 // Size: 0x10
};

