#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_SeasonVersion_type.BP_STRUCT_SeasonVersion_type
// Size: 0x48 // Inherited bytes: 0x00
struct FBP_STRUCT_SeasonVersion_type {
	// Fields
	int SeasonID_1_37EED6C0265C64EB753705C10E9C1764; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString MinVersion_2_631EDBC03A79884B4EECE45E0E9C857E; // Offset: 0x08 // Size: 0x10
	struct FString MaxVersion_3_44581C4049916A796DCF1E470E9C839E; // Offset: 0x18 // Size: 0x10
	struct FString SeasonStartBPpath_4_238D26C06BD735631644A269091629F8; // Offset: 0x28 // Size: 0x10
	struct FString SeasonSwitchBPpath_5_2323DFC07EF3F6B756B2708A0A63FE28; // Offset: 0x38 // Size: 0x10
};

