#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_TxMissionSegment_type.BP_STRUCT_TxMissionSegment_type
// Size: 0x84 // Inherited bytes: 0x00
struct FBP_STRUCT_TxMissionSegment_type {
	// Fields
	struct FString BigIcon_0_4608AC8012716CDC3747299A01C579EE; // Offset: 0x00 // Size: 0x10
	int Level_1_6191E3C0068E3A8D5DDB036301CBF23C; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FString Name_2_6A18860057AD3D18360D6868081CD5D5; // Offset: 0x18 // Size: 0x10
	int NeedExp_3_446570000C1247F02C069ECD0D850D30; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct FString SmallIcon_4_6A84264068762909100EA7940AB1595E; // Offset: 0x30 // Size: 0x10
	int Sort_5_20C98FC00C92E291363E7A61081A1574; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
	struct FString SubIcon_6_4BD6F2806BBFBAAA5C82C8B9038879FE; // Offset: 0x48 // Size: 0x10
	int TypeID_7_00F6B18008D173F03A790EF00A3381C4; // Offset: 0x58 // Size: 0x04
	char pad_0x5C[0x4]; // Offset: 0x5c // Size: 0x04
	struct FString TypeName_8_474AAE8070EFBBA06EA8FFA303825E05; // Offset: 0x60 // Size: 0x10
	int K_13_4085F8802E2653CE4DD7973E093E81BB; // Offset: 0x70 // Size: 0x04
	float adjust_factor1_f_14_3515BD804D2856C2108217C40E27E1D6; // Offset: 0x74 // Size: 0x04
	float adjust_factor2_f_15_0F2E7DC06EF247C910820AAF0E27E2D6; // Offset: 0x78 // Size: 0x04
	float B_high_f_16_6C4E874021C851155CACB7620607C7A6; // Offset: 0x7c // Size: 0x04
	float B_low_f_17_6FC833C01AABEB6541BA2BFA0F7DEEE6; // Offset: 0x80 // Size: 0x04
};

