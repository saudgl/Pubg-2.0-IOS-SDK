#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_UnknowPassBuyCfg_type.BP_STRUCT_UnknowPassBuyCfg_type
// Size: 0x40 // Inherited bytes: 0x00
struct FBP_STRUCT_UnknowPassBuyCfg_type {
	// Fields
	struct FString Desc2_0_67184800080A6DB06A7EAC820F5D4182; // Offset: 0x00 // Size: 0x10
	struct FString Desc1_1_671747C0080A6DAF6A7EAC810F5D4181; // Offset: 0x10 // Size: 0x10
	int ID_2_67757F0013C6DC1C495D34BC088EF5A4; // Offset: 0x20 // Size: 0x04
	int BuyItemId_3_40A836C02092165B4D6E49EC06E5FFB4; // Offset: 0x24 // Size: 0x04
	int buyType_4_7787F84001767BCD222963590E466F15; // Offset: 0x28 // Size: 0x04
	int ShowItem2_5_5880B4407E043CB101B132840E6FE672; // Offset: 0x2c // Size: 0x04
	int ShowItem1_6_587FB4007E043CB001B132850E6FE671; // Offset: 0x30 // Size: 0x04
	int BuyItem2Id_7_552003403C2CB6630C4AA70F0E5FE294; // Offset: 0x34 // Size: 0x04
	int PassType_8_506C2A007989DA460C18BC5E00265475; // Offset: 0x38 // Size: 0x04
	int IsExtra_9_29876BC02D0F514F4413ED8007F414E1; // Offset: 0x3c // Size: 0x04
};

