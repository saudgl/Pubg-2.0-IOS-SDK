#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_UnknowpassContinuousCfg_type.BP_STRUCT_UnknowpassContinuousCfg_type
// Size: 0x20 // Inherited bytes: 0x00
struct FBP_STRUCT_UnknowpassContinuousCfg_type {
	// Fields
	int id_0_45D218C03D9C559117FC108208C9C174; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString Image_1_552EBE400147560F154B05E20C38BB45; // Offset: 0x08 // Size: 0x10
	int lowerValue_2_6A866F00570FA3E0632CD8A905BEDDA5; // Offset: 0x18 // Size: 0x04
	int upperValue_3_63F46FC040CD6A290AD400CF05BC4C15; // Offset: 0x1c // Size: 0x04
};

