#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_VehiclePlaneSkinMapping_type.BP_STRUCT_VehiclePlaneSkinMapping_type
// Size: 0x18 // Inherited bytes: 0x00
struct FBP_STRUCT_VehiclePlaneSkinMapping_type {
	// Fields
	int OrginalID_0_035F8000705EAFE8164A73BF05CF7C94; // Offset: 0x00 // Size: 0x04
	int SkinID_1_2D869240386FF4E567A70940014D8664; // Offset: 0x04 // Size: 0x04
	struct FString iconURL_2_025050C0368B0D852A82EE78056E714C; // Offset: 0x08 // Size: 0x10
};

