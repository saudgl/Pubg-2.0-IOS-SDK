#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_VehicleRefitBPConfig_type.BP_STRUCT_VehicleRefitBPConfig_type
// Size: 0x18 // Inherited bytes: 0x00
struct FBP_STRUCT_VehicleRefitBPConfig_type {
	// Fields
	int ID_0_5B2431405FE6DA5350C148B308CCED84; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString path_1_6C12D940780BE1834EB793700CEE3068; // Offset: 0x08 // Size: 0x10
};

