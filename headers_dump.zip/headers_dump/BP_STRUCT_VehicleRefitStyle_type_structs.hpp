#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_VehicleRefitStyle_type.BP_STRUCT_VehicleRefitStyle_type
// Size: 0x9c // Inherited bytes: 0x00
struct FBP_STRUCT_VehicleRefitStyle_type {
	// Fields
	int cost_id1_21_40D3BDC00FA1EC252A325218091B0AE1; // Offset: 0x00 // Size: 0x04
	int cost_id2_2_40D4BE000FA1EC262A325219091B0AE2; // Offset: 0x04 // Size: 0x04
	int auto_unlock_3_70A1E14054C1515F34AD00AA03FE271B; // Offset: 0x08 // Size: 0x04
	int part_id_19_2960F1004F796BBC287325E80772B0B4; // Offset: 0x0c // Size: 0x04
	int part_group_id_20_580314001313FC7E5037A1C0001EF544; // Offset: 0x10 // Size: 0x04
	int style_id_6_3334EF8009D542BA023C1EFF04520144; // Offset: 0x14 // Size: 0x04
	int vehicle_group_id_7_2FA91E401396E1572443357005BAE444; // Offset: 0x18 // Size: 0x04
	int cost_num2_8_567B5EC042ECFAD5581D19B001B10392; // Offset: 0x1c // Size: 0x04
	int cost_num1_9_567A5E8042ECFAD4581D19B101B10391; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
	struct FString style_icon_10_2B88068062961F24124419A202014E0E; // Offset: 0x28 // Size: 0x10
	struct FString part_name_11_242D66002BB47CD41AA53D3702B10145; // Offset: 0x38 // Size: 0x10
	struct FString part_group_icon_12_75E1AB0010031F6A4A4800D10EF54A4E; // Offset: 0x48 // Size: 0x10
	struct FString style_name_13_7772E4800830FFC6124AFDB20202F465; // Offset: 0x58 // Size: 0x10
	int value1_14_12B54BC05132BBB9260C3FBC04D988D1; // Offset: 0x68 // Size: 0x04
	int value2_15_12B64C005132BBBA260C3FBF04D988D2; // Offset: 0x6c // Size: 0x04
	int real_part_16_420F46C07AAD2FE77C0DB8570D3321D4; // Offset: 0x70 // Size: 0x04
	int type2_17_243BF54066D327F75079C483054BFDB2; // Offset: 0x74 // Size: 0x04
	int type1_18_243AF50066D327F65079C482054BFDB1; // Offset: 0x78 // Size: 0x04
	int can_fit_22_68F7CD4000E30BD17923736E08996A54; // Offset: 0x7c // Size: 0x04
	struct FString part_group_tab_icon_23_089B9080591DEC3273FD6659077B104E; // Offset: 0x80 // Size: 0x10
	int real_part2_24_0189F34001B6E9815CB7C17003321DA2; // Offset: 0x90 // Size: 0x04
	int type21_25_7B46618009DF2DB0732EC53204BFDB01; // Offset: 0x94 // Size: 0x04
	int value21_26_048158402E894EF74D0737BF0D988D11; // Offset: 0x98 // Size: 0x04
};

