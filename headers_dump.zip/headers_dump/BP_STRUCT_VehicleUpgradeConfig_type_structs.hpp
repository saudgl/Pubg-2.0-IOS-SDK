#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_VehicleUpgradeConfig_type.BP_STRUCT_VehicleUpgradeConfig_type
// Size: 0x10 // Inherited bytes: 0x00
struct FBP_STRUCT_VehicleUpgradeConfig_type {
	// Fields
	int ActivityID_0_7B4833802DF94704131CF9510407A624; // Offset: 0x00 // Size: 0x04
	int ID_1_58EAC0400E2FAFC9355E1768014337B4; // Offset: 0x04 // Size: 0x04
	int ItemID_2_090F640079C1942C1AE8EC55086C02E4; // Offset: 0x08 // Size: 0x04
	int Series_3_2FEC57C01A6C921F29FD92CA06FDCCF3; // Offset: 0x0c // Size: 0x04
};

