#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BattleItemHandle_BP_Head_02_int.BattleItemHandle_BP_Head_02_int_C
// Size: 0xb38 // Inherited bytes: 0xb38
struct UBattleItemHandle_BP_Head_02_int_C : UBattleItemHandle_HeadBP_C {
};

