#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BattleItemHandle_BP_Wingman_int.BattleItemHandle_BP_Wingman_int_C
// Size: 0x180 // Inherited bytes: 0x180
struct UBattleItemHandle_BP_Wingman_int_C : UWingmanAvatarHandleBase_BP_C {
};

