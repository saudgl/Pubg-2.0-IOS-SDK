#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BattleItemHandle_GlideBP.BattleItemHandle_GlideBP_C
// Size: 0xb38 // Inherited bytes: 0xb22
struct UBattleItemHandle_GlideBP_C : UBattleItemHandle_AvatarBP_C {
	// Fields
	char pad_0xB22[0x6]; // Offset: 0xb22 // Size: 0x06
	struct UAnimMontage* startAimn; // Offset: 0xb28 // Size: 0x08
	struct UAnimSequenceBase* IdleAnim; // Offset: 0xb30 // Size: 0x08

	// Functions

	// Object Name: Function BattleItemHandle_GlideBP.BattleItemHandle_GlideBP_C.NewFunction_1
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void NewFunction_1(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)
};

