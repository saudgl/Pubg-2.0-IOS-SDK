#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BattleItemHandle_Jacket_633_int.BattleItemHandle_Jacket_633_int_C
// Size: 0xb22 // Inherited bytes: 0xb22
struct UBattleItemHandle_Jacket_633_int_C : UBattleItemHandle_AvatarBP_C {
};

