#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class BuildSystem.BuildingActorBase
// Size: 0x600 // Inherited bytes: 0x490
struct ABuildingActorBase : ALuaActor {
	// Fields
	char pad_0x490[0x1c]; // Offset: 0x490 // Size: 0x1c
	bool bCustomBlockingChannels; // Offset: 0x4ac // Size: 0x01
	char pad_0x4AD[0x3]; // Offset: 0x4ad // Size: 0x03
	struct TArray<enum class ECollisionChannel> CustomBlockingChannels; // Offset: 0x4b0 // Size: 0x10
	bool bCheckVisibilitySkipTypes; // Offset: 0x4c0 // Size: 0x01
	char pad_0x4C1[0x7]; // Offset: 0x4c1 // Size: 0x07
	struct TArray<struct UObject*> VisibilitySkipTypes; // Offset: 0x4c8 // Size: 0x10
	struct FBuildingActorWorldSnapSetup WorldSnapSetup; // Offset: 0x4d8 // Size: 0x24
	float DebugHealthDistance; // Offset: 0x4fc // Size: 0x04
	struct FVector DebugHealthOffset; // Offset: 0x500 // Size: 0x0c
	char pad_0x50C[0x4]; // Offset: 0x50c // Size: 0x04
	struct TArray<struct UObject*> ProhibitedActorTemplateList; // Offset: 0x510 // Size: 0x10
	struct TArray<struct UObject*> EnableBuildingList; // Offset: 0x520 // Size: 0x10
	struct FSoftObjectPath PreBuildingEffectPath; // Offset: 0x530 // Size: 0x18
	bool CanBuildUnderWater; // Offset: 0x548 // Size: 0x01
	bool bShouldSnapToWorldGrid; // Offset: 0x549 // Size: 0x01
	char pad_0x54A[0x2]; // Offset: 0x54a // Size: 0x02
	float UnderWaterMaxBuildDepth; // Offset: 0x54c // Size: 0x04
	struct FTransform DestroyedParticleTransformOffset; // Offset: 0x550 // Size: 0x30
	struct FSoftObjectPath DestroyBuildingEffectPath; // Offset: 0x580 // Size: 0x18
	bool bUseExtraCenterOffset; // Offset: 0x598 // Size: 0x01
	bool bUseExtraCenterRotation; // Offset: 0x599 // Size: 0x01
	char pad_0x59A[0x2]; // Offset: 0x59a // Size: 0x02
	struct FVector ActorCollisionBoxExtern; // Offset: 0x59c // Size: 0x0c
	struct FVector ActorCollisionBoxCenter; // Offset: 0x5a8 // Size: 0x0c
	struct FRotator ActorCollisionBoxRotator; // Offset: 0x5b4 // Size: 0x0c
	float Health; // Offset: 0x5c0 // Size: 0x04
	float MaxDeviation; // Offset: 0x5c4 // Size: 0x04
	float MaxTraceDepth; // Offset: 0x5c8 // Size: 0x04
	bool bDoQuadTrace; // Offset: 0x5cc // Size: 0x01
	enum class EBuildingActorConstructingMode ConstructingMode; // Offset: 0x5cd // Size: 0x01
	bool bEnableOverlayPlace; // Offset: 0x5ce // Size: 0x01
	bool bAutoPickValidPlace; // Offset: 0x5cf // Size: 0x01
	float OverlayPlaceHeight; // Offset: 0x5d0 // Size: 0x04
	float DetectDeath; // Offset: 0x5d4 // Size: 0x04
	char pad_0x5D8[0x4]; // Offset: 0x5d8 // Size: 0x04
	int MaxCountLimit; // Offset: 0x5dc // Size: 0x04
	bool bDoDensityCheck; // Offset: 0x5e0 // Size: 0x01
	char pad_0x5E1[0x7]; // Offset: 0x5e1 // Size: 0x07
	struct FString LuaModPath; // Offset: 0x5e8 // Size: 0x10
	char pad_0x5F8[0x8]; // Offset: 0x5f8 // Size: 0x08

	// Functions

	// Object Name: Function BuildSystem.BuildingActorBase.SpawnDestroyParticle
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults]
	void SpawnDestroyParticle(bool bSpawnParticle, struct FTransform& Loc, struct FSoftObjectPath& DestroyBuildingEffectPath, struct UWorld* World); // Offset: 0x102429e84 // Return & Params: Num(4) Size(0x60)

	// Object Name: Function BuildSystem.BuildingActorBase.PlayDestroyAnimation
	// Flags: [Native|Protected|BlueprintCallable]
	void PlayDestroyAnimation(bool bUseParticle); // Offset: 0x102429df8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BuildSystem.BuildingActorBase.OnTakeDamageFromVehicle
	// Flags: [Event|Protected|BlueprintEvent]
	void OnTakeDamageFromVehicle(struct AActor* DamagedActor, float ForwardSpeed, struct AActor* DamageCauser); // Offset: 0x103e7af64 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function BuildSystem.BuildingActorBase.OnPlayDestroyAnimation
	// Flags: [Event|Protected|BlueprintEvent]
	void OnPlayDestroyAnimation(bool bUseParticle); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BuildSystem.BuildingActorBase.OnBuildingActorDamaged
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public]
	void OnBuildingActorDamaged(float Health); // Offset: 0x102429d74 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BuildSystem.BuildingActorBase.OnBornAnimationPlayEndInClient
	// Flags: [Event|Protected|BlueprintEvent]
	void OnBornAnimationPlayEndInClient(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BuildSystem.BuildingActorBase.GetBuildID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	int GetBuildID(); // Offset: 0x102429d58 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BuildSystem.BuildingActorBase.BPOnOwnerChanged
	// Flags: [Event|Protected|BlueprintEvent]
	void BPOnOwnerChanged(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class BuildSystem.BuildingActorInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UBuildingActorInterface : UInterface {
	// Functions

	// Object Name: Function BuildSystem.BuildingActorInterface.ShouldUseExtraRotation
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	bool ShouldUseExtraRotation(); // Offset: 0x10242b1ec // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BuildSystem.BuildingActorInterface.ShouldUseExtraOffset
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	bool ShouldUseExtraOffset(); // Offset: 0x10242b1b0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BuildSystem.BuildingActorInterface.ShouldSnapToGrid
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	bool ShouldSnapToGrid(); // Offset: 0x10242b174 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BuildSystem.BuildingActorInterface.ShouldCustomBlockingChannels
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	bool ShouldCustomBlockingChannels(); // Offset: 0x10242b138 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BuildSystem.BuildingActorInterface.ShouldCheckVisibilityTypes
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	bool ShouldCheckVisibilityTypes(); // Offset: 0x10242b0fc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BuildSystem.BuildingActorInterface.SetBuildingActorID
	// Flags: [Native|Event|Public|BlueprintEvent]
	void SetBuildingActorID(int BuildID); // Offset: 0x10242b078 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BuildSystem.BuildingActorInterface.PrebuildCDOBodyInstance
	// Flags: [Native|Event|Public|HasOutParms|HasDefaults|BlueprintEvent]
	void PrebuildCDOBodyInstance(struct UWorld* World, struct FTransform& tranx); // Offset: 0x10242af90 // Return & Params: Num(2) Size(0x40)

	// Object Name: Function BuildSystem.BuildingActorInterface.NonCullingBeginPlay
	// Flags: [Native|Event|Public|BlueprintEvent]
	void NonCullingBeginPlay(); // Offset: 0x10242af74 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BuildSystem.BuildingActorInterface.MaxUnderWaterBuildDepth
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	float MaxUnderWaterBuildDepth(); // Offset: 0x10242af38 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BuildSystem.BuildingActorInterface.IsEnableOverlayPlace
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	bool IsEnableOverlayPlace(); // Offset: 0x10242aefc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BuildSystem.BuildingActorInterface.IsAutoPickValidPlace
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	bool IsAutoPickValidPlace(); // Offset: 0x10242aec0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BuildSystem.BuildingActorInterface.HandleBuildingDestroyed
	// Flags: [Native|Event|Public|BlueprintEvent]
	void HandleBuildingDestroyed(struct AController* InstigatedBy); // Offset: 0x10242ae3c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BuildSystem.BuildingActorInterface.HandleBuildingConstructed
	// Flags: [Native|Event|Public|BlueprintEvent]
	void HandleBuildingConstructed(struct AController* InstigatedBy); // Offset: 0x10242adb8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BuildSystem.BuildingActorInterface.GetWorldSnapSetup
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	struct FBuildingActorWorldSnapSetup GetWorldSnapSetup(); // Offset: 0x10242ad60 // Return & Params: Num(1) Size(0x24)

	// Object Name: Function BuildSystem.BuildingActorInterface.GetVisibilitySkipTypes
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	struct TArray<struct UObject*> GetVisibilitySkipTypes(); // Offset: 0x10242acf4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function BuildSystem.BuildingActorInterface.GetProhibitedActorTemplateList
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	struct TArray<struct UObject*> GetProhibitedActorTemplateList(); // Offset: 0x10242ac88 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function BuildSystem.BuildingActorInterface.GetPreBuildingEffectPath
	// Flags: [Native|Event|Public|HasDefaults|BlueprintEvent|Const]
	struct FSoftObjectPath GetPreBuildingEffectPath(); // Offset: 0x10242ac18 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function BuildSystem.BuildingActorInterface.GetOverlayPlaceHeight
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	float GetOverlayPlaceHeight(); // Offset: 0x10242abdc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BuildSystem.BuildingActorInterface.GetMaxTraceDepth
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	float GetMaxTraceDepth(); // Offset: 0x10242aba0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BuildSystem.BuildingActorInterface.GetMaxDeviation
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	float GetMaxDeviation(); // Offset: 0x10242ab64 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BuildSystem.BuildingActorInterface.GetDetectDeath
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	float GetDetectDeath(); // Offset: 0x10242ab28 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BuildSystem.BuildingActorInterface.GetDestroyedParticleTransformOffset
	// Flags: [Native|Event|Public|HasDefaults|BlueprintEvent|Const]
	struct FTransform GetDestroyedParticleTransformOffset(); // Offset: 0x10242aad0 // Return & Params: Num(1) Size(0x30)

	// Object Name: Function BuildSystem.BuildingActorInterface.GetDensityParams
	// Flags: [Native|Event|Public|HasOutParms|HasDefaults|BlueprintEvent|Const]
	struct FBuildingActorDensityCheck GetDensityParams(struct FVector& Location); // Offset: 0x10242aa04 // Return & Params: Num(2) Size(0x30)

	// Object Name: Function BuildSystem.BuildingActorInterface.GetCustomBlockingChannels
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	struct TArray<enum class ECollisionChannel> GetCustomBlockingChannels(); // Offset: 0x10242a998 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function BuildSystem.BuildingActorInterface.GetConstructingMode
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	enum class EBuildingActorConstructingMode GetConstructingMode(); // Offset: 0x10242a95c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BuildSystem.BuildingActorInterface.GetBuildingActorID
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	int GetBuildingActorID(); // Offset: 0x10242a920 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BuildSystem.BuildingActorInterface.GetActorCollisionBoxRotator
	// Flags: [Native|Event|Public|HasDefaults|BlueprintEvent|Const]
	struct FRotator GetActorCollisionBoxRotator(); // Offset: 0x10242a8e0 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function BuildSystem.BuildingActorInterface.GetActorCollisionBoxExtern
	// Flags: [Native|Event|Public|HasDefaults|BlueprintEvent|Const]
	struct FVector GetActorCollisionBoxExtern(); // Offset: 0x10242a8a0 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function BuildSystem.BuildingActorInterface.GetActorCollisionBoxCenter
	// Flags: [Native|Event|Public|HasDefaults|BlueprintEvent|Const]
	struct FVector GetActorCollisionBoxCenter(); // Offset: 0x10242a860 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function BuildSystem.BuildingActorInterface.CanDoQuadTrace
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	bool CanDoQuadTrace(); // Offset: 0x10242a824 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BuildSystem.BuildingActorInterface.CanBuildUnderWater
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	bool CanBuildUnderWater(); // Offset: 0x10242a7e8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BuildSystem.BuildingActorInterface.BPCheckPlacement
	// Flags: [Native|Event|Public|HasOutParms|HasDefaults|BlueprintEvent|Const]
	bool BPCheckPlacement(struct UWorld* World, struct FTransform& tranx); // Offset: 0x10242a6f0 // Return & Params: Num(3) Size(0x41)
};

// Object Name: Class BuildSystem.BuildingActorMgr
// Size: 0x3d8 // Inherited bytes: 0x3c8
struct ABuildingActorMgr : AActor {
	// Fields
	struct TArray<struct FBuildingActorInfo> BuildingActorList; // Offset: 0x3c8 // Size: 0x10

	// Functions

	// Object Name: Function BuildSystem.BuildingActorMgr.OnBuildingActorSpawned
	// Flags: [Final|Native|Public]
	void OnBuildingActorSpawned(struct AActor* InOwnerActor, struct ABuildingActorBase* InBuildingActor); // Offset: 0x10242d07c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function BuildSystem.BuildingActorMgr.OnBuildingActorDestroyed
	// Flags: [Final|Native|Public]
	void OnBuildingActorDestroyed(struct ABuildingActorBase* InBuildingActor); // Offset: 0x10242d000 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BuildSystem.BuildingActorMgr.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct ABuildingActorMgr* GetInstance(struct UObject* WorldContextObject); // Offset: 0x10242cf84 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class BuildSystem.BuildingGridComponent
// Size: 0x750 // Inherited bytes: 0x730
struct UBuildingGridComponent : UBoxComponent {
	// Fields
	struct FName CollisionProfileName; // Offset: 0x730 // Size: 0x08
	struct FVector BuildCenterOffset; // Offset: 0x738 // Size: 0x0c
	char pad_0x744[0xc]; // Offset: 0x744 // Size: 0x0c
};

// Object Name: Class BuildSystem.BuildSystemComponent
// Size: 0x400 // Inherited bytes: 0x1d8
struct UBuildSystemComponent : ULuaActorComponent {
	// Fields
	bool UseFixedDistanceBuild; // Offset: 0x1d1 // Size: 0x01
	struct FScriptMulticastDelegate OnConstructionComplete; // Offset: 0x1d8 // Size: 0x10
	struct FScriptMulticastDelegate OnDoubleClickMode2Event; // Offset: 0x1e8 // Size: 0x10
	struct FScriptMulticastDelegate OnDoubleClickMode2PercentEvent; // Offset: 0x1f8 // Size: 0x10
	float MaxmumConstructingDistance; // Offset: 0x208 // Size: 0x04
	char pad_0x20D[0x3]; // Offset: 0x20d // Size: 0x03
	struct ASelectBuildActor* BuildingSelectorClass; // Offset: 0x210 // Size: 0x08
	struct ASelectBuildActor* SelectBuildMeshClass; // Offset: 0x218 // Size: 0x08
	float UpdateBuildEnableTimer; // Offset: 0x220 // Size: 0x04
	float MinBuildDist; // Offset: 0x224 // Size: 0x04
	float GridGroundThreshold; // Offset: 0x228 // Size: 0x04
	bool AIIsOpenAdsorb; // Offset: 0x22c // Size: 0x01
	bool AIIsOpenLeftAndRightTry; // Offset: 0x22d // Size: 0x01
	char pad_0x22E[0x2]; // Offset: 0x22e // Size: 0x02
	float GridGroundCheckDepth; // Offset: 0x230 // Size: 0x04
	struct FWorldGridData WorldGridData; // Offset: 0x234 // Size: 0x0c
	bool bCanPlaceOnConstructableActor; // Offset: 0x240 // Size: 0x01
	char pad_0x241[0x3]; // Offset: 0x241 // Size: 0x03
	int bIsFastPlacementMode; // Offset: 0x244 // Size: 0x04
	int Mode2PressTouchBuildIndex; // Offset: 0x248 // Size: 0x04
	bool bIsStartPreBuildMode2; // Offset: 0x24c // Size: 0x01
	char pad_0x24D[0x3]; // Offset: 0x24d // Size: 0x03
	struct FVector2D Mode2PreBuildPos; // Offset: 0x250 // Size: 0x08
	float CurrentDoubleClickDuration; // Offset: 0x258 // Size: 0x04
	float ValidDoubleClickDuration; // Offset: 0x25c // Size: 0x04
	float ValidDoubleClickInterval; // Offset: 0x260 // Size: 0x04
	float ValidDoubleClickDistance; // Offset: 0x264 // Size: 0x04
	bool bSouldSkipOwningPlayer; // Offset: 0x268 // Size: 0x01
	bool bNativeTouchActorBuildEnabled; // Offset: 0x269 // Size: 0x01
	bool bNativeDoubleCkickBuildEnabled; // Offset: 0x26a // Size: 0x01
	char pad_0x26B[0x5]; // Offset: 0x26b // Size: 0x05
	struct TMap<int, struct UClass*> ActorSelectorMap; // Offset: 0x270 // Size: 0x50
	struct TArray<struct UObject*> SkippingObjects; // Offset: 0x2c0 // Size: 0x10
	bool bDebugDraw; // Offset: 0x2d0 // Size: 0x01
	bool bPickLocationDebugDraw; // Offset: 0x2d1 // Size: 0x01
	char pad_0x2D2[0x6]; // Offset: 0x2d2 // Size: 0x06
	struct TArray<struct UObject*> FilterTemplates; // Offset: 0x2d8 // Size: 0x10
	struct TArray<struct UObject*> ActorsShouldSkipVisiblityCheck; // Offset: 0x2e8 // Size: 0x10
	enum class ECollisionChannel BuildingGridChannel; // Offset: 0x2f8 // Size: 0x01
	char pad_0x2F9[0x3]; // Offset: 0x2f9 // Size: 0x03
	float MaxCanAdsorbAngle; // Offset: 0x2fc // Size: 0x04
	float SnappingDistance; // Offset: 0x300 // Size: 0x04
	float SnappingDetectRadius; // Offset: 0x304 // Size: 0x04
	float AIMaxCanRotateAngle; // Offset: 0x308 // Size: 0x04
	char pad_0x30C[0x4]; // Offset: 0x30c // Size: 0x04
	struct TArray<struct FName> BlackBuildTags; // Offset: 0x310 // Size: 0x10
	float BlackTracelineTopDist; // Offset: 0x320 // Size: 0x04
	float BlackTracelineDownDist; // Offset: 0x324 // Size: 0x04
	bool bBPOverrideLineTraceSwitch; // Offset: 0x328 // Size: 0x01
	bool bCheckPlaceActorPosSwitch; // Offset: 0x329 // Size: 0x01
	char pad_0x32A[0x6]; // Offset: 0x32a // Size: 0x06
	struct ASelectBuildActor* SelectBuildActor; // Offset: 0x330 // Size: 0x08
	char pad_0x338[0x20]; // Offset: 0x338 // Size: 0x20
	int CachedCDOIndex; // Offset: 0x358 // Size: 0x04
	char pad_0x35C[0x4]; // Offset: 0x35c // Size: 0x04
	struct AActor* CachedCDOActor; // Offset: 0x360 // Size: 0x08
	char pad_0x368[0x98]; // Offset: 0x368 // Size: 0x98

	// Functions

	// Object Name: Function BuildSystem.BuildSystemComponent.TryAttachToMoveablePlatform
	// Flags: [Event|Protected|HasDefaults|BlueprintEvent]
	void TryAttachToMoveablePlatform(struct AActor* SpawnedBuilding, struct FVector BuildLocation); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function BuildSystem.BuildSystemComponent.StopPlaceBuilding
	// Flags: [Native|Public|BlueprintCallable]
	void StopPlaceBuilding(); // Offset: 0x10242fd68 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BuildSystem.BuildSystemComponent.StartPrePlaceBuilding
	// Flags: [Native|Public|BlueprintCallable]
	void StartPrePlaceBuilding(int InBuildID, enum class EBuildingViewType viewType); // Offset: 0x10242fca8 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function BuildSystem.BuildSystemComponent.SkipCDTimeByBuildID
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SkipCDTimeByBuildID(int InBuildID, float IncreaseRate); // Offset: 0x10242fbf0 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function BuildSystem.BuildSystemComponent.ShouldEnableDoubleTouchMode
	// Flags: [Native|Event|Protected|BlueprintEvent]
	bool ShouldEnableDoubleTouchMode(); // Offset: 0x10242fbb4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BuildSystem.BuildSystemComponent.SetPrebuildEnabled
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void SetPrebuildEnabled(bool CanBePlaced, bool IsVisible); // Offset: 0x10242fae4 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function BuildSystem.BuildSystemComponent.ServerStopPlaceBuilding
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	void ServerStopPlaceBuilding(); // Offset: 0x10242fa88 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BuildSystem.BuildSystemComponent.ServerStartPrePlaceBuilding
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	void ServerStartPrePlaceBuilding(); // Offset: 0x10242fa2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BuildSystem.BuildSystemComponent.ServerPlaceBuildActor
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|HasDefaults|NetValidate]
	void ServerPlaceBuildActor(int BuildingIndex, struct FVector BuildLocation, struct FRotator BuildRotation, uint32_t InResult); // Offset: 0x10242f8b8 // Return & Params: Num(4) Size(0x20)

	// Object Name: Function BuildSystem.BuildSystemComponent.S2C_SkipCDTimeByBuildID
	// Flags: [Net|NetReliableNative|Event|Public|NetClient|BlueprintCallable]
	void S2C_SkipCDTimeByBuildID(int InBuildID, float IncreaseRate); // Offset: 0x10242f7f8 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function BuildSystem.BuildSystemComponent.S2C_ResetBuildngCDByBuildID
	// Flags: [Net|NetReliableNative|Event|Public|NetClient|BlueprintCallable]
	void S2C_ResetBuildngCDByBuildID(int InBuildID, float InNewCDTime); // Offset: 0x10242f738 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function BuildSystem.BuildSystemComponent.ResetBuildngCDByBuildID
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ResetBuildngCDByBuildID(int InBuildID, float InNewCDTime); // Offset: 0x10242f680 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function BuildSystem.BuildSystemComponent.ResetBuildList
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ResetBuildList(); // Offset: 0x10242f66c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BuildSystem.BuildSystemComponent.ProccessNothingHitTraceOverlap
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintEvent]
	bool ProccessNothingHitTraceOverlap(struct FVector& DestLocation, struct FRotator& DestRotation, float MaxBuildDist, struct FVector& OutLocation, int buildIndex, struct FVector& ViewLocation); // Offset: 0x103e7af64 // Return & Params: Num(7) Size(0x39)

	// Object Name: Function BuildSystem.BuildSystemComponent.PlaceBuildingWithIndex
	// Flags: [Native|Public|BlueprintCallable]
	void PlaceBuildingWithIndex(int buildIndex); // Offset: 0x10242f5e8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BuildSystem.BuildSystemComponent.PlaceBuildingAtLocation
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void PlaceBuildingAtLocation(int buildIndex, struct FVector& Loc, struct FRotator& Rot); // Offset: 0x10242f4cc // Return & Params: Num(3) Size(0x1c)

	// Object Name: Function BuildSystem.BuildSystemComponent.PlaceBuilding
	// Flags: [Native|Public|BlueprintCallable]
	void PlaceBuilding(); // Offset: 0x10242f4b0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BuildSystem.BuildSystemComponent.OverriveDeploymentTransform
	// Flags: [Native|Event|Public|HasOutParms|HasDefaults|BlueprintEvent]
	void OverriveDeploymentTransform(struct FRotator& rotIn, struct FVector& locIn, struct FRotator& rotOut, struct FVector& locOut); // Offset: 0x10242f338 // Return & Params: Num(4) Size(0x30)

	// Object Name: Function BuildSystem.BuildSystemComponent.OverrideBuildingMaxBuildDistance
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OverrideBuildingMaxBuildDistance(float BuildingMaxDistance, bool SetAll, int BuildingID); // Offset: 0x10242f234 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function BuildSystem.BuildSystemComponent.OnTouchedConstructableBoxEnded
	// Flags: [Native|Public]
	void OnTouchedConstructableBoxEnded(enum class ETouchIndex FingerIndex, struct UPrimitiveComponent* TouchedComponent); // Offset: 0x10242f174 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function BuildSystem.BuildSystemComponent.OnTouchedConstructableBox
	// Flags: [Native|Public]
	void OnTouchedConstructableBox(enum class ETouchIndex FingerIndex, struct UPrimitiveComponent* TouchedComponent); // Offset: 0x10242f0b4 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function BuildSystem.BuildSystemComponent.OnTouchActorBuild
	// Flags: [Native|Public|HasOutParms|HasDefaults]
	void OnTouchActorBuild(struct FVector2D& ScreenPosition, struct APlayerController* Controller); // Offset: 0x10242efe0 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function BuildSystem.BuildSystemComponent.OnAsyncLoadingEffectFinished
	// Flags: [Final|Native|Public]
	void OnAsyncLoadingEffectFinished(struct UParticleSystem* EffectPtr, int buildIndex); // Offset: 0x10242eea8 // Return & Params: Num(2) Size(0x2c)

	// Object Name: Function BuildSystem.BuildSystemComponent.OnAsyncLoadingBuildingFinished
	// Flags: [Final|Native|Public]
	void OnAsyncLoadingBuildingFinished(struct UClass* AcotrPtr, int buildIndex); // Offset: 0x10242ed70 // Return & Params: Num(2) Size(0x2c)

	// Object Name: Function BuildSystem.BuildSystemComponent.LineTraceToBlackTag
	// Flags: [Final|Native|Protected|HasDefaults]
	bool LineTraceToBlackTag(struct FVector BuildLocation); // Offset: 0x10242ece4 // Return & Params: Num(2) Size(0xd)

	// Object Name: Function BuildSystem.BuildSystemComponent.IsInPreBuildingMode
	// Flags: [Final|Native|Public]
	bool IsInPreBuildingMode(); // Offset: 0x10242ecc0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BuildSystem.BuildSystemComponent.IsCanPlaceBuildingBP
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	bool IsCanPlaceBuildingBP(int InBuildID); // Offset: 0x10242ec2c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function BuildSystem.BuildSystemComponent.IsCanPlaceBuilding
	// Flags: [Native|Public|BlueprintCallable]
	bool IsCanPlaceBuilding(int InBuildID, enum class EBuildingActionType _TYPE); // Offset: 0x10242eb5c // Return & Params: Num(3) Size(0x6)

	// Object Name: Function BuildSystem.BuildSystemComponent.GetPreBuildingEffectPath
	// Flags: [Event|Public|HasDefaults|BlueprintEvent|Const]
	struct FSoftObjectPath GetPreBuildingEffectPath(int InBuildID); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function BuildSystem.BuildSystemComponent.GetOwnerPlayerController
	// Flags: [Native|Protected]
	struct APlayerController* GetOwnerPlayerController(); // Offset: 0x10242eb20 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BuildSystem.BuildSystemComponent.GetMaxDistance
	// Flags: [Native|Event|Public|BlueprintEvent]
	float GetMaxDistance(); // Offset: 0x10242eae4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BuildSystem.BuildSystemComponent.GetIsHasInitData
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool GetIsHasInitData(); // Offset: 0x10242eaa8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BuildSystem.BuildSystemComponent.GetIndexByBuildingID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetIndexByBuildingID(int BuildID); // Offset: 0x10242ea1c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function BuildSystem.BuildSystemComponent.GetCurrentBuildType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class EBuildingType GetCurrentBuildType(); // Offset: 0x10242e9e8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BuildSystem.BuildSystemComponent.GetCDOByIndex
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure]
	struct AActor* GetCDOByIndex(int Index); // Offset: 0x10242e95c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function BuildSystem.BuildSystemComponent.GetBuildingList
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct TArray<struct FBuildingData> GetBuildingList(); // Offset: 0x10242e8f0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function BuildSystem.BuildSystemComponent.EnableBuildingByID
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EnableBuildingByID(int BuildID, bool bEnable); // Offset: 0x10242e834 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function BuildSystem.BuildSystemComponent.DoSceenTouchBuild
	// Flags: [Native|Protected|HasOutParms|HasDefaults|BlueprintCallable]
	void DoSceenTouchBuild(int buildIndex, struct FVector2D& ScreenPostion, int PointerIndex, enum class EBuildingActionType _TYPE, bool IsBegin, enum class EBuildingActionType CustomBuildEvent); // Offset: 0x10242e668 // Return & Params: Num(6) Size(0x13)

	// Object Name: Function BuildSystem.BuildSystemComponent.DensityCheck
	// Flags: [Native|Event|Protected|HasOutParms|BlueprintEvent]
	bool DensityCheck(struct FBuildingActorDensityCheck& DensityCheckParmas); // Offset: 0x10242e594 // Return & Params: Num(2) Size(0x21)

	// Object Name: Function BuildSystem.BuildSystemComponent.CheckShouldSkipByVisibility
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	bool CheckShouldSkipByVisibility(struct UPrimitiveComponent* _comp, int buildIndex); // Offset: 0x10242e4cc // Return & Params: Num(3) Size(0xd)

	// Object Name: Function BuildSystem.BuildSystemComponent.CheckPlacementOverlap
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintEvent]
	bool CheckPlacementOverlap(struct TArray<struct FHitResult>& HitArray, struct FVector& OutLocation, struct FVector& BoxExtent, struct FBuildingData& CurBuildData, struct FRotator& BuildRotation, struct FRotator& ControlRot, struct FVector& ViewLocation, bool& HasForbiddenObject); // Offset: 0x103e7af64 // Return & Params: Num(9) Size(0x8e)

	// Object Name: Function BuildSystem.BuildSystemComponent.CheckObjectIsOneOfTheTemplate
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	bool CheckObjectIsOneOfTheTemplate(struct UObject* Obj, struct TArray<struct UObject*> _ActorFilterTemplates); // Offset: 0x10242e398 // Return & Params: Num(3) Size(0x19)

	// Object Name: Function BuildSystem.BuildSystemComponent.BuildAtWorldLoc
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	bool BuildAtWorldLoc(int buildIndex, struct FTransform& tranx, struct FVector EndLocation, bool bUseTrace, enum class EBuildingActionType BuildType); // Offset: 0x10242e1dc // Return & Params: Num(6) Size(0x4f)

	// Object Name: Function BuildSystem.BuildSystemComponent.BP_LineTraceToBlackTag
	// Flags: [Event|Protected|HasDefaults|BlueprintEvent]
	bool BP_LineTraceToBlackTag(struct FVector BuildLocation); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0xd)

	// Object Name: Function BuildSystem.BuildSystemComponent.AddBuildingData
	// Flags: [Native|Public|BlueprintCallable]
	void AddBuildingData(struct FBuildingData InData); // Offset: 0x10242e114 // Return & Params: Num(1) Size(0x40)
};

// Object Name: Class BuildSystem.SelectBuildActor
// Size: 0x3d8 // Inherited bytes: 0x3c8
struct ASelectBuildActor : AActor {
	// Fields
	struct UParticleSystemComponent* SelectBuildEffect; // Offset: 0x3c8 // Size: 0x08
	char pad_0x3D0[0x8]; // Offset: 0x3d0 // Size: 0x08

	// Functions

	// Object Name: Function BuildSystem.SelectBuildActor.SetSelectActorTemplate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSelectActorTemplate(struct UParticleSystem* Template); // Offset: 0x102430d3c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BuildSystem.SelectBuildActor.SetSelectActorPlacementEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSelectActorPlacementEnable(bool PlacementEnable, bool IsVisible); // Offset: 0x102430c6c // Return & Params: Num(2) Size(0x2)

	// Object Name: Function BuildSystem.SelectBuildActor.SetIsPlacementEnable
	// Flags: [Final|Native|Public]
	void SetIsPlacementEnable(bool Val); // Offset: 0x102430bec // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BuildSystem.SelectBuildActor.OnParticleLoaded
	// Flags: [Native|Event|Public|BlueprintEvent]
	void OnParticleLoaded(); // Offset: 0x102430bd0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BuildSystem.SelectBuildActor.IsCurrentPlacementEnable
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsCurrentPlacementEnable(); // Offset: 0x102430bb4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BuildSystem.SelectBuildActor.GetIsPlacementEnable
	// Flags: [Final|Native|Public|Const]
	bool GetIsPlacementEnable(); // Offset: 0x102430b98 // Return & Params: Num(1) Size(0x1)
};

