#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass CameraPostProcessActor.CameraPostProcessActor_C
// Size: 0x980 // Inherited bytes: 0x3c8
struct ACameraPostProcessActor_C : AActor {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x3c8 // Size: 0x08
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x3d0 // Size: 0x08
	float Timeline_LerpPPSettings_104_7E99B53D425173C51E1B2D83BB82148A; // Offset: 0x3d8 // Size: 0x04
	float Timeline_LerpPPSettings_103_7E99B53D425173C51E1B2D83BB82148A; // Offset: 0x3dc // Size: 0x04
	float Timeline_LerpPPSettings_102_7E99B53D425173C51E1B2D83BB82148A; // Offset: 0x3e0 // Size: 0x04
	float Timeline_LerpPPSettings_101_7E99B53D425173C51E1B2D83BB82148A; // Offset: 0x3e4 // Size: 0x04
	enum class ETimelineDirection Timeline_LerpPPSettings__Direction_7E99B53D425173C51E1B2D83BB82148A; // Offset: 0x3e8 // Size: 0x01
	char pad_0x3E9[0x7]; // Offset: 0x3e9 // Size: 0x07
	struct UTimelineComponent* Timeline_LerpPPSettings; // Offset: 0x3f0 // Size: 0x08
	struct APostProcessVolume* currentPostProcessVolumn; // Offset: 0x3f8 // Size: 0x08
	int isLerp; // Offset: 0x400 // Size: 0x04
	char pad_0x404[0x4]; // Offset: 0x404 // Size: 0x04
	struct TArray<enum class EDepthOfFieldMethod> depthOfFieldMethodArray; // Offset: 0x408 // Size: 0x10
	float LerpAlpha; // Offset: 0x418 // Size: 0x04
	bool isReverse; // Offset: 0x41c // Size: 0x01
	char pad_0x41D[0x3]; // Offset: 0x41d // Size: 0x03
	struct FPostProcessSettings previousPPSettingsStruct; // Offset: 0x420 // Size: 0x560

	// Functions

	// Object Name: Function CameraPostProcessActor.CameraPostProcessActor_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function CameraPostProcessActor.CameraPostProcessActor_C.Timeline_LerpPPSettings__FinishedFunc
	// Flags: [BlueprintEvent]
	void Timeline_LerpPPSettings__FinishedFunc(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function CameraPostProcessActor.CameraPostProcessActor_C.Timeline_LerpPPSettings__UpdateFunc
	// Flags: [BlueprintEvent]
	void Timeline_LerpPPSettings__UpdateFunc(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function CameraPostProcessActor.CameraPostProcessActor_C.Event LerpPostProcessSettings
	// Flags: [BlueprintCallable|BlueprintEvent]
	void Event LerpPostProcessSettings(struct APostProcessVolume* currentPPVolumn, struct FBP_STRUCT_CameraPostProcessSettings_type targetPPSettingsStruct, float Time, int ID, bool isReverse); // Offset: 0x103e7af64 // Return & Params: Num(5) Size(0x131)

	// Object Name: Function CameraPostProcessActor.CameraPostProcessActor_C.ExecuteUbergraph_CameraPostProcessActor
	// Flags: [HasDefaults]
	void ExecuteUbergraph_CameraPostProcessActor(int EntryPoint); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x4)
};

