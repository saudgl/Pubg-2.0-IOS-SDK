#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class Client.AppBaseConfig
// Size: 0x150 // Inherited bytes: 0x28
struct UAppBaseConfig : UObject {
	// Fields
	int PUBLISH_REGION_ID; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct FString PUBLISH_AREA; // Offset: 0x30 // Size: 0x10
	struct FString IMSDK_GAME_ID; // Offset: 0x40 // Size: 0x10
	struct FString GEMAppID; // Offset: 0x50 // Size: 0x10
	uint32_t TSSGameId; // Offset: 0x60 // Size: 0x04
	char pad_0x64[0x4]; // Offset: 0x64 // Size: 0x04
	uint64 GameID; // Offset: 0x68 // Size: 0x08
	struct FString GameKey; // Offset: 0x70 // Size: 0x10
	uint64 GVoiceGameId; // Offset: 0x80 // Size: 0x08
	struct FString GVoiceGameKey; // Offset: 0x88 // Size: 0x10
	struct FString APPID_FACEBOOK; // Offset: 0x98 // Size: 0x10
	struct FString APPID_APPLE; // Offset: 0xa8 // Size: 0x10
	struct FString APPID_GOOGLE; // Offset: 0xb8 // Size: 0x10
	struct FString APPID_TWITTER; // Offset: 0xc8 // Size: 0x10
	struct FString APPID_WECHAT; // Offset: 0xd8 // Size: 0x10
	struct FString APPID_VK; // Offset: 0xe8 // Size: 0x10
	struct FString APPID_LINE; // Offset: 0xf8 // Size: 0x10
	struct FString APPID_QQ; // Offset: 0x108 // Size: 0x10
	struct FString GUID_GAMEMASTER; // Offset: 0x118 // Size: 0x10
	struct FString GEMCtrlURL; // Offset: 0x128 // Size: 0x10
	struct FString TGPACtrlURL; // Offset: 0x138 // Size: 0x10
	int SubsideFeatureLevel; // Offset: 0x148 // Size: 0x04
	char pad_0x14C[0x4]; // Offset: 0x14c // Size: 0x04
};

// Object Name: Class Client.AsyncLoadHelper
// Size: 0xe0 // Inherited bytes: 0x28
struct UAsyncLoadHelper : UObject {
	// Fields
	struct TMap<struct FString, struct UObject*> PreloadObjectMap; // Offset: 0x28 // Size: 0x50
	char pad_0x78[0x68]; // Offset: 0x78 // Size: 0x68

	// Functions

	// Object Name: Function Client.AsyncLoadHelper.SetMaxTaskNum
	// Flags: [Final|Native|Public]
	void SetMaxTaskNum(int Num); // Offset: 0x103a25474 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.AsyncLoadHelper.RunNextTask
	// Flags: [Final|Native|Public]
	void RunNextTask(); // Offset: 0x103a25460 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.AsyncLoadHelper.OnLoadCallBack
	// Flags: [Final|Native|Public|HasDefaults]
	void OnLoadCallBack(struct FSoftObjectPath softObjPath); // Offset: 0x103a25394 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function Client.AsyncLoadHelper.ClearOneTask
	// Flags: [Final|Native|Public]
	void ClearOneTask(struct FString ObjectPath); // Offset: 0x103a252d8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.AsyncLoadHelper.ClearAllTask
	// Flags: [Final|Native|Public]
	void ClearAllTask(); // Offset: 0x103a252c4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.AsyncLoadHelper.AddTask
	// Flags: [Final|Native|Public]
	void AddTask(struct FString ObjectPath, int LoadPriority); // Offset: 0x103a251c8 // Return & Params: Num(2) Size(0x14)
};

// Object Name: Class Client.AsyncTaskCDNDownloader
// Size: 0x98 // Inherited bytes: 0x28
struct UAsyncTaskCDNDownloader : UBlueprintAsyncActionBase {
	// Fields
	char pad_0x28[0x30]; // Offset: 0x28 // Size: 0x30
	struct FScriptMulticastDelegate onRequestHandler; // Offset: 0x58 // Size: 0x10
	char pad_0x68[0x30]; // Offset: 0x68 // Size: 0x30

	// Functions

	// Object Name: Function Client.AsyncTaskCDNDownloader.DownloadCDNContent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAsyncTaskCDNDownloader* DownloadCDNContent(struct FString URL, int loaderType, struct FString savedDir, bool breakpointContinualTransfer); // Offset: 0x103a25994 // Return & Params: Num(5) Size(0x38)
};

// Object Name: Class Client.AsyncTaskDownloader
// Size: 0x98 // Inherited bytes: 0x28
struct UAsyncTaskDownloader : UBlueprintAsyncActionBase {
	// Fields
	char pad_0x28[0x30]; // Offset: 0x28 // Size: 0x30
	struct FScriptMulticastDelegate onRequestHandler; // Offset: 0x58 // Size: 0x10
	char pad_0x68[0x30]; // Offset: 0x68 // Size: 0x30

	// Functions

	// Object Name: Function Client.AsyncTaskDownloader.DownloadContent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAsyncTaskDownloader* DownloadContent(struct FString URL, int loaderType, struct FString savedDir, bool breakpointContinualTransfer); // Offset: 0x103a25ed8 // Return & Params: Num(5) Size(0x38)
};

// Object Name: Class Client.BattleScriptHelper
// Size: 0x28 // Inherited bytes: 0x28
struct UBattleScriptHelper : UObject {
	// Functions

	// Object Name: Function Client.BattleScriptHelper.SyncNewBattlePlayer
	// Flags: [Final|Native|Static|Public|HasOutParms]
	uint32_t SyncNewBattlePlayer(struct UBattleUtils* Utils, uint64 UId, struct FPlayerInfoData& Info); // Offset: 0x103a266f4 // Return & Params: Num(4) Size(0xd4)

	// Object Name: Function Client.BattleScriptHelper.SyncGameInfo
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void SyncGameInfo(struct UBattleUtils* Utils, struct FBattleGameInfo& Info); // Offset: 0x103a2660c // Return & Params: Num(2) Size(0x40)

	// Object Name: Function Client.BattleScriptHelper.SyncGameExit
	// Flags: [Final|Native|Static|Public]
	void SyncGameExit(struct UBattleUtils* Utils); // Offset: 0x103a26598 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.BattleScriptHelper.SyncBattlePlayerExit
	// Flags: [Final|Native|Static|Public]
	void SyncBattlePlayerExit(struct UBattleUtils* Utils, uint64 UId, struct FName PlayerType, struct FString Reason); // Offset: 0x103a26420 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function Client.BattleScriptHelper.ResponPlayerWeaponDIYData
	// Flags: [Final|Native|Static|Public]
	void ResponPlayerWeaponDIYData(struct UBattleUtils* Utils, uint64 PlayerUID, struct FWeaponDIYData InWeaponDIYData); // Offset: 0x103a262e4 // Return & Params: Num(3) Size(0x60)

	// Object Name: Function Client.BattleScriptHelper.GenerateAIPlayerParams
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void GenerateAIPlayerParams(struct UBattleUtils* Utils, struct FPlayerInfoData& Info); // Offset: 0x103a26204 // Return & Params: Num(2) Size(0xc8)
};

// Object Name: Class Client.BattlePlayer
// Size: 0x160 // Inherited bytes: 0x28
struct UBattlePlayer : UObject {
	// Fields
	uint64 UId; // Offset: 0x28 // Size: 0x08
	struct FPlayerInfoData PlayerInfoData; // Offset: 0x30 // Size: 0xc0
	struct FPlayerAvatarData PlayerAvatarData; // Offset: 0xf0 // Size: 0x18
	struct TMap<int, struct FWeaponDIYData> WeaponDIYData; // Offset: 0x108 // Size: 0x50
	struct UBattleUtils* OwningBattleUtils; // Offset: 0x158 // Size: 0x08

	// Functions

	// Object Name: Function Client.BattlePlayer.ExtractGameModePlayerParams
	// Flags: [Final|Native|Public|Const]
	struct FGameModePlayerParams ExtractGameModePlayerParams(); // Offset: 0x103a26b7c // Return & Params: Num(1) Size(0x3a8)
};

// Object Name: Class Client.BattleAIPlayer
// Size: 0x160 // Inherited bytes: 0x160
struct UBattleAIPlayer : UBattlePlayer {
	// Functions

	// Object Name: Function Client.BattleAIPlayer.ExtractGameModeAIPlayerParams
	// Flags: [Final|Native|Public|Const]
	struct FGameModeAIPlayerParams ExtractGameModeAIPlayerParams(); // Offset: 0x103a26d30 // Return & Params: Num(1) Size(0x3b0)
};

// Object Name: Class Client.BattleUtils
// Size: 0x500 // Inherited bytes: 0x28
struct UBattleUtils : UObject {
	// Fields
	char pad_0x28[0x60]; // Offset: 0x28 // Size: 0x60
	struct UGameFrontendHUD* OwningFrontendHUD; // Offset: 0x88 // Size: 0x08
	char pad_0x90[0x10]; // Offset: 0x90 // Size: 0x10
	struct AUAEGameMode* BattleGameMode; // Offset: 0xa0 // Size: 0x08
	struct TArray<struct UBattlePlayer*> BattlePlayerList; // Offset: 0xa8 // Size: 0x10
	struct FBattleGameInfo CachedBattleGameInfo; // Offset: 0xb8 // Size: 0x38
	struct FGameModeAIPlayerParams CachedAIPlayerParams; // Offset: 0xf0 // Size: 0x3b0
	struct FString LuaFilePath; // Offset: 0x4a0 // Size: 0x10
	char pad_0x4B0[0x50]; // Offset: 0x4b0 // Size: 0x50

	// Functions

	// Object Name: Function Client.BattleUtils.SyncNewBattlePlayer
	// Flags: [Final|Native|Public|HasOutParms]
	uint32_t SyncNewBattlePlayer(uint64 UId, struct FPlayerInfoData& Info); // Offset: 0x103a27be4 // Return & Params: Num(3) Size(0xcc)

	// Object Name: Function Client.BattleUtils.SyncGameInfo
	// Flags: [Final|Native|Public|HasOutParms]
	void SyncGameInfo(struct FBattleGameInfo& Info); // Offset: 0x103a27b30 // Return & Params: Num(1) Size(0x38)

	// Object Name: Function Client.BattleUtils.SyncGameExit
	// Flags: [Final|Native|Public]
	void SyncGameExit(); // Offset: 0x103a27b1c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.BattleUtils.SyncBattlePlayerExit
	// Flags: [Final|Native|Public]
	void SyncBattlePlayerExit(uint64 UId, struct FName PlayerType, struct FString Reason); // Offset: 0x103a279dc // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.BattleUtils.RetrievePlayerParams
	// Flags: [Final|Native|Public|Const]
	struct FGameModePlayerParams RetrievePlayerParams(struct FPlayerID PlayerID); // Offset: 0x103a2791c // Return & Params: Num(2) Size(0x3b8)

	// Object Name: Function Client.BattleUtils.RetrieveAIPlayerParams
	// Flags: [Final|Native|Public]
	struct FGameModeAIPlayerParams RetrieveAIPlayerParams(struct FPlayerID PlayerID); // Offset: 0x103a2785c // Return & Params: Num(2) Size(0x3c0)

	// Object Name: Function Client.BattleUtils.ResponPlayerWeaponDIYData
	// Flags: [Final|Native|Public]
	void ResponPlayerWeaponDIYData(uint64 PlayerUID, struct FWeaponDIYData InWeaponDIYData); // Offset: 0x103a2774c // Return & Params: Num(2) Size(0x58)

	// Object Name: Function Client.BattleUtils.RequestSomePlayersBattleData
	// Flags: [Final|Native|Public]
	void RequestSomePlayersBattleData(struct TArray<uint64> PlayerUIDList, char DataType); // Offset: 0x103a27628 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.BattleUtils.RequestPlayerWeaponDIYData
	// Flags: [Final|Native|Public]
	void RequestPlayerWeaponDIYData(uint64 PlayerUID, int WeaponSkinID, int PlanID); // Offset: 0x103a27538 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function Client.BattleUtils.RequestOnePlayersBattleData
	// Flags: [Final|Native|Public]
	void RequestOnePlayersBattleData(uint64 PlayerUID, char DataType); // Offset: 0x103a27480 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.BattleUtils.RequestAllPlayersBattleData
	// Flags: [Final|Native|Public]
	void RequestAllPlayersBattleData(char DataType); // Offset: 0x103a27404 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.BattleUtils.OnPostLoadMapWithWorld
	// Flags: [Final|Native|Public]
	void OnPostLoadMapWithWorld(struct UWorld* World); // Offset: 0x103a27388 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.BattleUtils.NewBattlePlayer
	// Flags: [Final|Native|Public]
	struct UBattlePlayer* NewBattlePlayer(); // Offset: 0x103a27354 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.BattleUtils.NewBattleAIPlayer
	// Flags: [Final|Native|Public]
	struct UBattleAIPlayer* NewBattleAIPlayer(); // Offset: 0x103a27320 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.BattleUtils.HandleGameModeStateChanged
	// Flags: [Final|Native|Public|HasOutParms]
	void HandleGameModeStateChanged(struct FGameModeStateChangedParams& Params); // Offset: 0x103a27264 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BattleUtils.GetBattleGameMode
	// Flags: [Final|Native|Public|Const]
	struct AUAEGameMode* GetBattleGameMode(); // Offset: 0x103a27230 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.BattleUtils.GenerateAIPlayerParams
	// Flags: [Final|Native|Public|HasOutParms]
	void GenerateAIPlayerParams(struct FPlayerInfoData& Info); // Offset: 0x103a27184 // Return & Params: Num(1) Size(0xc0)

	// Object Name: Function Client.BattleUtils.FindPlayerByUID
	// Flags: [Final|Native|Public|Const]
	struct UBattlePlayer* FindPlayerByUID(uint64 UId, struct FName PlayerType); // Offset: 0x103a270c0 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.BattleUtils.FindPlayerByPlayerName
	// Flags: [Final|Native|Public|Const]
	struct UBattlePlayer* FindPlayerByPlayerName(struct FString PlayerName, struct FName PlayerType); // Offset: 0x103a26fb4 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.BattleUtils.FindPlayerByPlayerKey
	// Flags: [Final|Native|Public|Const]
	struct UBattlePlayer* FindPlayerByPlayerKey(uint32_t PlayerKey, struct FName PlayerType); // Offset: 0x103a26eec // Return & Params: Num(3) Size(0x18)
};

// Object Name: Class Client.BattleWindowMgr
// Size: 0x28 // Inherited bytes: 0x28
struct UBattleWindowMgr : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function Client.BattleWindowMgr.ShowUI
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ShowUI(struct UObject* WorldContextObject, struct FString WindowName, struct UObject* ObjectParam); // Offset: 0x103a28588 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.BattleWindowMgr.SetInstance
	// Flags: [Final|Native|Static|Public]
	void SetInstance(struct UBattleWindowMgrLuaUtils* InInstance, struct ULuaStateWrapper* InLuaStateWrapper); // Offset: 0x103a284dc // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Client.BattleWindowMgr.HideUI
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void HideUI(struct UObject* WorldContextObject, struct FString WindowName); // Offset: 0x103a283e8 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.BattleWindowMgr.CheckWindowOpen
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool CheckWindowOpen(struct UObject* WorldContextObject, struct FString WindowName); // Offset: 0x103a282ec // Return & Params: Num(3) Size(0x19)
};

// Object Name: Class Client.BattleWindowMgrLuaUtils
// Size: 0x70 // Inherited bytes: 0x28
struct UBattleWindowMgrLuaUtils : UObject {
	// Fields
	struct TWeakObjectPtr<struct ULuaStateWrapper> LuaStateWrapper; // Offset: 0x28 // Size: 0x08
	struct FString LuaManagerName; // Offset: 0x30 // Size: 0x10
	struct FString ShowUI; // Offset: 0x40 // Size: 0x10
	struct FString HideUI; // Offset: 0x50 // Size: 0x10
	struct FString CheckWindowOpen; // Offset: 0x60 // Size: 0x10
};

// Object Name: Class Client.BugReporter
// Size: 0xa0 // Inherited bytes: 0x28
struct UBugReporter : UObject {
	// Fields
	char pad_0x28[0x78]; // Offset: 0x28 // Size: 0x78

	// Functions

	// Object Name: Function Client.BugReporter.SendScreenShot
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SendScreenShot(struct FString errorReason, struct FString errorDescription, struct FString ImagePath, float X, float Y, float Z); // Offset: 0x103a28dd0 // Return & Params: Num(6) Size(0x3c)

	// Object Name: Function Client.BugReporter.SendLog
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SendLog(struct FString errorReason, struct FString errorDescription, float X, float Y, float Z, bool pullAll, bool zipLogUpload); // Offset: 0x103a28b48 // Return & Params: Num(7) Size(0x2e)

	// Object Name: Function Client.BugReporter.ReadZipLog
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ReadZipLog(struct FString Filename); // Offset: 0x103a28a8c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BugReporter.CompressLog
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct TArray<char> CompressLog(bool pullAllLog); // Offset: 0x103a289d0 // Return & Params: Num(2) Size(0x18)
};

// Object Name: Class Client.BuildConfig
// Size: 0x58 // Inherited bytes: 0x28
struct UBuildConfig : UObject {
	// Fields
	struct FString branch_name; // Offset: 0x28 // Size: 0x10
	struct FString build_no; // Offset: 0x38 // Size: 0x10
	struct FString build_url; // Offset: 0x48 // Size: 0x10
};

// Object Name: Class Client.BusinessHelper
// Size: 0x28 // Inherited bytes: 0x28
struct UBusinessHelper : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function Client.BusinessHelper.UIGetResWithPath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UObject* UIGetResWithPath(struct FString DesManagerName); // Offset: 0x103a2a928 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.BusinessHelper.UIGetLuaManagerByName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct ALuaClassObj* UIGetLuaManagerByName(struct UUAEUserWidget* pUIClass, struct FString InManagerName); // Offset: 0x103a2a82c // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.BusinessHelper.UIGetLuaManager
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct ALuaClassObj* UIGetLuaManager(struct UUAEUserWidget* pUIClass); // Offset: 0x103a2a7b0 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Client.BusinessHelper.StopUIStat
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void StopUIStat(struct FString UIName, bool bReport); // Offset: 0x103a2a6b4 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.BusinessHelper.StopTimeWatch
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	float StopTimeWatch(); // Offset: 0x103a2a680 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.BusinessHelper.StartUIStat
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void StartUIStat(struct FString UIName); // Offset: 0x103a2a5cc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BusinessHelper.StartTimeWatch
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void StartTimeWatch(); // Offset: 0x103a2a5b8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.BusinessHelper.SetUIStatMaxClickTimes
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetUIStatMaxClickTimes(int Times); // Offset: 0x103a2a544 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.BusinessHelper.ReportUIStat
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ReportUIStat(struct FString UIName, bool bGStatTime, bool bReport, float TotalTime); // Offset: 0x103a2a3b8 // Return & Params: Num(4) Size(0x18)

	// Object Name: Function Client.BusinessHelper.RemoveKnownMissingPackageRefObjectByObj
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void RemoveKnownMissingPackageRefObjectByObj(struct UObject* RefedObject); // Offset: 0x103a2a344 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.BusinessHelper.LoadAssetFromPath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UObject* LoadAssetFromPath(struct FString DesManagerName); // Offset: 0x103a2a2ac // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.BusinessHelper.IsSplitMiniPakVersion
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsSplitMiniPakVersion(); // Offset: 0x103a2a278 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.BusinessHelper.IsSplitMapPakVersion
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsSplitMapPakVersion(); // Offset: 0x103a2a244 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.BusinessHelper.IsFit
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsFit(); // Offset: 0x103a2a210 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.BusinessHelper.IsClassOf
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsClassOf(struct UObject* Object, struct UObject* Class); // Offset: 0x103a2a15c // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Client.BusinessHelper.IsCEVersion
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsCEVersion(); // Offset: 0x103a2a128 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.BusinessHelper.IsAppFromStore
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsAppFromStore(); // Offset: 0x103a2a0f4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.BusinessHelper.HasDownloadedBasePak
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool HasDownloadedBasePak(); // Offset: 0x103a2a0c0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.BusinessHelper.GetWidgetByName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UUAEUserWidget* GetWidgetByName(struct UUAEUserWidget* pUIClass, struct FString InManagerName, struct FString InWidgtName); // Offset: 0x103a29f98 // Return & Params: Num(4) Size(0x30)

	// Object Name: Function Client.BusinessHelper.GetTime
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	float GetTime(); // Offset: 0x103a29f64 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.BusinessHelper.GetSplitMapConfigInfo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetSplitMapConfigInfo(); // Offset: 0x103a29f00 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BusinessHelper.GetPublishRegionID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetPublishRegionID(); // Offset: 0x103a29ecc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.BusinessHelper.GetPublishRegion
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetPublishRegion(); // Offset: 0x103a29e68 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BusinessHelper.GetPackChannel
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetPackChannel(); // Offset: 0x103a29e04 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BusinessHelper.GetOpenId
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetOpenId(); // Offset: 0x103a29da0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BusinessHelper.GetMobileBasePath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetMobileBasePath(struct FString InPath); // Offset: 0x103a29ce0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.BusinessHelper.GetLuaManagerByName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct ALuaClassObj* GetLuaManagerByName(struct UUAEUserWidget* pUIClass, struct FString InManagerName); // Offset: 0x103a29be4 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.BusinessHelper.GetITopGameId
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetITopGameId(); // Offset: 0x103a29b80 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BusinessHelper.GetInGameLocalConnectURL
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetInGameLocalConnectURL(); // Offset: 0x103a29b1c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BusinessHelper.GetIMSDKEnv
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetIMSDKEnv(); // Offset: 0x103a29ae8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.BusinessHelper.GetDeviceQualityLevel
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetDeviceQualityLevel(); // Offset: 0x103a29ab4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.BusinessHelper.GetDeviceOrientation
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetDeviceOrientation(); // Offset: 0x103a29a80 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.BusinessHelper.GetDataTable
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UUAEDataTable* GetDataTable(struct FString tableName); // Offset: 0x103a299e8 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.BusinessHelper.GetCurrentNetworkState
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetCurrentNetworkState(); // Offset: 0x103a299b4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.BusinessHelper.GetChildByName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UWidget* GetChildByName(struct UUserWidget* pParent, struct FString Name); // Offset: 0x103a298e0 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.BusinessHelper.GetBuildURL
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetBuildURL(); // Offset: 0x103a2987c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BusinessHelper.GetBuildNo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetBuildNo(); // Offset: 0x103a29818 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BusinessHelper.GetBranchName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetBranchName(); // Offset: 0x103a297b4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BusinessHelper.GetBase64Key
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetBase64Key(); // Offset: 0x103a29750 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BusinessHelper.GetAppVersion
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetAppVersion(); // Offset: 0x103a296ec // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BusinessHelper.GetAOSSHOPID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetAOSSHOPID(); // Offset: 0x103a296b8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.BusinessHelper.GetAOSSHOP
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetAOSSHOP(); // Offset: 0x103a29654 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BusinessHelper.ClearDisplayLookupTable
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ClearDisplayLookupTable(); // Offset: 0x103a29640 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.BusinessHelper.BroadCastMSG
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void BroadCastMSG(struct UFrontendHUD* FrontendHUD, struct FString DesManagerName, struct FString Msg); // Offset: 0x103a29520 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.BusinessHelper.AddKnownMissingPackage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void AddKnownMissingPackage(struct FString PackageName, struct UObject* BindObj, bool bReplace); // Offset: 0x103a293e4 // Return & Params: Num(3) Size(0x19)
};

// Object Name: Class Client.IntlHelper
// Size: 0x28 // Inherited bytes: 0x28
struct UIntlHelper : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function Client.IntlHelper.UpdateXGPushNightTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void UpdateXGPushNightTag(bool BInit); // Offset: 0x103a2d390 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.IntlHelper.UpdateXGPushDayTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void UpdateXGPushDayTag(bool BInit); // Offset: 0x103a2d314 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.IntlHelper.UpdateVoiceUrl
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void UpdateVoiceUrl(struct FString regionVoiceUrl); // Offset: 0x103a2d260 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.IntlHelper.UnInitTweenMaker
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void UnInitTweenMaker(); // Offset: 0x103a2d24c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlHelper.TimeFormatString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString TimeFormatString(struct FString Format, int hours, int Mins, int secs); // Offset: 0x103a2d0d0 // Return & Params: Num(5) Size(0x30)

	// Object Name: Function Client.IntlHelper.SaveXGTags
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SaveXGTags(struct FString Language, struct FString timezone, struct FString Region); // Offset: 0x103a2cf2c // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.IntlHelper.OnSwitchLanguage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void OnSwitchLanguage(); // Offset: 0x103a2cf18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlHelper.OnChoosingZone
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void OnChoosingZone(int ZoneID, struct FString AddrIP, struct FString regionVoiceUrl); // Offset: 0x103a2cdac // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.IntlHelper.IsRemoteNotificationsEnabled
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsRemoteNotificationsEnabled(); // Offset: 0x103a2cd78 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.IntlHelper.IsHelpshiftEnable4CurrentChannel
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsHelpshiftEnable4CurrentChannel(); // Offset: 0x103a2cd44 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.IntlHelper.IsHelpshiftEnable
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsHelpshiftEnable(); // Offset: 0x103a2cd10 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.IntlHelper.InitTweenMaker
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void InitTweenMaker(); // Offset: 0x103a2ccfc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlHelper.HelpshiftUploadLog
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void HelpshiftUploadLog(); // Offset: 0x103a2cce8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlHelper.HelpshiftShowFAQsWithInfo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void HelpshiftShowFAQsWithInfo(struct FString PlayerName, struct FString PlayerLevel, struct FString PlayerGold, int PlayerRecharge, int PlayerRegisterTime, struct FString ExtraTags); // Offset: 0x103a2cae0 // Return & Params: Num(6) Size(0x48)

	// Object Name: Function Client.IntlHelper.HelpshiftShowFAQs
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void HelpshiftShowFAQs(); // Offset: 0x103a2cacc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlHelper.HelpshiftShowConversionWithInfo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void HelpshiftShowConversionWithInfo(struct FString Name, struct FString Level, struct FString Gold); // Offset: 0x103a2c928 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.IntlHelper.HelpshiftShowConversion
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void HelpshiftShowConversion(); // Offset: 0x103a2c914 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlHelper.HelpshiftRequestUnreadMessagesCount
	// Flags: [Final|Native|Static|Public]
	void HelpshiftRequestUnreadMessagesCount(); // Offset: 0x103a2c900 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlHelper.HelpshiftGetUnreadMessgesCount
	// Flags: [Final|Native|Static|Public]
	int HelpshiftGetUnreadMessgesCount(); // Offset: 0x103a2c8cc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.IntlHelper.HelpshiftClearUnreadMessgesCount
	// Flags: [Final|Native|Static|Public]
	void HelpshiftClearUnreadMessgesCount(); // Offset: 0x103a2c8b8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlHelper.GetSavedXGTimezoneTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetSavedXGTimezoneTag(); // Offset: 0x103a2c854 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.IntlHelper.GetSavedXGRegionTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetSavedXGRegionTag(); // Offset: 0x103a2c7f0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.IntlHelper.GetSavedXGPushNightTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetSavedXGPushNightTag(); // Offset: 0x103a2c78c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.IntlHelper.GetSavedXGPushDayTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetSavedXGPushDayTag(); // Offset: 0x103a2c728 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.IntlHelper.GetSavedXGLanguageTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetSavedXGLanguageTag(); // Offset: 0x103a2c6c4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.IntlHelper.GetPlayerUCLevel
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetPlayerUCLevel(); // Offset: 0x103a2c660 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.IntlHelper.GetLocalTimezone
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetLocalTimezone(); // Offset: 0x103a2c62c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.IntlHelper.GetLocalizeStringWithString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetLocalizeStringWithString(struct FString sourceString, int numStringIndex, struct FString string1, struct FString string2, struct FString string3, struct FString string4); // Offset: 0x103a2c3dc // Return & Params: Num(7) Size(0x68)

	// Object Name: Function Client.IntlHelper.GetLocalizeStringWithNum
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetLocalizeStringWithNum(int ID, int numStringIndex, struct FString string1, struct FString string2, struct FString string3, struct FString string4); // Offset: 0x103a2c1ac // Return & Params: Num(7) Size(0x58)

	// Object Name: Function Client.IntlHelper.GetLocalizeStrByStr
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetLocalizeStrByStr(struct FString Source, struct FString string1, struct FString string2, struct FString string3, struct FString string4); // Offset: 0x103a2bf9c // Return & Params: Num(6) Size(0x60)

	// Object Name: Function Client.IntlHelper.GetLocalizeStrByID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetLocalizeStrByID(int ID, struct FString string1, struct FString string2, struct FString string3, struct FString string4); // Offset: 0x103a2bda4 // Return & Params: Num(6) Size(0x58)

	// Object Name: Function Client.IntlHelper.GetLocalizationStringWithID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetLocalizationStringWithID(int ID); // Offset: 0x103a2bd00 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.IntlHelper.GetLocalizationString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetLocalizationString(struct FString Key); // Offset: 0x103a2bc40 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.IntlHelper.GetLocalizationBattleStringWithID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetLocalizationBattleStringWithID(int ID); // Offset: 0x103a2bb9c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.IntlHelper.GetHistoryErrorCode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetHistoryErrorCode(); // Offset: 0x103a2bb38 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.IntlHelper.GetGameMasterVID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetGameMasterVID(); // Offset: 0x103a2bad4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.IntlHelper.GetCurrentZoneID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetCurrentZoneID(); // Offset: 0x103a2baa0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.IntlHelper.FormatLocalizeStrByStr
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FString FormatLocalizeStrByStr(struct FString Source, struct TArray<struct FString>& stringArr); // Offset: 0x103a2b97c // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.IntlHelper.DownloadTranslation
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DownloadTranslation(struct FString PatchName); // Offset: 0x103a2b8c8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.IntlHelper.DownloadServerList
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DownloadServerList(); // Offset: 0x103a2b8b4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlHelper.DownloadCDNFile
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DownloadCDNFile(struct FString cdnUrl, struct FString SavePath); // Offset: 0x103a2b788 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.IntlHelper.DirectToNotificationSetup
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DirectToNotificationSetup(); // Offset: 0x103a2b774 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlHelper.ClearAdjustDeepLink
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ClearAdjustDeepLink(); // Offset: 0x103a2b760 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlHelper.AdjustParaAnalysis
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void AdjustParaAnalysis(); // Offset: 0x103a2b74c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlHelper.AddErrorCodeToHistory
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void AddErrorCodeToHistory(struct FString InErrorCode); // Offset: 0x103a2b698 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class Client.TestHUD
// Size: 0x3c8 // Inherited bytes: 0x3c8
struct ATestHUD : AActor {
	// Functions

	// Object Name: Function Client.TestHUD.TestFunctionNOParam
	// Flags: [Final|Native|Public|BlueprintCallable]
	void TestFunctionNOParam(); // Offset: 0x103a2e2f8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.TestHUD.TestFunctionBP_LUA
	// Flags: [Event|Public|BlueprintEvent]
	float TestFunctionBP_LUA(); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TestHUD.TestFunctionBP
	// Flags: [Event|Public|BlueprintEvent]
	float TestFunctionBP(); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TestHUD.Function_Lua
	// Flags: [Final|Native|Public|BlueprintCallable]
	float Function_Lua(); // Offset: 0x103a2e2c4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TestHUD.Function_CPlus_Call
	// Flags: [Final|Native|Public|BlueprintCallable]
	float Function_CPlus_Call(); // Offset: 0x103a2e290 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TestHUD.Function_CPlus
	// Flags: [Final|Native|Public|BlueprintCallable]
	float Function_CPlus(); // Offset: 0x103a2e25c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TestHUD.Function_BP_CPP
	// Flags: [Event|Public|BlueprintEvent]
	float Function_BP_CPP(); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TestHUD.Function_BP_Call_LUA
	// Flags: [Final|Native|Public|BlueprintCallable]
	float Function_BP_Call_LUA(); // Offset: 0x103a2e228 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TestHUD.Function_BP_Call_CPP
	// Flags: [Event|Public|BlueprintEvent]
	float Function_BP_Call_CPP(); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TestHUD.Function_BP_Call_CPlus
	// Flags: [Final|Native|Public|BlueprintCallable]
	float Function_BP_Call_CPlus(); // Offset: 0x103a2e1f4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TestHUD.Function_BP_Call
	// Flags: [Final|Native|Public|BlueprintCallable]
	float Function_BP_Call(); // Offset: 0x103a2e1c0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TestHUD.Function_BP
	// Flags: [Final|Native|Public|BlueprintCallable]
	float Function_BP(); // Offset: 0x103a2e18c // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class Client.CDNUpdate
// Size: 0x368 // Inherited bytes: 0x28
struct UCDNUpdate : UObject {
	// Fields
	char pad_0x28[0x90]; // Offset: 0x28 // Size: 0x90
	struct UGameFrontendHUD* GameFrontendHUD; // Offset: 0xb8 // Size: 0x08
	char pad_0xC0[0x2a8]; // Offset: 0xc0 // Size: 0x2a8

	// Functions

	// Object Name: Function Client.CDNUpdate.StartUpdateApp
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StartUpdateApp(); // Offset: 0x103a30fa8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.CDNUpdate.StartAppUpdate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StartAppUpdate(bool StartGrayUpdate); // Offset: 0x103a30f24 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.CDNUpdate.OnRequestProgress
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void OnRequestProgress(struct FCDNDownloaderInfo& Info); // Offset: 0x103a30e70 // Return & Params: Num(1) Size(0x30)

	// Object Name: Function Client.CDNUpdate.OnRequestComplete
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void OnRequestComplete(struct FCDNDownloaderInfo& Info); // Offset: 0x103a30dbc // Return & Params: Num(1) Size(0x30)

	// Object Name: Function Client.CDNUpdate.IsUpdating
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsUpdating(); // Offset: 0x103a30d88 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.CDNUpdate.IsGrayUpdate
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsGrayUpdate(); // Offset: 0x103a30d54 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.CDNUpdate.GetCurStage
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	int GetCurStage(float& percent, int& GetCurVal, int& GetMaxVal); // Offset: 0x103a30c18 // Return & Params: Num(4) Size(0x10)

	// Object Name: Function Client.CDNUpdate.FinishUpdate
	// Flags: [Final|Native|Public]
	void FinishUpdate(); // Offset: 0x103a30c04 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.CDNUpdate.ContinueUpdate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ContinueUpdate(); // Offset: 0x103a30bf0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.CDNUpdate.CancelUpdate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CancelUpdate(); // Offset: 0x103a30bdc // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Client.ClientNetInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UClientNetInterface : UNetInterface {
};

// Object Name: Class Client.CompressTextureHelper
// Size: 0x28 // Inherited bytes: 0x28
struct UCompressTextureHelper : UObject {
	// Functions

	// Object Name: Function Client.CompressTextureHelper.TestGetTexture2DFromDisk_KTX2
	// Flags: [Final|Native|Static|Public]
	struct UTexture2D* TestGetTexture2DFromDisk_KTX2(struct FString PathName); // Offset: 0x103a32200 // Return & Params: Num(2) Size(0x18)
};

// Object Name: Class Client.CrashContextProcessor
// Size: 0xd8 // Inherited bytes: 0x28
struct UCrashContextProcessor : UObject {
	// Fields
	char pad_0x28[0xb0]; // Offset: 0x28 // Size: 0xb0

	// Functions

	// Object Name: Function Client.CrashContextProcessor.TriggerLoginCrashTest
	// Flags: [Final|Native|Public|BlueprintCallable]
	void TriggerLoginCrashTest(); // Offset: 0x103a3263c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.CrashContextProcessor.TriggerLobbyCrashTest
	// Flags: [Final|Native|Public|BlueprintCallable]
	void TriggerLobbyCrashTest(int Type); // Offset: 0x103a325c0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.CrashContextProcessor.Initialize
	// Flags: [Final|Native|Public]
	void Initialize(); // Offset: 0x103a325ac // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.CrashContextProcessor.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UCrashContextProcessor* GetInstance(); // Offset: 0x103a32578 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.CrashContextProcessor.AddAttachFileString
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void AddAttachFileString(struct FString Type, bool bClear, struct FString& strinfo); // Offset: 0x103a32408 // Return & Params: Num(3) Size(0x28)
};

// Object Name: Class Client.GameBackendUtils
// Size: 0x30 // Inherited bytes: 0x30
struct UGameBackendUtils : UBackendUtils {
	// Functions

	// Object Name: Function Client.GameBackendUtils.GetTableManager
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UUAETableManager* GetTableManager(); // Offset: 0x103a3296c // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Client.GameBackendHUD
// Size: 0xb0 // Inherited bytes: 0xb0
struct UGameBackendHUD : UBackendHUD {
	// Functions

	// Object Name: Function Client.GameBackendHUD.GetUtils
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UGameBackendUtils* GetUtils(); // Offset: 0x103a32c48 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameBackendHUD.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UGameBackendHUD* GetInstance(); // Offset: 0x103a32c14 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameBackendHUD.GetGameFrontendHUDByGameInstance
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UGameFrontendHUD* GetGameFrontendHUDByGameInstance(struct UGameInstance* GameInstance); // Offset: 0x103a32b88 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Client.GameBackendHUD.GetFirstGameFrontendHUD
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UGameFrontendHUD* GetFirstGameFrontendHUD(struct UObject* WorldContextObject); // Offset: 0x103a32afc // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class Client.GameBusinessManager
// Size: 0x170 // Inherited bytes: 0xf8
struct UGameBusinessManager : ULogicManagerBase {
	// Fields
	struct TArray<struct FGameWidgetConfig> WidgetConfigList; // Offset: 0xf8 // Size: 0x10
	char pad_0x108[0x50]; // Offset: 0x108 // Size: 0x50
	struct AUAEPlayerController* OwningController; // Offset: 0x158 // Size: 0x08
	char pad_0x160[0x8]; // Offset: 0x160 // Size: 0x08
	struct ALuaClassObj* LuaObject; // Offset: 0x168 // Size: 0x08

	// Functions

	// Object Name: Function Client.GameBusinessManager.GetWidget
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UUAEUserWidget* GetWidget(int Index); // Offset: 0x103a32fcc // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Client.GameBusinessManager.GetLuaObject
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct ALuaClassObj* GetLuaObject(); // Offset: 0x103a32f98 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameBusinessManager.GetGameFrontendHUD
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UGameFrontendHUD* GetGameFrontendHUD(); // Offset: 0x103a32f64 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Client.GameFrontendHUD
// Size: 0x7e0 // Inherited bytes: 0x1d0
struct UGameFrontendHUD : UFrontendHUD {
	// Fields
	struct FScriptMulticastDelegate OnHandleWebviewActionDelegate; // Offset: 0x1d0 // Size: 0x10
	struct FScriptMulticastDelegate OnGetTicketNotifyDelegate; // Offset: 0x1e0 // Size: 0x10
	struct FScriptMulticastDelegate OnHandleServerListDownload; // Offset: 0x1f0 // Size: 0x10
	struct FString CSVTableRelativeDir; // Offset: 0x200 // Size: 0x10
	struct TMap<struct FName, struct FString> GameStatusMap; // Offset: 0x210 // Size: 0x50
	bool EnableTickLog; // Offset: 0x260 // Size: 0x01
	char pad_0x261[0x1f]; // Offset: 0x261 // Size: 0x1f
	struct UGVoiceInterface* GVoice; // Offset: 0x280 // Size: 0x08
	bool DisableGVoice; // Offset: 0x288 // Size: 0x01
	char pad_0x289[0x7]; // Offset: 0x289 // Size: 0x07
	struct UBugReporter* GameBugReporter; // Offset: 0x290 // Size: 0x08
	struct UGMLogShare* LogShare; // Offset: 0x298 // Size: 0x08
	int MaxUpdateRetryTimes; // Offset: 0x2a0 // Size: 0x04
	char pad_0x2A4[0xc]; // Offset: 0x2a4 // Size: 0x0c
	struct UGDolphinUpdater* GDolphin; // Offset: 0x2b0 // Size: 0x08
	struct UTranslator* Translator; // Offset: 0x2b8 // Size: 0x08
	struct UHttpWrapper* HttpWrapper; // Offset: 0x2c0 // Size: 0x08
	struct UGCPufferDownloader* GPuffer; // Offset: 0x2c8 // Size: 0x08
	struct ULaggingReporter* LaggingReporter; // Offset: 0x2d0 // Size: 0x08
	char pad_0x2D8[0x8]; // Offset: 0x2d8 // Size: 0x08
	struct UAsyncTaskDownloader* DownloadTask; // Offset: 0x2e0 // Size: 0x08
	char pad_0x2E8[0x44]; // Offset: 0x2e8 // Size: 0x44
	bool bUseDolphinUpdateFirst; // Offset: 0x32c // Size: 0x01
	bool bEnableUseDolphinUpdate; // Offset: 0x32d // Size: 0x01
	bool bEnableUseCDNUpdate; // Offset: 0x32e // Size: 0x01
	bool bUseDolphinUpdateAfterCDNFailed; // Offset: 0x32f // Size: 0x01
	bool bUseCDNUpdateAfterDolphinFailed; // Offset: 0x330 // Size: 0x01
	bool bEnableEditorPufferDownload; // Offset: 0x331 // Size: 0x01
	bool bIsWaitingUpdateStateData; // Offset: 0x332 // Size: 0x01
	bool IsUsingDolphinUpdate; // Offset: 0x333 // Size: 0x01
	bool IsUsingCDNUpdate; // Offset: 0x334 // Size: 0x01
	char pad_0x335[0x13]; // Offset: 0x335 // Size: 0x13
	struct UCDNUpdate* CDNUpdater; // Offset: 0x348 // Size: 0x08
	int ODPaksPoolSize; // Offset: 0x350 // Size: 0x04
	int ODPaksPoolSizeLowend; // Offset: 0x354 // Size: 0x04
	int ODPaksPoolSizeLowendThreshold; // Offset: 0x358 // Size: 0x04
	bool ODPaksEnable; // Offset: 0x35c // Size: 0x01
	char pad_0x35D[0x33]; // Offset: 0x35d // Size: 0x33
	struct FName UnrealNetworkStatus; // Offset: 0x390 // Size: 0x08
	char pad_0x398[0x18]; // Offset: 0x398 // Size: 0x18
	float UnrealNetworkConnectingTimer; // Offset: 0x3b0 // Size: 0x04
	char pad_0x3B4[0x1c]; // Offset: 0x3b4 // Size: 0x1c
	float UnrealNetworkConnectingTime; // Offset: 0x3d0 // Size: 0x04
	bool bUseDynamicCreateLuaManager; // Offset: 0x3d4 // Size: 0x01
	char pad_0x3D5[0x3]; // Offset: 0x3d5 // Size: 0x03
	struct TArray<struct FString> PersistentLuaManager; // Offset: 0x3d8 // Size: 0x10
	char pad_0x3E8[0x4]; // Offset: 0x3e8 // Size: 0x04
	bool bPatchReInitSequence; // Offset: 0x3ec // Size: 0x01
	char pad_0x3ED[0x3]; // Offset: 0x3ed // Size: 0x03
	struct ULuaStateWrapper* LuaStateWrapper; // Offset: 0x3f0 // Size: 0x08
	struct ULuaEventBridge* LuaEventBridgeInstace; // Offset: 0x3f8 // Size: 0x08
	struct UBattleWindowMgrLuaUtils* LuaBattleWindowMgr; // Offset: 0x400 // Size: 0x08
	struct ULuaBlueprintMgr* LuaBlueprintSysMgr; // Offset: 0x408 // Size: 0x08
	char pad_0x410[0x8]; // Offset: 0x410 // Size: 0x08
	struct FString ScriptBPRelativeDir; // Offset: 0x418 // Size: 0x10
	struct FString ScriptRelativeDir; // Offset: 0x428 // Size: 0x10
	struct FString InGameLuaDir; // Offset: 0x438 // Size: 0x10
	struct FString PreloadLuaFileRelativePath; // Offset: 0x448 // Size: 0x10
	struct TArray<struct FString> LuaDirList; // Offset: 0x458 // Size: 0x10
	struct TArray<struct FString> NoGCPackage; // Offset: 0x468 // Size: 0x10
	float LuaTickTime; // Offset: 0x478 // Size: 0x04
	bool bCallLuaTick; // Offset: 0x47c // Size: 0x01
	bool bAutoLoginEnable; // Offset: 0x47d // Size: 0x01
	char pad_0x47E[0x2a]; // Offset: 0x47e // Size: 0x2a
	int PingFirstReportIntervalSecond; // Offset: 0x4a8 // Size: 0x04
	int PingReportIntervalSecond; // Offset: 0x4ac // Size: 0x04
	int LossSyncIntervalSecond; // Offset: 0x4b0 // Size: 0x04
	int vmInstrumentOptimization; // Offset: 0x4b4 // Size: 0x04
	struct UTssManager* TssMgr; // Offset: 0x4b8 // Size: 0x08
	char pad_0x4C0[0x1c]; // Offset: 0x4c0 // Size: 0x1c
	float PingReportInterval; // Offset: 0x4dc // Size: 0x04
	char pad_0x4E0[0xd4]; // Offset: 0x4e0 // Size: 0xd4
	uint32_t ImageDownloadClearDayCount; // Offset: 0x5b4 // Size: 0x04
	struct FScriptMulticastDelegate UIStackChangeDelegate; // Offset: 0x5b8 // Size: 0x10
	struct FScriptMulticastDelegate UIStackRecoverDelegate; // Offset: 0x5c8 // Size: 0x10
	struct FScriptMulticastDelegate OnFRefreshAdaptationUIEvent; // Offset: 0x5d8 // Size: 0x10
	struct FScriptMulticastDelegate OnFRefreshAdaptationExUIEvent; // Offset: 0x5e8 // Size: 0x10
	char pad_0x5F8[0x78]; // Offset: 0x5f8 // Size: 0x78
	struct UImageDownloader* ImageDownloaderInGame; // Offset: 0x670 // Size: 0x08
	int FpsForWindowClient; // Offset: 0x678 // Size: 0x04
	char pad_0x67C[0x4]; // Offset: 0x67c // Size: 0x04
	struct UUDPPingCollector* UDPPingCollector; // Offset: 0x680 // Size: 0x08
	bool UIElemLayoutJsonConfigSwitch; // Offset: 0x688 // Size: 0x01
	bool NationAllSwitch; // Offset: 0x689 // Size: 0x01
	bool NationBattleSwitch; // Offset: 0x68a // Size: 0x01
	bool NationRankSwitch; // Offset: 0x68b // Size: 0x01
	bool SelfieSwitch; // Offset: 0x68c // Size: 0x01
	bool ReportBugSwitch; // Offset: 0x68d // Size: 0x01
	bool FirstVoicePopupSwitch; // Offset: 0x68e // Size: 0x01
	bool GDPRForbidVoiceSwitch; // Offset: 0x68f // Size: 0x01
	bool GDPRSettingSwitch; // Offset: 0x690 // Size: 0x01
	char pad_0x691[0x3]; // Offset: 0x691 // Size: 0x03
	int GDPRUserType; // Offset: 0x694 // Size: 0x04
	bool bShouldShowAdaptTipInLobby; // Offset: 0x698 // Size: 0x01
	char pad_0x699[0x3]; // Offset: 0x699 // Size: 0x03
	float fLaggingFPSDiffThreshold; // Offset: 0x69c // Size: 0x04
	float fLaggingFPSDiffThresholdMin; // Offset: 0x6a0 // Size: 0x04
	float fLaggingFPSDiffThresholdMax; // Offset: 0x6a4 // Size: 0x04
	float fLaggingFrameTimeThreshold; // Offset: 0x6a8 // Size: 0x04
	float fLaggingFrameTimeThresholdMin; // Offset: 0x6ac // Size: 0x04
	float fLaggingFrameTimeThresholdMax; // Offset: 0x6b0 // Size: 0x04
	float fFPSReportInterval; // Offset: 0x6b4 // Size: 0x04
	char pad_0x6B8[0xc]; // Offset: 0x6b8 // Size: 0x0c
	bool bUnLoadNoGcPackage; // Offset: 0x6c4 // Size: 0x01
	char pad_0x6C5[0x3]; // Offset: 0x6c5 // Size: 0x03
	struct TArray<struct UPackage*> NoGcPackages; // Offset: 0x6c8 // Size: 0x10
	bool bFlushAsyncLoadingBeforeGC; // Offset: 0x6d8 // Size: 0x01
	bool bEnablePandora; // Offset: 0x6d9 // Size: 0x01
	char pad_0x6DA[0x1]; // Offset: 0x6da // Size: 0x01
	bool bEnableJMLog; // Offset: 0x6db // Size: 0x01
	char pad_0x6DC[0xb4]; // Offset: 0x6dc // Size: 0xb4
	bool bEnableH5Cache; // Offset: 0x790 // Size: 0x01
	bool bCheckWorldNameForLoadConfig; // Offset: 0x791 // Size: 0x01
	char pad_0x792[0x6]; // Offset: 0x792 // Size: 0x06
	struct UColorBlindnessMgr* ColorBlindnessMgrInstace; // Offset: 0x798 // Size: 0x08
	struct TArray<struct FNativeHUDTickContainer> NativeHUDTickList; // Offset: 0x7a0 // Size: 0x10
	bool IsNativeHUDTickLock; // Offset: 0x7b0 // Size: 0x01
	bool IsShutDown; // Offset: 0x7b1 // Size: 0x01
	char pad_0x7B2[0x2]; // Offset: 0x7b2 // Size: 0x02
	int NativeHUDTickIndex; // Offset: 0x7b4 // Size: 0x04
	struct UAsyncLoadHelper* AsyncLoadHelper; // Offset: 0x7b8 // Size: 0x08
	struct FString BattleUtilsClassName; // Offset: 0x7c0 // Size: 0x10
	struct UBattleUtils* BattleUtils; // Offset: 0x7d0 // Size: 0x08
	char pad_0x7D8[0x4]; // Offset: 0x7d8 // Size: 0x04
	int DealyHideLoadingUI; // Offset: 0x7dc // Size: 0x04

	// Functions

	// Object Name: Function Client.GameFrontendHUD.VNGPostPersonalInfo
	// Flags: [Final|Native|Public|BlueprintCallable]
	void VNGPostPersonalInfo(struct FString OpenID, struct FString Name, struct FString passportId, struct FString email, struct FString phone, struct FString address); // Offset: 0x103a35950 // Return & Params: Num(6) Size(0x60)

	// Object Name: Function Client.GameFrontendHUD.UnRegisterUIShowHideEventDelegate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UnRegisterUIShowHideEventDelegate(struct FString Source); // Offset: 0x103a35894 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.TimeStatisticStop
	// Flags: [Final|Native|Public|BlueprintCallable]
	void TimeStatisticStop(int Type, struct FString Name); // Offset: 0x103a35798 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.GameFrontendHUD.TimeStatisticStart
	// Flags: [Final|Native|Public|BlueprintCallable]
	void TimeStatisticStart(int Type); // Offset: 0x103a3571c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GameFrontendHUD.TickUdpCollector
	// Flags: [Final|Native|Public]
	void TickUdpCollector(float DeltaTime); // Offset: 0x103a356a0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GameFrontendHUD.StatisVisibilityWidget
	// Flags: [Final|Native|Public]
	void StatisVisibilityWidget(struct UWidget* Widget); // Offset: 0x103a35624 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.StatisLoadedTexture
	// Flags: [Final|Native|Public]
	void StatisLoadedTexture(struct UTexture* Texture); // Offset: 0x103a355a8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.StartGrayUpdate
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool StartGrayUpdate(); // Offset: 0x103a35574 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GameFrontendHUD.StartDolphinUpdateAfterCDNUpdateFailed
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StartDolphinUpdateAfterCDNUpdateFailed(); // Offset: 0x103a35560 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GameFrontendHUD.StartCDNUpdateAfterDolphinUpdateFailed
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StartCDNUpdateAfterDolphinUpdateFailed(); // Offset: 0x103a3554c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GameFrontendHUD.ShutdownUnrealNetwork
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ShutdownUnrealNetwork(); // Offset: 0x103a35530 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GameFrontendHUD.SetShouldShowAdaptTipInLobby
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetShouldShowAdaptTipInLobby(bool bShoudShow); // Offset: 0x103a354ac // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GameFrontendHUD.SetGameSubMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetGameSubMode(struct FString SubMode); // Offset: 0x103a35414 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.SetGameStatusMap
	// Flags: [Final|Native|Public]
	void SetGameStatusMap(struct TMap<struct FName, struct FString> InGameStatusMap); // Offset: 0x103a35354 // Return & Params: Num(1) Size(0x50)

	// Object Name: Function Client.GameFrontendHUD.SetClientEnterBattleStage
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetClientEnterBattleStage(struct FString InStageStr); // Offset: 0x103a352bc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.SetAccountByWebLogin
	// Flags: [Final|Native|Public]
	void SetAccountByWebLogin(int Channel, struct FString OpenID, struct FString userId, struct FString TokenID, int ExpireTime); // Offset: 0x103a35100 // Return & Params: Num(5) Size(0x3c)

	// Object Name: Function Client.GameFrontendHUD.RetryDownload
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RetryDownload(); // Offset: 0x103a350ec // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GameFrontendHUD.RetryCDNDownload
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RetryCDNDownload(); // Offset: 0x103a350d8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GameFrontendHUD.ReleaseBattleUtils
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ReleaseBattleUtils(); // Offset: 0x103a350c4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GameFrontendHUD.RegisterUserSettingsDelegate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegisterUserSettingsDelegate(DelegateProperty Delegate); // Offset: 0x103a35034 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.RegisterUIShowHideEventDelegate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegisterUIShowHideEventDelegate(struct FString Source, DelegateProperty Delegate); // Offset: 0x103a34f24 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.GameFrontendHUD.OnWebviewNotify
	// Flags: [Final|RequiredAPI|Native|Public|HasOutParms]
	void OnWebviewNotify(struct FWebviewInfoWrapper& webviewinfo); // Offset: 0x103a34e78 // Return & Params: Num(1) Size(0x30)

	// Object Name: Function Client.GameFrontendHUD.OnWebviewActionNotify
	// Flags: [Final|RequiredAPI|Native|Public]
	void OnWebviewActionNotify(struct FString URL); // Offset: 0x103a34dbc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.OnUAAssistantEvent
	// Flags: [Final|RequiredAPI|Native|Public|HasOutParms]
	void OnUAAssistantEvent(struct FUAAssistantInfoWrapper& UAAssistentInfo); // Offset: 0x103a34d0c // Return & Params: Num(1) Size(0x28)

	// Object Name: Function Client.GameFrontendHUD.OnSDKCallbackEvent
	// Flags: [Final|RequiredAPI|Native|Public|HasOutParms]
	void OnSDKCallbackEvent(struct FSDKCallbackInfoWrapper& sdkCallbackInfo); // Offset: 0x103a34c5c // Return & Params: Num(1) Size(0x28)

	// Object Name: Function Client.GameFrontendHUD.OnRequestComplete
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void OnRequestComplete(struct FCDNDownloaderInfo& Info); // Offset: 0x103a34ba8 // Return & Params: Num(1) Size(0x30)

	// Object Name: Function Client.GameFrontendHUD.OnRefreshAccountInfo
	// Flags: [Final|RequiredAPI|Native|Public]
	void OnRefreshAccountInfo(bool Result, int InChannel, struct FString InOpenId); // Offset: 0x103a34a60 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.GameFrontendHUD.OnQuickLoginNotify
	// Flags: [Final|RequiredAPI|Native|Public|HasOutParms]
	void OnQuickLoginNotify(struct FWakeupInfoWrapper& wakeupinfo); // Offset: 0x103a349b4 // Return & Params: Num(1) Size(0x50)

	// Object Name: Function Client.GameFrontendHUD.OnPlatformFriendNotify
	// Flags: [Final|RequiredAPI|Native|Public|HasOutParms]
	void OnPlatformFriendNotify(struct FPlatformFriendInfoMap& PlatformFriendInfoMap); // Offset: 0x103a348f8 // Return & Params: Num(1) Size(0x58)

	// Object Name: Function Client.GameFrontendHUD.OnNotUpdateFinished
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OnNotUpdateFinished(); // Offset: 0x103a348e4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GameFrontendHUD.OnLoginFlowNotify
	// Flags: [Final|RequiredAPI|Native|Public]
	void OnLoginFlowNotify(int _Flow, int _Param, struct FString ExtraData); // Offset: 0x103a347a0 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.GameFrontendHUD.OnHttpImgResponse
	// Flags: [Final|Native|Protected]
	void OnHttpImgResponse(struct UTexture2D* Texture, struct UImageDownloader* downloader); // Offset: 0x103a346ec // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.OnGroupNotify
	// Flags: [Final|RequiredAPI|Native|Public|HasOutParms]
	void OnGroupNotify(struct FGroupInfoWrapper& groupInfo); // Offset: 0x103a3463c // Return & Params: Num(1) Size(0x50)

	// Object Name: Function Client.GameFrontendHUD.OnGetTicketNotify
	// Flags: [Final|RequiredAPI|Native|Public]
	void OnGetTicketNotify(struct FString Ticket); // Offset: 0x103a34580 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.OnGetShortUrlNotify
	// Flags: [Final|RequiredAPI|Native|Public]
	void OnGetShortUrlNotify(int Ret, struct FString ShortUrl); // Offset: 0x103a34484 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.GameFrontendHUD.OnGetCountryNoNotify
	// Flags: [Final|RequiredAPI|Native|Public]
	void OnGetCountryNoNotify(int country); // Offset: 0x103a34408 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GameFrontendHUD.OnGenQRImgNotify
	// Flags: [Final|RequiredAPI|Native|Public]
	void OnGenQRImgNotify(int Ret, int Size, struct FString imgPath); // Offset: 0x103a342f8 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.GameFrontendHUD.OnGCloudNetStateChangeNotify
	// Flags: [Final|RequiredAPI|Native|Public]
	void OnGCloudNetStateChangeNotify(int State, int EventParam1, int EventParam2, int EventParam3); // Offset: 0x103a341d0 // Return & Params: Num(4) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.OnGameMasterEvent
	// Flags: [Final|RequiredAPI|Native|Public]
	void OnGameMasterEvent(struct FString EventName, int Ret); // Offset: 0x103a340d4 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.GameFrontendHUD.OnCheckUpdateStateFinished
	// Flags: [Final|Native|Private|HasOutParms]
	void OnCheckUpdateStateFinished(struct FDownloaderInfo& Info); // Offset: 0x103a34028 // Return & Params: Num(1) Size(0x40)

	// Object Name: Function Client.GameFrontendHUD.OnAreaChanged
	// Flags: [Final|Native|Public]
	void OnAreaChanged(struct FString InArea); // Offset: 0x103a33f90 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.NotifyLoadingUIOperation
	// Flags: [Final|Native|Public|BlueprintCallable]
	void NotifyLoadingUIOperation(int OperationType); // Offset: 0x103a33f14 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GameFrontendHUD.MakeToSuppotAdaptation
	// Flags: [Final|Native|Public]
	void MakeToSuppotAdaptation(struct UPanelSlot* PanelSlot); // Offset: 0x103a33e98 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.LuaDoString
	// Flags: [Native|Public|BlueprintCallable|Const]
	void LuaDoString(struct FString LuaString); // Offset: 0x103a33df8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.IsWindowOB
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsWindowOB(); // Offset: 0x103a33dc4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GameFrontendHUD.IsInstallPlatform
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsInstallPlatform(struct FString PlatForm); // Offset: 0x103a33cf8 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.GameFrontendHUD.IsCEHideLobbyUI
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsCEHideLobbyUI(); // Offset: 0x103a33cc4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GameFrontendHUD.HasAnyNetMsgToHandle
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool HasAnyNetMsgToHandle(); // Offset: 0x103a33c90 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GameFrontendHUD.GetWidgetRenderCanChange
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetWidgetRenderCanChange(); // Offset: 0x103a33c5c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GameFrontendHUD.GetUserSettings
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct USaveGame* GetUserSettings(); // Offset: 0x103a33c20 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetUpdater
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UGDolphinUpdater* GetUpdater(); // Offset: 0x103a33c04 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetTranslator
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UTranslator* GetTranslator(); // Offset: 0x103a33be8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetShouldShowAdaptTipInLobby
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetShouldShowAdaptTipInLobby(); // Offset: 0x103a33bb4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GameFrontendHUD.GetSettingSubsystem
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct USettingSubsystem* GetSettingSubsystem(); // Offset: 0x103a33b80 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetPufferDownloader
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UGCPufferDownloader* GetPufferDownloader(); // Offset: 0x103a33b64 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetPingReportInfo
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetPingReportInfo(); // Offset: 0x103a33b00 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.GetPacketLossReportInfo
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetPacketLossReportInfo(); // Offset: 0x103a33a9c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.GetLuaStateWrapper
	// Flags: [Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct ULuaStateWrapper* GetLuaStateWrapper(); // Offset: 0x103a33a68 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetLuaEventBridge
	// Flags: [Final|Native|Public]
	struct ULuaEventBridge* GetLuaEventBridge(); // Offset: 0x103a33a34 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetLuaBlueprintSysMgr
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct ULuaBlueprintMgr* GetLuaBlueprintSysMgr(); // Offset: 0x103a33a00 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetHttpWrapper
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UHttpWrapper* GetHttpWrapper(); // Offset: 0x103a339e4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetGVoiceInterface
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UGVoiceInterface* GetGVoiceInterface(); // Offset: 0x103a339a8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetGameSubMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetGameSubMode(); // Offset: 0x103a33970 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.GetGameState
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct AGameStateBase* GetGameState(); // Offset: 0x103a3393c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetFPSReportInfo
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetFPSReportInfo(); // Offset: 0x103a338d8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.GetEffectSettingMgr
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UEffectSettingMgr* GetEffectSettingMgr(); // Offset: 0x103a3389c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetDetailNetInfoFromGCloud
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetDetailNetInfoFromGCloud(); // Offset: 0x103a33868 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GameFrontendHUD.GetColorBlindnessMgr
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UColorBlindnessMgr* GetColorBlindnessMgr(); // Offset: 0x103a3382c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetClientNetObj
	// Flags: [Final|Native|Public|Const]
	struct UObject* GetClientNetObj(); // Offset: 0x103a337f8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetClientEnterBattleStage
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetClientEnterBattleStage(); // Offset: 0x103a337c0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.GetBugReporter
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UBugReporter* GetBugReporter(); // Offset: 0x103a3378c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetBattleUtils
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UBattleUtils* GetBattleUtils(); // Offset: 0x103a33758 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetBattleIDHexStr
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetBattleIDHexStr(); // Offset: 0x103a336f4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.GetAutoRunModID
	// Flags: [Final|Native|Public]
	int GetAutoRunModID(); // Offset: 0x103a336c0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GameFrontendHUD.GetAsyncLoadHelper
	// Flags: [Final|Native|Public]
	struct UAsyncLoadHelper* GetAsyncLoadHelper(); // Offset: 0x103a3368c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.FinishModifyUserSettings
	// Flags: [Final|Native|Public|BlueprintCallable]
	void FinishModifyUserSettings(); // Offset: 0x103a33678 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GameFrontendHUD.EnableFPSAndMemoryLog
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EnableFPSAndMemoryLog(bool bEnable); // Offset: 0x103a335f4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GameFrontendHUD.DispatchLongTimeNoOperation
	// Flags: [Final|Native|Public|HasOutParms]
	void DispatchLongTimeNoOperation(int& TimeOutCounter); // Offset: 0x103a33568 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GameFrontendHUD.DispatchConfirmMisKill
	// Flags: [Final|Native|Public]
	void DispatchConfirmMisKill(struct FString KillerName); // Offset: 0x103a334e0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.CreateBattleUtils
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CreateBattleUtils(); // Offset: 0x103a334cc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GameFrontendHUD.CallGlobalScriptFunction
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CallGlobalScriptFunction(struct FString InFunctionName); // Offset: 0x103a3342c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.BeginModifyUserSettings
	// Flags: [Final|Native|Public|BlueprintCallable]
	void BeginModifyUserSettings(); // Offset: 0x103a33418 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GameFrontendHUD.BattleUtilsGameEnd
	// Flags: [Final|Native|Public|BlueprintCallable]
	void BattleUtilsGameEnd(); // Offset: 0x103a33404 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GameFrontendHUD.AfterLoadedEditorLogin
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AfterLoadedEditorLogin(); // Offset: 0x103a333f0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GameFrontendHUD.AddAdaptationWidgetDelegateEx
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddAdaptationWidgetDelegateEx(struct UPanelSlot* PanelSlot); // Offset: 0x103a33374 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.AddAdaptationWidgetDelegate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddAdaptationWidgetDelegate(struct UPanelSlot* PanelSlot); // Offset: 0x103a332f8 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Client.GameFrontendUtils
// Size: 0x398 // Inherited bytes: 0x398
struct UGameFrontendUtils : UFrontendUtils {
};

// Object Name: Class Client.GameJoyInterface
// Size: 0x48 // Inherited bytes: 0x28
struct UGameJoyInterface : UObject {
	// Fields
	struct UGameFrontendHUD* GameFrontendHUD; // Offset: 0x28 // Size: 0x08
	char pad_0x30[0x18]; // Offset: 0x30 // Size: 0x18

	// Functions

	// Object Name: Function Client.GameJoyInterface.ShareVideo
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ShareVideo(int Channel); // Offset: 0x103a3c264 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GameJoyInterface.SetGameFrontendHUD
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetGameFrontendHUD(struct UGameFrontendHUD* InHUD); // Offset: 0x103a3c1e8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameJoyInterface.OnVideoShare
	// Flags: [Final|Native|Private]
	void OnVideoShare(struct FString Msg); // Offset: 0x103a3c12c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameJoyInterface.OnShowVideoPlayer
	// Flags: [Final|Native|Private]
	void OnShowVideoPlayer(int IsShow); // Offset: 0x103a3c0b0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GameJoyInterface.OnRecordingStart
	// Flags: [Final|Native|Private]
	void OnRecordingStart(int Status); // Offset: 0x103a3c034 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GameJoyInterface.OnRecordingEnd
	// Flags: [Final|Native|Private]
	void OnRecordingEnd(int64_t Duration); // Offset: 0x103a3bfb8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameJoyInterface.OnManualRecordingStart
	// Flags: [Final|Native|Private]
	void OnManualRecordingStart(int Status); // Offset: 0x103a3bf3c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GameJoyInterface.OnCheckSDKPermission
	// Flags: [Final|Native|Private]
	void OnCheckSDKPermission(bool IsSuccess); // Offset: 0x103a3beb8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GameJoyInterface.OnCheckSDKFeature
	// Flags: [Final|Native|Private]
	void OnCheckSDKFeature(int sdkFeatureInt); // Offset: 0x103a3be3c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GameJoyInterface.IsSDKFeatureSupport
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsSDKFeatureSupport(); // Offset: 0x103a3be08 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GameJoyInterface.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UGameJoyInterface* GetInstance(); // Offset: 0x103a3bdd4 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Client.GDolphinUpdater
// Size: 0x318 // Inherited bytes: 0x28
struct UGDolphinUpdater : UObject {
	// Fields
	char pad_0x28[0x50]; // Offset: 0x28 // Size: 0x50
	struct TMap<struct FString, struct FString> pakHashList; // Offset: 0x78 // Size: 0x50
	char pad_0xC8[0xc8]; // Offset: 0xc8 // Size: 0xc8
	bool AllowIOSBGDownload; // Offset: 0x190 // Size: 0x01
	bool AllowIOSBGDownloadPush; // Offset: 0x191 // Size: 0x01
	bool DisableJPKRBGDownloadNightPush; // Offset: 0x192 // Size: 0x01
	char pad_0x193[0x1]; // Offset: 0x193 // Size: 0x01
	int DisableJPKRBGDownloadNightPushAfterHour; // Offset: 0x194 // Size: 0x04
	int DisableJPKRBGDownloadNightPushBeforeHour; // Offset: 0x198 // Size: 0x04
	int IOSBGDownloadPushDelaySeconds; // Offset: 0x19c // Size: 0x04
	bool EnableRandomBackupURL; // Offset: 0x1a0 // Size: 0x01
	bool EnablePufferUpdate; // Offset: 0x1a1 // Size: 0x01
	char pad_0x1A2[0x16]; // Offset: 0x1a2 // Size: 0x16
	struct FString UpdateInfoPath; // Offset: 0x1b8 // Size: 0x10
	bool OpenDebugLog; // Offset: 0x1c8 // Size: 0x01
	char pad_0x1C9[0x14f]; // Offset: 0x1c9 // Size: 0x14f

	// Functions

	// Object Name: Function Client.GDolphinUpdater.StartAppUpdate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StartAppUpdate(); // Offset: 0x103a3cd10 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GDolphinUpdater.SetEnableCDNGetVersion
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetEnableCDNGetVersion(bool Enable); // Offset: 0x103a3cc8c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GDolphinUpdater.OnUpdateError
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OnUpdateError(int curVersionStage, int ErrorCode); // Offset: 0x103a3cbd8 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.GDolphinUpdater.OnDolphinBGDownloadDone
	// Flags: [Final|Native|Public]
	void OnDolphinBGDownloadDone(); // Offset: 0x103a3cbc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GDolphinUpdater.OnAreaChanged
	// Flags: [Final|Native|Private]
	void OnAreaChanged(struct FString InArea); // Offset: 0x103a3cb2c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GDolphinUpdater.IsUpdating
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsUpdating(); // Offset: 0x103a3caf8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GDolphinUpdater.IsGrayUpdate
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsGrayUpdate(); // Offset: 0x103a3cac4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GDolphinUpdater.IsExamine
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsExamine(); // Offset: 0x103a3ca90 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GDolphinUpdater.Install
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Install(); // Offset: 0x103a3ca7c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GDolphinUpdater.GetTotalValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetTotalValue(); // Offset: 0x103a3ca48 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GDolphinUpdater.GetCurValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetCurValue(); // Offset: 0x103a3ca14 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GDolphinUpdater.GetCurStage
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	int GetCurStage(float& percent, int& GetCurVal, int& GetMaxVal); // Offset: 0x103a3c8d8 // Return & Params: Num(4) Size(0x10)

	// Object Name: Function Client.GDolphinUpdater.GetCurPercent
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetCurPercent(); // Offset: 0x103a3c8a4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GDolphinUpdater.GetChannelIDWithHUD
	// Flags: [Final|Native|Private]
	uint32_t GetChannelIDWithHUD(struct UGameFrontendHUD* InGameFrontendHUD); // Offset: 0x103a3c818 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.GDolphinUpdater.GetChannelID
	// Flags: [Final|Native|Private]
	uint32_t GetChannelID(); // Offset: 0x103a3c7e4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GDolphinUpdater.FinishUpdate
	// Flags: [Final|Native|Public]
	void FinishUpdate(); // Offset: 0x103a3c7d0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GDolphinUpdater.FinishPufferUpdate
	// Flags: [Final|Native|Public]
	void FinishPufferUpdate(); // Offset: 0x103a3c7bc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GDolphinUpdater.EnableIOSBGDownload4G
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EnableIOSBGDownload4G(bool bEnableCellularAccess); // Offset: 0x103a3c738 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GDolphinUpdater.EnableCDNGetVersion
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool EnableCDNGetVersion(); // Offset: 0x103a3c704 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GDolphinUpdater.ContinueUpdate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ContinueUpdate(); // Offset: 0x103a3c6f0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GDolphinUpdater.CancelUpdate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CancelUpdate(); // Offset: 0x103a3c6dc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GDolphinUpdater.CancelAppUpdate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CancelAppUpdate(); // Offset: 0x103a3c6c8 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Client.IMSDKNotice
// Size: 0xa8 // Inherited bytes: 0x28
struct UIMSDKNotice : UObject {
	// Fields
	char pad_0x28[0x80]; // Offset: 0x28 // Size: 0x80

	// Functions

	// Object Name: Function Client.IMSDKNotice.GetNotice
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct TArray<struct FIMSDKNoticeInfo> GetNotice(struct FString Scene); // Offset: 0x103a3dc44 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.IMSDKNotice.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UIMSDKNotice* GetInstance(); // Offset: 0x103a3dc10 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.IMSDKNotice.ClearNotice
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearNotice(); // Offset: 0x103a3dbfc // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Client.AvatarItemDownloadPuffer
// Size: 0x30 // Inherited bytes: 0x30
struct UAvatarItemDownloadPuffer : UAvatarItemDownload {
	// Functions

	// Object Name: Function Client.AvatarItemDownloadPuffer.StartDownloadItem
	// Flags: [Native|Public]
	void StartDownloadItem(uint32_t ItemId, uint32_t Priority, DelegateProperty OnItemDownloadDelegate); // Offset: 0x103a3e448 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.AvatarItemDownloadPuffer.StartBatchDownloadItem
	// Flags: [Native|Public]
	void StartBatchDownloadItem(struct TArray<uint32_t> ItemIDs, uint32_t Priority, DelegateProperty OnBatchItemDownloadDelegate); // Offset: 0x103a3e2c8 // Return & Params: Num(3) Size(0x28)
};

// Object Name: Class Client.GCPufferDownloader
// Size: 0x440 // Inherited bytes: 0x28
struct UGCPufferDownloader : UObject {
	// Fields
	char pad_0x28[0x2c8]; // Offset: 0x28 // Size: 0x2c8
	bool Disable; // Offset: 0x2f0 // Size: 0x01
	char pad_0x2F1[0x97]; // Offset: 0x2f1 // Size: 0x97
	struct FString DownloadDir; // Offset: 0x388 // Size: 0x10
	struct FString PufferTmpDir; // Offset: 0x398 // Size: 0x10
	uint32_t CleanFlagVer; // Offset: 0x3a8 // Size: 0x04
	char pad_0x3AC[0x4]; // Offset: 0x3ac // Size: 0x04
	struct TArray<struct FString> CleanFileNamePattern; // Offset: 0x3b0 // Size: 0x10
	bool PreFetchPakEnable; // Offset: 0x3c0 // Size: 0x01
	bool PreFetchFileClearEnable; // Offset: 0x3c1 // Size: 0x01
	bool PreFetchConvertEnable; // Offset: 0x3c2 // Size: 0x01
	char pad_0x3C3[0x5]; // Offset: 0x3c3 // Size: 0x05
	struct TArray<struct FString> PreFetchPakNames; // Offset: 0x3c8 // Size: 0x10
	uint32_t PreFetchReserveredDiskSpace; // Offset: 0x3d8 // Size: 0x04
	bool PreFetchODPak_Enable; // Offset: 0x3dc // Size: 0x01
	char pad_0x3DD[0x3]; // Offset: 0x3dd // Size: 0x03
	int PreFetchODPaks_MaxNum; // Offset: 0x3e0 // Size: 0x04
	int PreFetchODPaks_BatchSize; // Offset: 0x3e4 // Size: 0x04
	int PreFetchODPaks_FetchedNum; // Offset: 0x3e8 // Size: 0x04
	int PreFetchODPaks_FetchedIndex; // Offset: 0x3ec // Size: 0x04
	struct TArray<struct FString> PreFetchODPaks_Filenames; // Offset: 0x3f0 // Size: 0x10
	bool AllowIOSBGDownload; // Offset: 0x400 // Size: 0x01
	bool AllowIOSBGDownloadPush; // Offset: 0x401 // Size: 0x01
	bool DisableJPKRBGDownloadNightPush; // Offset: 0x402 // Size: 0x01
	char pad_0x403[0x1]; // Offset: 0x403 // Size: 0x01
	int DisableJPKRBGDownloadNightPushAfterHour; // Offset: 0x404 // Size: 0x04
	int DisableJPKRBGDownloadNightPushBeforeHour; // Offset: 0x408 // Size: 0x04
	int IOSBGDownloadPushDelaySeconds; // Offset: 0x40c // Size: 0x04
	bool DisableBGDownloadNotification; // Offset: 0x410 // Size: 0x01
	char pad_0x411[0x3]; // Offset: 0x411 // Size: 0x03
	float PreFetchODPaks_StartTime; // Offset: 0x414 // Size: 0x04
	struct FString PreFetchODPaks_ConfigName; // Offset: 0x418 // Size: 0x10
	char pad_0x428[0x18]; // Offset: 0x428 // Size: 0x18

	// Functions

	// Object Name: Function Client.GCPufferDownloader.StopTask
	// Flags: [Final|Native|Public]
	bool StopTask(uint64 TaskId); // Offset: 0x103a40a94 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.GCPufferDownloader.StopMergeBinDiffPak
	// Flags: [Final|Native|Public]
	int StopMergeBinDiffPak(int outterTaskID); // Offset: 0x103a40a08 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.GCPufferDownloader.StopCheckDownloadFileFraming
	// Flags: [Final|Native|Public]
	bool StopCheckDownloadFileFraming(int outterTaskID); // Offset: 0x103a4097c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Client.GCPufferDownloader.StopBGDownloadNotification
	// Flags: [Final|Native|Public]
	void StopBGDownloadNotification(); // Offset: 0x103a40968 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GCPufferDownloader.StopAllTask
	// Flags: [Final|Native|Public]
	bool StopAllTask(); // Offset: 0x103a40934 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GCPufferDownloader.StartDownloadItem
	// Flags: [Final|Native|Public]
	void StartDownloadItem(uint32_t ItemId, uint32_t Priority, DelegateProperty downloadDelegate); // Offset: 0x103a40830 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.GCPufferDownloader.StartBGDownloadNotification
	// Flags: [Final|Native|Public]
	void StartBGDownloadNotification(uint64 InDownloadedSize); // Offset: 0x103a407b4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GCPufferDownloader.StartBatchDownloadItem
	// Flags: [Final|Native|Public]
	void StartBatchDownloadItem(struct TArray<uint32_t> ItemIDs, uint32_t Priority, DelegateProperty OnBatchItemDownloadDelegate); // Offset: 0x103a4063c // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.GCPufferDownloader.SetTempProductIdBase
	// Flags: [Final|Native|Public]
	void SetTempProductIdBase(int ProductIdRaw); // Offset: 0x103a405c0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GCPufferDownloader.SetTempProductId
	// Flags: [Final|Native|Public]
	void SetTempProductId(struct FString ProductIdRaw); // Offset: 0x103a40504 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GCPufferDownloader.SetPrefetchConfig
	// Flags: [Final|Native|Public]
	void SetPrefetchConfig(bool pakEnable, bool fileClearEnable, bool convertEnable, int reserveredDiskSpace, struct FString FileList, int InPreFetchODPaksMaxNum, int InPreFetchODPaksBatchSize); // Offset: 0x103a402b0 // Return & Params: Num(7) Size(0x20)

	// Object Name: Function Client.GCPufferDownloader.SetIOSBGDownloadAttribute
	// Flags: [Final|Native|Public]
	void SetIOSBGDownloadAttribute(bool bEnableCellularAccess, bool bEnableResumeData, int nMinFileSize, int nMaxTasks); // Offset: 0x103a4016c // Return & Params: Num(4) Size(0xc)

	// Object Name: Function Client.GCPufferDownloader.SetImmDLMaxSpeed
	// Flags: [Final|Native|Public]
	bool SetImmDLMaxSpeed(uint64 MaxSpeed); // Offset: 0x103a400e0 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.GCPufferDownloader.ReturnSplitMiniPakFilelist_LuaState
	// Flags: [Final|Native|Static|Public]
	int ReturnSplitMiniPakFilelist_LuaState(); // Offset: 0x103a400c8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GCPufferDownloader.ReturnLocalFiles_LuaState
	// Flags: [Final|Native|Static|Public]
	int ReturnLocalFiles_LuaState(); // Offset: 0x103a400b0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GCPufferDownloader.RequestFile
	// Flags: [Final|Native|Public]
	uint64 RequestFile(struct FString FilePath, bool ForceUpdate); // Offset: 0x103a3ff9c // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.GCPufferDownloader.RemountPakFiles
	// Flags: [Final|Native|Public]
	bool RemountPakFiles(); // Offset: 0x103a3ff68 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GCPufferDownloader.ReadFile
	// Flags: [Final|Native|Public]
	struct FString ReadFile(struct FString Filename); // Offset: 0x103a3fe74 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.GCPufferDownloader.PreFetchPakFiles
	// Flags: [Final|Native|Public]
	bool PreFetchPakFiles(); // Offset: 0x103a3fe40 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GCPufferDownloader.PreFetchODPakFilesUpdate
	// Flags: [Final|Native|Public]
	int PreFetchODPakFilesUpdate(); // Offset: 0x103a3fe0c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GCPufferDownloader.PreFetchODPakFilesPreProcess
	// Flags: [Final|Native|Public]
	bool PreFetchODPakFilesPreProcess(bool Start); // Offset: 0x103a3fd78 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function Client.GCPufferDownloader.PreFetchODPakFilesPostProcess
	// Flags: [Final|Native|Public]
	bool PreFetchODPakFilesPostProcess(int ErrorCode); // Offset: 0x103a3fcec // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Client.GCPufferDownloader.PreFetchODPakFiles
	// Flags: [Final|Native|Public]
	bool PreFetchODPakFiles(bool Start); // Offset: 0x103a3fc58 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function Client.GCPufferDownloader.OnItemDownloadedInFighting
	// Flags: [Final|Native|Public]
	void OnItemDownloadedInFighting(struct FString PackHash, struct FString ErrorCode); // Offset: 0x103a3fb24 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.GCPufferDownloader.OnHashGenerateFinished
	// Flags: [Final|Native|Public]
	void OnHashGenerateFinished(int outterTaskID, struct FString hashCode); // Offset: 0x103a3fa28 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.GCPufferDownloader.MoveFileTo
	// Flags: [Final|Native|Public]
	int MoveFileTo(struct FString Filename, struct FString from, struct FString to); // Offset: 0x103a3f86c // Return & Params: Num(4) Size(0x34)

	// Object Name: Function Client.GCPufferDownloader.MoveFile
	// Flags: [Final|Native|Public]
	int MoveFile(struct FString from, struct FString to); // Offset: 0x103a3f728 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function Client.GCPufferDownloader.MergeBinDiffPak
	// Flags: [Final|Native|Public]
	int MergeBinDiffPak(int outterTaskID, struct FString PakFilenameOld, struct FString PakFilenameDiff, struct FString PakFilenameNew, bool fast); // Offset: 0x103a3f4e4 // Return & Params: Num(6) Size(0x40)

	// Object Name: Function Client.GCPufferDownloader.IsODPaks
	// Flags: [Final|Native|Public]
	bool IsODPaks(struct FString FilePath); // Offset: 0x103a3f418 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.GCPufferDownloader.IsODFileExists
	// Flags: [Final|Native|Public]
	bool IsODFileExists(struct FString Path); // Offset: 0x103a3f370 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.GCPufferDownloader.IsInitSuccess
	// Flags: [Final|Native|Public]
	bool IsInitSuccess(); // Offset: 0x103a3f33c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GCPufferDownloader.IsFileReady
	// Flags: [Final|Native|Public]
	bool IsFileReady(struct FString FilePath); // Offset: 0x103a3f270 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.GCPufferDownloader.IsFileExist
	// Flags: [Final|Native|Public]
	bool IsFileExist(struct FString Filename, struct FString extension); // Offset: 0x103a3f12c // Return & Params: Num(3) Size(0x21)

	// Object Name: Function Client.GCPufferDownloader.InitializeODPaks
	// Flags: [Final|Native|Public]
	bool InitializeODPaks(); // Offset: 0x103a3f0f8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GCPufferDownloader.GetTempWorkPath
	// Flags: [Final|Native|Public]
	struct FString GetTempWorkPath(); // Offset: 0x103a3f094 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GCPufferDownloader.GetProductIDBase
	// Flags: [Final|Native|Public|HasOutParms]
	void GetProductIDBase(struct TArray<int>& ProductIDs); // Offset: 0x103a3efec // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GCPufferDownloader.GetProductID
	// Flags: [Final|Native|Public|HasOutParms]
	void GetProductID(struct TArray<int>& ProductIDs); // Offset: 0x103a3ef44 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GCPufferDownloader.GetODPakNum
	// Flags: [Final|Native|Public]
	int GetODPakNum(); // Offset: 0x103a3ef10 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GCPufferDownloader.GetODPakName
	// Flags: [Final|Native|Public]
	struct FString GetODPakName(struct FString Path); // Offset: 0x103a3ee40 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.GCPufferDownloader.GetInitErrcode
	// Flags: [Final|Native|Public]
	uint32_t GetInitErrcode(); // Offset: 0x103a3ee0c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GCPufferDownloader.GetFileSizeCompressed
	// Flags: [Final|Native|Public]
	uint64 GetFileSizeCompressed(struct FString FilePath); // Offset: 0x103a3ed40 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.GCPufferDownloader.GetFileSize
	// Flags: [Final|Native|Public]
	float GetFileSize(struct FString Filename); // Offset: 0x103a3ec74 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.GCPufferDownloader.GetDownloadPath
	// Flags: [Final|Native|Public]
	struct FString GetDownloadPath(); // Offset: 0x103a3ec10 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GCPufferDownloader.GetCurrentSpeed
	// Flags: [Final|Native|Public]
	float GetCurrentSpeed(); // Offset: 0x103a3ebdc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GCPufferDownloader.GetBatchODPaksDownloadList_LuaState
	// Flags: [Final|Native|Public]
	int GetBatchODPaksDownloadList_LuaState(); // Offset: 0x103a3ebc4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GCPufferDownloader.EnableUseOldInterface
	// Flags: [Final|Native|Public]
	void EnableUseOldInterface(bool Enable); // Offset: 0x103a3eb40 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GCPufferDownloader.DeleteFileEvenIfUnfinished
	// Flags: [Final|Native|Public]
	bool DeleteFileEvenIfUnfinished(struct FString FilePath); // Offset: 0x103a3ea74 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.GCPufferDownloader.DeleteFile
	// Flags: [Final|Native|Static|Public]
	bool DeleteFile(struct FString fullPath); // Offset: 0x103a3e9b8 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.GCPufferDownloader.ConvertPreFetchFiles
	// Flags: [Final|Native|Public]
	bool ConvertPreFetchFiles(); // Offset: 0x103a3e984 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GCPufferDownloader.ConvertItemIdToPakName
	// Flags: [Final|Native|Public]
	struct FString ConvertItemIdToPakName(uint32_t ItemId); // Offset: 0x103a3e8d0 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.GCPufferDownloader.ClearUselessODPaks
	// Flags: [Final|Native|Public]
	bool ClearUselessODPaks(); // Offset: 0x103a3e89c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GCPufferDownloader.ClearPreFetchODPaksFiles
	// Flags: [Final|Native|Public]
	bool ClearPreFetchODPaksFiles(); // Offset: 0x103a3e868 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GCPufferDownloader.ClearPreFetchFiles
	// Flags: [Final|Native|Public]
	bool ClearPreFetchFiles(); // Offset: 0x103a3e834 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GCPufferDownloader.CheckDownloadFileFraming
	// Flags: [Final|Native|Public]
	bool CheckDownloadFileFraming(int outterTaskID, struct FString Filename, int chunkSize); // Offset: 0x103a3e6e8 // Return & Params: Num(4) Size(0x1d)
};

// Object Name: Class Client.GMLogShare
// Size: 0x30 // Inherited bytes: 0x28
struct UGMLogShare : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08

	// Functions

	// Object Name: Function Client.GMLogShare.ShareLogFile
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ShareLogFile(); // Offset: 0x103a41bb4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GMLogShare.Init
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void Init(); // Offset: 0x103a41ba0 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Client.GVoiceInterface
// Size: 0x278 // Inherited bytes: 0x28
struct UGVoiceInterface : UObject {
	// Fields
	char pad_0x28[0x9c]; // Offset: 0x28 // Size: 0x9c
	int lbsRoomMemberID; // Offset: 0xc4 // Size: 0x04
	char pad_0xC8[0x38]; // Offset: 0xc8 // Size: 0x38
	DelegateProperty CheckTempLbsRoomOnJoinRoom; // Offset: 0x100 // Size: 0x10
	DelegateProperty CheckTempLbsRoomOnQuitRoom; // Offset: 0x110 // Size: 0x10
	DelegateProperty OnSTTReportCallback; // Offset: 0x120 // Size: 0x10
	DelegateProperty OnRSTSCallback; // Offset: 0x130 // Size: 0x10
	DelegateProperty OnMuteSwitchResultCallback; // Offset: 0x140 // Size: 0x10
	struct FString ServerInfo; // Offset: 0x150 // Size: 0x10
	uint32_t openGvoiceLog; // Offset: 0x160 // Size: 0x04
	uint32_t MicVolumeMUFactor; // Offset: 0x164 // Size: 0x04
	uint32_t SpeekerVolumeMUFactor; // Offset: 0x168 // Size: 0x04
	char pad_0x16C[0x14]; // Offset: 0x16c // Size: 0x14
	struct UGameFrontendHUD* GameFrontendHUD; // Offset: 0x180 // Size: 0x08
	char pad_0x188[0xf0]; // Offset: 0x188 // Size: 0xf0

	// Functions

	// Object Name: Function Client.GVoiceInterface.UploadRecordFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UploadRecordFile(); // Offset: 0x103a43de4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.TestMic
	// Flags: [Final|Native|Public|BlueprintCallable]
	void TestMic(); // Offset: 0x103a43dd0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.TeamSpeakerEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool TeamSpeakerEnable(); // Offset: 0x103a43db4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.TeamMicphoneEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool TeamMicphoneEnable(); // Offset: 0x103a43d98 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.SwitchMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SwitchMode(enum class ECharacterMainType CharMode); // Offset: 0x103a43d1c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.SwitchMicphoneWhenCorpsMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SwitchMicphoneWhenCorpsMode(); // Offset: 0x103a43d08 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.SwitchCampRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SwitchCampRoom(enum class ECharacterMainType campMode); // Offset: 0x103a43c8c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.StopRecord
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StopRecord(); // Offset: 0x103a43c78 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.StopPlayRecordFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StopPlayRecordFile(); // Offset: 0x103a43c64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.StopInterphone
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StopInterphone(); // Offset: 0x103a43c50 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.StopCampMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StopCampMode(); // Offset: 0x103a43c3c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.StartRecord
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StartRecord(); // Offset: 0x103a43c28 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.StartInterphone
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StartInterphone(); // Offset: 0x103a43c14 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.StartCampMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StartCampMode(struct FString ZombieCampRoomName, struct FString ManCampRoomName, struct FString userId); // Offset: 0x103a43ad4 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.GVoiceInterface.SpeechToText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SpeechToText(); // Offset: 0x103a43ac0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.ShowOpenSpeakerAtFirstMsg
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ShowOpenSpeakerAtFirstMsg(); // Offset: 0x103a43aac // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.ShowCorpsModeCannotUseLBSVoice
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ShowCorpsModeCannotUseLBSVoice(); // Offset: 0x103a43a98 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.SetVoiceMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVoiceMode(int Type); // Offset: 0x103a43a1c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.SetSpeakerVolum
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSpeakerVolum(float Value); // Offset: 0x103a439a0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.SetSpeakerStatus
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSpeakerStatus(bool Flag); // Offset: 0x103a4391c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.SetReportBufferTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetReportBufferTime(int nTimeSec); // Offset: 0x103a438a0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.SetPlayerVolume
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPlayerVolume(struct FString InPlayerid, int InVol); // Offset: 0x103a437a4 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.GVoiceInterface.SetMicphoneVolum
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMicphoneVolum(float Value); // Offset: 0x103a43728 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.SetMicphoneStatus
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMicphoneStatus(bool Flag); // Offset: 0x103a436a4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.SetLbsVoiceRadius
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLbsVoiceRadius(float Radius); // Offset: 0x103a4362c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.SetLbsRoomEnableStatus
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLbsRoomEnableStatus(bool Flag); // Offset: 0x103a435a8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.SetGameFrontendHUD
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetGameFrontendHUD(struct UGameFrontendHUD* InHUD); // Offset: 0x103a4352c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GVoiceInterface.SetCurrentDownloadFieldID
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetCurrentDownloadFieldID(struct FString filedId); // Offset: 0x103a43470 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GVoiceInterface.SetAllVoiceStatus
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAllVoiceStatus(bool Flag); // Offset: 0x103a433ec // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.ResetWhenLogOut
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ResetWhenLogOut(); // Offset: 0x103a433d8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.ReportPlayers
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool ReportPlayers(struct FString InExtraInfo, struct TArray<struct FString> InOpenids); // Offset: 0x103a43274 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function Client.GVoiceInterface.ReportFileForAbroad
	// Flags: [Final|Native|Public|BlueprintCallable]
	int ReportFileForAbroad(struct FString InFilePath, bool InTranslate, bool InChangeVoice, int InTime); // Offset: 0x103a430f4 // Return & Params: Num(5) Size(0x1c)

	// Object Name: Function Client.GVoiceInterface.ReactiveLbsStatus
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ReactiveLbsStatus(); // Offset: 0x103a430e0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.QuitTempLbsRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	void QuitTempLbsRoom(struct FString roomStr); // Offset: 0x103a43024 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GVoiceInterface.QuitRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	void QuitRoom(); // Offset: 0x103a43010 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.PlayRecordFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	void PlayRecordFile(); // Offset: 0x103a42ffc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.OpenTeamSpeakerOnly
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OpenTeamSpeakerOnly(bool ShowTips); // Offset: 0x103a42f78 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.OpenTeamMicphoneOnly
	// Flags: [Final|Native|Public|BlueprintCallable]
	int OpenTeamMicphoneOnly(bool ShowTips); // Offset: 0x103a42ee4 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.GVoiceInterface.OpenTeamInterphone
	// Flags: [Final|Native|Public|BlueprintCallable]
	int OpenTeamInterphone(); // Offset: 0x103a42eb0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.OpenSpeakerByTempLbs
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OpenSpeakerByTempLbs(bool Open); // Offset: 0x103a42e2c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.OpenSpeaker
	// Flags: [Final|Native|Public|BlueprintCallable]
	int OpenSpeaker(); // Offset: 0x103a42df8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.OpenMicByTempLbs
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OpenMicByTempLbs(bool Open); // Offset: 0x103a42d74 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.OpenMicAndSpeakerAfterJoinLbsRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OpenMicAndSpeakerAfterJoinLbsRoom(); // Offset: 0x103a42d60 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.OpenMic
	// Flags: [Final|Native|Public|BlueprintCallable]
	int OpenMic(); // Offset: 0x103a42d2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.OpenIngameSpeaker
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OpenIngameSpeaker(); // Offset: 0x103a42d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.OpenIngameMicphone
	// Flags: [Final|Native|Public|BlueprintCallable]
	int OpenIngameMicphone(); // Offset: 0x103a42ce4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.OpenAllSpeaker
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OpenAllSpeaker(bool ShowTips); // Offset: 0x103a42c60 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.OpenAllMicphone
	// Flags: [Final|Native|Public|BlueprintCallable]
	int OpenAllMicphone(bool ShowTips); // Offset: 0x103a42bcc // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.GVoiceInterface.OpenAllInterphone
	// Flags: [Final|Native|Public|BlueprintCallable]
	int OpenAllInterphone(); // Offset: 0x103a42b98 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.OnRoomTypeChanged
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OnRoomTypeChanged(struct FString itemtext); // Offset: 0x103a42adc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GVoiceInterface.OnResume
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OnResume(); // Offset: 0x103a42ac8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.OnPause
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OnPause(); // Offset: 0x103a42ab4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.LbsSpeakerEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool LbsSpeakerEnable(); // Offset: 0x103a42a98 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.LbsMicphoneEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool LbsMicphoneEnable(); // Offset: 0x103a42a7c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.JoinTempLbsRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	void JoinTempLbsRoom(struct FString Room, struct FString userId); // Offset: 0x103a42948 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.GVoiceInterface.JoinRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	void JoinRoom(struct FString Room, struct FString userId); // Offset: 0x103a42814 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.GVoiceInterface.JoinLbsRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	void JoinLbsRoom(struct FString lbsRoom, struct FString userId); // Offset: 0x103a426e0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.GVoiceInterface.IsTeamInterphoneOpenned
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsTeamInterphoneOpenned(); // Offset: 0x103a426c4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.IsLbsInterphoneOpenned
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsLbsInterphoneOpenned(); // Offset: 0x103a426a8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.IsInterphoneMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsInterphoneMode(); // Offset: 0x103a42674 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.InitGVoiceComponent
	// Flags: [Final|Native|Public|BlueprintCallable]
	void InitGVoiceComponent(struct FString userId); // Offset: 0x103a425b8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GVoiceInterface.HaveTeamRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool HaveTeamRoom(); // Offset: 0x103a42584 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.HaveLbsRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool HaveLbsRoom(); // Offset: 0x103a42550 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.GetVoiceLength
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetVoiceLength(); // Offset: 0x103a4251c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.GetPlayerVolume
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetPlayerVolume(struct FString InPlayerid); // Offset: 0x103a42450 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.GVoiceInterface.GetAuthKey
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GetAuthKey(); // Offset: 0x103a4243c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.GetAudioDeviceConnectionState
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetAudioDeviceConnectionState(); // Offset: 0x103a42408 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.ForbidTeammateVoiceById
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ForbidTeammateVoiceById(int memberID, bool IsEnable); // Offset: 0x103a4234c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Client.GVoiceInterface.EnbleMicAndSpeakerByRoomName
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EnbleMicAndSpeakerByRoomName(struct FString roomName, bool Enable); // Offset: 0x103a42240 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.GVoiceInterface.EnableReportForAbroad
	// Flags: [Final|Native|Public|BlueprintCallable]
	int EnableReportForAbroad(bool InIsWholeRoundaudit); // Offset: 0x103a421ac // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.GVoiceInterface.EnableReportALLAbroad
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool EnableReportALLAbroad(bool InEnable, bool InWithEncryption, int InTimeout); // Offset: 0x103a42090 // Return & Params: Num(4) Size(0x9)

	// Object Name: Function Client.GVoiceInterface.DownloadRecordFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	void DownloadRecordFile(); // Offset: 0x103a4207c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.CommonTestMic
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CommonTestMic(); // Offset: 0x103a42068 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.CloseSpeaker
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CloseSpeaker(); // Offset: 0x103a42054 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.CloseMic
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CloseMic(); // Offset: 0x103a42040 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.CloseIngameSpeaker
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CloseIngameSpeaker(); // Offset: 0x103a4202c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.CloseIngameMicphone
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CloseIngameMicphone(); // Offset: 0x103a42018 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.CloseAllSpeaker
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CloseAllSpeaker(bool ShowTips); // Offset: 0x103a41f94 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.CloseAllMicphone
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CloseAllMicphone(bool ShowTips); // Offset: 0x103a41f10 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.CheckDeviceMuteState
	// Flags: [Final|Native|Public|BlueprintCallable]
	int CheckDeviceMuteState(); // Offset: 0x103a41edc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.CheckAndEnableRoomSpeaker
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CheckAndEnableRoomSpeaker(); // Offset: 0x103a41ec8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.ChatShowAgeRestrictionMsgInLobby
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ChatShowAgeRestrictionMsgInLobby(); // Offset: 0x103a41eb4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.ChatShowAgeRestrictionMsgInFighting
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ChatShowAgeRestrictionMsgInFighting(); // Offset: 0x103a41ea0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.ChatShowAgeRestrictionMsgInChat
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ChatShowAgeRestrictionMsgInChat(); // Offset: 0x103a41e8c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.ChatRequestPrivacyInSetting
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ChatRequestPrivacyInSetting(); // Offset: 0x103a41e78 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.ChatRequestPrivacyInGame
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ChatRequestPrivacyInGame(); // Offset: 0x103a41e64 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Client.HttpWrapper
// Size: 0xa0 // Inherited bytes: 0x28
struct UHttpWrapper : UObject {
	// Fields
	struct FScriptMulticastDelegate OnResponseEvent; // Offset: 0x28 // Size: 0x10
	char pad_0x38[0x68]; // Offset: 0x38 // Size: 0x68

	// Functions

	// Object Name: Function Client.HttpWrapper.SimplePostForLua
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SimplePostForLua(struct FString URL, struct FString Content, int Priority, int QueueType); // Offset: 0x103a49178 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function Client.HttpWrapper.SetQueueSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetQueueSize(int QueueType, int InSize); // Offset: 0x103a490c4 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.HttpWrapper.SetQueueEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetQueueEnable(bool InEnableQueue); // Offset: 0x103a49044 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.HttpWrapper.SetPoolEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPoolEnable(bool InEnablePool); // Offset: 0x103a48fbc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.HttpWrapper.RequestForLua
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	int RequestForLua(struct FString URL, struct FString Verb, struct TMap<struct FString, struct FString>& Headers, struct FString Content, int Priority, int QueueType); // Offset: 0x103a48d80 // Return & Params: Num(7) Size(0x8c)

	// Object Name: Function Client.HttpWrapper.GetQueueEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetQueueEnable(); // Offset: 0x103a48d64 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.HttpWrapper.GetPoolEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetPoolEnable(); // Offset: 0x103a48d38 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.HttpWrapper.GetInternalIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetInternalIndex(); // Offset: 0x103a48d1c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.HttpWrapper.CancelRequestAll
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CancelRequestAll(int QueueType); // Offset: 0x103a48ca0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.HttpWrapper.CancelRequest
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CancelRequest(int QueueType, int ReqIndex); // Offset: 0x103a48bec // Return & Params: Num(2) Size(0x8)
};

// Object Name: Class Client.ImageDownloader
// Size: 0xb0 // Inherited bytes: 0x28
struct UImageDownloader : UObject {
	// Fields
	struct FScriptMulticastDelegate OnSuccess; // Offset: 0x28 // Size: 0x10
	struct FScriptMulticastDelegate OnFail; // Offset: 0x38 // Size: 0x10
	struct FString FileURL; // Offset: 0x48 // Size: 0x10
	struct FString CompreesedFileUrl; // Offset: 0x58 // Size: 0x10
	struct FString FileSavePath; // Offset: 0x68 // Size: 0x10
	struct FString CompreesedFileSavePath; // Offset: 0x78 // Size: 0x10
	struct FString UrlHash; // Offset: 0x88 // Size: 0x10
	struct FString CompreesedUrlHash; // Offset: 0x98 // Size: 0x10
	bool InvalidImageFormat; // Offset: 0xa8 // Size: 0x01
	bool SaveDiskFile; // Offset: 0xa9 // Size: 0x01
	bool ForceUpdate; // Offset: 0xaa // Size: 0x01
	char pad_0xAB[0x5]; // Offset: 0xab // Size: 0x05

	// Functions

	// Object Name: Function Client.ImageDownloader.Start
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Start(struct FString URL); // Offset: 0x103a49818 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ImageDownloader.MakeDownloaderInGame
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UImageDownloader* MakeDownloaderInGame(); // Offset: 0x103a497e4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ImageDownloader.MakeDownloader
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UImageDownloader* MakeDownloader(); // Offset: 0x103a497b0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ImageDownloader.GetTextureFromUrlWithoutDownload
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UTexture2D* GetTextureFromUrlWithoutDownload(struct FString URL); // Offset: 0x103a496e4 // Return & Params: Num(2) Size(0x18)
};

// Object Name: Class Client.InGameUIManager
// Size: 0x360 // Inherited bytes: 0x170
struct UInGameUIManager : UGameBusinessManager {
	// Fields
	char pad_0x170[0x8]; // Offset: 0x170 // Size: 0x08
	struct TArray<struct UObject*> InGameUIList; // Offset: 0x178 // Size: 0x10
	char pad_0x188[0x68]; // Offset: 0x188 // Size: 0x68
	struct TMap<struct FString, struct TWeakObjectPtr<struct UUAEUserWidget>> WidgetsMap; // Offset: 0x1f0 // Size: 0x50
	struct TMap<int, struct FDynamicWidgetAsyncLoadData> PendingAsyncLoadRequests; // Offset: 0x240 // Size: 0x50
	char pad_0x290[0xd0]; // Offset: 0x290 // Size: 0xd0

	// Functions

	// Object Name: Function Client.InGameUIManager.SubUIWidgetListWithMountData
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SubUIWidgetListWithMountData(struct TArray<struct FInGameWidgetData>& InGameWidgetDataList, struct TArray<struct FString>& GameStatusStrList, bool InPersistentUI, bool InUsedByControler, bool InOberverOnly, int inUIControlState); // Offset: 0x103a4a690 // Return & Params: Num(6) Size(0x28)

	// Object Name: Function Client.InGameUIManager.SubUIWidgetList
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SubUIWidgetList(struct TArray<struct FGameWidgetConfig>& InWidgetConfigList, struct TArray<struct FString>& GameStatusStrList, bool InPersistentUI, bool InUsedByControler, bool InOberverOnly); // Offset: 0x103a4a494 // Return & Params: Num(5) Size(0x23)

	// Object Name: Function Client.InGameUIManager.SubDynamicUIWidgetList
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SubDynamicUIWidgetList(struct TArray<struct FDynamicWidgetData>& DynamicWidgetMap); // Offset: 0x103a4a3ec // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.InGameUIManager.OnAsyncLoadWidgetClassObj
	// Flags: [Final|Native|Public]
	void OnAsyncLoadWidgetClassObj(struct UObject* InClassObj, int RequestID); // Offset: 0x103a4a334 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.InGameUIManager.HandleUIMessage
	// Flags: [Final|Native|Public|BlueprintCallable]
	void HandleUIMessage(struct FString UIMessage); // Offset: 0x103a4a29c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.InGameUIManager.HandleMountWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	void HandleMountWidget(struct UInGameUIManager* IngameManager); // Offset: 0x103a4a220 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.InGameUIManager.HandleDynamicDestroy
	// Flags: [Final|Native|Public|BlueprintCallable]
	void HandleDynamicDestroy(); // Offset: 0x103a4a20c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.InGameUIManager.HandleDynamicCreation
	// Flags: [Final|Native|Public|BlueprintCallable]
	void HandleDynamicCreation(bool isAsyncLoad); // Offset: 0x103a4a188 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.InGameUIManager.GetWidgetHandleAsyncWithCallBack
	// Flags: [Final|Native|Public]
	void GetWidgetHandleAsyncWithCallBack(struct FString WidgetKey, DelegateProperty InCallback); // Offset: 0x103a4a09c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.InGameUIManager.GetWidgetHandle
	// Flags: [Final|Native|Public]
	struct UUAEUserWidget* GetWidgetHandle(struct FString WidgetKey); // Offset: 0x103a49ff4 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.InGameUIManager.GetMountCanvasPanel
	// Flags: [Final|Native|Public]
	struct UCanvasPanel* GetMountCanvasPanel(struct FString MountOuterName, struct FString MountName); // Offset: 0x103a49ef8 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.InGameUIManager.ChangeSubUIWidgetList
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void ChangeSubUIWidgetList(struct TArray<struct FGameWidgetConfig>& InWidgetConfigList); // Offset: 0x103a49e50 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class Client.IntlSDKComplianceHelper
// Size: 0x70 // Inherited bytes: 0x28
struct UIntlSDKComplianceHelper : UObject {
	// Fields
	struct FString IntlGameId; // Offset: 0x28 // Size: 0x10
	struct FString IntlSdkUrl; // Offset: 0x38 // Size: 0x10
	struct FString IntlSdkUrlDebug; // Offset: 0x48 // Size: 0x10
	struct FString IntlSdkKey; // Offset: 0x58 // Size: 0x10
	bool IntlSdkEnable; // Offset: 0x68 // Size: 0x01
	bool IntlLogEnable; // Offset: 0x69 // Size: 0x01
	char pad_0x6A[0x6]; // Offset: 0x6a // Size: 0x06

	// Functions

	// Object Name: Function Client.IntlSDKComplianceHelper.SetUserProfile
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetUserProfile(struct FString InRegion); // Offset: 0x103a4b398 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.IntlSDKComplianceHelper.SetParentStatus
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetParentStatus(int ParentCertificateStatus); // Offset: 0x103a4b31c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.IntlSDKComplianceHelper.SetLogConfig
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLogConfig(bool enableConsoleLog, bool enableFileLog, int LogLevel); // Offset: 0x103a4b210 // Return & Params: Num(3) Size(0x8)

	// Object Name: Function Client.IntlSDKComplianceHelper.SetEUAgreeStatus
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetEUAgreeStatus(int AgreeStatus); // Offset: 0x103a4b194 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.IntlSDKComplianceHelper.SetAdulthood
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAdulthood(int AgeStatus); // Offset: 0x103a4b118 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.IntlSDKComplianceHelper.SendEmail
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SendEmail(struct FString InEmail, struct FString UserName); // Offset: 0x103a4b02c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.IntlSDKComplianceHelper.QueryUserStatus
	// Flags: [Final|Native|Public|BlueprintCallable]
	void QueryUserStatus(); // Offset: 0x103a4b018 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlSDKComplianceHelper.QueryIsEEA
	// Flags: [Final|Native|Public|BlueprintCallable]
	void QueryIsEEA(struct FString InRegion); // Offset: 0x103a4af80 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.IntlSDKComplianceHelper.QueryConfig
	// Flags: [Final|Native|Public|BlueprintCallable]
	void QueryConfig(); // Offset: 0x103a4af6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlSDKComplianceHelper.OnMSDKEvnSwitched
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OnMSDKEvnSwitched(int Env); // Offset: 0x103a4aef0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.IntlSDKComplianceHelper.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UIntlSDKComplianceHelper* GetInstance(); // Offset: 0x103a4aebc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.IntlSDKComplianceHelper.ComplianceInit
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ComplianceInit(); // Offset: 0x103a4aea8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlSDKComplianceHelper.CommitBirthday
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CommitBirthday(struct FString InBirthday); // Offset: 0x103a4ae10 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class Client.LaggingReporter
// Size: 0x98 // Inherited bytes: 0x28
struct ULaggingReporter : UObject {
	// Fields
	char pad_0x28[0x20]; // Offset: 0x28 // Size: 0x20
	struct UGameFrontendHUD* GameFrontendHUD; // Offset: 0x48 // Size: 0x08
	char pad_0x50[0x48]; // Offset: 0x50 // Size: 0x48
};

// Object Name: Class Client.LiveBroadcast
// Size: 0x38 // Inherited bytes: 0x28
struct ULiveBroadcast : UObject {
	// Fields
	char pad_0x28[0x10]; // Offset: 0x28 // Size: 0x10

	// Functions

	// Object Name: Function Client.LiveBroadcast.SetFullScreen
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFullScreen(bool FullScreen); // Offset: 0x103a4bc38 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.LiveBroadcast.OpenLiveBroadcast
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OpenLiveBroadcast(struct FString URL, float Margin); // Offset: 0x103a4bb3c // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.LiveBroadcast.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct ULiveBroadcast* GetInstance(); // Offset: 0x103a4bb08 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.LiveBroadcast.CloseWebView
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CloseWebView(); // Offset: 0x103a4baf4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.LiveBroadcast.C2JSetString
	// Flags: [Final|Native|Static|Public]
	void C2JSetString(struct FString str); // Offset: 0x103a4ba40 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.LiveBroadcast.C2JSetIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	void C2JSetIndex(int Index); // Offset: 0x103a4b9c4 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class Client.LoadTexture
// Size: 0x28 // Inherited bytes: 0x28
struct ULoadTexture : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function Client.LoadTexture.LoadTexture2D
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UTexture2D* LoadTexture2D(struct FString ImagePath, bool& IsValid, int& OutWidth, int& OutHeight); // Offset: 0x103a4bff0 // Return & Params: Num(5) Size(0x28)

	// Object Name: Function Client.LoadTexture.GetTexture2DFromDiskFile
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UTexture2D* GetTexture2DFromDiskFile(struct FString FilePath); // Offset: 0x103a4bf58 // Return & Params: Num(2) Size(0x18)
};

// Object Name: Class Client.LuaBlueprintLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct ULuaBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function Client.LuaBlueprintLibrary.StringToLVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FLuaBPVar StringToLVar(struct UObject* WorldContextObject, struct FString Value); // Offset: 0x103a4ded8 // Return & Params: Num(3) Size(0x38)

	// Object Name: Function Client.LuaBlueprintLibrary.ObjectToLVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FLuaBPVar ObjectToLVar(struct UObject* WorldContextObject, struct UObject* O); // Offset: 0x103a4ddf8 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.LuaBlueprintLibrary.LVarToString
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FString LVarToString(struct UObject* WorldContextObject, struct FLuaBPVar& Value); // Offset: 0x103a4dce8 // Return & Params: Num(3) Size(0x38)

	// Object Name: Function Client.LuaBlueprintLibrary.LVarToObject
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct UObject* LVarToObject(struct UObject* WorldContextObject, struct FLuaBPVar& Value); // Offset: 0x103a4dc00 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.LuaBlueprintLibrary.LVarToInt
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	int LVarToInt(struct UObject* WorldContextObject, struct FLuaBPVar& Value); // Offset: 0x103a4db18 // Return & Params: Num(3) Size(0x2c)

	// Object Name: Function Client.LuaBlueprintLibrary.LVarToFloat
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	float LVarToFloat(struct UObject* WorldContextObject, struct FLuaBPVar& Value); // Offset: 0x103a4da30 // Return & Params: Num(3) Size(0x2c)

	// Object Name: Function Client.LuaBlueprintLibrary.LVarToBool
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	bool LVarToBool(struct UObject* WorldContextObject, struct FLuaBPVar& Value); // Offset: 0x103a4d948 // Return & Params: Num(3) Size(0x29)

	// Object Name: Function Client.LuaBlueprintLibrary.IntToLVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FLuaBPVar IntToLVar(struct UObject* WorldContextObject, int Value); // Offset: 0x103a4d868 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.LuaBlueprintLibrary.FloatToLVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FLuaBPVar FloatToLVar(struct UObject* WorldContextObject, float Value); // Offset: 0x103a4d788 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.LuaBlueprintLibrary.CallLuaWithMultiArgs
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void CallLuaWithMultiArgs(struct UObject* WorldContextObject, struct FString& Function, struct FLuaBPVar& InA, struct FLuaBPVar& InB, struct FLuaBPVar& InC, struct FLuaBPVar& InD, struct FLuaBPVar& InE, struct FLuaBPVar& InF, struct FLuaBPVar& OutA, struct FLuaBPVar& OutB, struct FLuaBPVar& OutC, struct FLuaBPVar& OutD); // Offset: 0x103a4d22c // Return & Params: Num(12) Size(0x158)

	// Object Name: Function Client.LuaBlueprintLibrary.CallLuaWithHUD
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void CallLuaWithHUD(struct UObject* WorldContextObject, struct UGameFrontendHUD* GameFrontendHUD, struct FString& Function, struct FLuaBPVar& InA, struct FLuaBPVar& InB, struct FLuaBPVar& InC, struct FLuaBPVar& InD, struct FLuaBPVar& OutA, struct FLuaBPVar& OutB, struct FLuaBPVar& OutC, struct FLuaBPVar& OutD); // Offset: 0x103a4cd78 // Return & Params: Num(11) Size(0x120)

	// Object Name: Function Client.LuaBlueprintLibrary.CallLuaWithArgs
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void CallLuaWithArgs(struct UObject* WorldContextObject, struct FString& Function, struct FLuaBPVar& InA, struct FLuaBPVar& InB, struct FLuaBPVar& InC, struct FLuaBPVar& InD, struct FLuaBPVar& OutA, struct FLuaBPVar& OutB, struct FLuaBPVar& OutC, struct FLuaBPVar& OutD); // Offset: 0x103a4c8fc // Return & Params: Num(10) Size(0x118)

	// Object Name: Function Client.LuaBlueprintLibrary.CallLua
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void CallLua(struct UObject* WorldContextObject, struct FString& Function, struct FLuaBPVar& OutA, struct FLuaBPVar& OutB, struct FLuaBPVar& OutC, struct FLuaBPVar& OutD); // Offset: 0x103a4c650 // Return & Params: Num(6) Size(0x98)

	// Object Name: Function Client.LuaBlueprintLibrary.BoolToLVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FLuaBPVar BoolToLVar(struct UObject* WorldContextObject, bool Value); // Offset: 0x103a4c568 // Return & Params: Num(3) Size(0x30)
};

// Object Name: Class Client.LuaBlueprintMgr
// Size: 0x80 // Inherited bytes: 0x28
struct ULuaBlueprintMgr : UObject {
	// Fields
	struct TMap<struct FString, struct ULuaBluepirntSys*> SystemMap; // Offset: 0x28 // Size: 0x50
	char pad_0x78[0x8]; // Offset: 0x78 // Size: 0x08

	// Functions

	// Object Name: Function Client.LuaBlueprintMgr.GetSystemByName
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct ULuaBluepirntSys* GetSystemByName(struct FString SystemName); // Offset: 0x103a4e5dc // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.LuaBlueprintMgr.AddSystem
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddSystem(struct FString SystemName, struct FString BPPath); // Offset: 0x103a4e4a8 // Return & Params: Num(2) Size(0x20)
};

// Object Name: Class Client.LuaBluepirntSys
// Size: 0xa0 // Inherited bytes: 0x28
struct ULuaBluepirntSys : UObject {
	// Fields
	char pad_0x28[0x60]; // Offset: 0x28 // Size: 0x60
	struct FString LuaFilePath; // Offset: 0x88 // Size: 0x10
	char pad_0x98[0x8]; // Offset: 0x98 // Size: 0x08

	// Functions

	// Object Name: Function Client.LuaBluepirntSys.Init
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void Init(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Client.LuaClassObj
// Size: 0x430 // Inherited bytes: 0x3e0
struct ALuaClassObj : ALuaContext {
	// Fields
	struct UGameBusinessManager* pManager; // Offset: 0x3e0 // Size: 0x08
	char pad_0x3E8[0x2]; // Offset: 0x3e8 // Size: 0x02
	bool bClearSourceCodeAfterInitialized; // Offset: 0x3ea // Size: 0x01
	char pad_0x3EB[0x45]; // Offset: 0x3eb // Size: 0x45

	// Functions

	// Object Name: Function Client.LuaClassObj.SubUIWidgetList
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SubUIWidgetList(struct TArray<struct FGameWidgetConfig>& InWidgetConfigList, struct TArray<struct FString>& GameStatusStrList, bool bPersistentUI, bool InStatusConcern, bool bDynamicWidget, bool bKeepDynamicWidget); // Offset: 0x103a4f3c8 // Return & Params: Num(6) Size(0x24)

	// Object Name: Function Client.LuaClassObj.SubShowHideEvent
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SubShowHideEvent(struct TArray<struct FString>& WidgetPathList); // Offset: 0x103a4f320 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.LuaClassObj.SubDefaultSceneCamera
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SubDefaultSceneCamera(int sceneCameraIndex); // Offset: 0x103a4f2a4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.LuaClassObj.SubDefaultChildUI
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SubDefaultChildUI(struct TArray<struct FString>& childList); // Offset: 0x103a4f1fc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.LuaClassObj.SubDefaultBaseUI
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SubDefaultBaseUI(struct FString baseUI); // Offset: 0x103a4f164 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.LuaClassObj.SubCollapseWidgetList
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SubCollapseWidgetList(struct FString RootWidgetName, struct TArray<struct FString>& ChildWidgetNames); // Offset: 0x103a4f068 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.LuaClassObj.SetWidgetZorder
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetWidgetZorder(int Index, int ZOrder); // Offset: 0x103a4efb4 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.LuaClassObj.RestoreWidgetZorder
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RestoreWidgetZorder(int Index); // Offset: 0x103a4ef38 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.LuaClassObj.RestoreAllWidgetZorder
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RestoreAllWidgetZorder(); // Offset: 0x103a4ef24 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.LuaClassObj.IsTopStackPanel
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsTopStackPanel(); // Offset: 0x103a4eef0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.LuaClassObj.IsPushedPanel
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsPushedPanel(); // Offset: 0x103a4eebc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.LuaClassObj.InCombatState
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool InCombatState(); // Offset: 0x103a4ee88 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.LuaClassObj.HandleUIMessageNoFetch
	// Flags: [Final|Native|Public|BlueprintCallable]
	void HandleUIMessageNoFetch(struct FString UIMessage); // Offset: 0x103a4edf0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.LuaClassObj.HandleUIMessage
	// Flags: [Final|Native|Public|BlueprintCallable]
	void HandleUIMessage(struct FString UIMessage); // Offset: 0x103a4ed58 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.LuaClassObj.HandleStopAsyncLoad
	// Flags: [Final|Native|Public|BlueprintCallable]
	void HandleStopAsyncLoad(); // Offset: 0x103a4ed44 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.LuaClassObj.HandleDynamicDestroy
	// Flags: [Final|Native|Public|BlueprintCallable]
	void HandleDynamicDestroy(); // Offset: 0x103a4ed30 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.LuaClassObj.HandleDynamicCreationInternal
	// Flags: [Final|Native|Public|BlueprintCallable]
	void HandleDynamicCreationInternal(bool isAsyncLoad); // Offset: 0x103a4ecac // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.LuaClassObj.HandleDynamicCreation
	// Flags: [Final|Native|Public|BlueprintCallable]
	void HandleDynamicCreation(bool isAsyncLoad); // Offset: 0x103a4ec28 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.LuaClassObj.HandleCollapseWidgetList
	// Flags: [Final|Native|Public|BlueprintCallable]
	void HandleCollapseWidgetList(struct FString RootWidgetName); // Offset: 0x103a4eb90 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.LuaClassObj.GetTopStackPanelSrcTag
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetTopStackPanelSrcTag(); // Offset: 0x103a4eb2c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.LuaClassObj.GetTopStackPanelDstTag
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetTopStackPanelDstTag(); // Offset: 0x103a4eac8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.LuaClassObj.GetGameStatus
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetGameStatus(); // Offset: 0x103a4ea64 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.LuaClassObj.ChangeSubUIWidgetList
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void ChangeSubUIWidgetList(struct TArray<struct FGameWidgetConfig>& InWidgetConfigList); // Offset: 0x103a4e9bc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.LuaClassObj.AddToTopStackPanel
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddToTopStackPanel(); // Offset: 0x103a4e9a8 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Client.MaskBox
// Size: 0x160 // Inherited bytes: 0x118
struct UMaskBox : UContentWidget {
	// Fields
	int InvalidateFrameCount; // Offset: 0x114 // Size: 0x04
	int Phase; // Offset: 0x118 // Size: 0x04
	int PhaseCount; // Offset: 0x11c // Size: 0x04
	bool IgnoreStretch; // Offset: 0x120 // Size: 0x01
	bool UpdateRenderTarget; // Offset: 0x121 // Size: 0x01
	int MaskType; // Offset: 0x124 // Size: 0x04
	struct FVector2D MaskTransformPivot; // Offset: 0x128 // Size: 0x08
	struct FVector2D MaskTransformScale; // Offset: 0x130 // Size: 0x08
	float MaskTransformAngle; // Offset: 0x138 // Size: 0x04
	char pad_0x13E[0x2]; // Offset: 0x13e // Size: 0x02
	struct UMaterialInterface* MaskMaterial; // Offset: 0x140 // Size: 0x08
	struct UTexture2D* MaskTexture; // Offset: 0x148 // Size: 0x08
	char pad_0x150[0x10]; // Offset: 0x150 // Size: 0x10

	// Functions

	// Object Name: Function Client.MaskBox.SetMaskTransformScale
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetMaskTransformScale(struct FVector2D Scale); // Offset: 0x103a5004c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.MaskBox.SetMaskTransformPivot
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetMaskTransformPivot(struct FVector2D Pivot); // Offset: 0x103a4ffd4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.MaskBox.SetMaskTransformAngle
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMaskTransformAngle(float Angle); // Offset: 0x103a4ff58 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.MaskBox.SetMaskMaterial
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMaskMaterial(struct UMaterialInterface* EffectMaterial); // Offset: 0x103a4fedc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.MaskBox.SetBrushFromTexture
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBrushFromTexture(struct UTexture2D* Texture); // Offset: 0x103a4fe60 // Return & Params: Num(1) Size(0x8)

	// Object Name: DelegateFunction Client.MaskBox.GetVector2D__DelegateSignature
	// Flags: [Public|Delegate|HasDefaults]
	struct FVector2D GetVector2D__DelegateSignature(); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.MaskBox.GetMaskMaterial
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UMaterialInstanceDynamic* GetMaskMaterial(); // Offset: 0x103a4fe2c // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Client.MidasManager
// Size: 0x1c8 // Inherited bytes: 0x28
struct UMidasManager : UObject {
	// Fields
	char pad_0x28[0x30]; // Offset: 0x28 // Size: 0x30
	struct FString payChannel; // Offset: 0x58 // Size: 0x10
	struct FString midasIdc; // Offset: 0x68 // Size: 0x10
	struct FString ZoneID; // Offset: 0x78 // Size: 0x10
	struct FString goodsZoneID; // Offset: 0x88 // Size: 0x10
	struct FString offerID; // Offset: 0x98 // Size: 0x10
	int iAOSShop; // Offset: 0xa8 // Size: 0x04
	char pad_0xAC[0x4]; // Offset: 0xac // Size: 0x04
	struct FString offerID_H5; // Offset: 0xb0 // Size: 0x10
	struct FString payChannel_H5; // Offset: 0xc0 // Size: 0x10
	char pad_0xD0[0x70]; // Offset: 0xd0 // Size: 0x70
	struct FString PAY_TYPE_UC; // Offset: 0x140 // Size: 0x10
	struct FString PAY_TYPE_GOODS; // Offset: 0x150 // Size: 0x10
	struct FString PAY_TYPE_SUBSCRIBE; // Offset: 0x160 // Size: 0x10
	struct UGameFrontendHUD* GameFrontendHUD; // Offset: 0x170 // Size: 0x08
	char pad_0x178[0x50]; // Offset: 0x178 // Size: 0x50

	// Functions

	// Object Name: Function Client.MidasManager.TickMidasPackage
	// Flags: [Final|Native|Private]
	void TickMidasPackage(); // Offset: 0x103a51f88 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.MidasManager.Tick
	// Flags: [Final|Native|Public]
	void Tick(float DeltaTime); // Offset: 0x103a51f0c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.MidasManager.SwitchPayChannel
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SwitchPayChannel(enum class EMidasMultiPayChannelSwitch switchChannel); // Offset: 0x103a51e90 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.MidasManager.Subscribe
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Subscribe(struct FString productid, int payItem, struct FString country, struct FString currency, struct FString serviceCode, struct FString ServiceName, bool autoPay); // Offset: 0x103a51b60 // Return & Params: Num(7) Size(0x59)

	// Object Name: Function Client.MidasManager.SetZoneID
	// Flags: [Final|Native|Public]
	void SetZoneID(struct FString inZoneID, struct FString inGoodsZoneID); // Offset: 0x103a51a2c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.MidasManager.SetRoleInfo
	// Flags: [Final|Native|Public]
	void SetRoleInfo(int InChannel, struct FString OpenID); // Offset: 0x103a51930 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.MidasManager.SetMidasIDC
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMidasIDC(struct FString idc); // Offset: 0x103a51874 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.MidasManager.SetJPAge
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetJPAge(int Age); // Offset: 0x103a517f8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.MidasManager.SetFrontendHUD
	// Flags: [Final|Native|Public]
	void SetFrontendHUD(struct UGameFrontendHUD* InFrontendHUD); // Offset: 0x103a5177c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.MidasManager.Reprovide
	// Flags: [Final|Native|Public]
	void Reprovide(); // Offset: 0x103a51768 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.MidasManager.Pay
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Pay(struct FString productid, int payItem, struct FString country, struct FString currency); // Offset: 0x103a51578 // Return & Params: Num(4) Size(0x38)

	// Object Name: Function Client.MidasManager.ModifySubscribe
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ModifySubscribe(struct FString oldProductId, struct FString newProductid, int payItem, struct FString country, struct FString currency, struct FString serviceCode, struct FString ServiceName, bool autoPay); // Offset: 0x103a511cc // Return & Params: Num(8) Size(0x69)

	// Object Name: Function Client.MidasManager.IsH5PayEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsH5PayEnable(); // Offset: 0x103a51198 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.MidasManager.Initialize
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Initialize(enum class EMidasMultiPayChannelSwitch envior); // Offset: 0x103a5111c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.MidasManager.H5Pay
	// Flags: [Final|Native|Public|BlueprintCallable]
	void H5Pay(struct FString country); // Offset: 0x103a51060 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.MidasManager.GoodsPresent
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GoodsPresent(struct FString productid, int payItem, struct FString price, struct FString country, struct FString currency, struct FString MetaData); // Offset: 0x103a50d80 // Return & Params: Num(6) Size(0x58)

	// Object Name: Function Client.MidasManager.Goods
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Goods(struct FString productid, int payItem, struct FString price, struct FString country, struct FString currency); // Offset: 0x103a50b18 // Return & Params: Num(5) Size(0x48)

	// Object Name: Function Client.MidasManager.GetProductInfo
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GetProductInfo(struct TArray<struct FString> listProductID); // Offset: 0x103a50a34 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.MidasManager.getPF
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString getPF(); // Offset: 0x103a509d0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.MidasManager.GetPayEnvironment
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetPayEnvironment(); // Offset: 0x103a5096c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.MidasManager.GetPayChannel
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetPayChannel(); // Offset: 0x103a50908 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.MidasManager.GetPackChannel
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetPackChannel(); // Offset: 0x103a508a4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.MidasManager.GetOfferID
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetOfferID(); // Offset: 0x103a50840 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.MidasManager.GetNativePackageTag
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetNativePackageTag(); // Offset: 0x103a507dc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.MidasManager.GetMPInfo
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GetMPInfo(struct FString country, struct FString currency); // Offset: 0x103a506a8 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.MidasManager.GetIntroPrice
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GetIntroPrice(struct TArray<struct FString> listProductID); // Offset: 0x103a505c4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.MidasManager.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UMidasManager* GetInstance(); // Offset: 0x103a50590 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.MidasManager.GetInIDC
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetInIDC(); // Offset: 0x103a5052c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.MidasManager.GetAOSSHOP
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetAOSSHOP(); // Offset: 0x103a504f8 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class Client.NewButton
// Size: 0x520 // Inherited bytes: 0x518
struct UNewButton : UButton {
	// Fields
	enum class EButtonClickSoundTypes ClickSound; // Offset: 0x518 // Size: 0x01
	char pad_0x519[0x7]; // Offset: 0x519 // Size: 0x07

	// Functions

	// Object Name: Function Client.NewButton.SetClickSound
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetClickSound(enum class EButtonClickSoundTypes inSoundType); // Offset: 0x103a5542c // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class Client.PlatformAppraise
// Size: 0x28 // Inherited bytes: 0x28
struct UPlatformAppraise : UObject {
};

// Object Name: Class Client.PublishAreaMgr
// Size: 0x28 // Inherited bytes: 0x28
struct UPublishAreaMgr : UObject {
	// Functions

	// Object Name: Function Client.PublishAreaMgr.SelectArea
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SelectArea(struct FString InArea); // Offset: 0x103a55ab4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.PublishAreaMgr.IsMultiAreaBuild
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsMultiAreaBuild(); // Offset: 0x103a55a80 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.PublishAreaMgr.GetString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetString(struct FString InKey, struct FString InDefaultValue); // Offset: 0x103a5596c // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.PublishAreaMgr.GetPublishAreas
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetPublishAreas(); // Offset: 0x103a55908 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.PublishAreaMgr.GetInt
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetInt(struct FString InKey, int InDefaultValue); // Offset: 0x103a55830 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.PublishAreaMgr.GetBool
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool GetBool(struct FString InKey, bool InDefaultValue); // Offset: 0x103a55750 // Return & Params: Num(3) Size(0x12)

	// Object Name: Function Client.PublishAreaMgr.GetArea
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetArea(); // Offset: 0x103a556ec // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class Client.ScreenInput
// Size: 0x60 // Inherited bytes: 0x28
struct UScreenInput : UObject {
	// Fields
	struct FScriptMulticastDelegate OnScreenTouch; // Offset: 0x28 // Size: 0x10
	DelegateProperty OnMouseButtonDown; // Offset: 0x38 // Size: 0x10
	char pad_0x48[0x18]; // Offset: 0x48 // Size: 0x18

	// Functions

	// Object Name: Function Client.ScreenInput.Shutdown
	// Flags: [Final|Native|Public]
	void Shutdown(); // Offset: 0x103a55f08 // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction Client.ScreenInput.OnScreenTouch__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnScreenTouch__DelegateSignature(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction Client.ScreenInput.OnMouseButtonDown__DelegateSignature
	// Flags: [Public|Delegate|HasOutParms|HasDefaults]
	void OnMouseButtonDown__DelegateSignature(struct FVector2D& ContainerPos); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScreenInput.Init
	// Flags: [Final|Native|Public]
	void Init(); // Offset: 0x103a55ef4 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Client.ScreenshotMaker
// Size: 0x28 // Inherited bytes: 0x28
struct UScreenshotMaker : UObject {
	// Functions

	// Object Name: Function Client.ScreenshotMaker.SaveToPhotosAlbumEx
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool SaveToPhotosAlbumEx(struct FString pathStr); // Offset: 0x103a56ba8 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScreenshotMaker.SaveToPhotosAlbum
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool SaveToPhotosAlbum(struct FString pathStr); // Offset: 0x103a56aec // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScreenshotMaker.ResizePicture
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ResizePicture(struct FString pathStr, float Scale, struct FString savePathStr); // Offset: 0x103a56974 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.ScreenshotMaker.ReMakePicture
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	void ReMakePicture(struct FString pathStr, struct FVector4 Vector4); // Offset: 0x103a56874 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScreenshotMaker.ReMakeMomentPicture
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	struct FString ReMakeMomentPicture(struct FString srcPath, struct FVector4 Vector4); // Offset: 0x103a56744 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScreenshotMaker.MakePictureWithName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString MakePictureWithName(struct FString PicName); // Offset: 0x103a56660 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScreenshotMaker.MakePictureToLua
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString MakePictureToLua(struct UGameFrontendHUD* InFrontendHUD, struct FString tableName, struct FString FunctionName, bool isShowUI); // Offset: 0x103a56474 // Return & Params: Num(5) Size(0x40)

	// Object Name: Function Client.ScreenshotMaker.MakePicture
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString MakePicture(bool isShowUI); // Offset: 0x103a563c8 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScreenshotMaker.MakeBugReprotPic
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString MakeBugReprotPic(bool isShowUI); // Offset: 0x103a5631c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScreenshotMaker.HasCaptured
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool HasCaptured(struct FString pathStr); // Offset: 0x103a56260 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScreenshotMaker.GetSaveStatus
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetSaveStatus(); // Offset: 0x103a5622c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScreenshotMaker.GetPhotoHash
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetPhotoHash(struct FString pathStr, int algorithmVersion); // Offset: 0x103a56130 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.ScreenshotMaker.GetMomentThumbPictureFullPathFiles
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct TArray<struct FString> GetMomentThumbPictureFullPathFiles(); // Offset: 0x103a560cc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScreenshotMaker.GetMomentPictureFullPathFiles
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct TArray<struct FString> GetMomentPictureFullPathFiles(); // Offset: 0x103a56068 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class Client.ScriptHelperClient
// Size: 0x28 // Inherited bytes: 0x28
struct UScriptHelperClient : UObject {
	// Functions

	// Object Name: Function Client.ScriptHelperClient.ZLIBDecompress
	// Flags: [Final|Native|Static|Public]
	struct FString ZLIBDecompress(struct FString CompressedData, int CompressedSize, int UnCompressedSize); // Offset: 0x103a73770 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function Client.ScriptHelperClient.ZLIBCompress_LuaState
	// Flags: [Final|Native|Static|Public]
	int ZLIBCompress_LuaState(); // Offset: 0x103a73758 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.WechatShareWithUrlInfo
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void WechatShareWithUrlInfo(struct TScriptInterface<Class>& ClientNetInterface, struct FString _descShare, struct FString _titleShare, struct FString _imgPath, struct FString _url, int _shareScene); // Offset: 0x103a7353c // Return & Params: Num(6) Size(0x54)

	// Object Name: Function Client.ScriptHelperClient.WeChatShareWithMiniApp
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void WeChatShareWithMiniApp(struct TScriptInterface<Class>& ClientNetInterface, struct FString _descShare, struct FString _titleShare, struct FString _imgPath, struct FString _webpageUrl, struct FString _userName, struct FString _path, struct FString _messageExt, struct FString _messageAction, int _shareScene); // Offset: 0x103a731c4 // Return & Params: Num(10) Size(0x94)

	// Object Name: Function Client.ScriptHelperClient.WechatShareToFriend
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void WechatShareToFriend(struct TScriptInterface<Class>& ClientNetInterface, struct FString OpenID, struct FString Title, struct FString Desc, struct FString mediaId, struct FString messageExt, struct FString mediaTagName, struct FString msdkExtInfo); // Offset: 0x103a72eec // Return & Params: Num(8) Size(0x80)

	// Object Name: Function Client.ScriptHelperClient.WechatShare
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void WechatShare(struct TScriptInterface<Class>& ClientNetInterface, struct FString _descShare, struct FString _titleShare, struct FString _imgPath, struct FString _mediaTagName, struct FString _messageExt); // Offset: 0x103a72cbc // Return & Params: Num(6) Size(0x60)

	// Object Name: Function Client.ScriptHelperClient.WechatQueryGroup
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void WechatQueryGroup(struct TScriptInterface<Class>& ClientNetInterface, struct FString unionId, struct FString OpenIdList); // Offset: 0x103a72b88 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.WechatJoinGroup
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void WechatJoinGroup(struct TScriptInterface<Class>& ClientNetInterface, struct FString unionId, struct FString chatRoomNickName); // Offset: 0x103a72a54 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.WechatCreateGroup
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void WechatCreateGroup(struct TScriptInterface<Class>& ClientNetInterface, struct FString unionId, struct FString chatRoomName, struct FString chatRoomNickName); // Offset: 0x103a728cc // Return & Params: Num(4) Size(0x40)

	// Object Name: Function Client.ScriptHelperClient.WakeupFromSuspendSound
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void WakeupFromSuspendSound(); // Offset: 0x103a728b8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.VPNTearDown
	// Flags: [Final|Native|Static|Public]
	int VPNTearDown(); // Offset: 0x103a72884 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.VPNSetUserInfo
	// Flags: [Final|Native|Static|Public]
	int VPNSetUserInfo(struct FString InUserId, struct FString InUserToken, struct FString InAppId); // Offset: 0x103a72744 // Return & Params: Num(4) Size(0x34)

	// Object Name: Function Client.ScriptHelperClient.VPNSetPortRange
	// Flags: [Final|Native|Static|Public]
	int VPNSetPortRange(int Min, int Max); // Offset: 0x103a72690 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.VPNSetNodelist
	// Flags: [Final|Native|Static|Public]
	int VPNSetNodelist(struct FString InNodelist); // Offset: 0x103a725f8 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.VPNPrepare
	// Flags: [Final|Native|Static|Public]
	int VPNPrepare(); // Offset: 0x103a725c4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.VPNHandUp
	// Flags: [Final|Native|Static|Public]
	int VPNHandUp(); // Offset: 0x103a72590 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.VPNGetNodeRegionList
	// Flags: [Final|Native|Static|Public]
	struct FString VPNGetNodeRegionList(); // Offset: 0x103a7252c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.VPNDialUp
	// Flags: [Final|Native|Static|Public]
	int VPNDialUp(struct FString InRegion); // Offset: 0x103a72494 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.Vibrate
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void Vibrate(int Param); // Offset: 0x103a72420 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.UserName
	// Flags: [Final|Native|Static|Public]
	struct FString UserName(); // Offset: 0x103a723bc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.UrlEncode
	// Flags: [Final|Native|Static|Public]
	struct FString UrlEncode(struct FString UnencodedString); // Offset: 0x103a722fc // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.UQMSetAppVersion
	// Flags: [Final|Native|Static|Public]
	void UQMSetAppVersion(struct FString Version); // Offset: 0x103a7226c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.UQMBuglyPutUserData
	// Flags: [Final|Native|Static|Public]
	void UQMBuglyPutUserData(struct FString Key, struct FString Value); // Offset: 0x103a72188 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.UQMBuglyPostException
	// Flags: [Final|Native|Static|Public]
	void UQMBuglyPostException(int Category, struct FString Reason); // Offset: 0x103a720bc // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.UQMBuglyLog
	// Flags: [Final|Native|Static|Public]
	void UQMBuglyLog(int Level, struct FString Tag, struct FString Log, bool needDump); // Offset: 0x103a71f54 // Return & Params: Num(4) Size(0x29)

	// Object Name: Function Client.ScriptHelperClient.UpdatePublishRegionForBattle
	// Flags: [Final|Native|Static|Public]
	void UpdatePublishRegionForBattle(); // Offset: 0x103a71f40 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.UpdateMemResource
	// Flags: [Final|Native|Static|Public]
	void UpdateMemResource(struct FString ResType, struct FString KeyWord); // Offset: 0x103a71e14 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.UpdateAkAudioDeviceBluetoothDelay
	// Flags: [Final|Native|Static|Public]
	void UpdateAkAudioDeviceBluetoothDelay(int InDelayTime); // Offset: 0x103a71da0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.UnsubscribeFromTopic
	// Flags: [Final|Native|Static|Public]
	void UnsubscribeFromTopic(struct FString Topic); // Offset: 0x103a71d10 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.UnmountPakFile
	// Flags: [Final|Native|Static|Public]
	bool UnmountPakFile(struct FString InPakFilename); // Offset: 0x103a71c78 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.UnitTestODPaksOpen
	// Flags: [Final|Native|Static|Public]
	void UnitTestODPaksOpen(int fileCount, int Times, int threadNum); // Offset: 0x103a71b90 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.TVMacroTesting
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void TVMacroTesting(); // Offset: 0x103a71b7c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.TriggerTouchEvent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void TriggerTouchEvent(float X, float Y, int event_type); // Offset: 0x103a71a94 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.TriggerLoginCrashTest
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void TriggerLoginCrashTest(); // Offset: 0x103a71a80 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.TriggerLobbyCrashTest
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void TriggerLobbyCrashTest(); // Offset: 0x103a71a6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.TriggerBlockAndroidANR
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void TriggerBlockAndroidANR(); // Offset: 0x103a71a58 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.TGPASwitchRichTapMode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void TGPASwitchRichTapMode(struct FString Mode); // Offset: 0x103a719a4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.TGPAStopRichTap
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void TGPAStopRichTap(); // Offset: 0x103a71990 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.TGPAStartRichTapWithData
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void TGPAStartRichTapWithData(struct FString InKey, struct TMap<struct FString, struct FString>& InMapData); // Offset: 0x103a71894 // Return & Params: Num(2) Size(0x60)

	// Object Name: Function Client.ScriptHelperClient.TGPAStartRichTap
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void TGPAStartRichTap(struct FString Filename); // Offset: 0x103a717e0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.TGPAGetRichTapSupport
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString TGPAGetRichTapSupport(); // Offset: 0x103a7177c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.TGPAGetRichTapAmplitudeSupport
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString TGPAGetRichTapAmplitudeSupport(); // Offset: 0x103a71718 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.Tex_UpdateMemResource
	// Flags: [Final|Native|Static|Public]
	void Tex_UpdateMemResource(struct FString KeyWord); // Offset: 0x103a71664 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.Tex_DumpMemObjectInfo
	// Flags: [Final|Native|Static|Public]
	void Tex_DumpMemObjectInfo(struct FString KeyWord); // Offset: 0x103a715b0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.TestSaveStringToFile
	// Flags: [Final|Native|Static|Public]
	void TestSaveStringToFile(struct FString String, struct FString TargetDir, struct FString FullPathName); // Offset: 0x103a71478 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.Tea2Encrypt_LuaState
	// Flags: [Final|Native|Static|Public]
	int Tea2Encrypt_LuaState(); // Offset: 0x103a71460 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.Tea2Decrypt_LuaState
	// Flags: [Final|Native|Static|Public]
	int Tea2Decrypt_LuaState(); // Offset: 0x103a71448 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.TapmReport
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void TapmReport(int Type, struct FString ExtraInfo, bool send); // Offset: 0x103a7130c // Return & Params: Num(3) Size(0x19)

	// Object Name: Function Client.ScriptHelperClient.TapmPostLargeValueS
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void TapmPostLargeValueS(struct FString catgory, struct FString Key, struct FString Value); // Offset: 0x103a71168 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.TapmMarkTime
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void TapmMarkTime(int Type); // Offset: 0x103a710f4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.TapmMarkLevelFin
	// Flags: [Final|Native|Static|Public]
	void TapmMarkLevelFin(); // Offset: 0x103a710e0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.TApmDisconnectReport
	// Flags: [Final|Native|Static|Public]
	void TApmDisconnectReport(struct UGameFrontendHUD* GameFrontendHUD, int EventId); // Offset: 0x103a71030 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.TApmDataReport
	// Flags: [Final|Native|Static|Public]
	void TApmDataReport(struct UGameFrontendHUD* GameFrontendHUD, int EventId, struct FString EventInfo); // Offset: 0x103a70efc // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.SwitchUser
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void SwitchUser(struct TScriptInterface<Class>& ClientNetInterface, bool useExternalAccount); // Offset: 0x103a70e34 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.SwitchSceneCamera
	// Flags: [Final|Native|Static|Public]
	void SwitchSceneCamera(struct UGameFrontendHUD* GameFrontendHUD, struct FString SceneCameraName, float blendTime, bool bForce); // Offset: 0x103a70cb8 // Return & Params: Num(4) Size(0x1d)

	// Object Name: Function Client.ScriptHelperClient.SwitchCampRoom
	// Flags: [Final|Native|Static|Public]
	void SwitchCampRoom(struct UGameFrontendHUD* GameFrontendHUD, int campMode); // Offset: 0x103a70c08 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.SuspendSound
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SuspendSound(); // Offset: 0x103a70bf4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.SubscribeToTopic
	// Flags: [Final|Native|Static|Public]
	void SubscribeToTopic(struct FString Topic); // Offset: 0x103a70b64 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.StringToFMargin
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FMargin StringToFMargin(struct FString MarginStr); // Offset: 0x103a70abc // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.StopUIStat
	// Flags: [Final|Native|Static|Public]
	void StopUIStat(struct FString UIName, bool bReport); // Offset: 0x103a709c0 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.StopTouchRecord
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FTouchInputRecord StopTouchRecord(); // Offset: 0x103a7095c // Return & Params: Num(1) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.StopTask
	// Flags: [Final|Native|Static|Public]
	bool StopTask(struct UGameFrontendHUD* GameFrontendHUD, uint64 TaskId); // Offset: 0x103a708a8 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.StopShaderPrecompile
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool StopShaderPrecompile(); // Offset: 0x103a70874 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.StopHapticsEngine
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void StopHapticsEngine(); // Offset: 0x103a70860 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.StopH5Downloading
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void StopH5Downloading(); // Offset: 0x103a7084c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.StopCampMode
	// Flags: [Final|Native|Static|Public]
	void StopCampMode(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a707d8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.StartUIStat
	// Flags: [Final|Native|Static|Public]
	void StartUIStat(struct FString UIName); // Offset: 0x103a70724 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.StartTrace
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void StartTrace(struct FString InHost, int InStartTTL, int InMaxTTL, int InCount); // Offset: 0x103a705d8 // Return & Params: Num(4) Size(0x1c)

	// Object Name: Function Client.ScriptHelperClient.StartTouchRecord
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void StartTouchRecord(); // Offset: 0x103a705c4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.StartShaderPrecompile
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool StartShaderPrecompile(); // Offset: 0x103a70590 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.StartOpenReadCollect
	// Flags: [Final|Native|Static|Public]
	void StartOpenReadCollect(struct UGameFrontendHUD* GameFrontendHUD, bool bStart); // Offset: 0x103a704d8 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.StartHapticsEngine
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void StartHapticsEngine(DelegateProperty Callback); // Offset: 0x103a70450 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.StartGrayUpdate
	// Flags: [Final|Native|Static|Public]
	bool StartGrayUpdate(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a703d4 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.StartDownloadItem
	// Flags: [Final|Native|Static|Public]
	void StartDownloadItem(uint32_t ItemId, uint32_t Priority, DelegateProperty OnItemDownloadDelegate); // Offset: 0x103a702d8 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.StartDolphinResourceUpdate
	// Flags: [Final|Native|Static|Public]
	void StartDolphinResourceUpdate(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a70264 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.StartCDNUpdateAfterDolphinUpdateFailed
	// Flags: [Final|Native|Static|Public]
	void StartCDNUpdateAfterDolphinUpdateFailed(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a701f0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.StartCampMode
	// Flags: [Final|Native|Static|Public]
	void StartCampMode(struct UGameFrontendHUD* GameFrontendHUD, struct FString ZombieCampRoomName, struct FString ManCampRoomName, struct FString userId); // Offset: 0x103a7007c // Return & Params: Num(4) Size(0x38)

	// Object Name: Function Client.ScriptHelperClient.StartBatchDownloadItem
	// Flags: [Final|Native|Static|Public]
	void StartBatchDownloadItem(struct TArray<uint32_t> ItemIDs, uint32_t Priority, DelegateProperty OnBatchItemDownloadDelegate); // Offset: 0x103a6ff0c // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.ScriptHelperClient.ShutdownUnrealNetwork
	// Flags: [Final|Native|Static|Public]
	void ShutdownUnrealNetwork(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a6fe98 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.ShutdownPuffer
	// Flags: [Final|Native|Static|Public]
	void ShutdownPuffer(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a6fe24 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.ShowWebView
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ShowWebView(bool Show); // Offset: 0x103a6fda8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.ShowVLink
	// Flags: [Final|Native|Static|Public]
	void ShowVLink(struct FString jsonString, struct FString signString); // Offset: 0x103a6fcc4 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.ShowVideoListDialog
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ShowVideoListDialog(); // Offset: 0x103a6fcb0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.ShowScreenDebugMessage
	// Flags: [Final|Native|Static|Public]
	void ShowScreenDebugMessage(struct FString Message); // Offset: 0x103a6fbfc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.ShowH5WebView
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ShowH5WebView(); // Offset: 0x103a6fbe8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.ShorterStreamingDistanceWhenGameEnd
	// Flags: [Final|Native|Static|Public]
	void ShorterStreamingDistanceWhenGameEnd(uint32_t Distance); // Offset: 0x103a6fb74 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.ShareWithUploadPhotoByChannel
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void ShareWithUploadPhotoByChannel(struct TScriptInterface<Class>& ClientNetInterface, struct FString _imgPath, int _channel, struct FString _url); // Offset: 0x103a6fa00 // Return & Params: Num(4) Size(0x38)

	// Object Name: Function Client.ScriptHelperClient.ShareWithPhotoByChannel
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void ShareWithPhotoByChannel(struct TScriptInterface<Class>& ClientNetInterface, struct FString _imgPath, struct FString _mediaTagName, struct FString _messageExt, struct FString _messageAction, int _channel, struct FString _url); // Offset: 0x103a6f790 // Return & Params: Num(7) Size(0x68)

	// Object Name: Function Client.ScriptHelperClient.ShareLogFile
	// Flags: [Final|Native|Static|Public]
	void ShareLogFile(); // Offset: 0x103a6f77c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.SetWebViewCacheInfoDelegate
	// Flags: [Final|Native|Static|Public]
	void SetWebViewCacheInfoDelegate(DelegateProperty Delegate); // Offset: 0x103a6f6f4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.SetWeatherInfo
	// Flags: [Final|Native|Static|Public]
	void SetWeatherInfo(struct UGameFrontendHUD* GameFrontendHUD, int WeatherID, struct FString WeatherName); // Offset: 0x103a6f5c0 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.SetVpnServiceStrategy
	// Flags: [Final|Native|Static|Public]
	bool SetVpnServiceStrategy(struct FString InKey, int InValue); // Offset: 0x103a6f4e8 // Return & Params: Num(3) Size(0x15)

	// Object Name: Function Client.ScriptHelperClient.SetVoiceSwitch
	// Flags: [Final|Native|Static|Public]
	void SetVoiceSwitch(struct UGameFrontendHUD* GameFrontendHUD, bool FirstVoicePopupSwitch, bool GDPRForbidVoiceSwitch, bool GDPRSettingSwitch); // Offset: 0x103a6f3a0 // Return & Params: Num(4) Size(0xb)

	// Object Name: Function Client.ScriptHelperClient.SetVoiceReEneterInfo
	// Flags: [Final|Native|Static|Public]
	void SetVoiceReEneterInfo(struct UGameFrontendHUD* GameFrontendHUD, float Duration, int MaxCount); // Offset: 0x103a6f2b4 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.SetUserVulkanSetting
	// Flags: [Final|Native|Static|Public]
	void SetUserVulkanSetting(bool Enable); // Offset: 0x103a6f238 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.SetUserTGPATapEnableFlag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetUserTGPATapEnableFlag(int EnableFlag); // Offset: 0x103a6f1c4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.SetUserProperty
	// Flags: [Final|Native|Static|Public]
	void SetUserProperty(struct FString propertyKey, struct FString propertyValue); // Offset: 0x103a6f0e0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.SetUpdatedSoPatchFile
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool SetUpdatedSoPatchFile(struct FString InSourceFile, int InABI); // Offset: 0x103a6f008 // Return & Params: Num(3) Size(0x15)

	// Object Name: Function Client.ScriptHelperClient.SetupAkAudioDeviceListener
	// Flags: [Final|Native|Static|Public]
	void SetupAkAudioDeviceListener(); // Offset: 0x103a6eff4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.SetUIStatMaxClickTimes
	// Flags: [Final|Native|Static|Public]
	void SetUIStatMaxClickTimes(int Times); // Offset: 0x103a6ef80 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.SetUIRectOffset
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetUIRectOffset(struct FString uirect); // Offset: 0x103a6eecc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.SetUIElemLayoutJsonConfigSwitch
	// Flags: [Final|Native|Static|Public]
	void SetUIElemLayoutJsonConfigSwitch(struct UGameFrontendHUD* GameFrontendHUD, bool UIElemLayoutJsonConfigSwitch); // Offset: 0x103a6ee14 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.SetUIConfigTGPATapEnableFlag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetUIConfigTGPATapEnableFlag(int uiEnable); // Offset: 0x103a6eda0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.SetTssNetworkStatus
	// Flags: [Final|Native|Static|Public]
	void SetTssNetworkStatus(struct UGameFrontendHUD* GameFrontendHUD, int Status); // Offset: 0x103a6ecf0 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.SetTickMemoryInterval
	// Flags: [Final|Native|Static|Public]
	void SetTickMemoryInterval(struct UGameFrontendHUD* GameFrontendHUD, float interval); // Offset: 0x103a6ec40 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.SetTGPATapWhiteListFlag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetTGPATapWhiteListFlag(int TapWhiteList); // Offset: 0x103a6ebcc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.SetTestEditorNum
	// Flags: [Final|Native|Static|Public]
	void SetTestEditorNum(int PlayerCount, struct FString Num, struct FString SceneName, int PlatForm); // Offset: 0x103a6ea20 // Return & Params: Num(4) Size(0x2c)

	// Object Name: Function Client.ScriptHelperClient.SetSoundEffectQuality
	// Flags: [Final|Native|Static|Public]
	bool SetSoundEffectQuality(int Type); // Offset: 0x103a6e9a4 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Client.ScriptHelperClient.SetShowFriendObservers
	// Flags: [Final|Native|Static|Public]
	void SetShowFriendObservers(struct UGameFrontendHUD* GameFrontendHUD, bool bShow); // Offset: 0x103a6e8ec // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.SetSelfieSwitch
	// Flags: [Final|Native|Static|Public]
	void SetSelfieSwitch(struct UGameFrontendHUD* GameFrontendHUD, bool SelfieSwitch); // Offset: 0x103a6e834 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.SetSdkIoctl
	// Flags: [Final|Native|Static|Public|HasOutParms]
	int SetSdkIoctl(struct UGameFrontendHUD* GameFrontendHUD, int request, struct FString& Token); // Offset: 0x103a6e714 // Return & Params: Num(4) Size(0x24)

	// Object Name: Function Client.ScriptHelperClient.SetScreenHole
	// Flags: [Final|Native|Static|Public]
	void SetScreenHole(struct FString sceenHole); // Offset: 0x103a6e660 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.SetReportBugSwitch
	// Flags: [Final|Native|Static|Public]
	void SetReportBugSwitch(struct UGameFrontendHUD* GameFrontendHUD, bool ReportBugSwitch); // Offset: 0x103a6e5a8 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.SetRemoteResource
	// Flags: [Final|Native|Static|Public]
	void SetRemoteResource(struct FString AssetId, struct UObject* DescObj); // Offset: 0x103a6e4b4 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.SetRegionNoByLua
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void SetRegionNoByLua(struct TScriptInterface<Class>& ClientNetInterface, int regionNo); // Offset: 0x103a6e3f4 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.SetRedBloodSwitch
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetRedBloodSwitch(bool redBloodSwitch); // Offset: 0x103a6e378 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.SetPufferBuildInfo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetPufferBuildInfo(struct FString PipeLineID, struct FString BuildNo); // Offset: 0x103a6e24c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.SetPublishRegion
	// Flags: [Final|Native|Static|Public]
	void SetPublishRegion(struct FString Region); // Offset: 0x103a6e198 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.SetPlayerBaseInfo
	// Flags: [Final|Native|Static|Public]
	void SetPlayerBaseInfo(struct UGameFrontendHUD* GameFrontendHUD, struct FString OpenID, uint64 RoleID, struct FString PlayerName, struct FString HeadIconUrl); // Offset: 0x103a6df70 // Return & Params: Num(5) Size(0x40)

	// Object Name: Function Client.ScriptHelperClient.SetOnGetItemBigIcon
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetOnGetItemBigIcon(DelegateProperty onShow); // Offset: 0x103a6dee8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.SetNationSwitch
	// Flags: [Final|Native|Static|Public]
	void SetNationSwitch(struct UGameFrontendHUD* GameFrontendHUD, bool NationAllSwitch, bool NationBattleSwitch, bool NationRankSwitch); // Offset: 0x103a6dda0 // Return & Params: Num(4) Size(0xb)

	// Object Name: Function Client.ScriptHelperClient.SetMyFriendObserversDetail
	// Flags: [Final|Native|Static|Public]
	void SetMyFriendObserversDetail(struct UGameFrontendHUD* GameFrontendHUD, struct TArray<struct FFriendObserver> FriendObserversDetails); // Offset: 0x103a6dc84 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.SetMiniGameFinalAwardResId
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetMiniGameFinalAwardResId(struct UGameFrontendHUD* GameFrontendHUD, int AwardResId); // Offset: 0x103a6dbd4 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.SetMidasZoneID_LuaState
	// Flags: [Final|Native|Static|Public]
	int SetMidasZoneID_LuaState(); // Offset: 0x103a6dbbc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.SetMidasIDC
	// Flags: [Final|Native|Static|Public]
	void SetMidasIDC(struct FString midasIdc); // Offset: 0x103a6db08 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.SetLinkStyle
	// Flags: [Final|Native|Static|Public]
	bool SetLinkStyle(struct FString StyleName, int FontSize, struct FString FontPath, struct FString FontColor, bool ShowUnderline, struct FString PathHyperLinkNormalBrush, struct FString PathHyperLinkHoveredrBrush); // Offset: 0x103a6d7d8 // Return & Params: Num(8) Size(0x61)

	// Object Name: Function Client.ScriptHelperClient.SetLevelStreamingUnloadTimeslice
	// Flags: [Final|Native|Static|Public]
	void SetLevelStreamingUnloadTimeslice(bool Enabled); // Offset: 0x103a6d75c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.SetiTOPLbsDelay
	// Flags: [Final|Native|Static|Public]
	void SetiTOPLbsDelay(int Delay); // Offset: 0x103a6d6e8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.SetIPRegion
	// Flags: [Final|Native|Static|Public]
	void SetIPRegion(int region_no); // Offset: 0x103a6d674 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.SetIosStuckEnableByServerConfig
	// Flags: [Final|Native|Static|Public]
	void SetIosStuckEnableByServerConfig(int bEnable); // Offset: 0x103a6d600 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.SetIOSBGDownloadAttribute
	// Flags: [Final|Native|Static|Public]
	void SetIOSBGDownloadAttribute(struct UGameFrontendHUD* GameFrontendHUD, bool bEnableCellularAccess, bool bEnableResumeData, int nMinFileSize, int nMaxTasks); // Offset: 0x103a6d488 // Return & Params: Num(5) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.SetIntDefaultConfig
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetIntDefaultConfig(int Value); // Offset: 0x103a6d414 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.SetImageVersionString
	// Flags: [Final|Native|Static|Public]
	void SetImageVersionString(struct FString oldVersion, struct FString newVersion); // Offset: 0x103a6d330 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.SetImageStyle
	// Flags: [Final|Native|Static|Public]
	bool SetImageStyle(struct FString StyleName, int ImageSize, struct FString ImagePath, struct FString ImageColor, bool bPreLoad); // Offset: 0x103a6d0f0 // Return & Params: Num(6) Size(0x3a)

	// Object Name: Function Client.ScriptHelperClient.SetHapticsEngineEnable
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetHapticsEngineEnable(bool bEnable); // Offset: 0x103a6d074 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.SetGlobalRedBloodSwitch
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetGlobalRedBloodSwitch(bool redBloodSwitch); // Offset: 0x103a6cff8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.SetGDPRUserType
	// Flags: [Final|Native|Static|Public]
	void SetGDPRUserType(struct UGameFrontendHUD* GameFrontendHUD, int GDPRUserType); // Offset: 0x103a6cf48 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.SetGameStatusMap
	// Flags: [Final|Native|Static|Public]
	void SetGameStatusMap(struct UGameFrontendHUD* GameFrontendHUD, struct TMap<struct FName, struct FString> GameStatusMap); // Offset: 0x103a6ce50 // Return & Params: Num(2) Size(0x58)

	// Object Name: Function Client.ScriptHelperClient.SetGameSrvID
	// Flags: [Final|Native|Static|Public]
	void SetGameSrvID(struct UGameFrontendHUD* GameFrontendHUD, int GameSrvID); // Offset: 0x103a6cda0 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.SetFontStyle
	// Flags: [Final|Native|Static|Public]
	bool SetFontStyle(struct FString StyleName, int FontSize, struct FString FontPath, struct FString FontColor, bool UseShadow, bool IsBold); // Offset: 0x103a6cb18 // Return & Params: Num(7) Size(0x3b)

	// Object Name: Function Client.ScriptHelperClient.SetExtraLocalizationMap
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetExtraLocalizationMap(struct TMap<struct FString, struct FString>& translationMap); // Offset: 0x103a6ca74 // Return & Params: Num(1) Size(0x50)

	// Object Name: Function Client.ScriptHelperClient.SetExtraItemTableMappingByFix
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void SetExtraItemTableMappingByFix(struct TMap<int, struct FItemFixTableItem>& ItemFixMap); // Offset: 0x103a6c9d0 // Return & Params: Num(1) Size(0x50)

	// Object Name: Function Client.ScriptHelperClient.SetDynamicLevels
	// Flags: [Final|Native|Static|Public]
	void SetDynamicLevels(struct UGameFrontendHUD* GameFrontendHUD, struct TArray<struct FString> DynamicLevels); // Offset: 0x103a6c8b4 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.SetDumpShaderCompile
	// Flags: [Final|Native|Static|Public]
	void SetDumpShaderCompile(int iDumpVal); // Offset: 0x103a6c840 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.SetCrashContextReportLevel
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetCrashContextReportLevel(int Level); // Offset: 0x103a6c7cc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.SetCanWatchEnemy
	// Flags: [Final|Native|Static|Public]
	void SetCanWatchEnemy(struct UGameFrontendHUD* GameFrontendHUD, bool bCan); // Offset: 0x103a6c714 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.SetBtnClickInCdFunc
	// Flags: [Final|Native|Static|Public]
	void SetBtnClickInCdFunc(); // Offset: 0x103a6c700 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.SetAccountRegion
	// Flags: [Final|Native|Static|Public]
	void SetAccountRegion(struct FString Region); // Offset: 0x103a6c64c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.SendRetriveBeginnerFinisheGuideReq
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SendRetriveBeginnerFinisheGuideReq(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a6c5d8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.SendRecordFinishedGuideReq
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SendRecordFinishedGuideReq(struct UGameFrontendHUD* GameFrontendHUD, struct FString TipsID); // Offset: 0x103a6c4e4 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.SendPlayEmote
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SendPlayEmote(struct UGameFrontendHUD* GameFrontendHUD, int EmoteIndex); // Offset: 0x103a6c434 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.SendLobbyChat
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SendLobbyChat(struct UGameFrontendHUD* GameFrontendHUD, struct FString gid, struct FString Content); // Offset: 0x103a6c2c8 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.ScriptHelperClient.SendDirtyToFilter
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SendDirtyToFilter(struct UGameFrontendHUD* GameFrontendHUD, struct FString dirtyString, struct FString prefixString, int UId); // Offset: 0x103a6c11c // Return & Params: Num(4) Size(0x2c)

	// Object Name: Function Client.ScriptHelperClient.SendClientLog
	// Flags: [Final|Native|Static|Public]
	void SendClientLog(struct UGameFrontendHUD* GameFrontendHUD, struct FString errorReason, struct FString errorDescription, bool pullAll); // Offset: 0x103a6bfb4 // Return & Params: Num(4) Size(0x29)

	// Object Name: Function Client.ScriptHelperClient.ScheduleLocalNotificationAtTime
	// Flags: [Final|Native|Static|Public]
	void ScheduleLocalNotificationAtTime(int Year, int Month, int Day, int Hour, int Minute, int Second, bool LocalTime, struct FString Title, struct FString Body, struct FString Action, int NotificationID); // Offset: 0x103a6bbf8 // Return & Params: Num(11) Size(0x54)

	// Object Name: Function Client.ScriptHelperClient.SaveStringToIntermediateFile
	// Flags: [Final|Native|Static|Public]
	void SaveStringToIntermediateFile(struct FString String, struct FString Filename); // Offset: 0x103a6bb14 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.SaveStringToFile
	// Flags: [Final|Native|Static|Public]
	void SaveStringToFile(struct FString String, struct FString Filename); // Offset: 0x103a6ba30 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.SaveSavFile
	// Flags: [Final|Native|Static|Public]
	bool SaveSavFile(struct FString CompressedData, struct FString Filename, int CompressedSize, int UnCompressedSize); // Offset: 0x103a6b880 // Return & Params: Num(5) Size(0x29)

	// Object Name: Function Client.ScriptHelperClient.SaveLuaMemoryFile
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SaveLuaMemoryFile(struct FString Filename, struct FString InputContent, bool RmExistFile); // Offset: 0x103a6b754 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function Client.ScriptHelperClient.SaveArrayToFile
	// Flags: [Final|Native|Static|Public|HasOutParms]
	bool SaveArrayToFile(struct TArray<char>& Content, struct FString Filename); // Offset: 0x103a6b64c // Return & Params: Num(3) Size(0x21)

	// Object Name: Function Client.ScriptHelperClient.RunConsoleCommondAndGetString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString RunConsoleCommondAndGetString(struct FString commond); // Offset: 0x103a6b58c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.RunConsoleCommond
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void RunConsoleCommond(struct FString commond); // Offset: 0x103a6b4fc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.RoomOwnerInterruptGame
	// Flags: [Final|Native|Static|Public]
	void RoomOwnerInterruptGame(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a6b488 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.ReturnToLobby
	// Flags: [Final|Native|Static|Public]
	void ReturnToLobby(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a6b414 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.RestartGame
	// Flags: [Final|Native|Static|Public]
	void RestartGame(); // Offset: 0x103a6b400 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.RequestFile
	// Flags: [Final|Native|Static|Public]
	uint64 RequestFile(struct UGameFrontendHUD* GameFrontendHUD, struct FString FilePath, bool ForceUpdate); // Offset: 0x103a6b2b4 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function Client.ScriptHelperClient.ReportFirebaseEventWithString
	// Flags: [Final|Native|Static|Public]
	void ReportFirebaseEventWithString(struct FString eventTypeString, struct FString bundleExtraKey, struct FString bundleExtraValue, bool isUnique); // Offset: 0x103a6b134 // Return & Params: Num(4) Size(0x31)

	// Object Name: Function Client.ScriptHelperClient.ReportFirebaseEventWithParam
	// Flags: [Final|Native|Static|Public]
	void ReportFirebaseEventWithParam(struct FString eventTypeString, struct TMap<struct FString, struct FString> _params, bool isUnique); // Offset: 0x103a6afdc // Return & Params: Num(3) Size(0x61)

	// Object Name: Function Client.ScriptHelperClient.ReportEventRegisterCompleted
	// Flags: [Final|Native|Static|Public]
	void ReportEventRegisterCompleted(); // Offset: 0x103a6afc8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.ReportEventPurchaseConsider
	// Flags: [Final|Native|Static|Public]
	void ReportEventPurchaseConsider(); // Offset: 0x103a6afb4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.ReportEventLoadingCompleted
	// Flags: [Final|Native|Static|Public]
	void ReportEventLoadingCompleted(); // Offset: 0x103a6afa0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.ReportContextValuesOnCrash
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void ReportContextValuesOnCrash(struct FString& Json); // Offset: 0x103a6af00 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.ReportBuglyLogWithFDNum
	// Flags: [Final|Native|Static|Public]
	void ReportBuglyLogWithFDNum(struct FString baseLogInfo); // Offset: 0x103a6ae4c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.ReportBattleChat
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ReportBattleChat(struct UGameFrontendHUD* GameFrontendHUD, struct FString Msg, int msgExtraParam); // Offset: 0x103a6ad18 // Return & Params: Num(3) Size(0x1c)

	// Object Name: Function Client.ScriptHelperClient.ReplyInvite
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ReplyInvite(struct UGameFrontendHUD* GameFrontendHUD, struct FString gid, bool bReply); // Offset: 0x103a6abdc // Return & Params: Num(3) Size(0x19)

	// Object Name: Function Client.ScriptHelperClient.RemoveKnownMissingPackage
	// Flags: [Final|Native|Static|Public]
	void RemoveKnownMissingPackage(struct FString PackageName); // Offset: 0x103a6ab28 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.RemountPakFiles
	// Flags: [Final|Native|Static|Public]
	bool RemountPakFiles(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a6aaac // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.ReInitializePuffer
	// Flags: [Final|Native|Static|Public]
	void ReInitializePuffer(struct UGameFrontendHUD* GameFrontendHUD, bool needCheck, int maxDownloadsPerTask, int maxDownTask, int maxDownloadSpeed, bool useOldInterface, bool removeOldWhenUpdate, int versionType); // Offset: 0x103a6a878 // Return & Params: Num(8) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.RecordLuaExceptionInfo
	// Flags: [Final|Native|Static|Public]
	void RecordLuaExceptionInfo(struct FString exception); // Offset: 0x103a6a7c4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.QuitVoiceRoom
	// Flags: [Final|Native|Static|Public]
	void QuitVoiceRoom(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a6a750 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.QuitLbsVoiceRoom
	// Flags: [Final|Native|Static|Public]
	void QuitLbsVoiceRoom(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a6a6dc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.QuitFightChat
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void QuitFightChat(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a6a668 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.QuickLogin
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void QuickLogin(struct TScriptInterface<Class>& ClientNetInterface, int refreshTokenBeforeExpDays); // Offset: 0x103a6a5a8 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.QQShareToFriend
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void QQShareToFriend(struct TScriptInterface<Class>& ClientNetInterface, int act, struct FString OpenID, struct FString Title, struct FString Desc, struct FString targetUrl, struct FString imgUrl, struct FString previewText, struct FString gameTag, struct FString msdkExtInfo); // Offset: 0x103a6a23c // Return & Params: Num(10) Size(0x98)

	// Object Name: Function Client.ScriptHelperClient.QQShareH5WithPhoto
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void QQShareH5WithPhoto(struct TScriptInterface<Class>& ClientNetInterface, struct FString _title, struct FString _fullURL, int Channel); // Offset: 0x103a6a0c8 // Return & Params: Num(4) Size(0x34)

	// Object Name: Function Client.ScriptHelperClient.QQShare
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void QQShare(struct TScriptInterface<Class>& ClientNetInterface, struct FString _descShare, struct FString _titleShare, struct FString _imgPath, struct FString _imgUrl, struct FString _url, int _shareScene); // Offset: 0x103a69e58 // Return & Params: Num(7) Size(0x64)

	// Object Name: Function Client.ScriptHelperClient.QQAddFriend
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void QQAddFriend(struct TScriptInterface<Class>& ClientNetInterface, struct FString OpenID, struct FString Desc, struct FString Message); // Offset: 0x103a69cd0 // Return & Params: Num(4) Size(0x40)

	// Object Name: Function Client.ScriptHelperClient.PVEAutoTestGetEnermyLocation
	// Flags: [Final|Native|Static|Public|HasDefaults]
	struct FVector PVEAutoTestGetEnermyLocation(); // Offset: 0x103a69c98 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.PubgmSimulateActionClientEx
	// Flags: [Final|Native|Static|Public]
	void PubgmSimulateActionClientEx(struct UGameFrontendHUD* GameFrontendHUD, int SimulateType); // Offset: 0x103a69be8 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.ProjectSavedDir
	// Flags: [Final|Native|Static|Public]
	struct FString ProjectSavedDir(); // Offset: 0x103a69b84 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.ProjectContentDir
	// Flags: [Final|Native|Static|Public]
	struct FString ProjectContentDir(); // Offset: 0x103a69b20 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.ProcessSoPatch
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool ProcessSoPatch(struct FString InAppVerStr); // Offset: 0x103a69a88 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.ProcessServerRelationChainError
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void ProcessServerRelationChainError(struct TScriptInterface<Class>& ClientNetInterface, struct FString ErrorMsg, int iForceLoginInterval); // Offset: 0x103a69944 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function Client.ScriptHelperClient.PostGameStatusToTGPASMap
	// Flags: [Final|Native|Static|Public]
	void PostGameStatusToTGPASMap(struct UGameFrontendHUD* GameFrontendHUD, struct FString Key, struct TMap<struct FString, struct FString> mapData); // Offset: 0x103a697d0 // Return & Params: Num(3) Size(0x68)

	// Object Name: Function Client.ScriptHelperClient.PlayHapticsFile
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PlayHapticsFile(struct FString FilePath, int Duration, DelegateProperty Callback); // Offset: 0x103a69688 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.ScriptHelperClient.PandoraSendCmd
	// Flags: [Final|Native|Static|Public]
	void PandoraSendCmd(struct FString jsonStr); // Offset: 0x103a695d4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.PandoraInit
	// Flags: [Final|Native|Static|Public]
	void PandoraInit(struct FString InOpenId, struct FString InRoleId, struct FString InAppId, struct FString InPlatId, struct FString InAccType, struct FString InArea, struct FString InPartion, struct FString InCloudTest, struct FString InAccessToken, struct FString InSdkVersion, struct FString InGameVersion, struct FString InRoleName, struct FString InPayToken, struct FString InHeadUrl, struct FString InChanelId, struct FString InBelongingId, struct FString InLanguage, struct FString InTicket, struct FString InIp, struct FString InNation, struct FString InNetType); // Offset: 0x103a68b8c // Return & Params: Num(21) Size(0x150)

	// Object Name: Function Client.ScriptHelperClient.PandoraErrorReport
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void PandoraErrorReport(int iType, int iActId, int errCode, struct FString errMsg, struct FString extraMsg, struct TMap<struct FString, struct FString>& extendDict); // Offset: 0x103a6898c // Return & Params: Num(6) Size(0x80)

	// Object Name: Function Client.ScriptHelperClient.PandoraEnable
	// Flags: [Final|Native|Static|Public]
	void PandoraEnable(bool Enable); // Offset: 0x103a68910 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.PandoraClose
	// Flags: [Final|Native|Static|Public]
	void PandoraClose(); // Offset: 0x103a688fc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.OpenWebviewInGameProcess
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void OpenWebviewInGameProcess(struct FString URL, int Left, int Top, int Right, int Bottom); // Offset: 0x103a68774 // Return & Params: Num(5) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.OpenURLWithExtra
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void OpenURLWithExtra(struct FString URL, struct TMap<struct FString, struct FString> ExtraMap); // Offset: 0x103a68640 // Return & Params: Num(2) Size(0x60)

	// Object Name: Function Client.ScriptHelperClient.OpenURL
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void OpenURL(struct FString URL, bool isGetTicket, bool withNeverAdjust, bool bKeepCache); // Offset: 0x103a684ac // Return & Params: Num(4) Size(0x13)

	// Object Name: Function Client.ScriptHelperClient.OpenShaderCodeLibrary
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool OpenShaderCodeLibrary(struct FString Path, struct FString VersionNum); // Offset: 0x103a68378 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function Client.ScriptHelperClient.OpenH5FromCache
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void OpenH5FromCache(struct UGameFrontendHUD* GameFrontendHUD, struct FString ModuleName, struct FString Language, int netType, int Top, int Left, int Right, struct FString ViewParam); // Offset: 0x103a680a0 // Return & Params: Num(8) Size(0x48)

	// Object Name: DelegateFunction Client.ScriptHelperClient.OnWebViewCacheInfoDelegate__DelegateSignature
	// Flags: [Public|Delegate]
	void OnWebViewCacheInfoDelegate__DelegateSignature(int code); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.OnWebViewCache
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void OnWebViewCache(int code); // Offset: 0x103a6802c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.OnNotifyFightFriendChat
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void OnNotifyFightFriendChat(struct UGameFrontendHUD* GameFrontendHUD, struct FFightFriendChat& Data); // Offset: 0x103a67f48 // Return & Params: Num(2) Size(0x40)

	// Object Name: Function Client.ScriptHelperClient.OnMiniGameEnded
	// Flags: [Final|Native|Static|Public]
	void OnMiniGameEnded(struct UGameFrontendHUD* GameFrontendHUD, int Score, int Duration, bool bGameClosed); // Offset: 0x103a67e1c // Return & Params: Num(4) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.OnIslandPlayerInfoNotify
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void OnIslandPlayerInfoNotify(struct UGameFrontendHUD* GameFrontendHUD, int LandId); // Offset: 0x103a67d6c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.OnInviteNextBattle
	// Flags: [Final|Native|Static|Public]
	bool OnInviteNextBattle(struct UGameFrontendHUD* GameFrontendHUD, struct FString gid, struct FString Name); // Offset: 0x103a67c44 // Return & Params: Num(4) Size(0x29)

	// Object Name: Function Client.ScriptHelperClient.OnGetUpdateStateCDNConfigUrl
	// Flags: [Final|Native|Static|Public]
	void OnGetUpdateStateCDNConfigUrl(struct UGameFrontendHUD* GameFrontendHUD, struct FString URL); // Offset: 0x103a67b78 // Return & Params: Num(2) Size(0x18)

	// Object Name: DelegateFunction Client.ScriptHelperClient.OnGetItemBigIcon__DelegateSignature
	// Flags: [Public|Delegate]
	struct FString OnGetItemBigIcon__DelegateSignature(struct FString strPath); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.OnFilterFinish
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void OnFilterFinish(struct UGameFrontendHUD* GameFrontendHUD, struct FString filterText); // Offset: 0x103a67aac // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.OnEnterLobbyReloadLocalizationResource
	// Flags: [Final|Native|Static|Public]
	void OnEnterLobbyReloadLocalizationResource(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a67a38 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.OnEnterGameReleaseLocalizationResource
	// Flags: [Final|Native|Static|Public]
	void OnEnterGameReleaseLocalizationResource(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a679c4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.OnDolphinAppUpdateFinished
	// Flags: [Final|Native|Static|Public]
	void OnDolphinAppUpdateFinished(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a67950 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.OnCombatHitFeedback
	// Flags: [Final|Native|Static|Public]
	void OnCombatHitFeedback(struct UGameFrontendHUD* GameFrontendHUD, bool bCombatHitFeedbackEnable); // Offset: 0x103a67898 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.OnBattleResultCallBack
	// Flags: [Final|Native|Static|Public]
	void OnBattleResultCallBack(struct UGameFrontendHUD* GameFrontendHUD, struct FBattleResultData BattleResultData); // Offset: 0x103a67798 // Return & Params: Num(2) Size(0x90)

	// Object Name: Function Client.ScriptHelperClient.OnBattleResult
	// Flags: [Final|Native|Static|Public]
	void OnBattleResult(struct UGameFrontendHUD* GameFrontendHUD, struct FBattleResultData BattleResultData); // Offset: 0x103a67698 // Return & Params: Num(2) Size(0x90)

	// Object Name: Function Client.ScriptHelperClient.ObjectPoolServerSwitch
	// Flags: [Final|Native|Static|Public]
	void ObjectPoolServerSwitch(bool bSwitchOn); // Offset: 0x103a6761c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.NotifyBeginnerFinishedGuideUpdated
	// Flags: [Final|Native|Static|Public]
	void NotifyBeginnerFinishedGuideUpdated(struct UGameFrontendHUD* GameFrontendHUD, bool GuideSwitch, struct TArray<struct FPlayerFinishedGuide> finished_guide, int player_level, int player_exp_type); // Offset: 0x103a67440 // Return & Params: Num(5) Size(0x28)

	// Object Name: Function Client.ScriptHelperClient.MSDKWebViewCallJS
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void MSDKWebViewCallJS(struct FString strJS); // Offset: 0x103a6738c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.MoveFollowTarget
	// Flags: [Final|Native|Static|Public]
	void MoveFollowTarget(struct UGameFrontendHUD* GameFrontendHUD, int FollowType, uint64 UId); // Offset: 0x103a672a0 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.MoveFile
	// Flags: [Final|Native|Static|Public]
	bool MoveFile(struct FString SrcFullPath, struct FString DesFullPath); // Offset: 0x103a671b4 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function Client.ScriptHelperClient.MountPakFile
	// Flags: [Final|Native|Static|Public]
	bool MountPakFile(struct FString InPakFilename, struct FString Key); // Offset: 0x103a670c8 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function Client.ScriptHelperClient.MidasSDKInit_LuaState
	// Flags: [Final|Native|Static|Public]
	int MidasSDKInit_LuaState(); // Offset: 0x103a670b0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.MidasReprovide_LuaState
	// Flags: [Final|Native|Static|Public]
	int MidasReprovide_LuaState(); // Offset: 0x103a67098 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.MidasPay
	// Flags: [Final|Native|Static|Public]
	void MidasPay(struct FString productid, int payItem, struct FString country, struct FString currency); // Offset: 0x103a66f20 // Return & Params: Num(4) Size(0x38)

	// Object Name: Function Client.ScriptHelperClient.MidasH5Pay
	// Flags: [Final|Native|Static|Public]
	void MidasH5Pay(struct FString country); // Offset: 0x103a66e90 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.MidasGoodsPresent
	// Flags: [Final|Native|Static|Public]
	void MidasGoodsPresent(struct FString productid, int payItem, struct FString price, struct FString country, struct FString currency, struct FString MetaData); // Offset: 0x103a66c70 // Return & Params: Num(6) Size(0x58)

	// Object Name: Function Client.ScriptHelperClient.MidasGoods
	// Flags: [Final|Native|Static|Public]
	void MidasGoods(struct FString productid, int payItem, struct FString price, struct FString country, struct FString currency); // Offset: 0x103a66aa4 // Return & Params: Num(5) Size(0x48)

	// Object Name: Function Client.ScriptHelperClient.MessageBoxExt
	// Flags: [Final|Native|Static|Public]
	void MessageBoxExt(struct FString Caption, struct FString Text); // Offset: 0x103a669c0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.MediaCopyFromPakToLocal
	// Flags: [Final|Native|Static|Public]
	bool MediaCopyFromPakToLocal(struct FString from, bool bForce); // Offset: 0x103a668b4 // Return & Params: Num(3) Size(0x12)

	// Object Name: Function Client.ScriptHelperClient.MD5LuaString_LuaState
	// Flags: [Final|Native|Static|Public]
	int MD5LuaString_LuaState(); // Offset: 0x103a6689c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.MD5HashAnsiString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString MD5HashAnsiString(struct FString str); // Offset: 0x103a667b8 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.ManualSleep
	// Flags: [Final|Native|Static|Public]
	void ManualSleep(float Seconds); // Offset: 0x103a66744 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.LuaLoadFileToString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString LuaLoadFileToString(struct FString InFileName); // Offset: 0x103a66684 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.LogoutAllDevices
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void LogoutAllDevices(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103a66600 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.Logout
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void Logout(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103a6657c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.LoginWithExtraInfo
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void LoginWithExtraInfo(struct TScriptInterface<Class>& ClientNetInterface, uint32_t Channel, struct FString InExtraJson); // Offset: 0x103a66460 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.ScriptHelperClient.Login
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void Login(struct TScriptInterface<Class>& ClientNetInterface, uint32_t Channel); // Offset: 0x103a663a0 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.LobbySetUserRegion
	// Flags: [Final|Native|Static|Public]
	void LobbySetUserRegion(int InRegion); // Offset: 0x103a6632c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.LobbySetProxyPortlist
	// Flags: [Final|Native|Static|Public]
	void LobbySetProxyPortlist(struct FString InNodePortList); // Offset: 0x103a6629c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.LobbySetProxyNodelist
	// Flags: [Final|Native|Static|Public]
	void LobbySetProxyNodelist(struct FString InNodeIpList); // Offset: 0x103a6620c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.LobbySetEchoPortlist
	// Flags: [Final|Native|Static|Public]
	void LobbySetEchoPortlist(struct FString InEchoPortList); // Offset: 0x103a6617c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.LobbyIsLinkProxy
	// Flags: [Final|Native|Static|Public]
	bool LobbyIsLinkProxy(struct FString InIp, int InPort); // Offset: 0x103a660a4 // Return & Params: Num(3) Size(0x15)

	// Object Name: Function Client.ScriptHelperClient.LobbyAddAddress
	// Flags: [Final|Native|Static|Public]
	void LobbyAddAddress(struct FString InProtocol, struct FString InIp, int InPort); // Offset: 0x103a65f80 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function Client.ScriptHelperClient.LoadSavFile_LuaState
	// Flags: [Final|Native|Static|Public]
	int LoadSavFile_LuaState(); // Offset: 0x103a65f68 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.LoadMidasProductInfo_LuaState
	// Flags: [Final|Native|Static|Public]
	int LoadMidasProductInfo_LuaState(); // Offset: 0x103a65f50 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.LoadMidasMP_LuaState
	// Flags: [Final|Native|Static|Public]
	int LoadMidasMP_LuaState(); // Offset: 0x103a65f38 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.LoadMidasIntroPrice_LuaState
	// Flags: [Final|Native|Static|Public]
	int LoadMidasIntroPrice_LuaState(); // Offset: 0x103a65f20 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.LoadIntermediateFileToString
	// Flags: [Final|Native|Static|Public]
	struct FString LoadIntermediateFileToString(struct FString Filename); // Offset: 0x103a65e60 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.LoadH5FromCache
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void LoadH5FromCache(struct UGameFrontendHUD* GameFrontendHUD, struct FString ModuleName, struct FString Language, int netType, int Top, int Left, int Right, struct FString ViewParam); // Offset: 0x103a65b88 // Return & Params: Num(8) Size(0x48)

	// Object Name: Function Client.ScriptHelperClient.LoadFileToStringByFullPath
	// Flags: [Final|Native|Static|Public]
	struct FString LoadFileToStringByFullPath(struct FString FullPathName); // Offset: 0x103a65ac8 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.LoadFileToString
	// Flags: [Final|Native|Static|Public]
	struct FString LoadFileToString(struct FString Filename); // Offset: 0x103a65a08 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.LoadFileToArray
	// Flags: [Final|Native|Static|Public]
	struct TArray<char> LoadFileToArray(struct FString Filename); // Offset: 0x103a65948 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.LoadAmendODs
	// Flags: [Final|Native|Static|Public]
	bool LoadAmendODs(struct TMap<uint32_t, struct FString> Keys); // Offset: 0x103a65888 // Return & Params: Num(2) Size(0x51)

	// Object Name: Function Client.ScriptHelperClient.LoadAFDTranslation
	// Flags: [Final|Native|Static|Public]
	void LoadAFDTranslation(); // Offset: 0x103a65874 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.LaunchUrl
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void LaunchUrl(struct FString& URL); // Offset: 0x103a657d4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.JoinVoiceRoom
	// Flags: [Final|Native|Static|Public]
	void JoinVoiceRoom(struct UGameFrontendHUD* GameFrontendHUD, struct FString roomName, struct FString userId); // Offset: 0x103a65668 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.ScriptHelperClient.JoinLbsVoiceRoom
	// Flags: [Final|Native|Static|Public]
	void JoinLbsVoiceRoom(struct UGameFrontendHUD* GameFrontendHUD, struct FString lbsRoomName, struct FString userId); // Offset: 0x103a654fc // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.ScriptHelperClient.IsWindowsClientReplay
	// Flags: [Final|Native|Static|Public]
	bool IsWindowsClientReplay(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a65480 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.IsWindowOB
	// Flags: [Final|Native|Static|Public]
	bool IsWindowOB(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a65404 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.IsUsingBluetooth
	// Flags: [Final|Native|Static|Public]
	bool IsUsingBluetooth(); // Offset: 0x103a653d0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsUseTypicalResultFlowMode
	// Flags: [Final|Native|Static|Public]
	bool IsUseTypicalResultFlowMode(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a65354 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.IsUpdateSkip
	// Flags: [Final|Native|Static|Public]
	bool IsUpdateSkip(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a652d8 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.IsUIAutoTest
	// Flags: [Final|Native|Static|Public]
	bool IsUIAutoTest(); // Offset: 0x103a652a4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsTypicalMode
	// Flags: [Final|Native|Static|Public]
	bool IsTypicalMode(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a65228 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.IsTest
	// Flags: [Final|Native|Static|Public]
	bool IsTest(); // Offset: 0x103a651f4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsSystemVPNOpened
	// Flags: [Final|Native|Static|Public]
	bool IsSystemVPNOpened(); // Offset: 0x103a651c0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsSupportVulkan
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsSupportVulkan(); // Offset: 0x103a6518c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsSplitMiniPakVersion
	// Flags: [Final|Native|Static|Public]
	bool IsSplitMiniPakVersion(); // Offset: 0x103a65158 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsSplitMapPakVersion
	// Flags: [Final|Native|Static|Public]
	bool IsSplitMapPakVersion(); // Offset: 0x103a65124 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.isSkipUpdateByRepair
	// Flags: [Final|Native|Static|Public]
	bool isSkipUpdateByRepair(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a650a8 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.IsShipping
	// Flags: [Final|Native|Static|Public]
	bool IsShipping(); // Offset: 0x103a65074 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsSavFileData
	// Flags: [Final|Native|Static|Public]
	bool IsSavFileData(struct FString CompressedData, int CompressedSize, int UnCompressedSize, int ToCheckEndWithCDLenght); // Offset: 0x103a64efc // Return & Params: Num(5) Size(0x1d)

	// Object Name: Function Client.ScriptHelperClient.IsRuningOnVulkan
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsRuningOnVulkan(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a64e80 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.IsReleaseVersion
	// Flags: [Final|Native|Static|Public|HasOutParms]
	bool IsReleaseVersion(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103a64df4 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsPVEMode
	// Flags: [Final|Native|Static|Public]
	bool IsPVEMode(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a64d78 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.IsOpenAOS90FPSConfig
	// Flags: [Final|Native|Static|Public]
	bool IsOpenAOS90FPSConfig(); // Offset: 0x103a64d44 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsODPakMonted
	// Flags: [Final|Native|Static|Public]
	bool IsODPakMonted(struct FString Filename); // Offset: 0x103a64cac // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsNotificationEnabled
	// Flags: [Final|Native|Static|Public]
	bool IsNotificationEnabled(); // Offset: 0x103a64c78 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsNoAuthMode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsNoAuthMode(); // Offset: 0x103a64c44 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsNetworkReachable
	// Flags: [Final|Native|Static|Public]
	bool IsNetworkReachable(); // Offset: 0x103a64c10 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsNeedClearHiddenUI
	// Flags: [Final|Native|Static|Public]
	bool IsNeedClearHiddenUI(struct UFrontendHUD* GameFrontendHUD); // Offset: 0x103a64b94 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.IsMounted
	// Flags: [Final|Native|Static|Public]
	bool IsMounted(struct FString Filename); // Offset: 0x103a64afc // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsLaunchedByLocalNotification
	// Flags: [Final|Native|Static|Public]
	bool IsLaunchedByLocalNotification(); // Offset: 0x103a64ac8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsJaguar
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsJaguar(); // Offset: 0x103a64a94 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsIPhoneFiveSOriginal
	// Flags: [Final|Native|Static|Public]
	bool IsIPhoneFiveSOriginal(); // Offset: 0x103a64a60 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsIPhoneFiveS
	// Flags: [Final|Native|Static|Public]
	bool IsIPhoneFiveS(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a649e4 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.IsIOSVersionAbove13
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsIOSVersionAbove13(); // Offset: 0x103a649b0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsInstallWX
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool IsInstallWX(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103a64924 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsInstallWhatsapp
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool IsInstallWhatsapp(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103a64898 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsInstallVK
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool IsInstallVK(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103a6480c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsInstallTwitter
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool IsInstallTwitter(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103a64780 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsInstallQQByiTOP
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool IsInstallQQByiTOP(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103a646f4 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsInstallOpenRec
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool IsInstallOpenRec(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103a64668 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsInstallMirrativ
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool IsInstallMirrativ(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103a645dc // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsInstallMessenger
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool IsInstallMessenger(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103a64550 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsInstallLite
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool IsInstallLite(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103a644c4 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsInstallLine
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool IsInstallLine(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103a64438 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsInstallFaceBook
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool IsInstallFaceBook(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103a643ac // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsInstallDiscord
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool IsInstallDiscord(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103a64320 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsHarmonyOS
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsHarmonyOS(); // Offset: 0x103a642ec // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsHapticsEngineEnable
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsHapticsEngineEnable(); // Offset: 0x103a642b8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsForCE
	// Flags: [Final|Native|Static|Public]
	bool IsForCE(); // Offset: 0x103a64284 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsFileReady
	// Flags: [Final|Native|Static|Public]
	bool IsFileReady(struct UGameFrontendHUD* GameFrontendHUD, struct FString FilePath); // Offset: 0x103a64188 // Return & Params: Num(3) Size(0x19)

	// Object Name: Function Client.ScriptHelperClient.IsFileExistsWithPakCheckMatchExt
	// Flags: [Final|Native|Static|Public]
	bool IsFileExistsWithPakCheckMatchExt(struct FString Filename); // Offset: 0x103a640f0 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsFileExistsWithPakCheck
	// Flags: [Final|Native|Static|Public]
	bool IsFileExistsWithPakCheck(struct FString Filename); // Offset: 0x103a64058 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsFileExistsWithOutPakCheck
	// Flags: [Final|Native|Static|Public]
	bool IsFileExistsWithOutPakCheck(struct FString Path); // Offset: 0x103a63fc0 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsFileExistByFileName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsFileExistByFileName(struct FString Filename); // Offset: 0x103a63f28 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsFileExistByExtension
	// Flags: [Final|Native|Static|Public]
	bool IsFileExistByExtension(struct UGameFrontendHUD* GameFrontendHUD, struct FString Filename, struct FString fileExtension); // Offset: 0x103a63db4 // Return & Params: Num(4) Size(0x29)

	// Object Name: Function Client.ScriptHelperClient.IsFileExist
	// Flags: [Final|Native|Static|Public]
	bool IsFileExist(struct UGameFrontendHUD* GameFrontendHUD, struct FString Filename); // Offset: 0x103a63cb8 // Return & Params: Num(3) Size(0x19)

	// Object Name: Function Client.ScriptHelperClient.IsEmulatorWhenInit
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsEmulatorWhenInit(); // Offset: 0x103a63c84 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsEmulator
	// Flags: [Final|Native|Static|Public]
	bool IsEmulator(); // Offset: 0x103a63c50 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsEditorDedicatedServer
	// Flags: [Final|Native|Static|Public]
	bool IsEditorDedicatedServer(); // Offset: 0x103a63c1c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsEditor
	// Flags: [Final|Native|Static|Public]
	bool IsEditor(); // Offset: 0x103a63be8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsDolbyAtmosSupported
	// Flags: [Final|Native|Static|Public]
	bool IsDolbyAtmosSupported(); // Offset: 0x103a63bb4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsDeviceSupportsViberation
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsDeviceSupportsViberation(); // Offset: 0x103a63b80 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsDeviceSupportsHapticsEngine
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsDeviceSupportsHapticsEngine(); // Offset: 0x103a63b4c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsDeviceHWSupportVulkan
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsDeviceHWSupportVulkan(); // Offset: 0x103a63b18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsDevelopment
	// Flags: [Final|Native|Static|Public]
	bool IsDevelopment(); // Offset: 0x103a63ae4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsConnected
	// Flags: [Final|Native|Static|Public|HasOutParms]
	bool IsConnected(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103a63a58 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsCEVersion
	// Flags: [Final|Native|Static|Public]
	bool IsCEVersion(); // Offset: 0x103a63a24 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsCEHideLobbyUI
	// Flags: [Final|Native|Static|Public]
	bool IsCEHideLobbyUI(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a639a8 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.IsBasePrefecthOpen
	// Flags: [Final|Native|Static|Public]
	bool IsBasePrefecthOpen(); // Offset: 0x103a63974 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsAwakedByNotification
	// Flags: [Final|Native|Static|Public]
	bool IsAwakedByNotification(); // Offset: 0x103a63940 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsAndroidHasGyr
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsAndroidHasGyr(); // Offset: 0x103a6390c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.InviteWhatsappOfflineFriends
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void InviteWhatsappOfflineFriends(struct TScriptInterface<Class>& ClientNetInterface, struct FString Title, struct FString Content); // Offset: 0x103a637d8 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.InviteSystemOfflineFriends
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void InviteSystemOfflineFriends(struct TScriptInterface<Class>& ClientNetInterface, struct FString Title, struct FString Content); // Offset: 0x103a636a4 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.InviteSMSOfflineFriends
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void InviteSMSOfflineFriends(struct TScriptInterface<Class>& ClientNetInterface, struct FString Content); // Offset: 0x103a635c4 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.InviteLineOfflineFriends
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void InviteLineOfflineFriends(struct TScriptInterface<Class>& ClientNetInterface, struct FString Title, struct FString Content); // Offset: 0x103a63490 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.InviteFBOfflineFriends
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void InviteFBOfflineFriends(struct TScriptInterface<Class>& ClientNetInterface, struct FString Title, struct FString Content, struct FString link); // Offset: 0x103a63308 // Return & Params: Num(4) Size(0x40)

	// Object Name: Function Client.ScriptHelperClient.InstallNewApp
	// Flags: [Final|Native|Static|Public]
	void InstallNewApp(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a63294 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.InitVPN
	// Flags: [Final|Native|Static|Public]
	int InitVPN(struct FString InVPNGUID, struct FString InClientVersion); // Offset: 0x103a631a8 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function Client.ScriptHelperClient.InitVlink
	// Flags: [Final|Native|Static|Public]
	void InitVlink(); // Offset: 0x103a63194 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.InitQuantumPlatformMisc
	// Flags: [Final|Native|Static|Public]
	void InitQuantumPlatformMisc(); // Offset: 0x103a63180 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.InitLoginAccount
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void InitLoginAccount(struct TScriptInterface<Class>& ClientNetInterface, uint64 AccUin, struct FString AccPswd); // Offset: 0x103a6303c // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.ScriptHelperClient.InitJavaFunctions
	// Flags: [Final|Native|Static|Public]
	void InitJavaFunctions(); // Offset: 0x103a63028 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.InitIMSDKEnv
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void InitIMSDKEnv(struct TScriptInterface<Class>& ClientNetInterface, uint32_t iEnv); // Offset: 0x103a62f68 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.InitializePuffer
	// Flags: [Final|Native|Static|Public]
	void InitializePuffer(struct UGameFrontendHUD* GameFrontendHUD, bool needCheck, int maxDownloadsPerTask, int maxDownTask, int maxDownloadSpeed, bool useOldInterface, bool removeOldWhenUpdate, int versionType); // Offset: 0x103a62d34 // Return & Params: Num(8) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.InitializeLaggingReporter
	// Flags: [Final|Native|Static|Public]
	void InitializeLaggingReporter(struct UGameFrontendHUD* GameFrontendHUD, bool Enable); // Offset: 0x103a62c7c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.InitHF
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void InitHF(); // Offset: 0x103a62c68 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.InitGCloudRemoteConfig
	// Flags: [Final|Native|Static|Public]
	void InitGCloudRemoteConfig(); // Offset: 0x103a62c54 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.InitDH
	// Flags: [Final|Native|Static|Public]
	int InitDH(struct FString gen, struct FString prime, int v_srand); // Offset: 0x103a62ae0 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function Client.ScriptHelperClient.Ini_UpdateMemResource
	// Flags: [Final|Native|Static|Public]
	void Ini_UpdateMemResource(struct FString KeyWord, struct FString CMDvalue); // Offset: 0x103a629b4 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.HtmlEncode
	// Flags: [Final|Native|Static|Public]
	struct FString HtmlEncode(struct FString UnencodedString); // Offset: 0x103a628f4 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.HideH5WebView
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void HideH5WebView(); // Offset: 0x103a628e0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.HaveReceivedNoticeCallback
	// Flags: [Final|Native|Static|Public]
	bool HaveReceivedNoticeCallback(); // Offset: 0x103a628ac // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.HasRemoteConfigReady
	// Flags: [Final|Native|Static|Public]
	bool HasRemoteConfigReady(); // Offset: 0x103a62878 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.HasNotice
	// Flags: [Final|Native|Static|Public]
	bool HasNotice(int Type, struct FString Scene); // Offset: 0x103a627a4 // Return & Params: Num(3) Size(0x19)

	// Object Name: Function Client.ScriptHelperClient.HasNotchInScreen
	// Flags: [Final|Native|Static|Public]
	bool HasNotchInScreen(); // Offset: 0x103a62770 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.HasDownloadedBasePak
	// Flags: [Final|Native|Static|Public]
	bool HasDownloadedBasePak(); // Offset: 0x103a6273c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.HasActiveWifi
	// Flags: [Final|Native|Static|Public]
	bool HasActiveWifi(); // Offset: 0x103a62708 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.GotoPlatformAppraise
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void GotoPlatformAppraise(); // Offset: 0x103a626f4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.GMTestAllocUObjs
	// Flags: [Final|Native|Static|Public]
	void GMTestAllocUObjs(struct UGameFrontendHUD* GameFrontendHUD, int Num); // Offset: 0x103a62644 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.GMH5Enable
	// Flags: [Final|Native|Static|Public]
	void GMH5Enable(bool Flag); // Offset: 0x103a625c8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.GetWidgetsByClass
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetWidgetsByClass(struct UWidget* Parent, struct UObject* Type, struct TArray<struct UWidget*>& Children); // Offset: 0x103a624b4 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GetWebViewTicket
	// Flags: [Final|Native|Static|Public|HasOutParms]
	struct FString GetWebViewTicket(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103a62400 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GetWeaponDIYIconPath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetWeaponDIYIconPath(struct FString PlayerUID, int WeaponId, struct FString PlanID, bool relativePath, int Width, int Height); // Offset: 0x103a62194 // Return & Params: Num(7) Size(0x48)

	// Object Name: Function Client.ScriptHelperClient.GetVolume
	// Flags: [Final|Native|Static|Public]
	int GetVolume(int InStreamType); // Offset: 0x103a62118 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.GetUserVulkanSetting
	// Flags: [Final|Native|Static|Public]
	bool GetUserVulkanSetting(); // Offset: 0x103a620e4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.GetUserTGPATapEnableFlag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetUserTGPATapEnableFlag(); // Offset: 0x103a620b0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetUnrealNetworkStatus
	// Flags: [Final|Native|Static|Public]
	struct FString GetUnrealNetworkStatus(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a6200c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.GetUIRectOffset
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetUIRectOffset(); // Offset: 0x103a61fa8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetToken
	// Flags: [Final|Native|Static|Public|HasOutParms]
	struct FString GetToken(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103a61ef4 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GetTimeInMiliSeconds
	// Flags: [Final|Native|Static|Public]
	float GetTimeInMiliSeconds(); // Offset: 0x103a61ec0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetTGPATapDeviceSupportFlag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetTGPATapDeviceSupportFlag(); // Offset: 0x103a61e8c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetTelecomSvr
	// Flags: [Final|Native|Static|Public]
	struct FString GetTelecomSvr(); // Offset: 0x103a61e28 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetTCDeviceLevel
	// Flags: [Final|Native|Static|Public]
	int GetTCDeviceLevel(); // Offset: 0x103a61df4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetTableCount
	// Flags: [Final|Native|Static|Public]
	int GetTableCount(struct FString tableName); // Offset: 0x103a61d5c // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.GetSystemLanguage_LuaState
	// Flags: [Final|Native|Static|Public]
	int GetSystemLanguage_LuaState(); // Offset: 0x103a61d44 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetSubsideFeatureLevel
	// Flags: [Final|Native|Static|Public]
	uint32_t GetSubsideFeatureLevel(); // Offset: 0x103a61d10 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetSrcVersion
	// Flags: [Final|Native|Static|Public]
	struct FString GetSrcVersion(); // Offset: 0x103a61cac // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetSplitMapConfigInfo
	// Flags: [Final|Native|Static|Public]
	struct FString GetSplitMapConfigInfo(); // Offset: 0x103a61c48 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetSpecialData
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetSpecialData(); // Offset: 0x103a61be4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetSoundEffectQuality
	// Flags: [Final|Native|Static|Public]
	int GetSoundEffectQuality(); // Offset: 0x103a61bb0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetShaderPrecompileProgress
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetShaderPrecompileProgress(); // Offset: 0x103a61b7c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetServerDelay
	// Flags: [Final|Native|Static|Public]
	int GetServerDelay(struct FString ServerAddress); // Offset: 0x103a61ae4 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.GetScreenWidthForWebview
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetScreenWidthForWebview(); // Offset: 0x103a61ab0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetScreenWidth
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetScreenWidth(); // Offset: 0x103a61a7c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetScreenHole
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetScreenHole(); // Offset: 0x103a61a18 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetScreenHight
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetScreenHight(); // Offset: 0x103a619e4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetScreenHeightForWebview
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetScreenHeightForWebview(); // Offset: 0x103a619b0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetScreenDensity
	// Flags: [Final|Native|Static|Public]
	int GetScreenDensity(); // Offset: 0x103a6197c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetRingMode
	// Flags: [Final|Native|Static|Public]
	int GetRingMode(); // Offset: 0x103a61948 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetRemarkNameByGIDWithObj
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetRemarkNameByGIDWithObj(struct UObject* Obj, struct FString gid, struct FString PlayerName); // Offset: 0x103a617ac // Return & Params: Num(4) Size(0x38)

	// Object Name: Function Client.ScriptHelperClient.GetRemarkNameByGID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetRemarkNameByGID(struct UGameFrontendHUD* GameFrontendHUD, struct FString gid, struct FString PlayerName); // Offset: 0x103a61610 // Return & Params: Num(4) Size(0x38)

	// Object Name: Function Client.ScriptHelperClient.GetRegisterChannelID
	// Flags: [Final|Native|Static|Public|HasOutParms]
	struct FString GetRegisterChannelID(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103a6155c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GetRedBloodSwitch
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool GetRedBloodSwitch(); // Offset: 0x103a61528 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.GetPufferInitResult
	// Flags: [Final|Native|Static|Public]
	bool GetPufferInitResult(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a614ac // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.GetPufferInitErrCode
	// Flags: [Final|Native|Static|Public]
	uint32_t GetPufferInitErrCode(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a61430 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.GetPublishRegion
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetPublishRegion(); // Offset: 0x103a613cc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetPublicKey
	// Flags: [Final|Native|Static|Public]
	struct FString GetPublicKey(struct FString cli_pri_key); // Offset: 0x103a612e8 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GetPrivateKey
	// Flags: [Final|Native|Static|Public]
	struct FString GetPrivateKey(); // Offset: 0x103a61284 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetPingReportInfo
	// Flags: [Final|Native|Static|Public]
	struct FString GetPingReportInfo(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a611e0 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.GetPingReportData
	// Flags: [Final|Native|Static|Public]
	struct FString GetPingReportData(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a6113c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.GetPhysicalFileTime
	// Flags: [Final|Native|Static|Public]
	int64_t GetPhysicalFileTime(struct FString InPath); // Offset: 0x103a61080 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.GetPhoneType
	// Flags: [Final|Native|Static|Public]
	struct FString GetPhoneType(); // Offset: 0x103a6101c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetPhoneDeviceID
	// Flags: [Final|Native|Static|Public]
	struct FString GetPhoneDeviceID(); // Offset: 0x103a60fb8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetPhoneAdvertisingID
	// Flags: [Final|Native|Static|Public]
	struct FString GetPhoneAdvertisingID(); // Offset: 0x103a60f54 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetPackChannel
	// Flags: [Final|Native|Static|Public]
	struct FString GetPackChannel(); // Offset: 0x103a60ef0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetOSVersion
	// Flags: [Final|Native|Static|Public]
	struct FString GetOSVersion(); // Offset: 0x103a60e8c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetODPaksFileUseTime
	// Flags: [Final|Native|Static|Public]
	struct TArray<struct FString> GetODPaksFileUseTime(struct FString DumpFilename); // Offset: 0x103a60da8 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GetNotificationExtraDataString
	// Flags: [Final|Native|Static|Public]
	struct FString GetNotificationExtraDataString(struct FString Key); // Offset: 0x103a60ce8 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GetNotchSize
	// Flags: [Final|Native|Static|Public]
	struct TArray<int> GetNotchSize(); // Offset: 0x103a60c84 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetNetWorkType
	// Flags: [Final|Native|Static|Public]
	struct FString GetNetWorkType(); // Offset: 0x103a60c20 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetNativeVersion
	// Flags: [Final|Native|Static|Public]
	struct FString GetNativeVersion(); // Offset: 0x103a60bbc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetNativePackageTag
	// Flags: [Final|Native|Static|Public]
	struct FString GetNativePackageTag(); // Offset: 0x103a60b58 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetMyFriendObservers
	// Flags: [Final|Native|Static|Public]
	struct TArray<struct FString> GetMyFriendObservers(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a60ab4 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.GetMidasPF_LuaState
	// Flags: [Final|Native|Static|Public]
	int GetMidasPF_LuaState(); // Offset: 0x103a60a9c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetMidasPayChannel_LuaState
	// Flags: [Final|Native|Static|Public]
	int GetMidasPayChannel_LuaState(); // Offset: 0x103a60a84 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetMemoryStats_LuaState
	// Flags: [Final|Native|Static|Public]
	int GetMemoryStats_LuaState(); // Offset: 0x103a60a6c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetMemorySize
	// Flags: [Final|Native|Static|Public]
	int GetMemorySize(); // Offset: 0x103a60a38 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetLuaRootDir
	// Flags: [Final|Native|Static|Public]
	struct FString GetLuaRootDir(); // Offset: 0x103a609d4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetLoginChannel
	// Flags: [Final|Native|Static|Public|HasOutParms]
	int GetLoginChannel(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103a60948 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.GetLaunchLocalNotificationID
	// Flags: [Final|Native|Static|Public]
	struct FString GetLaunchLocalNotificationID(); // Offset: 0x103a608e4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetKnownMissingPackage
	// Flags: [Final|Native|Static|Public]
	struct TArray<struct FString> GetKnownMissingPackage(struct FString PackageName, struct FString DumpFilename); // Offset: 0x103a60788 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.GetiTOPLbsDelay
	// Flags: [Final|Native|Static|Public]
	int GetiTOPLbsDelay(); // Offset: 0x103a60754 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetITopGameId
	// Flags: [Final|Native|Static|Public|HasOutParms]
	struct FString GetITopGameId(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103a606a0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GetIsSecretVersion
	// Flags: [Final|Native|Static|Public]
	int GetIsSecretVersion(); // Offset: 0x103a6066c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetIsPlayerUsingVPN
	// Flags: [Final|Native|Static|Public]
	bool GetIsPlayerUsingVPN(); // Offset: 0x103a60638 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.GetIsOpenBattlePlayback
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool GetIsOpenBattlePlayback(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a605bc // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.GetIPRegion
	// Flags: [Final|Native|Static|Public]
	int GetIPRegion(); // Offset: 0x103a60588 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetIpAddrByHost
	// Flags: [Final|Native|Static|Public]
	struct FString GetIpAddrByHost(struct FString Host); // Offset: 0x103a604c8 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GetIpAddr
	// Flags: [Final|Native|Static|Public]
	struct FString GetIpAddr(); // Offset: 0x103a60464 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetIntDefaultOffset
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetIntDefaultOffset(); // Offset: 0x103a60430 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetInstallChannelID
	// Flags: [Final|Native|Static|Public|HasOutParms]
	struct FString GetInstallChannelID(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103a6037c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GetIMSDKEnv
	// Flags: [Final|Native|Static|Public]
	int GetIMSDKEnv(); // Offset: 0x103a60348 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetH5CacheStatus
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool GetH5CacheStatus(struct FString ModuleName); // Offset: 0x103a602b0 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.GetGvoiceReconnectInfo
	// Flags: [Final|Native|Static|Public]
	void GetGvoiceReconnectInfo(struct UGameFrontendHUD* GameFrontendHUD, struct TMap<struct FString, struct FString> Data); // Offset: 0x103a601b8 // Return & Params: Num(2) Size(0x58)

	// Object Name: Function Client.ScriptHelperClient.GetGroupInfo
	// Flags: [Final|Native|Static|Public|HasOutParms]
	struct FGroupInfoWrapper GetGroupInfo(struct TScriptInterface<Class>& ClientNetInterface, int SnsAction); // Offset: 0x103a600bc // Return & Params: Num(3) Size(0x68)

	// Object Name: Function Client.ScriptHelperClient.GetGoogleServiceVersionCode
	// Flags: [Final|Native|Static|Public]
	int GetGoogleServiceVersionCode(); // Offset: 0x103a60088 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetGLVersion
	// Flags: [Final|Native|Static|Public]
	struct FString GetGLVersion(); // Offset: 0x103a60024 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetGLType
	// Flags: [Final|Native|Static|Public]
	struct FString GetGLType(); // Offset: 0x103a5ffc0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetGameStatus
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetGameStatus(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a5ff1c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.GetGameModeID
	// Flags: [Final|Native|Static|Public]
	struct FString GetGameModeID(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a5fe78 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.GetGameMasterGUID
	// Flags: [Final|Native|Static|Public]
	struct FString GetGameMasterGUID(); // Offset: 0x103a5fe14 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetFPS
	// Flags: [Final|Native|Static|Public]
	float GetFPS(); // Offset: 0x103a5fde0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetFireBaseFCMToken
	// Flags: [Final|Native|Static|Public]
	struct FString GetFireBaseFCMToken(); // Offset: 0x103a5fd7c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetFileSizeOnDiskBytes
	// Flags: [Final|Native|Static|Public]
	int64_t GetFileSizeOnDiskBytes(struct FString FilePath); // Offset: 0x103a5fcc0 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.GetFileSizeOnDisk
	// Flags: [Final|Native|Static|Public]
	uint32_t GetFileSizeOnDisk(struct FString FilePath); // Offset: 0x103a5fc04 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.GetFileSizeCompressed
	// Flags: [Final|Native|Static|Public]
	uint64 GetFileSizeCompressed(struct UGameFrontendHUD* GameFrontendHUD, struct FString FilePath); // Offset: 0x103a5fb08 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GetFileDirPath
	// Flags: [Final|Native|Static|Public]
	struct FString GetFileDirPath(struct FString FilePath); // Offset: 0x103a5fa24 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GetFBFriendsUnregistered
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void GetFBFriendsUnregistered(struct TScriptInterface<Class>& ClientNetInterface, uint32_t page, uint32_t Count, uint32_t Type, struct FString extend); // Offset: 0x103a5f894 // Return & Params: Num(5) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.GetExactDeviceLevel
	// Flags: [Final|Native|Static|Public]
	int GetExactDeviceLevel(); // Offset: 0x103a5f860 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetEncodeUrl
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetEncodeUrl(struct FString URL); // Offset: 0x103a5f77c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GetEmulatorName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetEmulatorName(); // Offset: 0x103a5f718 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetDSVersion
	// Flags: [Final|Native|Static|Public]
	struct FString GetDSVersion(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a5f674 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.GetDeviceQualityLevel
	// Flags: [Final|Native|Static|Public]
	int GetDeviceQualityLevel(); // Offset: 0x103a5f640 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetDevicePlatformName
	// Flags: [Final|Native|Static|Public]
	struct FString GetDevicePlatformName(); // Offset: 0x103a5f5dc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetDeviceName
	// Flags: [Final|Native|Static|Public]
	struct FString GetDeviceName(); // Offset: 0x103a5f578 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetDeviceModel
	// Flags: [Final|Native|Static|Public]
	struct FString GetDeviceModel(); // Offset: 0x103a5f514 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetDeviceMaxSupportSoundEffect
	// Flags: [Final|Native|Static|Public]
	int GetDeviceMaxSupportSoundEffect(); // Offset: 0x103a5f4e0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetDeviceInfo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetDeviceInfo(); // Offset: 0x103a5f47c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetDeviceFreeSpace
	// Flags: [Final|Native|Static|Public]
	uint64 GetDeviceFreeSpace(); // Offset: 0x103a5f448 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.GetCurrentRHILevel
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetCurrentRHILevel(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a5f3a4 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.GetCurrentLanguage_LuaState
	// Flags: [Final|Native|Static|Public]
	int GetCurrentLanguage_LuaState(); // Offset: 0x103a5f38c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetCurrentChannel
	// Flags: [Final|Native|Static|Public]
	int GetCurrentChannel(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a5f310 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.GetCpuType
	// Flags: [Final|Native|Static|Public]
	struct FString GetCpuType(); // Offset: 0x103a5f2ac // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetCDNUpdateInfo
	// Flags: [Final|Native|Static|Public]
	void GetCDNUpdateInfo(struct UGameFrontendHUD* GameFrontendHUD, struct TMap<struct FString, struct FString> Data); // Offset: 0x103a5f1b4 // Return & Params: Num(2) Size(0x58)

	// Object Name: Function Client.ScriptHelperClient.GetBuildVersion
	// Flags: [Final|Native|Static|Public]
	struct FString GetBuildVersion(); // Offset: 0x103a5f150 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetBattleKey
	// Flags: [Final|Native|Static|Public]
	struct FString GetBattleKey(struct FString svr_pub_key, struct FString cli_pri_key); // Offset: 0x103a5eff4 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.GetAreaIPNo
	// Flags: [Final|Native|Static|Public]
	struct FString GetAreaIPNo(); // Offset: 0x103a5ef90 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetAppVersion
	// Flags: [Final|Native|Static|Public]
	struct FString GetAppVersion(); // Offset: 0x103a5ef2c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetApplicationVersion
	// Flags: [Final|Native|Static|Public]
	struct FString GetApplicationVersion(); // Offset: 0x103a5eec8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetAOSSHOP
	// Flags: [Final|Native|Static|Public]
	struct FString GetAOSSHOP(); // Offset: 0x103a5ee64 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetAndroidSysInfo
	// Flags: [Final|Native|Static|Public]
	struct FString GetAndroidSysInfo(); // Offset: 0x103a5ee00 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetAndroidSOVersion
	// Flags: [Final|Native|Static|Public]
	int GetAndroidSOVersion(); // Offset: 0x103a5edcc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetAndroidMaxStackSize
	// Flags: [Final|Native|Static|Public]
	uint32_t GetAndroidMaxStackSize(); // Offset: 0x103a5ed98 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetAndroidMaxFDNum
	// Flags: [Final|Native|Static|Public]
	uint32_t GetAndroidMaxFDNum(); // Offset: 0x103a5ed64 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetAndroidCurrentFDNum
	// Flags: [Final|Native|Static|Public]
	uint32_t GetAndroidCurrentFDNum(); // Offset: 0x103a5ed30 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetAndroidBuildForArm
	// Flags: [Final|Native|Static|Public]
	int GetAndroidBuildForArm(); // Offset: 0x103a5ecfc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetAllLocalNotificationIDs
	// Flags: [Final|Native|Static|Public]
	struct TArray<int> GetAllLocalNotificationIDs(); // Offset: 0x103a5ec98 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetAllFilesInDir
	// Flags: [Final|Native|Static|Public]
	struct TArray<struct FString> GetAllFilesInDir(struct FString Dir, struct FString Pattern); // Offset: 0x103a5eb84 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.GetAccountRegion
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetAccountRegion(); // Offset: 0x103a5eb20 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetAccessToken
	// Flags: [Final|Native|Static|Public|HasOutParms]
	struct FString GetAccessToken(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103a5ea6c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GenerateQRImage
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void GenerateQRImage(struct TScriptInterface<Class>& ClientNetInterface, int Tag, int Size, struct FString Content, struct FString logoPath); // Offset: 0x103a5e8c0 // Return & Params: Num(5) Size(0x38)

	// Object Name: Function Client.ScriptHelperClient.GEMReportSubEvent
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void GEMReportSubEvent(struct UGameFrontendHUD* GameFrontendHUD, struct FString EventName, struct FString SubEventName, struct TArray<struct FString>& eventParams); // Offset: 0x103a5e73c // Return & Params: Num(4) Size(0x38)

	// Object Name: Function Client.ScriptHelperClient.GEMReportShaderPrecompileEvent
	// Flags: [Final|Native|Static|Public]
	void GEMReportShaderPrecompileEvent(struct UGameFrontendHUD* GameFrontendHUD, bool IsSuccess, struct FString strDesc); // Offset: 0x103a5e604 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GEMReportEvent
	// Flags: [Final|Native|Static|Public]
	void GEMReportEvent(struct UGameFrontendHUD* GameFrontendHUD, struct FString EventName, struct TMap<struct FString, struct FString> eventParams); // Offset: 0x103a5e490 // Return & Params: Num(3) Size(0x68)

	// Object Name: Function Client.ScriptHelperClient.GEMReportEnterLobbyEvent
	// Flags: [Final|Native|Static|Public]
	void GEMReportEnterLobbyEvent(struct UGameFrontendHUD* GameFrontendHUD, bool IsSuccess, struct FString strDesc); // Offset: 0x103a5e358 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GCloudRemoteConfigStartOnce
	// Flags: [Final|Native|Static|Public]
	void GCloudRemoteConfigStartOnce(); // Offset: 0x103a5e344 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.GCloudRemoteConfigSetUrl
	// Flags: [Final|Native|Static|Public]
	void GCloudRemoteConfigSetUrl(struct FString InRemoteConfigUrl); // Offset: 0x103a5e2b4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GCloudRemoteConfigGetString
	// Flags: [Final|Native|Static|Public]
	struct FString GCloudRemoteConfigGetString(struct FString InKey, struct FString InDefaultValue); // Offset: 0x103a5e1a0 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.GCloudRemoteConfigGetInt
	// Flags: [Final|Native|Static|Public]
	int GCloudRemoteConfigGetInt(struct FString InKey, int InDefaultValue); // Offset: 0x103a5e0c8 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.GCloudRemoteConfigGetBool
	// Flags: [Final|Native|Static|Public]
	bool GCloudRemoteConfigGetBool(struct FString InKey, bool InDefaultValue); // Offset: 0x103a5dfe8 // Return & Params: Num(3) Size(0x12)

	// Object Name: Function Client.ScriptHelperClient.GCloudRemoteConfigClear
	// Flags: [Final|Native|Static|Public]
	void GCloudRemoteConfigClear(); // Offset: 0x103a5dfd4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.GameMasterSetUserInfo
	// Flags: [Final|Native|Static|Public]
	void GameMasterSetUserInfo(struct FString InPaidInfo, struct FString InUserToken, struct FString InAppId); // Offset: 0x103a5de9c // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.GameMasterSetUsableRegion
	// Flags: [Final|Native|Static|Public]
	void GameMasterSetUsableRegion(struct FString InRegion); // Offset: 0x103a5de0c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GameMasterSetUdpEchoPort
	// Flags: [Final|Native|Static|Public]
	void GameMasterSetUdpEchoPort(int InPort); // Offset: 0x103a5dd98 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GameMasterSetOnlyWifiAccel
	// Flags: [Final|Native|Static|Public]
	void GameMasterSetOnlyWifiAccel(bool InOn); // Offset: 0x103a5dd1c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.GameMasterSetFreeFlowUser
	// Flags: [Final|Native|Static|Public]
	void GameMasterSetFreeFlowUser(int InType); // Offset: 0x103a5dca8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GameMasterOnNetDelay
	// Flags: [Final|Native|Static|Public]
	void GameMasterOnNetDelay(int InMillis); // Offset: 0x103a5dc34 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GameMasterIsAccelOpened
	// Flags: [Final|Native|Static|Public]
	bool GameMasterIsAccelOpened(); // Offset: 0x103a5dc00 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.GameMasterInit
	// Flags: [Final|Native|Static|Public]
	int GameMasterInit(int InHookType, struct FString InGuid, struct FString InLibs, int InEchoPort); // Offset: 0x103a5da98 // Return & Params: Num(5) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.GameMasterGetWebUIUrl
	// Flags: [Final|Native|Static|Public]
	struct FString GameMasterGetWebUIUrl(int InType); // Offset: 0x103a5d9f4 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.GameMasterGetVIPValidTime
	// Flags: [Final|Native|Static|Public]
	struct FString GameMasterGetVIPValidTime(); // Offset: 0x103a5d990 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GameMasterGetUserID
	// Flags: [Final|Native|Static|Public]
	struct FString GameMasterGetUserID(); // Offset: 0x103a5d92c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GameMasterGetAccelerationStatus
	// Flags: [Final|Native|Static|Public]
	int GameMasterGetAccelerationStatus(); // Offset: 0x103a5d8f8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GameMasterClearAccelAddr
	// Flags: [Final|Native|Static|Public]
	void GameMasterClearAccelAddr(); // Offset: 0x103a5d8e4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.GameMasterBeginRound
	// Flags: [Final|Native|Static|Public]
	void GameMasterBeginRound(struct FString InOpenId, struct FString InPvpId); // Offset: 0x103a5d800 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GameMasterAddNewArenaAddress
	// Flags: [Final|Native|Static|Public]
	void GameMasterAddNewArenaAddress(struct FString InProtocol, struct FString InIp, int InPort); // Offset: 0x103a5d6dc // Return & Params: Num(3) Size(0x24)

	// Object Name: Function Client.ScriptHelperClient.GameMasterAddAccelAddr
	// Flags: [Final|Native|Static|Public]
	void GameMasterAddAccelAddr(struct FString InProtocol, struct FString InIp, int InPort); // Offset: 0x103a5d5b8 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function Client.ScriptHelperClient.GameJoySwitchOn
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void GameJoySwitchOn(int isOn); // Offset: 0x103a5d544 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GameJoyStopManualRecord
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void GameJoyStopManualRecord(); // Offset: 0x103a5d530 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.GameJoyStartMomentsRecord
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void GameJoyStartMomentsRecord(); // Offset: 0x103a5d51c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.GameJoyStartManualRecord
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void GameJoyStartManualRecord(); // Offset: 0x103a5d508 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.GameJoySetVideoQuality
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void GameJoySetVideoQuality(int Quality); // Offset: 0x103a5d494 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GameJoySetMomentRecordSwitchOn
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void GameJoySetMomentRecordSwitchOn(int isOn); // Offset: 0x103a5d420 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GameJoySetLuaguage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void GameJoySetLuaguage(); // Offset: 0x103a5d40c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.GameJoySetCurrentRecorderPosition
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void GameJoySetCurrentRecorderPosition(float X, float Y); // Offset: 0x103a5d360 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.GameJoyIsSDKFeatureSupport
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool GameJoyIsSDKFeatureSupport(); // Offset: 0x103a5d32c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.GameJoyGenerateMomentsVideo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void GameJoyGenerateMomentsVideo(struct TArray<struct FTimeStamp> shortVideosTimeStampList, struct TArray<struct FTimeStamp> largeVideosTimeStampList, struct FString Title, struct TMap<struct FString, struct FString> ExtraInfo); // Offset: 0x103a5d0c0 // Return & Params: Num(4) Size(0x80)

	// Object Name: Function Client.ScriptHelperClient.GameJoyEndMomentsRecord
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void GameJoyEndMomentsRecord(); // Offset: 0x103a5d0ac // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.GameJoyClearMomentsVideo
	// Flags: [Final|Native|Static|Public]
	void GameJoyClearMomentsVideo(); // Offset: 0x103a5d098 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.FullPathFileExist
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool FullPathFileExist(struct FString Filename); // Offset: 0x103a5d000 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.FlushKnownMissingPackageRefObject
	// Flags: [Final|Native|Static|Public]
	void FlushKnownMissingPackageRefObject(); // Offset: 0x103a5cfec // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.FinishPufferUpdateInDolphin
	// Flags: [Final|Native|Static|Public]
	void FinishPufferUpdateInDolphin(struct UGameFrontendHUD* GameFrontendHUD, bool IsFinished); // Offset: 0x103a5cf34 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.FindFilesRecursiveSkipPakPlatform
	// Flags: [Final|Native|Static|Public]
	struct TArray<struct FString> FindFilesRecursiveSkipPakPlatform(struct FString Dir, struct FString Pattern); // Offset: 0x103a5ce20 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.FindFiles_LuaState
	// Flags: [Final|Native|Static|Public]
	int FindFiles_LuaState(); // Offset: 0x103a5ce08 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.FileSystemTesting
	// Flags: [Final|Native|Static|Public]
	void FileSystemTesting(uint32_t Count); // Offset: 0x103a5cd94 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.ExitGameForSafety
	// Flags: [Final|Native|Static|Public]
	void ExitGameForSafety(); // Offset: 0x103a5cd80 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.ExitGame
	// Flags: [Final|Native|Static|Public]
	void ExitGame(); // Offset: 0x103a5cd6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.EnterLoading
	// Flags: [Final|Native|Static|Public]
	void EnterLoading(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a5ccf8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.EnterFightChat
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void EnterFightChat(struct UGameFrontendHUD* GameFrontendHUD, struct FString gid); // Offset: 0x103a5cc04 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.EnterBattleStandAlone
	// Flags: [Final|Native|Static|Public]
	void EnterBattleStandAlone(struct UGameFrontendHUD* GameFrontendHUD, struct FString MapPath, uint32_t PlayerKey, struct FString PlayerName); // Offset: 0x103a5ca54 // Return & Params: Num(4) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.EnterBattle
	// Flags: [Final|Native|Static|Public]
	void EnterBattle(struct UGameFrontendHUD* GameFrontendHUD, struct FString HostnameOrIP, uint32_t Port, uint32_t PlayerKey, struct FString PlayerName, struct FString PacketKey, uint64 GameID, bool IsObserver, struct TMap<int, struct FString> AdvConfig, int WaterType, uint32_t WaterUserID); // Offset: 0x103a5c644 // Return & Params: Num(11) Size(0xa8)

	// Object Name: Function Client.ScriptHelperClient.EncryptUID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString EncryptUID(struct FString sUid, struct FString sKey); // Offset: 0x103a5c4e8 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.EncryptItemData
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void EncryptItemData(struct TArray<int>& EncryptionItemList); // Offset: 0x103a5c448 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.EnableUseOldInterface
	// Flags: [Final|Native|Static|Public]
	void EnableUseOldInterface(struct UGameFrontendHUD* GameFrontendHUD, bool Enable); // Offset: 0x103a5c390 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.EnableTxtCheck
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void EnableTxtCheck(); // Offset: 0x103a5c37c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.EnableReportGVoiceEvent
	// Flags: [Final|Native|Static|Public]
	void EnableReportGVoiceEvent(struct UGameFrontendHUD* GameFrontendHUD, bool GVoiceInitGVoiceComponentReportEnable, bool GVoiceJoinRoomReportEnable, bool GVoiceQuitRoomReportEnable, bool GVoiceJoinLbsRoomReportEnable, bool GVoiceQuitLbsRoomReportEnable, bool GVoiceOnJoinTeamRoomReportEnable, bool GVoiceOnJoinLbsRoomReportEnable); // Offset: 0x103a5c114 // Return & Params: Num(8) Size(0xf)

	// Object Name: Function Client.ScriptHelperClient.EnableLocalizationStatus
	// Flags: [Final|Native|Static|Public]
	void EnableLocalizationStatus(struct UGameFrontendHUD* GameFrontendHUD, bool Status); // Offset: 0x103a5c05c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.EnableIosStuckWork
	// Flags: [Final|Native|Static|Public]
	void EnableIosStuckWork(struct UGameFrontendHUD* GameFrontendHUD, bool bEnable); // Offset: 0x103a5bfa4 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.EnableGvoiceGemReport
	// Flags: [Final|Native|Static|Public]
	void EnableGvoiceGemReport(struct UGameFrontendHUD* GameFrontendHUD, bool Enable); // Offset: 0x103a5beec // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.EnableGvoice
	// Flags: [Final|Native|Static|Public]
	void EnableGvoice(struct UGameFrontendHUD* GameFrontendHUD, bool Enable); // Offset: 0x103a5be34 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.EnableCampGvoice
	// Flags: [Final|Native|Static|Public]
	void EnableCampGvoice(struct UGameFrontendHUD* GameFrontendHUD, bool Enable); // Offset: 0x103a5bd7c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.EnableAutoObjectRefreshStage
	// Flags: [Final|Native|Static|Public]
	void EnableAutoObjectRefreshStage(bool bEnable); // Offset: 0x103a5bd00 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.EnableAudioRouteChangedNotify
	// Flags: [Final|Native|Static|Public]
	void EnableAudioRouteChangedNotify(bool Enable); // Offset: 0x103a5bc84 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.DumpOpenReadCollect
	// Flags: [Final|Native|Static|Public]
	void DumpOpenReadCollect(struct UGameFrontendHUD* GameFrontendHUD, struct FString DumpFilename); // Offset: 0x103a5bb90 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.DumpLogFile
	// Flags: [Final|Native|Static|Public]
	void DumpLogFile(bool backup); // Offset: 0x103a5bb14 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.Disconnect
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void Disconnect(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103a5ba90 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.DisableRepairResource
	// Flags: [Final|Native|Static|Public]
	void DisableRepairResource(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a5ba1c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.DirectToSetting
	// Flags: [Final|Native|Static|Public]
	void DirectToSetting(); // Offset: 0x103a5ba08 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.DestroyConnector
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void DestroyConnector(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103a5b984 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.DeleteFile
	// Flags: [Final|Native|Static|Public]
	bool DeleteFile(struct FString fullPath); // Offset: 0x103a5b8ec // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.DeleteDirectory
	// Flags: [Final|Native|Static|Public]
	void DeleteDirectory(struct FString FilePath); // Offset: 0x103a5b838 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.DelayToSetAutoInitFacebookLog
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DelayToSetAutoInitFacebookLog(bool IsAutoInit); // Offset: 0x103a5b7bc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.DelayToInitFacebookSDK
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DelayToInitFacebookSDK(bool IsAutoInit, bool WithLaunchOption); // Offset: 0x103a5b6fc // Return & Params: Num(2) Size(0x2)

	// Object Name: Function Client.ScriptHelperClient.DelayInitThirdPartSDK
	// Flags: [Final|Native|Static|Public]
	void DelayInitThirdPartSDK(); // Offset: 0x103a5b6e8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.CreateHapticsEngine
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void CreateHapticsEngine(DelegateProperty Callback); // Offset: 0x103a5b660 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.ConvertToAbsolutePathForExternalAppForWrite
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString ConvertToAbsolutePathForExternalAppForWrite(struct FString FilePath); // Offset: 0x103a5b5a0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.ConvertToAbsolutePathForExternalAppForRead
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString ConvertToAbsolutePathForExternalAppForRead(struct FString FilePath); // Offset: 0x103a5b4e0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.ConvertRelativePathToFull
	// Flags: [Final|Native|Static|Public]
	struct FString ConvertRelativePathToFull(struct FString InPath); // Offset: 0x103a5b3fc // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.ConvertGamePathToRelativeFilePath
	// Flags: [Final|Native|Static|Public]
	struct FString ConvertGamePathToRelativeFilePath(struct FString Path); // Offset: 0x103a5b33c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.ConnectToURL
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void ConnectToURL(struct TScriptInterface<Class>& ClientNetInterface, struct FString URL, int ConnectTimeOutSeconds); // Offset: 0x103a5b1f8 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function Client.ScriptHelperClient.ComputerName
	// Flags: [Final|Native|Static|Public]
	struct FString ComputerName(); // Offset: 0x103a5b194 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.CloseWebView
	// Flags: [Final|Native|Static|Public]
	void CloseWebView(); // Offset: 0x103a5b180 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.CloseVLink
	// Flags: [Final|Native|Static|Public]
	void CloseVLink(); // Offset: 0x103a5b16c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.CloseVideoListDialog
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void CloseVideoListDialog(); // Offset: 0x103a5b158 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.CloseH5WebView
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void CloseH5WebView(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a5b0e4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.ClipBoardCopy
	// Flags: [Final|Native|Static|Public]
	void ClipBoardCopy(struct FString Text); // Offset: 0x103a5b030 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.ClientKickPlayerFromGame
	// Flags: [Final|Native|Static|Public]
	void ClientKickPlayerFromGame(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a5afbc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.ClientEnterWarMode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ClientEnterWarMode(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a5af48 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.ClientConfirmReturnToGame
	// Flags: [Final|Native|Static|Public]
	void ClientConfirmReturnToGame(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a5aed4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.ClientConfirmMisKill
	// Flags: [Final|Native|Static|Public]
	void ClientConfirmMisKill(struct UGameFrontendHUD* GameFrontendHUD, int bConfirm); // Offset: 0x103a5ae24 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.ClearUpdatedSoPatch
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ClearUpdatedSoPatch(); // Offset: 0x103a5ae10 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.ClearNotifications
	// Flags: [Final|Native|Static|Public]
	void ClearNotifications(); // Offset: 0x103a5adfc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.ClearNotice
	// Flags: [Final|Native|Static|Public]
	void ClearNotice(); // Offset: 0x103a5ade8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.ClearChannelID
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void ClearChannelID(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103a5ad64 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.ClearAllLocalNotifications
	// Flags: [Final|Native|Static|Public]
	void ClearAllLocalNotifications(); // Offset: 0x103a5ad50 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.CheckRegisterGestureConflictWithZoom
	// Flags: [Final|Native|Static|Public]
	void CheckRegisterGestureConflictWithZoom(); // Offset: 0x103a5ad3c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.CheckFilesInPak
	// Flags: [Final|Native|Static|Public|HasOutParms]
	struct TArray<struct FString> CheckFilesInPak(struct TArray<struct FString>& Files); // Offset: 0x103a5ac6c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.CheckBeforeInitPuffer
	// Flags: [Final|Native|Static|Public]
	void CheckBeforeInitPuffer(); // Offset: 0x103a5ac58 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.ChangeLocalizationReleaseTestStatus
	// Flags: [Final|Native|Static|Public]
	void ChangeLocalizationReleaseTestStatus(struct UGameFrontendHUD* GameFrontendHUD, bool Status); // Offset: 0x103a5aba0 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.CanUseHapticsEngine
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool CanUseHapticsEngine(); // Offset: 0x103a5ab6c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.CancelLocalNotification
	// Flags: [Final|Native|Static|Public]
	void CancelLocalNotification(int NotificationID); // Offset: 0x103a5aaf8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.CallIngameFirstTimeTips
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void CallIngameFirstTimeTips(struct UGameFrontendHUD* GameFrontendHUD, struct FString tableName, struct FString FunctionName); // Offset: 0x103a5a9d8 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.ScriptHelperClient.CallEngineGC
	// Flags: [Final|Native|Static|Public]
	void CallEngineGC(); // Offset: 0x103a5a9c4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.CacheH5WebView
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void CacheH5WebView(struct FString ModuleName); // Offset: 0x103a5a934 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.BuglySetAppVersion
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void BuglySetAppVersion(struct TScriptInterface<Class>& ClientNetInterface, struct FString Version); // Offset: 0x103a5a830 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.BuglyPutUserData
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void BuglyPutUserData(struct TScriptInterface<Class>& ClientNetInterface, struct FString Key, struct FString Value); // Offset: 0x103a5a6b4 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.BuglyPostException
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void BuglyPostException(struct TScriptInterface<Class>& ClientNetInterface, int Category, struct FString Reason); // Offset: 0x103a5a570 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.ScriptHelperClient.BuglyLog
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void BuglyLog(struct TScriptInterface<Class>& ClientNetInterface, int Level, struct FString Tag, struct FString Log, bool needDump); // Offset: 0x103a5a364 // Return & Params: Num(5) Size(0x39)

	// Object Name: Function Client.ScriptHelperClient.AutoTestWaitForUIWithName
	// Flags: [Final|Native|Static|Public]
	void AutoTestWaitForUIWithName(struct FString UIName); // Offset: 0x103a5a2d4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestWaitForSecond
	// Flags: [Final|Native|Static|Public]
	void AutoTestWaitForSecond(int sec); // Offset: 0x103a5a260 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.AutoTestWaitForJumpPlane
	// Flags: [Final|Native|Static|Public]
	bool AutoTestWaitForJumpPlane(); // Offset: 0x103a5a22c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.AutoTestVehicleDriverShoot
	// Flags: [Final|Native|Static|Public]
	void AutoTestVehicleDriverShoot(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a5a1b8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.AutoTestVaultWall
	// Flags: [Final|Native|Static|Public]
	void AutoTestVaultWall(); // Offset: 0x103a5a1a4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AutoTestUsePropSkillClientEx
	// Flags: [Final|Native|Static|Public]
	void AutoTestUsePropSkillClientEx(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a5a130 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.AutoTestUseItemClientEx
	// Flags: [Final|Native|Static|Public]
	void AutoTestUseItemClientEx(struct UGameFrontendHUD* GameFrontendHUD, int ItemId); // Offset: 0x103a5a080 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestUseItem
	// Flags: [Final|Native|Static|Public]
	void AutoTestUseItem(int ItemId); // Offset: 0x103a5a00c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.AutoTestUpgradePropSkillClientEx
	// Flags: [Final|Native|Static|Public]
	void AutoTestUpgradePropSkillClientEx(struct UGameFrontendHUD* GameFrontendHUD, int ItemId); // Offset: 0x103a59f5c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestToggleVehicleSync
	// Flags: [Final|Native|Static|Public]
	void AutoTestToggleVehicleSync(struct UGameFrontendHUD* GameFrontendHUD, bool Val); // Offset: 0x103a59ea4 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.AutoTestThrowBoomOnlyClientEx
	// Flags: [Final|Native|Static|Public]
	void AutoTestThrowBoomOnlyClientEx(struct UGameFrontendHUD* GameFrontendHUD, int SkillID); // Offset: 0x103a59df4 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestThrowBoom
	// Flags: [Final|Native|Static|Public]
	void AutoTestThrowBoom(int SkillID); // Offset: 0x103a59d80 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.AutoTestSwitchWeapon
	// Flags: [Final|Native|Static|Public]
	void AutoTestSwitchWeapon(int WeaponType); // Offset: 0x103a59d0c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.AutoTestSwitchMode
	// Flags: [Final|Native|Static|Public]
	void AutoTestSwitchMode(struct FString FunName); // Offset: 0x103a59c7c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestSwitchGameStatus
	// Flags: [Final|Native|Static|Public]
	void AutoTestSwitchGameStatus(struct UGameFrontendHUD* GameFrontendHUD, struct FName GameStatus, struct FString Options); // Offset: 0x103a59b48 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.AutoTestStopRecordStats
	// Flags: [Final|Native|Static|Public]
	void AutoTestStopRecordStats(); // Offset: 0x103a59b34 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AutoTestStartRecordStats
	// Flags: [Final|Native|Static|Public]
	void AutoTestStartRecordStats(struct FString FileStr); // Offset: 0x103a59aa4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestStartFireOnlyClientEx
	// Flags: [Final|Native|Static|Public]
	void AutoTestStartFireOnlyClientEx(struct UGameFrontendHUD* GameFrontendHUD, int X, int Y, int Z, int sec); // Offset: 0x103a59948 // Return & Params: Num(5) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.AutoTestStartFire
	// Flags: [Final|Native|Static|Public]
	void AutoTestStartFire(int X, int Y, int Z, int sec); // Offset: 0x103a59828 // Return & Params: Num(4) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestSpecating
	// Flags: [Final|Native|Static|Public]
	void AutoTestSpecating(struct UGameFrontendHUD* GameFrontendHUD, int leftTeamCnt); // Offset: 0x103a59778 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestSpawnVehicle
	// Flags: [Final|Native|Static|Public]
	void AutoTestSpawnVehicle(struct FString ResPath); // Offset: 0x103a596c4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestSetVehicleRotation
	// Flags: [Final|Native|Static|Public]
	void AutoTestSetVehicleRotation(int X, int Y, int Z); // Offset: 0x103a595dc // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestSetRecordFrequency
	// Flags: [Final|Native|Static|Public]
	void AutoTestSetRecordFrequency(uint32_t Frequency); // Offset: 0x103a59568 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.AutoTestSetActorRotation
	// Flags: [Final|Native|Static|Public]
	void AutoTestSetActorRotation(float Rate, float Speed); // Offset: 0x103a594bc // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.AutoTestSetActorPitch
	// Flags: [Final|Native|Static|Public]
	void AutoTestSetActorPitch(float Rate); // Offset: 0x103a59448 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.AutoTestSetActorFacePoint
	// Flags: [Final|Native|Static|Public]
	void AutoTestSetActorFacePoint(int X, int Y, int Z); // Offset: 0x103a59360 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestSendBuffertoSvr
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void AutoTestSendBuffertoSvr(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103a592dc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestReloadOnlyClientEx
	// Flags: [Final|Native|Static|Public]
	void AutoTestReloadOnlyClientEx(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a59268 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.AutoTestPickupItemOnlyClientEx
	// Flags: [Final|Native|Static|Public|HasDefaults]
	struct FVector2D AutoTestPickupItemOnlyClientEx(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a591e8 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestPickupItem
	// Flags: [Final|Native|Static|Public|HasDefaults]
	struct FVector2D AutoTestPickupItem(); // Offset: 0x103a591b0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.AutoTestOpenTraceRPC
	// Flags: [Final|Native|Static|Public]
	void AutoTestOpenTraceRPC(); // Offset: 0x103a5919c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AutoTestOpenScope
	// Flags: [Final|Native|Static|Public]
	void AutoTestOpenScope(bool bOpenScope); // Offset: 0x103a59120 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.AutoTestOpenDoorOnlyClientEx
	// Flags: [Final|Native|Static|Public]
	void AutoTestOpenDoorOnlyClientEx(struct UGameFrontendHUD* GameFrontendHUD, int bOpen); // Offset: 0x103a59070 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestMustDie
	// Flags: [Final|Native|Static|Public]
	void AutoTestMustDie(struct UGameFrontendHUD* GameFrontendHUD, int leftTeamCnt); // Offset: 0x103a58fc0 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestMoveVehicleForward
	// Flags: [Final|Native|Static|Public]
	void AutoTestMoveVehicleForward(float Speed, float Rate, float sec); // Offset: 0x103a58ed8 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestMoveToPoint
	// Flags: [Final|Native|Static|Public]
	void AutoTestMoveToPoint(int X, int Y, int Z); // Offset: 0x103a58df0 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestJumpPlane
	// Flags: [Final|Native|Static|Public]
	void AutoTestJumpPlane(int sec); // Offset: 0x103a58d7c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.AutoTestJump
	// Flags: [Final|Native|Static|Public]
	void AutoTestJump(); // Offset: 0x103a58d68 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AutoTestIsOnVehicle
	// Flags: [Final|Native|Static|Public]
	bool AutoTestIsOnVehicle(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a58cec // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.AutoTestIsDriver
	// Flags: [Final|Native|Static|Public]
	bool AutoTestIsDriver(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a58c70 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.AutoTestInputMovement
	// Flags: [Final|Native|Static|Public]
	void AutoTestInputMovement(float Rate); // Offset: 0x103a58bfc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGMVehicleMoveAndTowardClientEx
	// Flags: [Final|Native|Static|Public]
	void AutoTestGMVehicleMoveAndTowardClientEx(struct UGameFrontendHUD* GameFrontendHUD, float X, float Y, float Z, float x1, float y1, float Z1); // Offset: 0x103a58a2c // Return & Params: Num(7) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGMGotoClientEx
	// Flags: [Final|Native|Static|Public]
	void AutoTestGMGotoClientEx(struct UGameFrontendHUD* GameFrontendHUD, int X, int Y, int Z); // Offset: 0x103a58908 // Return & Params: Num(4) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGMGoto
	// Flags: [Final|Native|Static|Public]
	void AutoTestGMGoto(int X, int Y, int Z); // Offset: 0x103a58820 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGMCommand
	// Flags: [Final|Native|Static|Public]
	void AutoTestGMCommand(struct FString Command); // Offset: 0x103a58790 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetVehicleLocationClientEx
	// Flags: [Final|Native|Static|Public|HasDefaults]
	struct FVector AutoTestGetVehicleLocationClientEx(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a58710 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetVehicleLocation
	// Flags: [Final|Native|Static|Public|HasDefaults]
	struct FVector AutoTestGetVehicleLocation(); // Offset: 0x103a586d8 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetRuntimeStats
	// Flags: [Final|Native|Static|Public]
	void AutoTestGetRuntimeStats(); // Offset: 0x103a586c4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetRenderTimeDetail
	// Flags: [Final|Native|Static|Public]
	void AutoTestGetRenderTimeDetail(); // Offset: 0x103a586b0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetPrimitivesDetail
	// Flags: [Final|Native|Static|Public]
	void AutoTestGetPrimitivesDetail(); // Offset: 0x103a5869c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetOnVehicle
	// Flags: [Final|Native|Static|Public]
	void AutoTestGetOnVehicle(); // Offset: 0x103a58688 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetOffVehicle
	// Flags: [Final|Native|Static|Public]
	void AutoTestGetOffVehicle(); // Offset: 0x103a58674 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetNearVehiclePos
	// Flags: [Final|Native|Static|Public|HasDefaults]
	struct FVector AutoTestGetNearVehiclePos(); // Offset: 0x103a5863c // Return & Params: Num(1) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetMemoryDetail
	// Flags: [Final|Native|Static|Public]
	void AutoTestGetMemoryDetail(); // Offset: 0x103a58628 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetMapName
	// Flags: [Final|Native|Static|Public]
	struct FString AutoTestGetMapName(); // Offset: 0x103a585c4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetGameModeState
	// Flags: [Final|Native|Static|Public]
	struct FString AutoTestGetGameModeState(); // Offset: 0x103a58560 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetFrameInfo
	// Flags: [Final|Native|Static|Public|HasDefaults]
	struct FVector AutoTestGetFrameInfo(); // Offset: 0x103a58528 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetDrawCallDetail
	// Flags: [Final|Native|Static|Public]
	void AutoTestGetDrawCallDetail(); // Offset: 0x103a58514 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetDis2D
	// Flags: [Final|Native|Static|Public]
	int AutoTestGetDis2D(int X, int Y, int Z, int x2, int y2, int z2); // Offset: 0x103a58374 // Return & Params: Num(7) Size(0x1c)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetCircleLocationClientEx
	// Flags: [Final|Native|Static|Public|HasDefaults]
	struct FVector AutoTestGetCircleLocationClientEx(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103a582f4 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetActorName
	// Flags: [Final|Native|Static|Public]
	struct FString AutoTestGetActorName(); // Offset: 0x103a58290 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetActorLocationListClientEx
	// Flags: [Final|Native|Static|Public]
	struct TArray<struct FVector> AutoTestGetActorLocationListClientEx(struct UGameFrontendHUD* GameFrontendHUD, int ActorType, float RangeRadius); // Offset: 0x103a58174 // Return & Params: Num(4) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetActorLocation
	// Flags: [Final|Native|Static|Public|HasDefaults]
	struct FVector AutoTestGetActorLocation(struct FString PlayerName); // Offset: 0x103a580d4 // Return & Params: Num(2) Size(0x1c)

	// Object Name: Function Client.ScriptHelperClient.AutoTestForceVehiclePosPullClientEx
	// Flags: [Final|Native|Static|Public]
	float AutoTestForceVehiclePosPullClientEx(struct UGameFrontendHUD* GameFrontendHUD, bool bNext); // Offset: 0x103a58014 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestEnableUITest
	// Flags: [Final|Native|Static|Public]
	void AutoTestEnableUITest(); // Offset: 0x103a58000 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AutoTestDropItemClientEx
	// Flags: [Final|Native|Static|Public]
	void AutoTestDropItemClientEx(struct UGameFrontendHUD* GameFrontendHUD, int ItemId, int nCount); // Offset: 0x103a57f18 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestContinuousMoveTo
	// Flags: [Final|Native|Static|Public]
	void AutoTestContinuousMoveTo(float X, float Y, float Z); // Offset: 0x103a57e30 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestConsoleCommand
	// Flags: [Final|Native|Static|Public]
	void AutoTestConsoleCommand(struct FString Command); // Offset: 0x103a57da0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestCloseTraceRPC
	// Flags: [Final|Native|Static|Public]
	void AutoTestCloseTraceRPC(); // Offset: 0x103a57d8c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AutoTestClickButton
	// Flags: [Final|Native|Static|Public]
	void AutoTestClickButton(struct FString ButtonName); // Offset: 0x103a57cfc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestAddItemClientEx
	// Flags: [Final|Native|Static|Public]
	void AutoTestAddItemClientEx(struct UGameFrontendHUD* GameFrontendHUD, int ItemId, int nCount); // Offset: 0x103a57c14 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestAddItem
	// Flags: [Final|Native|Static|Public]
	void AutoTestAddItem(int ItemId, int nCount); // Offset: 0x103a57b68 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.AutoMoveToTargetPosClientEx
	// Flags: [Final|Native|Static|Public|HasDefaults]
	void AutoMoveToTargetPosClientEx(struct UGameFrontendHUD* GameFrontendHUD, struct FVector targetPos); // Offset: 0x103a57ab8 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.AskForNotificationPermission
	// Flags: [Final|Native|Static|Public]
	void AskForNotificationPermission(); // Offset: 0x103a57aa4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AndroidShouldShowPermissionRationale
	// Flags: [Final|Native|Static|Public]
	bool AndroidShouldShowPermissionRationale(); // Offset: 0x103a57a70 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.AndroidCheckPermission
	// Flags: [Final|Native|Static|Public]
	bool AndroidCheckPermission(); // Offset: 0x103a57a3c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.AkAudio_UnloadInitBank
	// Flags: [Final|Native|Static|Public]
	void AkAudio_UnloadInitBank(); // Offset: 0x103a57a28 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AkAudio_UnloadAllFilePackages
	// Flags: [Final|Native|Static|Public]
	void AkAudio_UnloadAllFilePackages(); // Offset: 0x103a57a14 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AkAudio_StopAllSounds
	// Flags: [Final|Native|Static|Public]
	void AkAudio_StopAllSounds(bool bShouldStopUISounds); // Offset: 0x103a57998 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.AkAudio_LoadInitBank
	// Flags: [Final|Native|Static|Public]
	void AkAudio_LoadInitBank(); // Offset: 0x103a57984 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AkAudio_Flush
	// Flags: [Final|Native|Static|Public]
	void AkAudio_Flush(struct UWorld* WorldToFlush); // Offset: 0x103a57910 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.AkAudio_ClearBanks
	// Flags: [Final|Native|Static|Public]
	void AkAudio_ClearBanks(); // Offset: 0x103a578fc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AddKnownMissingPackage
	// Flags: [Final|Native|Static|Public]
	void AddKnownMissingPackage(struct FString PackageName, struct UObject* BindObj, bool bReplace); // Offset: 0x103a577c0 // Return & Params: Num(3) Size(0x19)

	// Object Name: Function Client.ScriptHelperClient.AddCrashContextData
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void AddCrashContextData(int Key, struct FString Val, bool bAppendTimeStamp, int reportLevel); // Offset: 0x103a5766c // Return & Params: Num(4) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.AddAttachFileString
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void AddAttachFileString(struct FString Type, bool bClear, struct FString& strinfo); // Offset: 0x103a57504 // Return & Params: Num(3) Size(0x28)
};

// Object Name: Class Client.ScriptHelperEngine
// Size: 0x28 // Inherited bytes: 0x28
struct UScriptHelperEngine : UObject {
	// Functions

	// Object Name: Function Client.ScriptHelperEngine.TestLz4Decompress
	// Flags: [Final|Native|Static|Public|HasOutParms]
	struct TArray<char> TestLz4Decompress(struct TArray<char>& Source, bool bEnable); // Offset: 0x103a80350 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.ScriptHelperEngine.TestLz4Compress
	// Flags: [Final|Native|Static|Public|HasOutParms]
	struct TArray<char> TestLz4Compress(struct TArray<char>& Source); // Offset: 0x103a80280 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperEngine.ReplaceEmoji
	// Flags: [Final|Native|Static|Public]
	struct FString ReplaceEmoji(struct FString Content, int MaxEmojiNum, struct FString SpecialCharacter); // Offset: 0x103a8012c // Return & Params: Num(4) Size(0x38)

	// Object Name: Function Client.ScriptHelperEngine.IsLowMemoryDevice
	// Flags: [Final|Native|Static|Public]
	bool IsLowMemoryDevice(); // Offset: 0x103a800f8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperEngine.GetMemoryUsedVirtualInKB
	// Flags: [Final|Native|Static|Public]
	float GetMemoryUsedVirtualInKB(); // Offset: 0x103a800c4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperEngine.GetMemoryUsedPhysicalInKB
	// Flags: [Final|Native|Static|Public]
	float GetMemoryUsedPhysicalInKB(); // Offset: 0x103a80090 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class Client.SDKCallbackHelper
// Size: 0x88 // Inherited bytes: 0x28
struct USDKCallbackHelper : UObject {
	// Fields
	struct FScriptMulticastDelegate SDKCallbackDelegate; // Offset: 0x28 // Size: 0x10
	char pad_0x38[0x50]; // Offset: 0x38 // Size: 0x50

	// Functions

	// Object Name: Function Client.SDKCallbackHelper.Init
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Init(); // Offset: 0x103a808d0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.SDKCallbackHelper.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct USDKCallbackHelper* GetInstance(); // Offset: 0x103a8089c // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Client.SettingSubsystem
// Size: 0x170 // Inherited bytes: 0x30
struct USettingSubsystem : UGameInstanceSubsystem {
	// Fields
	struct FString CachedSaveGameName; // Offset: 0x30 // Size: 0x10
	struct TArray<struct FCustomSettingSaveGame> CustomSettingSaveGames; // Offset: 0x40 // Size: 0x10
	DelegateProperty GetUserSettingsDelegate; // Offset: 0x50 // Size: 0x10
	struct UEffectSettingMgr* EffectSettingMgrInstace; // Offset: 0x60 // Size: 0x08
	struct USaveGame* UserSettings; // Offset: 0x68 // Size: 0x08
	struct UObject* UserSettingsClass; // Offset: 0x70 // Size: 0x08
	struct FString UserSettingsClassName; // Offset: 0x78 // Size: 0x10
	struct FString ActiveSaveGameName; // Offset: 0x88 // Size: 0x10
	char pad_0x98[0x8]; // Offset: 0x98 // Size: 0x08
	struct FString LanguageSettingsClassName; // Offset: 0xa0 // Size: 0x10
	struct FString LanguageSaveGameName; // Offset: 0xb0 // Size: 0x10
	char pad_0xC0[0x60]; // Offset: 0xc0 // Size: 0x60
	struct TMap<struct FString, bool> LanguageMap; // Offset: 0x120 // Size: 0x50

	// Functions

	// Object Name: Function Client.SettingSubsystem.SetUserSettings_String
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetUserSettings_String(struct FString PropertyName, struct FString Val); // Offset: 0x103a81b98 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function Client.SettingSubsystem.SetUserSettings_Int
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetUserSettings_Int(struct FString PropertyName, int Value); // Offset: 0x103a81a8c // Return & Params: Num(3) Size(0x15)

	// Object Name: Function Client.SettingSubsystem.SetUserSettings_Float
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetUserSettings_Float(struct FString PropertyName, float Value); // Offset: 0x103a81980 // Return & Params: Num(3) Size(0x15)

	// Object Name: Function Client.SettingSubsystem.SetUserSettings_Bool
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetUserSettings_Bool(struct FString PropertyName, bool Value, bool IngoreSave); // Offset: 0x103a8181c // Return & Params: Num(4) Size(0x13)

	// Object Name: Function Client.SettingSubsystem.RegisterUserSettingsDelegate_Int
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegisterUserSettingsDelegate_Int(struct FString PropertyName, DelegateProperty Delegate); // Offset: 0x103a8170c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.SettingSubsystem.RegisterUserSettingsDelegate_Float
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegisterUserSettingsDelegate_Float(struct FString PropertyName, DelegateProperty Delegate); // Offset: 0x103a815fc // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.SettingSubsystem.RegisterUserSettingsDelegate_Bool
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegisterUserSettingsDelegate_Bool(struct FString PropertyName, DelegateProperty Delegate); // Offset: 0x103a814ec // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.SettingSubsystem.RegisterUserSettingsDelegate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegisterUserSettingsDelegate(DelegateProperty Delegate); // Offset: 0x103a8145c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.SettingSubsystem.GetUserSettingsByDelegate
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct USaveGame* GetUserSettingsByDelegate(struct FString LayoutName); // Offset: 0x103a813b4 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.SettingSubsystem.GetUserSettings_String
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetUserSettings_String(struct FString PropertyName); // Offset: 0x103a812c0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.SettingSubsystem.GetUserSettings_Int
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetUserSettings_Int(struct FString PropertyName); // Offset: 0x103a811f4 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.SettingSubsystem.GetUserSettings_Float
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetUserSettings_Float(struct FString PropertyName); // Offset: 0x103a81128 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.SettingSubsystem.GetUserSettings_Bool
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetUserSettings_Bool(struct FString PropertyName); // Offset: 0x103a8105c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.SettingSubsystem.GetUserSettings
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct USaveGame* GetUserSettings(); // Offset: 0x103a81028 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.SettingSubsystem.GetUserLanguageSettingsProperty_String
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetUserLanguageSettingsProperty_String(struct FString PropertyName); // Offset: 0x103a80f34 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.SettingSubsystem.GetEffectSettingMgr
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UEffectSettingMgr* GetEffectSettingMgr(); // Offset: 0x103a80f00 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.SettingSubsystem.GetCustomSetting
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct USaveGame* GetCustomSetting(struct FString InSlotName); // Offset: 0x103a80e58 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.SettingSubsystem.FinishModifyUserSettings
	// Flags: [Final|Native|Public|BlueprintCallable]
	void FinishModifyUserSettings(); // Offset: 0x103a80e44 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.SettingSubsystem.CheckLocalizationLanguage
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CheckLocalizationLanguage(); // Offset: 0x103a80e30 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.SettingSubsystem.BeginModifyUserSettings
	// Flags: [Final|Native|Public|BlueprintCallable]
	void BeginModifyUserSettings(); // Offset: 0x103a80e1c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.SettingSubsystem.AddCustomSetting
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddCustomSetting(struct FString InSlotName, struct USaveGame* InSaveGame); // Offset: 0x103a80d44 // Return & Params: Num(2) Size(0x18)
};

// Object Name: Class Client.STExtraClientUtils
// Size: 0x28 // Inherited bytes: 0x28
struct USTExtraClientUtils : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function Client.STExtraClientUtils.GetWidgetHandleAsyncWithCallBack
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void GetWidgetHandleAsyncWithCallBack(struct UObject* WorldContext, struct FString ModuleName, struct FString WidgetKey, DelegateProperty Callback); // Offset: 0x103a826e4 // Return & Params: Num(4) Size(0x38)

	// Object Name: Function Client.STExtraClientUtils.GetDynamicWidgetHandle
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	struct UUAEUserWidget* GetDynamicWidgetHandle(struct UObject* WorldContext, struct FString ModuleName, struct FString WidetKey); // Offset: 0x103a825ac // Return & Params: Num(4) Size(0x30)

	// Object Name: Function Client.STExtraClientUtils.GetBPUtils
	// Flags: [Final|Native|Static|Public]
	struct USTExtraClientUIBPUtils* GetBPUtils(); // Offset: 0x103a82578 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.STExtraClientUtils.AsyncLoadAssetInstWithCallback
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int AsyncLoadAssetInstWithCallback(struct FString InPath, DelegateProperty Callback); // Offset: 0x103a8248c // Return & Params: Num(3) Size(0x24)
};

// Object Name: Class Client.STExtraClientUIBPUtils
// Size: 0x148 // Inherited bytes: 0x28
struct USTExtraClientUIBPUtils : UObject {
	// Fields
	char pad_0x28[0xd0]; // Offset: 0x28 // Size: 0xd0
	struct TMap<int, struct FAssetAsyncRequest> PendingAsyncAssetRequests; // Offset: 0xf8 // Size: 0x50

	// Functions

	// Object Name: Function Client.STExtraClientUIBPUtils.OnAsyncAssetLoaded
	// Flags: [Final|Native|Public|HasDefaults]
	void OnAsyncAssetLoaded(struct FSoftObjectPath InSoftPath, int RequestIdx); // Offset: 0x103a82b6c // Return & Params: Num(2) Size(0x1c)

	// Object Name: Function Client.STExtraClientUIBPUtils.AsyncLoadAssetInstWithCallback
	// Flags: [Final|Native|Public]
	int AsyncLoadAssetInstWithCallback(struct FString InPath, DelegateProperty Callback); // Offset: 0x103a82a70 // Return & Params: Num(3) Size(0x24)
};

// Object Name: Class Client.Translator
// Size: 0x138 // Inherited bytes: 0x28
struct UTranslator : UObject {
	// Fields
	struct FString SubscriptionKey; // Offset: 0x28 // Size: 0x10
	struct FString StoredAccessToken; // Offset: 0x38 // Size: 0x10
	DelegateProperty OnGetAccessTokenDelegate; // Offset: 0x48 // Size: 0x10
	DelegateProperty OnDetectDelegate; // Offset: 0x58 // Size: 0x10
	DelegateProperty OnTranslateDelegate; // Offset: 0x68 // Size: 0x10
	char pad_0x78[0x98]; // Offset: 0x78 // Size: 0x98
	struct UGameFrontendHUD* GameFrontendHUD; // Offset: 0x110 // Size: 0x08
	char pad_0x118[0x20]; // Offset: 0x118 // Size: 0x20

	// Functions

	// Object Name: Function Client.Translator.TranslateV2
	// Flags: [Final|Native|Public|BlueprintCallable]
	void TranslateV2(int Channel, int ID, struct FString Text); // Offset: 0x103a83bc4 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.Translator.Translate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Translate(struct FString URL, struct FString Verb, struct TMap<struct FString, struct FString> Headers, struct FString Content); // Offset: 0x103a83a04 // Return & Params: Num(4) Size(0x80)

	// Object Name: Function Client.Translator.PostMsg
	// Flags: [Final|Native|Public|BlueprintCallable]
	void PostMsg(struct FString URL, struct FString Content); // Offset: 0x103a83918 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.Translator.OnTranslateV2
	// Flags: [Final|Native|Private]
	void OnTranslateV2(bool Success, struct FString Data); // Offset: 0x103a83834 // Return & Params: Num(2) Size(0x18)

	// Object Name: DelegateFunction Client.Translator.OnTranslate__DelegateSignature
	// Flags: [Public|Delegate]
	void OnTranslate__DelegateSignature(bool IsSuccess, struct FString LanguageFrom, struct FString Translation); // Offset: 0x103e7af64 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.Translator.OnTranslate
	// Flags: [Final|Native|Private]
	void OnTranslate(bool Success, struct FString Data); // Offset: 0x103a83750 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.Translator.OnGetAccessTokenV2
	// Flags: [Final|Native|Private]
	void OnGetAccessTokenV2(bool Success, struct FString Data); // Offset: 0x103a8366c // Return & Params: Num(2) Size(0x18)

	// Object Name: DelegateFunction Client.Translator.OnGetAccessToken__DelegateSignature
	// Flags: [Public|Delegate]
	void OnGetAccessToken__DelegateSignature(bool IsSuccess, struct FString Token); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.Translator.OnGetAccessToken
	// Flags: [Final|Native|Private]
	void OnGetAccessToken(bool Success, struct FString Data); // Offset: 0x103a83588 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.Translator.OnDetectV2
	// Flags: [Final|Native|Private]
	void OnDetectV2(bool Success, struct FString Data); // Offset: 0x103a834a4 // Return & Params: Num(2) Size(0x18)

	// Object Name: DelegateFunction Client.Translator.OnDetect__DelegateSignature
	// Flags: [Public|Delegate]
	void OnDetect__DelegateSignature(bool IsSuccess, struct FString from, struct FString to); // Offset: 0x103e7af64 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.Translator.OnDetect
	// Flags: [Final|Native|Private]
	void OnDetect(bool Success, struct FString Data); // Offset: 0x103a833c0 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.Translator.HasTranslating
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool HasTranslating(); // Offset: 0x103a8338c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.Translator.GetAccessToken
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GetAccessToken(bool bForceGet, struct FString URL, struct FString Verb, struct TMap<struct FString, struct FString> Headers, struct FString Content); // Offset: 0x103a83180 // Return & Params: Num(5) Size(0x88)

	// Object Name: Function Client.Translator.Detect
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Detect(struct FString URL, struct FString Verb, struct TMap<struct FString, struct FString> Headers, struct FString Content); // Offset: 0x103a82fc0 // Return & Params: Num(4) Size(0x80)
};

// Object Name: Class Client.TssManager
// Size: 0x60 // Inherited bytes: 0x28
struct UTssManager : UObject {
	// Fields
	struct FString TssHostInfo; // Offset: 0x28 // Size: 0x10
	struct FString TssCDNHostInfo; // Offset: 0x38 // Size: 0x10
	struct FString TssBuildInIpInfo; // Offset: 0x48 // Size: 0x10
	int TssLocal; // Offset: 0x58 // Size: 0x04
	char pad_0x5C[0x4]; // Offset: 0x5c // Size: 0x04

	// Functions

	// Object Name: Function Client.TssManager.SendSkdData_LuaState
	// Flags: [Final|Native|Static|Public]
	int SendSkdData_LuaState(); // Offset: 0x103a84198 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TssManager.SendEigeninfoData_LuaState
	// Flags: [Final|Native|Static|Public]
	int SendEigeninfoData_LuaState(); // Offset: 0x103a84180 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TssManager.SaveSendEigeninfoCode_LuaState
	// Flags: [Final|Native|Static|Public]
	uint32_t SaveSendEigeninfoCode_LuaState(); // Offset: 0x103a84168 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TssManager.OnRecvData_LuaState
	// Flags: [Final|Native|Static|Public]
	int OnRecvData_LuaState(); // Offset: 0x103a84150 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TssManager.GetUserTag4Lua_LuaState
	// Flags: [Final|Native|Static|Public]
	int GetUserTag4Lua_LuaState(); // Offset: 0x103a84138 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TssManager.GetDeviceFeature_LuaState
	// Flags: [Final|Native|Static|Public]
	int GetDeviceFeature_LuaState(); // Offset: 0x103a84120 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TssManager.EigenArrayObfuscationVerify_LuaState
	// Flags: [Final|Native|Static|Public]
	int EigenArrayObfuscationVerify_LuaState(); // Offset: 0x103a84108 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class Client.UAEClientGameMode
// Size: 0x498 // Inherited bytes: 0x498
struct AUAEClientGameMode : AGameMode {
};

// Object Name: Class Client.UAELobbyGameMode
// Size: 0x498 // Inherited bytes: 0x498
struct AUAELobbyGameMode : AUAEClientGameMode {
};

// Object Name: Class Client.UAELobbyPlayerController
// Size: 0x730 // Inherited bytes: 0x730
struct AUAELobbyPlayerController : APlayerController {
};

// Object Name: Class Client.UTRichTextBlock
// Size: 0xb08 // Inherited bytes: 0x100
struct UUTRichTextBlock : UWidget {
	// Fields
	char pad_0x100[0x8]; // Offset: 0x100 // Size: 0x08
	struct FScriptMulticastDelegate OnHyperlinkClicked; // Offset: 0x108 // Size: 0x10
	struct FString ContentText; // Offset: 0x118 // Size: 0x10
	char pad_0x128[0x10]; // Offset: 0x128 // Size: 0x10
	struct FSlateFontInfo Font; // Offset: 0x138 // Size: 0x58
	bool bSupportHyLink; // Offset: 0x190 // Size: 0x01
	bool bSupportImage; // Offset: 0x191 // Size: 0x01
	char pad_0x192[0x2]; // Offset: 0x192 // Size: 0x02
	struct FLinearColor TextColor; // Offset: 0x194 // Size: 0x10
	enum class ETextJustify Justification; // Offset: 0x1a4 // Size: 0x01
	enum class ETextVerticalJustify TextVerticalJustification; // Offset: 0x1a5 // Size: 0x01
	bool AutoWrapText; // Offset: 0x1a6 // Size: 0x01
	char pad_0x1A7[0x1]; // Offset: 0x1a7 // Size: 0x01
	struct FScrollBarStyle ScrollBarStyle; // Offset: 0x1a8 // Size: 0x680
	struct FMargin HScrollBarPadding; // Offset: 0x828 // Size: 0x10
	struct FMargin VScrollBarPadding; // Offset: 0x838 // Size: 0x10
	float WrapTextAt; // Offset: 0x848 // Size: 0x04
	struct FMargin Margin; // Offset: 0x84c // Size: 0x10
	float LineHeightPercentage; // Offset: 0x85c // Size: 0x04
	struct FString HyperlinkDecoratorTag; // Offset: 0x860 // Size: 0x10
	struct FString HyperlinkCallBackFunctionName; // Offset: 0x870 // Size: 0x10
	struct FString HyperlinkCallBackTableName; // Offset: 0x880 // Size: 0x10
	char pad_0x890[0x270]; // Offset: 0x890 // Size: 0x270
	struct UGameFrontendHUD* GameFrontendHUD; // Offset: 0xb00 // Size: 0x08

	// Functions

	// Object Name: Function Client.UTRichTextBlock.SetText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetText(struct FText InText); // Offset: 0x103a849a0 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function Client.UTRichTextBlock.SetGameFrontendHUD
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetGameFrontendHUD(struct UGameFrontendHUD* InHUD); // Offset: 0x103a84924 // Return & Params: Num(1) Size(0x8)

	// Object Name: DelegateFunction Client.UTRichTextBlock.OnHyperlinkClickedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnHyperlinkClickedEvent__DelegateSignature(struct FMetaDataHolder& MetaDataHolder); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x50)

	// Object Name: Function Client.UTRichTextBlock.GetText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FText GetText(); // Offset: 0x103a848c0 // Return & Params: Num(1) Size(0x18)
};

// Object Name: Class Client.AEVarButton
// Size: 0x550 // Inherited bytes: 0x118
struct UAEVarButton : UContentWidget {
	// Fields
	struct USlateWidgetStyleAsset* Style; // Offset: 0x118 // Size: 0x08
	struct FButtonStyle WidgetStyle; // Offset: 0x120 // Size: 0x338
	struct FLinearColor ColorAndOpacity; // Offset: 0x458 // Size: 0x10
	struct FLinearColor BackgroundColor; // Offset: 0x468 // Size: 0x10
	enum class EButtonClickMethod ClickMethod; // Offset: 0x478 // Size: 0x01
	enum class EButtonTouchMethod TouchMethod; // Offset: 0x479 // Size: 0x01
	bool IsFocusable; // Offset: 0x47a // Size: 0x01
	bool IsPassMouseEvent; // Offset: 0x47b // Size: 0x01
	char pad_0x47C[0x4]; // Offset: 0x47c // Size: 0x04
	struct FString ButtonVar; // Offset: 0x480 // Size: 0x10
	struct FScriptMulticastDelegate OnButtonClicked; // Offset: 0x490 // Size: 0x10
	struct FScriptMulticastDelegate OnButtonPressed; // Offset: 0x4a0 // Size: 0x10
	struct FScriptMulticastDelegate OnButtonReleased; // Offset: 0x4b0 // Size: 0x10
	struct FScriptMulticastDelegate OnButtonHovered; // Offset: 0x4c0 // Size: 0x10
	struct FScriptMulticastDelegate OnButtonUnhovered; // Offset: 0x4d0 // Size: 0x10
	DelegateProperty OnMouseButtonDownEvent; // Offset: 0x4e0 // Size: 0x10
	char pad_0x4F0[0x10]; // Offset: 0x4f0 // Size: 0x10
	struct FScriptMulticastDelegate OnClicked; // Offset: 0x500 // Size: 0x10
	struct FScriptMulticastDelegate OnPressed; // Offset: 0x510 // Size: 0x10
	struct FScriptMulticastDelegate OnReleased; // Offset: 0x520 // Size: 0x10
	struct FScriptMulticastDelegate OnHovered; // Offset: 0x530 // Size: 0x10
	struct FScriptMulticastDelegate OnUnhovered; // Offset: 0x540 // Size: 0x10

	// Functions

	// Object Name: Function Client.AEVarButton.SetTouchMethod
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTouchMethod(enum class EButtonTouchMethod InTouchMethod); // Offset: 0x103a84f78 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.AEVarButton.SetStyle
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetStyle(struct FButtonStyle& InStyle); // Offset: 0x103a84ec4 // Return & Params: Num(1) Size(0x338)

	// Object Name: Function Client.AEVarButton.SetColorAndOpacity
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetColorAndOpacity(struct FLinearColor InColorAndOpacity); // Offset: 0x103a84e48 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.AEVarButton.SetClickMethod
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetClickMethod(enum class EButtonClickMethod InClickMethod); // Offset: 0x103a84dcc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.AEVarButton.SetBackgroundColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetBackgroundColor(struct FLinearColor InBackgroundColor); // Offset: 0x103a84d50 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.AEVarButton.IsPressed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsPressed(); // Offset: 0x103a84d1c // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class Client.ReuseFallC
// Size: 0xec0 // Inherited bytes: 0x218
struct UReuseFallC : UUserWidget {
	// Fields
	struct FScriptMulticastDelegate OnBeforeNewItem; // Offset: 0x218 // Size: 0x10
	struct FScriptMulticastDelegate OnAfterNewItem; // Offset: 0x228 // Size: 0x10
	struct FScriptMulticastDelegate OnRefreshItem; // Offset: 0x238 // Size: 0x10
	struct FScriptMulticastDelegate OnItemCreated; // Offset: 0x248 // Size: 0x10
	struct FScriptMulticastDelegate OnTouchFinish; // Offset: 0x258 // Size: 0x10
	struct FScriptMulticastDelegate OnOverscrollState; // Offset: 0x268 // Size: 0x10
	struct FScrollBoxStyle ScrollBoxStyle; // Offset: 0x278 // Size: 0x2e8
	enum class EWidgetClipping ScrollBoxClipping; // Offset: 0x560 // Size: 0x01
	char pad_0x561[0x7]; // Offset: 0x561 // Size: 0x07
	struct FScrollBarStyle ScrollBarStyle; // Offset: 0x568 // Size: 0x680
	enum class ESlateVisibility ScrollBarVisibility; // Offset: 0xbe8 // Size: 0x01
	char pad_0xBE9[0x3]; // Offset: 0xbe9 // Size: 0x03
	struct FVector2D ScrollbarThickness; // Offset: 0xbec // Size: 0x08
	int ColumnNum; // Offset: 0xbf4 // Size: 0x04
	int ItemHeight; // Offset: 0xbf8 // Size: 0x04
	int ItemPaddingX; // Offset: 0xbfc // Size: 0x04
	int ItemPaddingY; // Offset: 0xc00 // Size: 0x04
	float OverscrollLength; // Offset: 0xc04 // Size: 0x04
	struct UUserWidget* ItemClass; // Offset: 0xc08 // Size: 0x08
	struct TMap<struct FString, struct UUserWidget*> OtherItemClass; // Offset: 0xc10 // Size: 0x50
	int PreviewCount; // Offset: 0xc60 // Size: 0x04
	int ItemPoolMaxNum; // Offset: 0xc64 // Size: 0x04
	int TopSpaceReserved; // Offset: 0xc68 // Size: 0x04
	int BottomSpaceReserved; // Offset: 0xc6c // Size: 0x04
	char pad_0xC70[0x38]; // Offset: 0xc70 // Size: 0x38
	struct UUserWidget* CurItemClass; // Offset: 0xca8 // Size: 0x08
	char pad_0xCB0[0x210]; // Offset: 0xcb0 // Size: 0x210

	// Functions

	// Object Name: Function Client.ReuseFallC.SetScrollOffset
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetScrollOffset(float NewScrollOffset); // Offset: 0x103a85994 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseFallC.SetItemSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetItemSize(int __Idx, float __Size); // Offset: 0x103a858dc // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.ReuseFallC.SetItemFullStyle
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetItemFullStyle(int idx); // Offset: 0x103a85860 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseFallC.SetCurItemClass
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetCurItemClass(struct FString StrName); // Offset: 0x103a857b8 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ReuseFallC.ScrollToStart
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ScrollToStart(); // Offset: 0x103a857a4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ReuseFallC.ScrollToEnd
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ScrollToEnd(); // Offset: 0x103a85790 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ReuseFallC.ResetCurItemClassToDefault
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ResetCurItemClassToDefault(); // Offset: 0x103a8577c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ReuseFallC.Reload
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Reload(int __ItemCount); // Offset: 0x103a85700 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseFallC.RefreshOne
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RefreshOne(int __Idx); // Offset: 0x103a85684 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseFallC.Refresh
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Refresh(); // Offset: 0x103a85670 // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction Client.ReuseFallC.OnUpdateItemDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnUpdateItemDelegate__DelegateSignature(struct UUserWidget* Widget, int idx); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0xc)

	// Object Name: DelegateFunction Client.ReuseFallC.OnTouchFinishDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnTouchFinishDelegate__DelegateSignature(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ReuseFallC.OnTouchFinishCallback
	// Flags: [Final|Native|Protected]
	void OnTouchFinishCallback(); // Offset: 0x103a8565c // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction Client.ReuseFallC.OnOverscrollStateDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnOverscrollStateDelegate__DelegateSignature(enum class EReuseFallOverscrollState State); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x1)

	// Object Name: DelegateFunction Client.ReuseFallC.OnCreateItemDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnCreateItemDelegate__DelegateSignature(struct UUserWidget* Widget, int idx); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0xc)

	// Object Name: DelegateFunction Client.ReuseFallC.OnBeforeNewItemDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnBeforeNewItemDelegate__DelegateSignature(int idx); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x4)

	// Object Name: DelegateFunction Client.ReuseFallC.OnAfterNewItemDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnAfterNewItemDelegate__DelegateSignature(struct UUserWidget* Widget, int idx); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ReuseFallC.JumpByIdx
	// Flags: [Final|Native|Public|BlueprintCallable]
	void JumpByIdx(int __Idx, bool bImmedia); // Offset: 0x103a855a0 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Client.ReuseFallC.GetViewSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector2D GetViewSize(); // Offset: 0x103a85584 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ReuseFallC.GetScrollOffset
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetScrollOffset(); // Offset: 0x103a85550 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseFallC.GetOverscrollState
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class EReuseFallOverscrollState GetOverscrollState(); // Offset: 0x103a85534 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ReuseFallC.GetContentSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector2D GetContentSize(); // Offset: 0x103a85518 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ReuseFallC.ClearItemFullStyle
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearItemFullStyle(); // Offset: 0x103a85504 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ReuseFallC.Clear
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Clear(); // Offset: 0x103a854f0 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Client.ReuseListC
// Size: 0xce8 // Inherited bytes: 0x218
struct UReuseListC : UUserWidget {
	// Fields
	struct FScriptMulticastDelegate OnUpdateItemParam; // Offset: 0x218 // Size: 0x10
	struct FScriptMulticastDelegate OnUpdateItem; // Offset: 0x228 // Size: 0x10
	struct FScriptMulticastDelegate OnScrollItem; // Offset: 0x238 // Size: 0x10
	struct FScriptMulticastDelegate OnCreateItem; // Offset: 0x248 // Size: 0x10
	struct FScrollBoxStyle ScrollBoxStyle; // Offset: 0x258 // Size: 0x2e8
	enum class EWidgetClipping ScrollBoxClipping; // Offset: 0x540 // Size: 0x01
	enum class ESlateVisibility ScrollBoxVisibility; // Offset: 0x541 // Size: 0x01
	char pad_0x542[0x6]; // Offset: 0x542 // Size: 0x06
	struct FScrollBarStyle ScrollBarStyle; // Offset: 0x548 // Size: 0x680
	enum class ESlateVisibility ScrollBarVisibility; // Offset: 0xbc8 // Size: 0x01
	char pad_0xBC9[0x3]; // Offset: 0xbc9 // Size: 0x03
	struct FVector2D ScrollbarThickness; // Offset: 0xbcc // Size: 0x08
	int ItemWidth; // Offset: 0xbd4 // Size: 0x04
	int ItemHeight; // Offset: 0xbd8 // Size: 0x04
	int PaddingX; // Offset: 0xbdc // Size: 0x04
	int PaddingY; // Offset: 0xbe0 // Size: 0x04
	int TitleSize; // Offset: 0xbe4 // Size: 0x04
	int TitlePadding; // Offset: 0xbe8 // Size: 0x04
	bool AutoTitleSize; // Offset: 0xbec // Size: 0x01
	enum class EReuseListStyle Style; // Offset: 0xbed // Size: 0x01
	char pad_0xBEE[0x2]; // Offset: 0xbee // Size: 0x02
	struct UUserWidget* ItemClass; // Offset: 0xbf0 // Size: 0x08
	int PreviewCount; // Offset: 0xbf8 // Size: 0x04
	enum class EReuseListNotFullAlignStyle NotFullAlignStyle; // Offset: 0xbfc // Size: 0x01
	bool NotFullScrollBoxHitTestInvisible; // Offset: 0xbfd // Size: 0x01
	bool UpdateForceLayoutPrepass; // Offset: 0xbfe // Size: 0x01
	char pad_0xBFF[0x1]; // Offset: 0xbff // Size: 0x01
	int ItemCacheNum; // Offset: 0xc00 // Size: 0x04
	int DelayUpdateTimeLimitMS; // Offset: 0xc04 // Size: 0x04
	char pad_0xC08[0xe0]; // Offset: 0xc08 // Size: 0xe0

	// Functions

	// Object Name: Function Client.ReuseListC.SetTitleSlotAutoSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTitleSlotAutoSize(bool as); // Offset: 0x103a86b38 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ReuseListC.SetTitleSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTitleSize(int sz); // Offset: 0x103a86abc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseListC.SetScrollOffset
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetScrollOffset(float NewScrollOffset); // Offset: 0x103a86a40 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseListC.ScrollToStart
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ScrollToStart(); // Offset: 0x103a86a2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ReuseListC.ScrollToEnd
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ScrollToEnd(); // Offset: 0x103a86a18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ReuseListC.Reset
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Reset(struct UUserWidget* __ItemClass, enum class EReuseListStyle __Style, int __ItemWidth, int __ItemHeight, int __PaddingX, int __PaddingY); // Offset: 0x103a86878 // Return & Params: Num(6) Size(0x1c)

	// Object Name: Function Client.ReuseListC.Reload
	// Flags: [Native|Public|BlueprintCallable]
	void Reload(int __ItemCount); // Offset: 0x103a867f4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseListC.RefreshParam
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RefreshParam(struct FString _Param); // Offset: 0x103a8675c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ReuseListC.RefreshOneParam
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RefreshOneParam(int __Idx, struct FString _Param); // Offset: 0x103a86688 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ReuseListC.RefreshOne
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RefreshOne(int __Idx); // Offset: 0x103a8660c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseListC.Refresh
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Refresh(); // Offset: 0x103a865f8 // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction Client.ReuseListC.OnUpdateItemParamDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnUpdateItemParamDelegate__DelegateSignature(struct UUserWidget* Widget, int idx, struct FString Param); // Offset: 0x103e7af64 // Return & Params: Num(3) Size(0x20)

	// Object Name: DelegateFunction Client.ReuseListC.OnUpdateItemDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnUpdateItemDelegate__DelegateSignature(struct UUserWidget* Widget, int idx); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0xc)

	// Object Name: DelegateFunction Client.ReuseListC.OnScrollItemDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnScrollItemDelegate__DelegateSignature(int BeginIdx, int EndIdx); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0x8)

	// Object Name: DelegateFunction Client.ReuseListC.OnCreateItemDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnCreateItemDelegate__DelegateSignature(struct UUserWidget* Widget); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ReuseListC.JumpByIdxStyle
	// Flags: [Final|Native|Public|BlueprintCallable]
	void JumpByIdxStyle(int __Idx, enum class EReuseListJumpStyle __Style); // Offset: 0x103a86540 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Client.ReuseListC.JumpByIdx
	// Flags: [Final|Native|Public|BlueprintCallable]
	void JumpByIdx(int __Idx); // Offset: 0x103a864c4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseListC.GetViewSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector2D GetViewSize(); // Offset: 0x103a864a8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ReuseListC.GetScrollOffset
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetScrollOffset(); // Offset: 0x103a86474 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseListC.GetPaddingY
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetPaddingY(); // Offset: 0x103a86458 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseListC.GetPaddingX
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetPaddingX(); // Offset: 0x103a8643c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseListC.GetItemWidthAndPaddingX
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetItemWidthAndPaddingX(); // Offset: 0x103a86418 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseListC.GetItemWidth
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetItemWidth(); // Offset: 0x103a863fc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseListC.GetItemHeightAndPaddingY
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetItemHeightAndPaddingY(); // Offset: 0x103a863d8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseListC.GetItemHeight
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetItemHeight(); // Offset: 0x103a863bc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseListC.GetContentSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector2D GetContentSize(); // Offset: 0x103a863a0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ReuseListC.GetAllWidgetItems
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void GetAllWidgetItems(struct TArray<struct UUserWidget*>& ResultItemList); // Offset: 0x103a862f8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ReuseListC.FindItem
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UUserWidget* FindItem(int idx); // Offset: 0x103a8626c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Client.ReuseListC.Clear
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Clear(); // Offset: 0x103a8624c // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Client.ReusePageC
// Size: 0x350 // Inherited bytes: 0x218
struct UReusePageC : UUserWidget {
	// Fields
	struct FScriptMulticastDelegate OnUpdateItem; // Offset: 0x218 // Size: 0x10
	struct FScriptMulticastDelegate OnPageChanged; // Offset: 0x228 // Size: 0x10
	struct FScriptMulticastDelegate OnCreateItem; // Offset: 0x238 // Size: 0x10
	struct FScriptMulticastDelegate OnBeginDrag; // Offset: 0x248 // Size: 0x10
	struct FScriptMulticastDelegate OnEndDrag; // Offset: 0x258 // Size: 0x10
	struct FScriptMulticastDelegate OnEndScroll; // Offset: 0x268 // Size: 0x10
	struct UUserWidget* ItemClass; // Offset: 0x278 // Size: 0x08
	char IsLoopPage : 1; // Offset: 0x280 // Size: 0x01
	char IsVertical : 1; // Offset: 0x280 // Size: 0x01
	char CanDrag : 1; // Offset: 0x280 // Size: 0x01
	char pad_0x280_3 : 5; // Offset: 0x280 // Size: 0x01
	char pad_0x281[0x3]; // Offset: 0x281 // Size: 0x03
	int CanDragLimit; // Offset: 0x284 // Size: 0x04
	float AutoPlayRate; // Offset: 0x288 // Size: 0x04
	int ShowPageNum; // Offset: 0x28c // Size: 0x04
	int DragPageNum; // Offset: 0x290 // Size: 0x04
	float DChgPageParam; // Offset: 0x294 // Size: 0x04
	float ScrollInertial; // Offset: 0x298 // Size: 0x04
	float ScrollRate; // Offset: 0x29c // Size: 0x04
	char pad_0x2A0[0xb0]; // Offset: 0x2a0 // Size: 0xb0

	// Functions

	// Object Name: Function Client.ReusePageC.SetAutoPlayRate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAutoPlayRate(float Rate); // Offset: 0x103a89910 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReusePageC.SelectPage
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SelectPage(int __Idx); // Offset: 0x103a89894 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReusePageC.Reload
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Reload(int __Count); // Offset: 0x103a89818 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReusePageC.Play
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Play(bool bPlay); // Offset: 0x103a89794 // Return & Params: Num(1) Size(0x1)

	// Object Name: DelegateFunction Client.ReusePageC.OnUpdateItemDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnUpdateItemDelegate__DelegateSignature(struct UUserWidget* Widget, int idx); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0xc)

	// Object Name: DelegateFunction Client.ReusePageC.OnPageChangedDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnPageChangedDelegate__DelegateSignature(int PageIdx); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x4)

	// Object Name: DelegateFunction Client.ReusePageC.OnEndScrollDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnEndScrollDelegate__DelegateSignature(int PageIdx); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x4)

	// Object Name: DelegateFunction Client.ReusePageC.OnEndDragDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnEndDragDelegate__DelegateSignature(int PageIdx); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x4)

	// Object Name: DelegateFunction Client.ReusePageC.OnCreateItemDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnCreateItemDelegate__DelegateSignature(struct UUserWidget* Widget); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x8)

	// Object Name: DelegateFunction Client.ReusePageC.OnBeginDragDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnBeginDragDelegate__DelegateSignature(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ReusePageC.MovePrePage
	// Flags: [Final|Native|Public|BlueprintCallable]
	void MovePrePage(); // Offset: 0x103a89780 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ReusePageC.MoveNextPage
	// Flags: [Final|Native|Public|BlueprintCallable]
	void MoveNextPage(); // Offset: 0x103a8976c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ReusePageC.IsDraging
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsDraging(); // Offset: 0x103a8974c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ReusePageC.GetPageCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetPageCount(); // Offset: 0x103a89730 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReusePageC.GetPage
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetPage(); // Offset: 0x103a89714 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReusePageC.GetOffset
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetOffset(); // Offset: 0x103a896f8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReusePageC.GetAutoPlayRate
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetAutoPlayRate(); // Offset: 0x103a896dc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReusePageC.GetAllItems
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void GetAllItems(struct TArray<struct UUserWidget*>& ResultItemList, bool OnlyVisible); // Offset: 0x103a895e0 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ReusePageC.ClearCache
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearCache(); // Offset: 0x103a895cc // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Client.UDPPingCollector
// Size: 0x138 // Inherited bytes: 0x28
struct UUDPPingCollector : UObject {
	// Fields
	char pad_0x28[0x30]; // Offset: 0x28 // Size: 0x30
	struct TMap<struct FString, struct FPingServerInfo> mUDPPingInfoMap; // Offset: 0x58 // Size: 0x50
	char pad_0xA8[0x20]; // Offset: 0xa8 // Size: 0x20
	struct FScriptMulticastDelegate UDPPingShadowResultToLuaDelegate; // Offset: 0xc8 // Size: 0x10
	char pad_0xD8[0x60]; // Offset: 0xd8 // Size: 0x60

	// Functions

	// Object Name: Function Client.UDPPingCollector.TickUDPPing
	// Flags: [Final|Native|Public|BlueprintCallable]
	void TickUDPPing(float DeltaTime); // Offset: 0x103a8a5e4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.UDPPingCollector.setUDPPingServerAddress
	// Flags: [Final|Native|Public|BlueprintCallable]
	void setUDPPingServerAddress(struct FString ServerIP, struct FString ServerPort, int ZoneID, int WaterMarkType); // Offset: 0x103a8a434 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function Client.UDPPingCollector.PingServer
	// Flags: [Final|Native|Public|BlueprintCallable]
	void PingServer(struct FString address, float Timeout, int WaterMarkType); // Offset: 0x103a8a2f8 // Return & Params: Num(3) Size(0x18)

	// Object Name: DelegateFunction Client.UDPPingCollector.OnPingServerResultDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnPingServerResultDelegate__DelegateSignature(struct FString address, int IsSuccess, float Time); // Offset: 0x103e7af64 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.UDPPingCollector.IsChooingZoneAccess
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsChooingZoneAccess(); // Offset: 0x103a8a2c4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.UDPPingCollector.isAllZoneHasPingValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool isAllZoneHasPingValue(); // Offset: 0x103a8a290 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.UDPPingCollector.Init
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Init(float MinPingintervalTime, float pingintervalTime, float pingTimeoutSecond, float normalDelayMilliSecond, float maxAutoChooseZoneDelayMilliSecond); // Offset: 0x103a8a12c // Return & Params: Num(5) Size(0x14)

	// Object Name: Function Client.UDPPingCollector.GetZoneServerDelay
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetZoneServerDelay(struct FString ServerAddress); // Offset: 0x103a8a060 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.UDPPingCollector.GetMinDealyAddress
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetMinDealyAddress(); // Offset: 0x103a8a02c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.UDPPingCollector.ChoosingZone
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ChoosingZone(int ZoneID, struct FString AddrIP); // Offset: 0x103a89f30 // Return & Params: Num(2) Size(0x18)
};

// Object Name: Class Client.ViberateEngine
// Size: 0x28 // Inherited bytes: 0x28
struct UViberateEngine : UObject {
};

// Object Name: Class Client.VibrateSystemManager
// Size: 0x448 // Inherited bytes: 0x30
struct UVibrateSystemManager : UGameInstanceSubsystem {
	// Fields
	char pad_0x30[0x10]; // Offset: 0x30 // Size: 0x10
	struct FString ClassPath; // Offset: 0x40 // Size: 0x10
	struct FString VibrateAssetTablePath; // Offset: 0x50 // Size: 0x10
	int MaxAmplitude; // Offset: 0x60 // Size: 0x04
	int GroundSpesificMatVibrationMinGrear; // Offset: 0x64 // Size: 0x04
	float VehicleBreakingMinSpeedThreshold; // Offset: 0x68 // Size: 0x04
	float VehicleGearMinSpeedThreshold; // Offset: 0x6c // Size: 0x04
	struct TArray<int> TriggerVehicleVibrateGroundPhysicMatList; // Offset: 0x70 // Size: 0x10
	float TriggerVehicleVibrateMinSlip; // Offset: 0x80 // Size: 0x04
	float TriggerVehicleVibrateMinSuspensionRaisePercent; // Offset: 0x84 // Size: 0x04
	float VehicleRaiseSuspensionVibrateInerval; // Offset: 0x88 // Size: 0x04
	int InitAssetProccessNumFrames; // Offset: 0x8c // Size: 0x04
	struct FString LoopTime; // Offset: 0x90 // Size: 0x10
	char pad_0xA0[0x50]; // Offset: 0xa0 // Size: 0x50
	struct TMap<int, enum class EVibrateTriggerEventType> LoadedVibrateAssetIDAndEventTypeMap; // Offset: 0xf0 // Size: 0x50
	struct TMap<enum class EVibrateStrengthLevel, float> VibrateStrengthLevelModifireMap; // Offset: 0x140 // Size: 0x50
	struct TMap<enum class EVibrateTriggerEventType, float> VibrateEventMinIntervalMap; // Offset: 0x190 // Size: 0x50
	struct TArray<enum class EVibrateTriggerEventType> CharacterVibrateEventList; // Offset: 0x1e0 // Size: 0x10
	struct TArray<enum class EVibrateTriggerEventType> WeaponVibrateEventList; // Offset: 0x1f0 // Size: 0x10
	struct TArray<enum class EVibrateTriggerEventType> VehicleVibrateEventList; // Offset: 0x200 // Size: 0x10
	struct TArray<enum class EVibrateTriggerEventType> SoundUIVibrateEventList; // Offset: 0x210 // Size: 0x10
	struct TArray<enum class EVibrateTriggerEventType> CharacterBeHitVibrateEventList; // Offset: 0x220 // Size: 0x10
	struct TArray<enum class EVibrateTriggerEventType> VehicleEngineVibrateEventList; // Offset: 0x230 // Size: 0x10
	struct TArray<enum class EVibrateTriggerEventType> VehicleBeHitVibrateEventList; // Offset: 0x240 // Size: 0x10
	bool bEntireVibrationSwitch; // Offset: 0x250 // Size: 0x01
	bool bCharacterVibrationSwitch; // Offset: 0x251 // Size: 0x01
	bool bWeaponVibrationSwitch; // Offset: 0x252 // Size: 0x01
	bool bVehicleVibrationSwitch; // Offset: 0x253 // Size: 0x01
	bool bSoundUIVibrationSwitch; // Offset: 0x254 // Size: 0x01
	char pad_0x255[0x3]; // Offset: 0x255 // Size: 0x03
	int CharacterVibrationLevel; // Offset: 0x258 // Size: 0x04
	int WeaponVibrationLevel; // Offset: 0x25c // Size: 0x04
	int VehicleVibrationLevel; // Offset: 0x260 // Size: 0x04
	int SoundUIVibrationLevel; // Offset: 0x264 // Size: 0x04
	int EntireVibrationLevel; // Offset: 0x268 // Size: 0x04
	bool bCharacterVibrate; // Offset: 0x26c // Size: 0x01
	bool bWeaponVibrate; // Offset: 0x26d // Size: 0x01
	bool bVehicleVibrate; // Offset: 0x26e // Size: 0x01
	bool bSoundUIVibrate; // Offset: 0x26f // Size: 0x01
	bool bCharacterBeHitVibrate; // Offset: 0x270 // Size: 0x01
	bool bCharacterClimbVibrate; // Offset: 0x271 // Size: 0x01
	bool bCharacterFallVibrate; // Offset: 0x272 // Size: 0x01
	bool bCharacterSwimVibrate; // Offset: 0x273 // Size: 0x01
	bool bAutoWeaponVibrate; // Offset: 0x274 // Size: 0x01
	bool bSemiAutoWeaponVibrate; // Offset: 0x275 // Size: 0x01
	bool bBoltWeaponVibrate; // Offset: 0x276 // Size: 0x01
	bool bOtherWeaponVibrate; // Offset: 0x277 // Size: 0x01
	bool bVehicleEngineVibrate; // Offset: 0x278 // Size: 0x01
	bool bVehicleBeHitVibrate; // Offset: 0x279 // Size: 0x01
	bool bVehicleCrashVibrate; // Offset: 0x27a // Size: 0x01
	bool bFootstepSoundUIVibrate; // Offset: 0x27b // Size: 0x01
	bool bFireShotSoundUIVibrate; // Offset: 0x27c // Size: 0x01
	bool bGlassBrokenSoundUIVibrate; // Offset: 0x27d // Size: 0x01
	bool bVehicleSoundUIVibrate; // Offset: 0x27e // Size: 0x01
	char pad_0x27F[0x1]; // Offset: 0x27f // Size: 0x01
	struct FTimerHandle StopVibrateHandle; // Offset: 0x280 // Size: 0x08
	int CurPlayingVibrateAssetIndex; // Offset: 0x288 // Size: 0x04
	int CurLoopPlayingVibrateAssetIndex; // Offset: 0x28c // Size: 0x04
	int DeviceSupportVibrateType; // Offset: 0x290 // Size: 0x04
	bool bInGameVibration; // Offset: 0x294 // Size: 0x01
	bool bIsHandBreaking; // Offset: 0x295 // Size: 0x01
	char pad_0x296[0x52]; // Offset: 0x296 // Size: 0x52
	bool bHasLastVehicle; // Offset: 0x2e8 // Size: 0x01
	char pad_0x2E9[0x3]; // Offset: 0x2e9 // Size: 0x03
	int LastVehicleGear; // Offset: 0x2ec // Size: 0x04
	bool bIsLastVehicleBreaking; // Offset: 0x2f0 // Size: 0x01
	bool bIsLastVehicleSlipping; // Offset: 0x2f1 // Size: 0x01
	char pad_0x2F2[0x2]; // Offset: 0x2f2 // Size: 0x02
	int LastVehicleGroundContactMaterialSurfaceType; // Offset: 0x2f4 // Size: 0x04
	struct TMap<int, bool> LastVehicleGearVibrateCache; // Offset: 0x2f8 // Size: 0x50
	struct TMap<enum class EVibrateTriggerEventType, float> LastVibrateEventTimeMap; // Offset: 0x348 // Size: 0x50
	float CurVehicleRaiseSuspensionVibrateCD; // Offset: 0x398 // Size: 0x04
	char pad_0x39C[0x7c]; // Offset: 0x39c // Size: 0x7c
	struct TArray<struct FVibrateEntity> CacheVibrateEntityList; // Offset: 0x418 // Size: 0x10
	char pad_0x428[0x20]; // Offset: 0x428 // Size: 0x20

	// Functions

	// Object Name: Function Client.VibrateSystemManager.StopVibrate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StopVibrate(); // Offset: 0x103a8ca28 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.VibrateSystemManager.SetVibrationLoopTime
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void SetVibrationLoopTime(struct FString InLoopTime); // Offset: 0x103a8c988 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.VibrateSystemManager.PostVibrateTriggerActionDirectly
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void PostVibrateTriggerActionDirectly(int SpesifyID, int Amplitude); // Offset: 0x103a8c8cc // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.VibrateSystemManager.PostVibrateTriggerAction
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void PostVibrateTriggerAction(struct FVibrateTriggerAction& Action, bool bCheckGate, bool bCheckInterval, int SpesifyID); // Offset: 0x103a8c720 // Return & Params: Num(4) Size(0x40)

	// Object Name: Function Client.VibrateSystemManager.PlayVibrateEntity
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void PlayVibrateEntity(struct FVibrateEntity& entity); // Offset: 0x103a8c658 // Return & Params: Num(1) Size(0x48)

	// Object Name: Function Client.VibrateSystemManager.ModifyWeaponVibrationSwitch
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyWeaponVibrationSwitch(bool Val); // Offset: 0x103a8c5cc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyWeaponVibrationLevel
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyWeaponVibrationLevel(int InVal); // Offset: 0x103a8c548 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.VibrateSystemManager.ModifyVehicleVibrationSwitch
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyVehicleVibrationSwitch(bool Val); // Offset: 0x103a8c4bc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyVehicleVibrationLevel
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyVehicleVibrationLevel(int InVal); // Offset: 0x103a8c438 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.VibrateSystemManager.ModifyVehicleSoundUIVibrateSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyVehicleSoundUIVibrateSetting(bool Val); // Offset: 0x103a8c3ac // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyVehicleEngineVibrationSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyVehicleEngineVibrationSetting(bool Val); // Offset: 0x103a8c320 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyVehicleCrashVibrateSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyVehicleCrashVibrateSetting(bool Val); // Offset: 0x103a8c294 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyVehicleBeHitVibrateSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyVehicleBeHitVibrateSetting(bool Val); // Offset: 0x103a8c208 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifySoundUIVibrationSwitch
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifySoundUIVibrationSwitch(bool Val); // Offset: 0x103a8c17c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifySoundUIVibrationLevel
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifySoundUIVibrationLevel(int InVal); // Offset: 0x103a8c0f8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.VibrateSystemManager.ModifySemiAutoWeaponVibrateSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifySemiAutoWeaponVibrateSetting(bool Val); // Offset: 0x103a8c06c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyOtherWeaponVibrateSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyOtherWeaponVibrateSetting(bool Val); // Offset: 0x103a8bfe0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyGlassBrokenSoundUIVibrateSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyGlassBrokenSoundUIVibrateSetting(bool Val); // Offset: 0x103a8bf54 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyFootstepSoundUIVibrateSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyFootstepSoundUIVibrateSetting(bool Val); // Offset: 0x103a8bec8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyFireShotSoundUIVibrateSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyFireShotSoundUIVibrateSetting(bool Val); // Offset: 0x103a8be3c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyEntireVibrationSwitch
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyEntireVibrationSwitch(bool Val); // Offset: 0x103a8bdb0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyEntireVibrationLevel
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ModifyEntireVibrationLevel(int InValue); // Offset: 0x103a8bd34 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.VibrateSystemManager.ModifyCharacterVibrationSwitch
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyCharacterVibrationSwitch(bool Val); // Offset: 0x103a8bca8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyCharacterVibrationLevel
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyCharacterVibrationLevel(int InVal); // Offset: 0x103a8bc24 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.VibrateSystemManager.ModifyCharacterSwimVibrateSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyCharacterSwimVibrateSetting(bool Val); // Offset: 0x103a8bb98 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyCharacterFallVibrateSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyCharacterFallVibrateSetting(bool Val); // Offset: 0x103a8bb0c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyCharacterClimbVibrateSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyCharacterClimbVibrateSetting(bool Val); // Offset: 0x103a8ba80 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyCharacterBeHitVibrateSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyCharacterBeHitVibrateSetting(bool Val); // Offset: 0x103a8b9f4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyBoltWeaponVibrateSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyBoltWeaponVibrateSetting(bool Val); // Offset: 0x103a8b968 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyAutoWeaponVibrateSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyAutoWeaponVibrateSetting(bool Val); // Offset: 0x103a8b8dc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.LoadUserSettingData
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void LoadUserSettingData(int inCharacterVibrationLevel, int inWeaponVibrationLevel, int inVehicleVibrationLevel, int inSoundUIVibrationLevel, bool binCharacterBeHitVibrate, bool binCharacterClimbVibrate, bool binCharacterFallVibrate, bool binCharacterSwimVibrate, bool binVehicleEngineVibrate, bool binVehicleBeHitVibrate, bool binVehicleCrashVibrate, bool binFootstepSoundUIVibrate, bool binFireShotSoundUIVibrate, bool binGlassBrokenSoundUIVibrate, bool binVehicleSoundUIVibrate, int inEntireVibrationLevel, bool binAutoWeaponVibrate, bool binSemiAutoWeaponVibrate, bool binBoltWeaponVibrate, bool binOtherWeaponVibrate); // Offset: 0x103a8b2f0 // Return & Params: Num(20) Size(0x24)

	// Object Name: Function Client.VibrateSystemManager.InvalidateVibrateEntityByEventType
	// Flags: [Final|Native|Public|BlueprintCallable]
	void InvalidateVibrateEntityByEventType(enum class EVibrateTriggerEventType EventType); // Offset: 0x103a8b274 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.InitUserSetting
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void InitUserSetting(); // Offset: 0x103a8b258 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.VibrateSystemManager.InitSystem
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void InitSystem(); // Offset: 0x103a8b23c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.VibrateSystemManager.HandleApplicationWillTerminate
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void HandleApplicationWillTerminate(); // Offset: 0x103a8b220 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.VibrateSystemManager.HandleApplicationWillEnterBackground
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void HandleApplicationWillEnterBackground(); // Offset: 0x103a8b204 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.VibrateSystemManager.HandleApplicationWillDeactivate
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void HandleApplicationWillDeactivate(); // Offset: 0x103a8b1e8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.VibrateSystemManager.HandleApplicationHasReactivated
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void HandleApplicationHasReactivated(); // Offset: 0x103a8b1cc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.VibrateSystemManager.HandleApplicationHasEnteredForeground
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void HandleApplicationHasEnteredForeground(); // Offset: 0x103a8b1b0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.VibrateSystemManager.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UVibrateSystemManager* GetInstance(struct UObject* WorldContext, bool bAutoCreate); // Offset: 0x103a8b0f0 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.VibrateSystemManager.GetEntireVibrationLevel
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetEntireVibrationLevel(); // Offset: 0x103a8b0bc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.VibrateSystemManager.GetCurrentPlayingVibrationDebugInfo
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetCurrentPlayingVibrationDebugInfo(); // Offset: 0x103a8b058 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.VibrateSystemManager.GetAmplitudeByAlpha
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetAmplitudeByAlpha(float Alpha); // Offset: 0x103a8afc4 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.VibrateSystemManager.ClearAllVibration
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void ClearAllVibration(); // Offset: 0x103a8afa8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.VibrateSystemManager.CheckShootWeaponTypeVibrateGate
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	bool CheckShootWeaponTypeVibrateGate(struct ASTExtraWeapon* Weapon); // Offset: 0x103a8af14 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.VibrateSystemManager.CheckAndCopyFilesToSavedDir
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void CheckAndCopyFilesToSavedDir(struct UVibrateSystemManager* Mgr); // Offset: 0x103a8aea0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.VibrateSystemManager.ActiveInGameVibration
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ActiveInGameVibration(bool Inactive); // Offset: 0x103a8ae1c // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class Client.WINSDKFBWebLogin
// Size: 0x130 // Inherited bytes: 0x100
struct UWINSDKFBWebLogin : UWidget {
	// Fields
	struct FScriptMulticastDelegate OnUrlChanged; // Offset: 0x100 // Size: 0x10
	struct FScriptMulticastDelegate OnHttpResponed; // Offset: 0x110 // Size: 0x10
	struct FString InitialURL; // Offset: 0x120 // Size: 0x10

	// Functions

	// Object Name: DelegateFunction Client.WINSDKFBWebLogin.OnWINSDKHttpResponed__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnWINSDKHttpResponed__DelegateSignature(bool requestSucc, struct FString txtContent); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0x18)

	// Object Name: DelegateFunction Client.WINSDKFBWebLogin.OnUrlChanged__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnUrlChanged__DelegateSignature(struct FText& Text); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function Client.WINSDKFBWebLogin.LoadURL
	// Flags: [Final|Native|Public|BlueprintCallable]
	void LoadURL(struct FString NewURL); // Offset: 0x103a8e3f8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.WINSDKFBWebLogin.DoHttpRequest
	// Flags: [Final|Native|Public|BlueprintCallable]
	void DoHttpRequest(struct FString URL); // Offset: 0x103a8e360 // Return & Params: Num(1) Size(0x10)
};

