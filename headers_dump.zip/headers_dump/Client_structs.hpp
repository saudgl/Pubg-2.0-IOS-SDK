#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct Client.CDNDownloaderInfo
// Size: 0x30 // Inherited bytes: 0x00
struct FCDNDownloaderInfo {
	// Fields
	enum class FCDNDownloaderStateEnum State; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString FileSavePath; // Offset: 0x08 // Size: 0x10
	bool Result; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x3]; // Offset: 0x19 // Size: 0x03
	int BytesSent; // Offset: 0x1c // Size: 0x04
	int BytesReceived; // Offset: 0x20 // Size: 0x04
	int ContentType; // Offset: 0x24 // Size: 0x04
	int ResponseCode; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct Client.DownloaderInfo
// Size: 0x40 // Inherited bytes: 0x00
struct FDownloaderInfo {
	// Fields
	enum class FDownloaderStateEnum State; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString FileSavePath; // Offset: 0x08 // Size: 0x10
	bool Result; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x3]; // Offset: 0x19 // Size: 0x03
	int BytesSent; // Offset: 0x1c // Size: 0x04
	int BytesReceived; // Offset: 0x20 // Size: 0x04
	int ContentType; // Offset: 0x24 // Size: 0x04
	int ResponseCode; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct FString StringContent; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct Client.PingServerInfo
// Size: 0x30 // Inherited bytes: 0x00
struct FPingServerInfo {
	// Fields
	char pad_0x0[0x30]; // Offset: 0x00 // Size: 0x30
};

// Object Name: ScriptStruct Client.TimeStamp
// Size: 0x20 // Inherited bytes: 0x00
struct FTimeStamp {
	// Fields
	struct FString Title; // Offset: 0x00 // Size: 0x10
	int Priority; // Offset: 0x10 // Size: 0x04
	int StartTime; // Offset: 0x14 // Size: 0x04
	int EndTime; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct Client.GroupInfoWrapper
// Size: 0x50 // Inherited bytes: 0x00
struct FGroupInfoWrapper {
	// Fields
	int SnsAction; // Offset: 0x00 // Size: 0x04
	int Flag; // Offset: 0x04 // Size: 0x04
	int ErrorCode; // Offset: 0x08 // Size: 0x04
	int PlatForm; // Offset: 0x0c // Size: 0x04
	struct FString Desc; // Offset: 0x10 // Size: 0x10
	struct FWechatGroupInfomation wechatGroupInfo; // Offset: 0x20 // Size: 0x30
};

// Object Name: ScriptStruct Client.WechatGroupInfomation
// Size: 0x30 // Inherited bytes: 0x00
struct FWechatGroupInfomation {
	// Fields
	struct FString OpenIdList; // Offset: 0x00 // Size: 0x10
	struct FString MemberNum; // Offset: 0x10 // Size: 0x10
	struct FString ChatRoomURL; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct Client.PlayerFinishedGuide
// Size: 0x08 // Inherited bytes: 0x00
struct FPlayerFinishedGuide {
	// Fields
	int GuideID; // Offset: 0x00 // Size: 0x04
	int FinishedCounts; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct Client.FightFriendChat
// Size: 0x38 // Inherited bytes: 0x00
struct FFightFriendChat {
	// Fields
	struct FString UId; // Offset: 0x00 // Size: 0x10
	struct FString Name; // Offset: 0x10 // Size: 0x10
	struct FString Msg; // Offset: 0x20 // Size: 0x10
	bool selfMsg; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x7]; // Offset: 0x31 // Size: 0x07
};

// Object Name: ScriptStruct Client.TouchInputRecord
// Size: 0x30 // Inherited bytes: 0x00
struct FTouchInputRecord {
	// Fields
	struct TArray<float> Times; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FVector2D> Positions; // Offset: 0x10 // Size: 0x10
	struct TArray<int> Types; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct Client.MetaDataHolder
// Size: 0x50 // Inherited bytes: 0x00
struct FMetaDataHolder {
	// Fields
	struct TMap<struct FString, struct FString> MetaData; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct Client.PlatformFriendInfoMap
// Size: 0x58 // Inherited bytes: 0x00
struct FPlatformFriendInfoMap {
	// Fields
	int page; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TMap<struct FString, struct FString> friendsInfo; // Offset: 0x08 // Size: 0x50
};

// Object Name: ScriptStruct Client.WakeupInfoWrapper
// Size: 0x50 // Inherited bytes: 0x00
struct FWakeupInfoWrapper {
	// Fields
	char pad_0x0[0x50]; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct Client.WebviewInfoWrapper
// Size: 0x30 // Inherited bytes: 0x00
struct FWebviewInfoWrapper {
	// Fields
	int ErrorCode; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString Reason; // Offset: 0x08 // Size: 0x10
	int extend; // Offset: 0x18 // Size: 0x04
	int Extend2; // Offset: 0x1c // Size: 0x04
	struct FString MsgData; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct Client.ShortURLInfoWrapper
// Size: 0x28 // Inherited bytes: 0x00
struct FShortURLInfoWrapper {
	// Fields
	int ErrorCode; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString Reason; // Offset: 0x08 // Size: 0x10
	struct FString ShortUrl; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct Client.GameMasterInfoWrapper
// Size: 0x18 // Inherited bytes: 0x00
struct FGameMasterInfoWrapper {
	// Fields
	struct FString EventName; // Offset: 0x00 // Size: 0x10
	int Result; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct Client.OnRequestPermissionResultWrapper
// Size: 0x28 // Inherited bytes: 0x00
struct FOnRequestPermissionResultWrapper {
	// Fields
	int code; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString permission; // Offset: 0x08 // Size: 0x10
	struct FString grantResult; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct Client.UAAssistantInfoWrapper
// Size: 0x28 // Inherited bytes: 0x00
struct FUAAssistantInfoWrapper {
	// Fields
	enum class EUnifiedAccountType UAType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int Result; // Offset: 0x04 // Size: 0x04
	struct FString ExtraJson; // Offset: 0x08 // Size: 0x10
	struct FString RetsultMsg; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct Client.SDKCallbackInfoWrapper
// Size: 0x28 // Inherited bytes: 0x00
struct FSDKCallbackInfoWrapper {
	// Fields
	enum class ESDKCallbackType CallbackType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString CallbackParameter; // Offset: 0x08 // Size: 0x10
	struct FString ExtraJson; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct Client.UploadFinishCallbackInfoWrapper
// Size: 0x18 // Inherited bytes: 0x00
struct FUploadFinishCallbackInfoWrapper {
	// Fields
	int Result; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString URL; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct Client.LoadTaskCfg
// Size: 0x18 // Inherited bytes: 0x00
struct FLoadTaskCfg {
	// Fields
	struct FString ObjectPath; // Offset: 0x00 // Size: 0x10
	int LoadPriority; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct Client.BattleGameInfo
// Size: 0x38 // Inherited bytes: 0x00
struct FBattleGameInfo {
	// Fields
	uint64 GameID; // Offset: 0x00 // Size: 0x08
	struct FString GameModeID; // Offset: 0x08 // Size: 0x10
	int GameMapID; // Offset: 0x18 // Size: 0x04
	int WeatherID; // Offset: 0x1c // Size: 0x04
	struct FString WeatherName; // Offset: 0x20 // Size: 0x10
	bool bUsedSimulation; // Offset: 0x30 // Size: 0x01
	bool bEnableClimbing; // Offset: 0x31 // Size: 0x01
	char pad_0x32[0x6]; // Offset: 0x32 // Size: 0x06
};

// Object Name: ScriptStruct Client.VersionConfig
// Size: 0x100 // Inherited bytes: 0x00
struct FVersionConfig {
	// Fields
	char pad_0x0[0x100]; // Offset: 0x00 // Size: 0x100
};

// Object Name: ScriptStruct Client.Version
// Size: 0x90 // Inherited bytes: 0x00
struct FVersion {
	// Fields
	char pad_0x0[0x90]; // Offset: 0x00 // Size: 0x90
};

// Object Name: ScriptStruct Client.PatchConfig
// Size: 0x80 // Inherited bytes: 0x00
struct FPatchConfig {
	// Fields
	char pad_0x0[0x80]; // Offset: 0x00 // Size: 0x80
};

// Object Name: ScriptStruct Client.PatchURL
// Size: 0x28 // Inherited bytes: 0x00
struct FPatchURL {
	// Fields
	char pad_0x0[0x28]; // Offset: 0x00 // Size: 0x28
};

// Object Name: ScriptStruct Client.GetTicketInfoWrapper
// Size: 0x10 // Inherited bytes: 0x00
struct FGetTicketInfoWrapper {
	// Fields
	struct FString Ticket; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct Client.WebviewActionInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FWebviewActionInfo {
	// Fields
	struct FString URL; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct Client.PlatformFriendInfo
// Size: 0x40 // Inherited bytes: 0x00
struct FPlatformFriendInfo {
	// Fields
	struct FString userId; // Offset: 0x00 // Size: 0x10
	struct FString UserName; // Offset: 0x10 // Size: 0x10
	struct FString headportraitURL; // Offset: 0x20 // Size: 0x10
	struct FString OpenID; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct Client.DelayLoadInlineTextImageStyle
// Size: 0xf0 // Inherited bytes: 0x08
struct FDelayLoadInlineTextImageStyle : FSlateWidgetStyle {
	// Fields
	struct FSlateBrush Image; // Offset: 0x08 // Size: 0xb8
	int16_t Baseline; // Offset: 0xc0 // Size: 0x02
	char pad_0xC2[0x2e]; // Offset: 0xc2 // Size: 0x2e
};

// Object Name: ScriptStruct Client.GameWidgetConfig
// Size: 0x30 // Inherited bytes: 0x00
struct FGameWidgetConfig {
	// Fields
	struct FString Path; // Offset: 0x00 // Size: 0x10
	struct FString Container; // Offset: 0x10 // Size: 0x10
	int ZOrder; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
	struct UObject* WidgetClass; // Offset: 0x28 // Size: 0x08
};

// Object Name: ScriptStruct Client.NativeHUDTickContainer
// Size: 0x0c // Inherited bytes: 0x00
struct FNativeHUDTickContainer {
	// Fields
	int WidgetIndex; // Offset: 0x00 // Size: 0x04
	struct TWeakObjectPtr<struct UUAEUserWidget> pWidget; // Offset: 0x04 // Size: 0x08
};

// Object Name: ScriptStruct Client.IMSDKNoticeInfos
// Size: 0x10 // Inherited bytes: 0x00
struct FIMSDKNoticeInfos {
	// Fields
	struct TArray<struct FIMSDKNoticeInfo> Infos; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct Client.IMSDKNoticeInfo
// Size: 0xe0 // Inherited bytes: 0x00
struct FIMSDKNoticeInfo {
	// Fields
	struct FString MsgID; // Offset: 0x00 // Size: 0x10
	struct FString OpenID; // Offset: 0x10 // Size: 0x10
	struct FString MsgUrl; // Offset: 0x20 // Size: 0x10
	enum class EIMSDKNoticeType MsgType; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x7]; // Offset: 0x31 // Size: 0x07
	struct FString MsgScene; // Offset: 0x38 // Size: 0x10
	struct FString StartTime; // Offset: 0x48 // Size: 0x10
	struct FString EndTime; // Offset: 0x58 // Size: 0x10
	enum class EIMSDKContentType MsgContentType; // Offset: 0x68 // Size: 0x01
	char pad_0x69[0x7]; // Offset: 0x69 // Size: 0x07
	struct FString MsgOrder; // Offset: 0x70 // Size: 0x10
	struct FString ContentUrl; // Offset: 0x80 // Size: 0x10
	struct TArray<struct FIMSDKPictureInfomation> PicArray; // Offset: 0x90 // Size: 0x10
	struct FString MsgTitle; // Offset: 0xa0 // Size: 0x10
	struct FString msgContent; // Offset: 0xb0 // Size: 0x10
	struct FString MsgEditCond; // Offset: 0xc0 // Size: 0x10
	struct FString LoginTimes; // Offset: 0xd0 // Size: 0x10
};

// Object Name: ScriptStruct Client.IMSDKPictureInfomation
// Size: 0x38 // Inherited bytes: 0x00
struct FIMSDKPictureInfomation {
	// Fields
	enum class EIMSDKScreenDir PicScreenDir; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString PicPath; // Offset: 0x08 // Size: 0x10
	struct FString HashValue; // Offset: 0x18 // Size: 0x10
	struct FString picTitle; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct Client.NoticeInfos
// Size: 0x10 // Inherited bytes: 0x00
struct FNoticeInfos {
	// Fields
	struct TArray<struct FNoticeInfo> Infos; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct Client.NoticeInfo
// Size: 0xd0 // Inherited bytes: 0x00
struct FNoticeInfo {
	// Fields
	struct FString MsgID; // Offset: 0x00 // Size: 0x10
	struct FString OpenID; // Offset: 0x10 // Size: 0x10
	struct FString MsgUrl; // Offset: 0x20 // Size: 0x10
	enum class ENoticeType MsgType; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x7]; // Offset: 0x31 // Size: 0x07
	struct FString MsgScene; // Offset: 0x38 // Size: 0x10
	struct FString StartTime; // Offset: 0x48 // Size: 0x10
	struct FString EndTime; // Offset: 0x58 // Size: 0x10
	enum class EContentType MsgContentType; // Offset: 0x68 // Size: 0x01
	char pad_0x69[0x7]; // Offset: 0x69 // Size: 0x07
	struct FString MsgOrder; // Offset: 0x70 // Size: 0x10
	struct FString ContentUrl; // Offset: 0x80 // Size: 0x10
	struct TArray<struct FPictureInfomation> PicArray; // Offset: 0x90 // Size: 0x10
	struct FString MsgTitle; // Offset: 0xa0 // Size: 0x10
	struct FString msgContent; // Offset: 0xb0 // Size: 0x10
	struct FString MsgEditCond; // Offset: 0xc0 // Size: 0x10
};

// Object Name: ScriptStruct Client.PictureInfomation
// Size: 0x28 // Inherited bytes: 0x00
struct FPictureInfomation {
	// Fields
	enum class EScreenDir PicScreenDir; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString PicPath; // Offset: 0x08 // Size: 0x10
	struct FString HashValue; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct Client.BatchDownloadPackHashes
// Size: 0x10 // Inherited bytes: 0x00
struct FBatchDownloadPackHashes {
	// Fields
	struct TArray<struct FString> Hashes; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct Client.BatchDownloadPack
// Size: 0x30 // Inherited bytes: 0x00
struct FBatchDownloadPack {
	// Fields
	struct TArray<uint32_t> ItemIDs; // Offset: 0x00 // Size: 0x10
	struct TArray<uint32_t> ErrorCodes; // Offset: 0x10 // Size: 0x10
	char pad_0x20[0x10]; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct Client.PufferDownloadLastTaskStatus
// Size: 0x18 // Inherited bytes: 0x00
struct FPufferDownloadLastTaskStatus {
	// Fields
	struct FDateTime Time; // Offset: 0x00 // Size: 0x08
	char pad_0x8[0x10]; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct Client.PufferObj
// Size: 0x18 // Inherited bytes: 0x00
struct FPufferObj {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x00 // Size: 0x18
};

// Object Name: ScriptStruct Client.PufferDownloadStates
// Size: 0x30 // Inherited bytes: 0x00
struct FPufferDownloadStates {
	// Fields
	struct TArray<double> speeds; // Offset: 0x00 // Size: 0x10
	struct FString Filename; // Offset: 0x10 // Size: 0x10
	char pad_0x20[0x10]; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct Client.DynamicWidgetAsyncLoadData
// Size: 0xb8 // Inherited bytes: 0x00
struct FDynamicWidgetAsyncLoadData {
	// Fields
	struct FString WidgetKey; // Offset: 0x00 // Size: 0x10
	struct FDynamicWidgetData DynamicWidgetData; // Offset: 0x10 // Size: 0x98
	DelegateProperty Callback; // Offset: 0xa8 // Size: 0x10
};

// Object Name: ScriptStruct Client.DynamicWidgetData
// Size: 0x98 // Inherited bytes: 0x00
struct FDynamicWidgetData {
	// Fields
	bool bAutoDestory; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString MountModule; // Offset: 0x08 // Size: 0x10
	struct FInGameWidgetData InGameWidgetData; // Offset: 0x18 // Size: 0x80
};

// Object Name: ScriptStruct Client.InGameWidgetData
// Size: 0x80 // Inherited bytes: 0x00
struct FInGameWidgetData {
	// Fields
	int bAutoShow; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FGameWidgetConfig GameWidgetConfig; // Offset: 0x08 // Size: 0x30
	struct FWidgetMountData WidgetMountData; // Offset: 0x38 // Size: 0x48
};

// Object Name: ScriptStruct Client.WidgetMountData
// Size: 0x48 // Inherited bytes: 0x00
struct FWidgetMountData {
	// Fields
	struct FMargin MarginData; // Offset: 0x00 // Size: 0x10
	struct FAnchors AnchorsData; // Offset: 0x10 // Size: 0x10
	struct FVector2D Position; // Offset: 0x20 // Size: 0x08
	struct FString MountName; // Offset: 0x28 // Size: 0x10
	struct FString MountOuterName; // Offset: 0x38 // Size: 0x10
};

// Object Name: ScriptStruct Client.UEComplianceResult
// Size: 0xa8 // Inherited bytes: 0x00
struct FUEComplianceResult {
	// Fields
	int AdultStatus; // Offset: 0x00 // Size: 0x04
	int ParentCertificateStatus; // Offset: 0x04 // Size: 0x04
	int EUUserAgreeStatus; // Offset: 0x08 // Size: 0x04
	int AdultAge; // Offset: 0x0c // Size: 0x04
	int GameGrade; // Offset: 0x10 // Size: 0x04
	int CertificateType; // Offset: 0x14 // Size: 0x04
	bool IsEEA; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x3]; // Offset: 0x19 // Size: 0x03
	int MethodId; // Offset: 0x1c // Size: 0x04
	int RetCode; // Offset: 0x20 // Size: 0x04
	int ThirdCode; // Offset: 0x24 // Size: 0x04
	struct FString ThirdMsg; // Offset: 0x28 // Size: 0x10
	struct FString ParentCertificateStatusExpiration; // Offset: 0x38 // Size: 0x10
	struct FString CountryCode; // Offset: 0x48 // Size: 0x10
	struct FString AdultStatusExpiration; // Offset: 0x58 // Size: 0x10
	struct FString TS; // Offset: 0x68 // Size: 0x10
	struct FString Region; // Offset: 0x78 // Size: 0x10
	struct FString retMsg; // Offset: 0x88 // Size: 0x10
	struct FString ExtraJson; // Offset: 0x98 // Size: 0x10
};

// Object Name: ScriptStruct Client.ArrayLuaBPVar
// Size: 0x20 // Inherited bytes: 0x00
struct FArrayLuaBPVar {
	// Fields
	char pad_0x0[0x20]; // Offset: 0x00 // Size: 0x20
};

// Object Name: ScriptStruct Client.MapLuaBPVar
// Size: 0x20 // Inherited bytes: 0x00
struct FMapLuaBPVar {
	// Fields
	char pad_0x0[0x20]; // Offset: 0x00 // Size: 0x20
};

// Object Name: ScriptStruct Client.LuaBPVar
// Size: 0x20 // Inherited bytes: 0x00
struct FLuaBPVar {
	// Fields
	char pad_0x0[0x20]; // Offset: 0x00 // Size: 0x20
};

// Object Name: ScriptStruct Client.MidasPack
// Size: 0x58 // Inherited bytes: 0x00
struct FMidasPack {
	// Fields
	char pad_0x0[0x58]; // Offset: 0x00 // Size: 0x58
};

// Object Name: ScriptStruct Client.LobbyTeamState
// Size: 0x08 // Inherited bytes: 0x00
struct FLobbyTeamState {
	// Fields
	int UId; // Offset: 0x00 // Size: 0x04
	int team_state; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct Client.SDKCallbackWrapper
// Size: 0x28 // Inherited bytes: 0x00
struct FSDKCallbackWrapper {
	// Fields
	enum class ESDKCallbackMethodId MethodId; // Offset: 0x00 // Size: 0x02
	char pad_0x2[0x6]; // Offset: 0x02 // Size: 0x06
	struct FString RetJson; // Offset: 0x08 // Size: 0x10
	struct FString ExtraJson; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct Client.CustomSettingSaveGame
// Size: 0x18 // Inherited bytes: 0x00
struct FCustomSettingSaveGame {
	// Fields
	struct FString LayoutSlotName; // Offset: 0x00 // Size: 0x10
	struct USaveGame* SaveGame; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct Client.AssetAsyncRequest
// Size: 0x20 // Inherited bytes: 0x00
struct FAssetAsyncRequest {
	// Fields
	struct FString Path; // Offset: 0x00 // Size: 0x10
	DelegateProperty Callback; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct Client.VibrateEntity
// Size: 0x48 // Inherited bytes: 0x00
struct FVibrateEntity {
	// Fields
	int AssetId; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString AssetAbsPath; // Offset: 0x08 // Size: 0x10
	int PlayAmplitude; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct FString PlayKeyParam; // Offset: 0x20 // Size: 0x10
	int PlayPriority; // Offset: 0x30 // Size: 0x04
	float PlayDuration; // Offset: 0x34 // Size: 0x04
	bool bIsLoop; // Offset: 0x38 // Size: 0x01
	bool bIsValid; // Offset: 0x39 // Size: 0x01
	char pad_0x3A[0x2]; // Offset: 0x3a // Size: 0x02
	float PushTime; // Offset: 0x3c // Size: 0x04
	enum class EVibrateTriggerEventType EventType; // Offset: 0x40 // Size: 0x01
	char pad_0x41[0x7]; // Offset: 0x41 // Size: 0x07
};

// Object Name: ScriptStruct Client.VibrateTriggerAction
// Size: 0x38 // Inherited bytes: 0x00
struct FVibrateTriggerAction {
	// Fields
	int VibrateAmplitude; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FVibrateTriggerMainItem TriggerMainItem; // Offset: 0x08 // Size: 0x18
	struct TArray<struct FVibrateTriggerSubItem> TriggerSubItemList; // Offset: 0x20 // Size: 0x10
	enum class EVibrateTriggerEventType TriggerEventType; // Offset: 0x30 // Size: 0x01
	enum class EVibrateTriggerActionType TriggerActionType; // Offset: 0x31 // Size: 0x01
	char pad_0x32[0x6]; // Offset: 0x32 // Size: 0x06
};

// Object Name: ScriptStruct Client.VibrateTriggerSubItem
// Size: 0x18 // Inherited bytes: 0x00
struct FVibrateTriggerSubItem {
	// Fields
	enum class EVibrateTriggerSubItemType SubItemType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString Data; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct Client.VibrateTriggerMainItem
// Size: 0x18 // Inherited bytes: 0x00
struct FVibrateTriggerMainItem {
	// Fields
	enum class EVibrateTriggerMainItemType MainItemType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString Data; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct Client.VibrateAssetItemConfig
// Size: 0x80 // Inherited bytes: 0x00
struct FVibrateAssetItemConfig {
	// Fields
	int AssetId; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FVibrateTriggerCondition TriggerCondition; // Offset: 0x08 // Size: 0x38
	struct FString AssetPath; // Offset: 0x40 // Size: 0x10
	struct FString PlayKeyParam; // Offset: 0x50 // Size: 0x10
	float AutoStopTime; // Offset: 0x60 // Size: 0x04
	int PlayPriority; // Offset: 0x64 // Size: 0x04
	float PlayDuration; // Offset: 0x68 // Size: 0x04
	char pad_0x6C[0x4]; // Offset: 0x6c // Size: 0x04
	struct FString AbsPath; // Offset: 0x70 // Size: 0x10
};

// Object Name: ScriptStruct Client.VibrateTriggerCondition
// Size: 0x38 // Inherited bytes: 0x00
struct FVibrateTriggerCondition {
	// Fields
	bool bOnlyMatchMainItemType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FVibrateTriggerMainItem TriggerMainItem; // Offset: 0x08 // Size: 0x18
	struct TArray<struct FVibrateTriggerSubItem> TriggerSubItemList; // Offset: 0x20 // Size: 0x10
	enum class EVibrateTriggerEventType TriggerEventType; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x7]; // Offset: 0x31 // Size: 0x07
};

