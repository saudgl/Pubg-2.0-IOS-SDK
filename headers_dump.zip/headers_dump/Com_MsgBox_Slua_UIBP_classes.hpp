#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Com_MsgBox_Slua_UIBP.Com_MsgBox_Slua_UIBP_C
// Size: 0x2e8 // Inherited bytes: 0x218
struct UCom_MsgBox_Slua_UIBP_C : UUserWidget {
	// Fields
	struct UWidgetAnimation* Anim_Enter; // Offset: 0x218 // Size: 0x08
	struct UButton* Button_Cancel; // Offset: 0x220 // Size: 0x08
	struct UButton* Button_Close; // Offset: 0x228 // Size: 0x08
	struct UButton* Button_OK; // Offset: 0x230 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_CD; // Offset: 0x238 // Size: 0x08
	struct UCheckBox* CheckBox_Option; // Offset: 0x240 // Size: 0x08
	struct UTextBlock* CheckBox_OptionText; // Offset: 0x248 // Size: 0x08
	struct UCommon_BackgroundBlur_C* Common_BackgroundBlur; // Offset: 0x250 // Size: 0x08
	struct UCommon_UIPopupBG_C* Common_UIPopupBG; // Offset: 0x258 // Size: 0x08
	struct UHorizontalBox* dingyue_tips; // Offset: 0x260 // Size: 0x08
	struct UHorizontalBox* HBox_Button; // Offset: 0x268 // Size: 0x08
	struct UCanvasPanel* HorizontalBox_URL; // Offset: 0x270 // Size: 0x08
	struct UImage* Image_3; // Offset: 0x278 // Size: 0x08
	struct UImage* Image_6; // Offset: 0x280 // Size: 0x08
	struct UImage* Image_107; // Offset: 0x288 // Size: 0x08
	struct UImage* Image_OKBg; // Offset: 0x290 // Size: 0x08
	struct UUTRichTextBlock* RichText_Content; // Offset: 0x298 // Size: 0x08
	struct UUTRichTextBlock* RichText_ContentMidas; // Offset: 0x2a0 // Size: 0x08
	struct UUTRichTextBlock* RichText_UrlTips; // Offset: 0x2a8 // Size: 0x08
	struct UScrollBox* ScrollBox_1; // Offset: 0x2b0 // Size: 0x08
	struct UScrollBox* ScrollBox_Msg; // Offset: 0x2b8 // Size: 0x08
	struct UTextBlock* Text_cancel; // Offset: 0x2c0 // Size: 0x08
	struct UTextBlock* Text_ok; // Offset: 0x2c8 // Size: 0x08
	struct UTextBlock* Text_Title; // Offset: 0x2d0 // Size: 0x08
	struct UTextBlock* TextBlock_CD; // Offset: 0x2d8 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_Font; // Offset: 0x2e0 // Size: 0x08

	// Functions

	// Object Name: Function Com_MsgBox_Slua_UIBP.Com_MsgBox_Slua_UIBP_C.SetButtonOkState
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetButtonOkState(bool bInIsEnabled); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x1)
};

