#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass CommonLoadingUI.CommonLoadingUI_C
// Size: 0x220 // Inherited bytes: 0x218
struct UCommonLoadingUI_C : UUserWidget {
	// Fields
	struct UImage* Image_mask_bg; // Offset: 0x218 // Size: 0x08
};

