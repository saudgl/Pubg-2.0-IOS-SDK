#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Common_BackgroundBlur.Common_BackgroundBlur_C
// Size: 0x3e0 // Inherited bytes: 0x3d0
struct UCommon_BackgroundBlur_C : UUAEUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x3d0 // Size: 0x08
	struct UBackgroundBlur* BlurComponent; // Offset: 0x3d8 // Size: 0x08

	// Functions

	// Object Name: Function Common_BackgroundBlur.Common_BackgroundBlur_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Common_BackgroundBlur.Common_BackgroundBlur_C.ExecuteUbergraph_Common_BackgroundBlur
	// Flags: [None]
	void ExecuteUbergraph_Common_BackgroundBlur(int EntryPoint); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x4)
};

