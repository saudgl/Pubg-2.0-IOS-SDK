#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Common_DragDrop_Item.Common_DragDrop_Item_C
// Size: 0x369 // Inherited bytes: 0x218
struct UCommon_DragDrop_Item_C : UUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x218 // Size: 0x08
	int dragStyle; // Offset: 0x220 // Size: 0x04
	int SLOT_COMMON_ITEM; // Offset: 0x224 // Size: 0x04
	int SLOT_EMOJI_ITEM; // Offset: 0x228 // Size: 0x04
	int dragItem; // Offset: 0x22c // Size: 0x04
	int dragInst; // Offset: 0x230 // Size: 0x04
	char pad_0x234[0x4]; // Offset: 0x234 // Size: 0x04
	struct FString dragExtendData; // Offset: 0x238 // Size: 0x10
	struct FScriptMulticastDelegate OnDragStarted; // Offset: 0x248 // Size: 0x10
	struct FScriptMulticastDelegate OnDragCanceled; // Offset: 0x258 // Size: 0x10
	struct UCommon_DragDrop_Data_C* dragOperation; // Offset: 0x268 // Size: 0x08
	struct FScriptMulticastDelegate OnDragReadyToShape; // Offset: 0x270 // Size: 0x10
	bool isTouching; // Offset: 0x280 // Size: 0x01
	char pad_0x281[0x7]; // Offset: 0x281 // Size: 0x07
	struct FScriptMulticastDelegate OnDragClicked; // Offset: 0x288 // Size: 0x10
	struct UUserWidget* dragDropWidget; // Offset: 0x298 // Size: 0x08
	struct TArray<int> acceptableDragType; // Offset: 0x2a0 // Size: 0x10
	struct FScriptMulticastDelegate OnDragSuccess; // Offset: 0x2b0 // Size: 0x10
	bool dragEnable; // Offset: 0x2c0 // Size: 0x01
	bool dropEnable; // Offset: 0x2c1 // Size: 0x01
	char pad_0x2C2[0x6]; // Offset: 0x2c2 // Size: 0x06
	struct FScriptMulticastDelegate OnItemTouchStarted; // Offset: 0x2c8 // Size: 0x10
	struct FScriptMulticastDelegate OnItemTouchEnded; // Offset: 0x2d8 // Size: 0x10
	struct FVector2D touchPos; // Offset: 0x2e8 // Size: 0x08
	struct TMap<int, struct UUserWidget*> dragDropItemMap; // Offset: 0x2f0 // Size: 0x50
	bool NewVar_1; // Offset: 0x340 // Size: 0x01
	char pad_0x341[0x7]; // Offset: 0x341 // Size: 0x07
	struct FString DragPath; // Offset: 0x348 // Size: 0x10
	struct FScriptMulticastDelegate OnItemTouchMoved; // Offset: 0x358 // Size: 0x10
	bool allDirectionEnable; // Offset: 0x368 // Size: 0x01

	// Functions

	// Object Name: Function Common_DragDrop_Item.Common_DragDrop_Item_C.SetAllDirectionEnable
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetAllDirectionEnable(bool Enable); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Common_DragDrop_Item.Common_DragDrop_Item_C.RegisterDragWithDragPath
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void RegisterDragWithDragPath(int Style, int ItemId, int InstID, struct FString ExtraData, struct FString extraPath); // Offset: 0x103e7af64 // Return & Params: Num(5) Size(0x30)

	// Object Name: Function Common_DragDrop_Item.Common_DragDrop_Item_C.CreateWidgetByDragDropType
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void CreateWidgetByDragDropType(int Type, struct UUserWidget*& Output); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Common_DragDrop_Item.Common_DragDrop_Item_C.GetDragDropWidget
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetDragDropWidget(int dragDropType, struct UUserWidget*& Output); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Common_DragDrop_Item.Common_DragDrop_Item_C.OnTouchMoved
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	struct FEventReply OnTouchMoved(struct FGeometry MyGeometry, struct FPointerEvent& InTouchEvent); // Offset: 0x103e7af64 // Return & Params: Num(3) Size(0x168)

	// Object Name: Function Common_DragDrop_Item.Common_DragDrop_Item_C.SetDropEnable
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetDropEnable(bool Enable); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Common_DragDrop_Item.Common_DragDrop_Item_C.SetDragEnable
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetDragEnable(bool Enable); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Common_DragDrop_Item.Common_DragDrop_Item_C.SetEnable
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetEnable(bool Enable); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Common_DragDrop_Item.Common_DragDrop_Item_C.UnRegisterDrop
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void UnRegisterDrop(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Common_DragDrop_Item.Common_DragDrop_Item_C.RegisterDrop
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	bool RegisterDrop(int dragType); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Common_DragDrop_Item.Common_DragDrop_Item_C.OnDrop
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	bool OnDrop(struct FGeometry MyGeometry, struct FPointerEvent PointerEvent, struct UDragDropOperation* Operation); // Offset: 0x103e7af64 // Return & Params: Num(4) Size(0xb9)

	// Object Name: Function Common_DragDrop_Item.Common_DragDrop_Item_C.OnTouchEnded
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	struct FEventReply OnTouchEnded(struct FGeometry MyGeometry, struct FPointerEvent& InTouchEvent); // Offset: 0x103e7af64 // Return & Params: Num(3) Size(0x168)

	// Object Name: Function Common_DragDrop_Item.Common_DragDrop_Item_C.OnTouchStarted
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	struct FEventReply OnTouchStarted(struct FGeometry MyGeometry, struct FPointerEvent& InTouchEvent); // Offset: 0x103e7af64 // Return & Params: Num(3) Size(0x168)

	// Object Name: Function Common_DragDrop_Item.Common_DragDrop_Item_C.GetDefaultTexture
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void GetDefaultTexture(struct UTexture2D*& Texture); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Common_DragDrop_Item.Common_DragDrop_Item_C.RegisterDrag
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void RegisterDrag(int Style, int ItemId, int InstID, struct FString ExtraData); // Offset: 0x103e7af64 // Return & Params: Num(4) Size(0x20)

	// Object Name: Function Common_DragDrop_Item.Common_DragDrop_Item_C.OnDragDetected
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void OnDragDetected(struct FGeometry MyGeometry, struct FPointerEvent& PointerEvent, struct UDragDropOperation*& Operation); // Offset: 0x103e7af64 // Return & Params: Num(3) Size(0xb8)

	// Object Name: Function Common_DragDrop_Item.Common_DragDrop_Item_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Common_DragDrop_Item.Common_DragDrop_Item_C.OnDragCancelled
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	void OnDragCancelled(struct FPointerEvent& PointerEvent, struct UDragDropOperation* Operation); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0x80)

	// Object Name: Function Common_DragDrop_Item.Common_DragDrop_Item_C.ForceStartDrag
	// Flags: [BlueprintCallable|BlueprintEvent]
	void ForceStartDrag(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Common_DragDrop_Item.Common_DragDrop_Item_C.OnMouseLeave
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	void OnMouseLeave(struct FPointerEvent& MouseEvent); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x78)

	// Object Name: Function Common_DragDrop_Item.Common_DragDrop_Item_C.ExecuteUbergraph_Common_DragDrop_Item
	// Flags: [HasDefaults]
	void ExecuteUbergraph_Common_DragDrop_Item(int EntryPoint); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Common_DragDrop_Item.Common_DragDrop_Item_C.OnItemTouchMoved__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnItemTouchMoved__DelegateSignature(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Common_DragDrop_Item.Common_DragDrop_Item_C.OnItemTouchEnded__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnItemTouchEnded__DelegateSignature(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Common_DragDrop_Item.Common_DragDrop_Item_C.OnItemTouchStarted__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnItemTouchStarted__DelegateSignature(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Common_DragDrop_Item.Common_DragDrop_Item_C.OnDragSuccess__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnDragSuccess__DelegateSignature(struct UCommon_DragDrop_Data_C* Operation); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Common_DragDrop_Item.Common_DragDrop_Item_C.OnDragClicked__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnDragClicked__DelegateSignature(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Common_DragDrop_Item.Common_DragDrop_Item_C.OnDragReadyToShape__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnDragReadyToShape__DelegateSignature(struct UWidget* generatedWidget, struct UCommon_DragDrop_Data_C* dragOperation); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Common_DragDrop_Item.Common_DragDrop_Item_C.OnDragCanceled__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnDragCanceled__DelegateSignature(struct UCommon_DragDrop_Data_C* Operation); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Common_DragDrop_Item.Common_DragDrop_Item_C.OnDragStarted__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnDragStarted__DelegateSignature(struct UCommon_DragDrop_Data_C* Operation); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x8)
};

