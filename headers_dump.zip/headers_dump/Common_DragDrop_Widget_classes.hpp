#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Common_DragDrop_Widget.Common_DragDrop_Widget_C
// Size: 0x228 // Inherited bytes: 0x218
struct UCommon_DragDrop_Widget_C : UUserWidget {
	// Fields
	struct UImage* DefaultTexture; // Offset: 0x218 // Size: 0x08
	struct UImage* Frame; // Offset: 0x220 // Size: 0x08
};

