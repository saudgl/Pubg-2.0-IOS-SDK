#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Common_Tips_NoArrow_UIBP.Common_Tips_NoArrow_UIBP_C
// Size: 0x220 // Inherited bytes: 0x218
struct UCommon_Tips_NoArrow_UIBP_C : UUserWidget {
	// Fields
	struct UTextBlock* Text; // Offset: 0x218 // Size: 0x08
};

