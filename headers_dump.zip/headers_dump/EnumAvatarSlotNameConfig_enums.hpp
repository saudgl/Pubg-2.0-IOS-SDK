#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedEnum EnumAvatarSlotNameConfig.EnumAvatarSlotNameConfig
enum class EnumAvatarSlotNameConfig : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	NewEnumerator4 = 3,
	NewEnumerator3 = 4,
	NewEnumerator5 = 5,
	NewEnumerator6 = 6,
	NewEnumerator7 = 7,
	EnumAvatarSlotNameConfig_MAX = 8
};

