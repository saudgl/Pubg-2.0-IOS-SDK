#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class GEM.FpsReportActor
// Size: 0x3c8 // Inherited bytes: 0x3c8
struct AFpsReportActor : AActor {
};

