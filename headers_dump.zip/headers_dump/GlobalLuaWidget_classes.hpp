#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass GlobalLuaWidget.GlobalLuaWidget_C
// Size: 0x288 // Inherited bytes: 0x288
struct UGlobalLuaWidget_C : ULuaUserWidget {
	// Functions

	// Object Name: Function GlobalLuaWidget.GlobalLuaWidget_C.GetNewLevelTaskData
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetNewLevelTaskData(struct FString TaskId, bool& Has, struct FBP_STRUCT_NewLevelTask_type& BP_STRUCT_NewLevelTask_type); // Offset: 0x103e7af64 // Return & Params: Num(3) Size(0xa0)
};

