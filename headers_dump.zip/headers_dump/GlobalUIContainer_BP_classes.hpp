#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass GlobalUIContainer_BP.GlobalUIContainer_BP_C
// Size: 0x3f0 // Inherited bytes: 0x3e0
struct UGlobalUIContainer_BP_C : UUAEWidgetContainer {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x3e0 // Size: 0x08
	struct UCanvasPanel* CanvasContainer; // Offset: 0x3e8 // Size: 0x08

	// Functions

	// Object Name: Function GlobalUIContainer_BP.GlobalUIContainer_BP_C.AddWidgetInternal
	// Flags: [Event|Protected|BlueprintEvent]
	void AddWidgetInternal(struct UUserWidget* Widget); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GlobalUIContainer_BP.GlobalUIContainer_BP_C.RemoveWidgetInternal
	// Flags: [Event|Protected|BlueprintEvent]
	void RemoveWidgetInternal(struct UUserWidget* Widget); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GlobalUIContainer_BP.GlobalUIContainer_BP_C.AddWidgetWithZOrderInternal
	// Flags: [Event|Protected|BlueprintEvent]
	void AddWidgetWithZOrderInternal(struct UUserWidget* Widget, int ZOrder); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function GlobalUIContainer_BP.GlobalUIContainer_BP_C.ExecuteUbergraph_GlobalUIContainer_BP
	// Flags: [HasDefaults]
	void ExecuteUbergraph_GlobalUIContainer_BP(int EntryPoint); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x4)
};

