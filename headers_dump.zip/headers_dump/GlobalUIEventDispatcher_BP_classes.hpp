#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass GlobalUIEventDispatcher_BP.GlobalUIEventDispatcher_BP_C
// Size: 0x38 // Inherited bytes: 0x28
struct UGlobalUIEventDispatcher_BP_C : UObject {
	// Fields
	struct FScriptMulticastDelegate WardrobePutDownEvent; // Offset: 0x28 // Size: 0x10

	// Functions

	// Object Name: Function GlobalUIEventDispatcher_BP.GlobalUIEventDispatcher_BP_C.WardrobePutDownEvent__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void WardrobePutDownEvent__DelegateSignature(int PutonID, int resID); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0x8)
};

