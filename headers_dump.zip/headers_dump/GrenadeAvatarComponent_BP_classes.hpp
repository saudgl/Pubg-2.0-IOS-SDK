#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass GrenadeAvatarComponent_BP.GrenadeAvatarComponent_BP_C
// Size: 0x558 // Inherited bytes: 0x488
struct UGrenadeAvatarComponent_BP_C : UGrenadeAvatarComponent {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x488 // Size: 0x08
	struct UParticleSystem* ExplodeEffect; // Offset: 0x490 // Size: 0x28
	struct UAkAudioEvent* ExplodeSound; // Offset: 0x4b8 // Size: 0x28
	struct UAkAudioEvent* GrenadeFuzeAkSoundEvent; // Offset: 0x4e0 // Size: 0x28
	struct UAkAudioEvent* GrenadeThrowAkSoundEvent; // Offset: 0x508 // Size: 0x28
	struct UAkAudioEvent* GrenadeWallCollideAkSoundEvent; // Offset: 0x530 // Size: 0x28

	// Functions

	// Object Name: Function GrenadeAvatarComponent_BP.GrenadeAvatarComponent_BP_C.GetDefaultAvatarID
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	int GetDefaultAvatarID(int InAvatarID); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function GrenadeAvatarComponent_BP.GrenadeAvatarComponent_BP_C.GetItemAvatarHandlePath
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetItemAvatarHandlePath(int ItemId); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function GrenadeAvatarComponent_BP.GrenadeAvatarComponent_BP_C.GetItemAvatarHandle
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	struct UBackpackCommonAvatarHandle* GetItemAvatarHandle(int ItemId); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function GrenadeAvatarComponent_BP.GrenadeAvatarComponent_BP_C.GrenadeAvatarEquiped
	// Flags: [BlueprintCallable|BlueprintEvent]
	void GrenadeAvatarEquiped(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GrenadeAvatarComponent_BP.GrenadeAvatarComponent_BP_C.ReceiveBeginPlay
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveBeginPlay(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GrenadeAvatarComponent_BP.GrenadeAvatarComponent_BP_C.ExecuteUbergraph_GrenadeAvatarComponent_BP
	// Flags: [None]
	void ExecuteUbergraph_GrenadeAvatarComponent_BP(int EntryPoint); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x4)
};

