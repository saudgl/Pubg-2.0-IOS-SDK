#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Lobby20_Mode_UIBP.Lobby20_Mode_UIBP_C
// Size: 0x280 // Inherited bytes: 0x218
struct ULobby20_Mode_UIBP_C : UUserWidget {
	// Fields
	struct UButton* Button_Item; // Offset: 0x218 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_8; // Offset: 0x220 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_9; // Offset: 0x228 // Size: 0x08
	struct UImage* Image_3; // Offset: 0x230 // Size: 0x08
	struct UImage* Image_5; // Offset: 0x238 // Size: 0x08
	struct UImage* Image_10; // Offset: 0x240 // Size: 0x08
	struct UImage* Image_Mode_Icon; // Offset: 0x248 // Size: 0x08
	struct UImage* Image_Mode_PlayerCnt; // Offset: 0x250 // Size: 0x08
	struct UImage* Image_New; // Offset: 0x258 // Size: 0x08
	struct UTextBlock* Text_MapName; // Offset: 0x260 // Size: 0x08
	struct UTextBlock* Text_ModelName; // Offset: 0x268 // Size: 0x08
	struct UTextBlock* Text_PerspectiveType; // Offset: 0x270 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_ModeType; // Offset: 0x278 // Size: 0x08
};

