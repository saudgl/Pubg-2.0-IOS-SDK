#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Lobby20_Tab_Item_UIBP.Lobby20_Tab_Item_UIBP_C
// Size: 0x260 // Inherited bytes: 0x218
struct ULobby20_Tab_Item_UIBP_C : UUserWidget {
	// Fields
	struct UWidgetAnimation* Anim_Shake; // Offset: 0x218 // Size: 0x08
	struct UButton* Button_1; // Offset: 0x220 // Size: 0x08
	struct UImage* Image_5; // Offset: 0x228 // Size: 0x08
	struct UImage* Image_RedDot; // Offset: 0x230 // Size: 0x08
	struct UCanvasPanel* Panel_Download; // Offset: 0x238 // Size: 0x08
	struct UReddot_Anchor_C* Reddot_Anchor; // Offset: 0x240 // Size: 0x08
	struct USizeBox* SizeBox_6; // Offset: 0x248 // Size: 0x08
	struct UTextBlock* TextBlock_1; // Offset: 0x250 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_Handbook; // Offset: 0x258 // Size: 0x08
};

