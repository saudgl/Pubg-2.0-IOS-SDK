#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass LobbyHallVehicleBP.LobbyHallVehicleBP_C
// Size: 0x730 // Inherited bytes: 0x730
struct ALobbyHallVehicleBP_C : ALobbyModelShowActorBP_C {
};

