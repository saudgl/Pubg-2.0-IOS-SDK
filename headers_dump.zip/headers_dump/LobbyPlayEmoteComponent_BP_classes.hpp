#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass LobbyPlayEmoteComponent_BP.LobbyPlayEmoteComponent_BP_C
// Size: 0x410 // Inherited bytes: 0x3a0
struct ULobbyPlayEmoteComponent_BP_C : ULobbyPlayEmoteComponent {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x3a0 // Size: 0x08
	struct ULevelSequencePlayer* LevelSequencePlayer; // Offset: 0x3a8 // Size: 0x08
	struct ALevelSequenceActor* LevelSequenceActor; // Offset: 0x3b0 // Size: 0x08
	struct UBP_LevelSequenceCameraMask_C* levelSequenceMask; // Offset: 0x3b8 // Size: 0x08
	struct TSet<int> stopEmoteArray; // Offset: 0x3c0 // Size: 0x50

	// Functions

	// Object Name: Function LobbyPlayEmoteComponent_BP.LobbyPlayEmoteComponent_BP_C.OnEquipmentChange
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnEquipmentChange(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LobbyPlayEmoteComponent_BP.LobbyPlayEmoteComponent_BP_C.OnStartLevelSequence
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnStartLevelSequence(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LobbyPlayEmoteComponent_BP.LobbyPlayEmoteComponent_BP_C.GetLobbyCamera
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetLobbyCamera(struct ACameraActor*& CameraActor); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function LobbyPlayEmoteComponent_BP.LobbyPlayEmoteComponent_BP_C.OnStopLevelSequence
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnStopLevelSequence(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LobbyPlayEmoteComponent_BP.LobbyPlayEmoteComponent_BP_C.ChangetoLevelSequenceCamera
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ChangetoLevelSequenceCamera(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LobbyPlayEmoteComponent_BP.LobbyPlayEmoteComponent_BP_C.OnTrackEvent
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnTrackEvent(struct FString EventData); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LobbyPlayEmoteComponent_BP.LobbyPlayEmoteComponent_BP_C.PlayCameraEmoteAnim
	// Flags: [Event|Public|BlueprintEvent]
	void PlayCameraEmoteAnim(struct ULevelSequence* CurrentCameraEmoteAnim); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function LobbyPlayEmoteComponent_BP.LobbyPlayEmoteComponent_BP_C.StopCameraEmoteAnim
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void StopCameraEmoteAnim(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LobbyPlayEmoteComponent_BP.LobbyPlayEmoteComponent_BP_C.ShowAvatarForEmote
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void ShowAvatarForEmote(bool Show, bool force); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function LobbyPlayEmoteComponent_BP.LobbyPlayEmoteComponent_BP_C.ExecuteUbergraph_LobbyPlayEmoteComponent_BP
	// Flags: [None]
	void ExecuteUbergraph_LobbyPlayEmoteComponent_BP(int EntryPoint); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x4)
};

