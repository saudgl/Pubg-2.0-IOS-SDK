#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass LobbyWeaponAnimList_Rifle.LobbyWeaponAnimList_Rifle_C
// Size: 0x270 // Inherited bytes: 0x270
struct ULobbyWeaponAnimList_Rifle_C : UAELobbyCharAnimListComp {
};

