#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass LobbyWeaponAnimationComponent.LobbyWeaponAnimationComponent_C
// Size: 0x121 // Inherited bytes: 0x110
struct ULobbyWeaponAnimationComponent_C : UActorComponent {
	// Fields
	struct ABP_PlayerLobbyPawn_C* LobbyPlayer; // Offset: 0x110 // Size: 0x08
	struct ALobbyWeaponAnimationActor_C* WeaponAnimationActor; // Offset: 0x118 // Size: 0x08
	bool IsEnable; // Offset: 0x120 // Size: 0x01

	// Functions

	// Object Name: Function LobbyWeaponAnimationComponent.LobbyWeaponAnimationComponent_C.SyncMontage
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SyncMontage(float Position); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LobbyWeaponAnimationComponent.LobbyWeaponAnimationComponent_C.StopLobbyWeaponAnimation
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void StopLobbyWeaponAnimation(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LobbyWeaponAnimationComponent.LobbyWeaponAnimationComponent_C.PlayOnAction
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void PlayOnAction(int ActionID, bool isMVPMotion); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function LobbyWeaponAnimationComponent.LobbyWeaponAnimationComponent_C.PlayLobbyWeaponAnimationByID
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void PlayLobbyWeaponAnimationByID(int WeaponAnimationID, bool isMVPMotion); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function LobbyWeaponAnimationComponent.LobbyWeaponAnimationComponent_C.Destroy
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void Destroy(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LobbyWeaponAnimationComponent.LobbyWeaponAnimationComponent_C.SetLobbyPlayerObj
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetLobbyPlayerObj(struct ABP_PlayerLobbyPawn_C* LobbyPlayerObj); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x8)
};

