#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Lobby_Control_Comp.Lobby_Control_Comp_C
// Size: 0x2a8 // Inherited bytes: 0x218
struct ULobby_Control_Comp_C : UUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x218 // Size: 0x08
	struct UNamedSlot* NamedSlot_1; // Offset: 0x220 // Size: 0x08
	struct FVector2D posDown; // Offset: 0x228 // Size: 0x08
	struct FScriptMulticastDelegate OnTouchEndedDispatcher; // Offset: 0x230 // Size: 0x10
	int from; // Offset: 0x240 // Size: 0x04
	int to; // Offset: 0x244 // Size: 0x04
	bool bAnimation; // Offset: 0x248 // Size: 0x01
	char pad_0x249[0x3]; // Offset: 0x249 // Size: 0x03
	float DeltaTime; // Offset: 0x24c // Size: 0x04
	bool bInPos; // Offset: 0x250 // Size: 0x01
	bool bIsDoubleSpeed; // Offset: 0x251 // Size: 0x01
	char pad_0x252[0x6]; // Offset: 0x252 // Size: 0x06
	struct TArray<struct FVector> PosList; // Offset: 0x258 // Size: 0x10
	bool bDown; // Offset: 0x268 // Size: 0x01
	char pad_0x269[0x7]; // Offset: 0x269 // Size: 0x07
	struct TArray<struct FVector> VelocityList; // Offset: 0x270 // Size: 0x10
	bool bMoveOneStep; // Offset: 0x280 // Size: 0x01
	bool bHasTeam; // Offset: 0x281 // Size: 0x01
	char pad_0x282[0x6]; // Offset: 0x282 // Size: 0x06
	struct FScriptMulticastDelegate OnTouchStartedDispatcher; // Offset: 0x288 // Size: 0x10
	struct FScriptMulticastDelegate OnLobbyEndedDispatcher; // Offset: 0x298 // Size: 0x10

	// Functions

	// Object Name: Function Lobby_Control_Comp.Lobby_Control_Comp_C.CancelScroll
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void CancelScroll(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_Control_Comp.Lobby_Control_Comp_C.CheckSide12
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void CheckSide12(float pos, bool& inside); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Lobby_Control_Comp.Lobby_Control_Comp_C.OnMouseButtonUp
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	struct FEventReply OnMouseButtonUp(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Offset: 0x103e7af64 // Return & Params: Num(3) Size(0x168)

	// Object Name: Function Lobby_Control_Comp.Lobby_Control_Comp_C.OnMouseButtonDown
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	struct FEventReply OnMouseButtonDown(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Offset: 0x103e7af64 // Return & Params: Num(3) Size(0x168)

	// Object Name: Function Lobby_Control_Comp.Lobby_Control_Comp_C.SetCameraPos
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetCameraPos(float X, float Y, float Z); // Offset: 0x103e7af64 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Lobby_Control_Comp.Lobby_Control_Comp_C.MoveCamera
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void MoveCamera(struct FVector Speed, float Time, int sideIndex, bool& bStop); // Offset: 0x103e7af64 // Return & Params: Num(4) Size(0x15)

	// Object Name: Function Lobby_Control_Comp.Lobby_Control_Comp_C.OnTouchEnded
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	struct FEventReply OnTouchEnded(struct FGeometry MyGeometry, struct FPointerEvent& InTouchEvent); // Offset: 0x103e7af64 // Return & Params: Num(3) Size(0x168)

	// Object Name: Function Lobby_Control_Comp.Lobby_Control_Comp_C.OnTouchMoved
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	struct FEventReply OnTouchMoved(struct FGeometry MyGeometry, struct FPointerEvent& InTouchEvent); // Offset: 0x103e7af64 // Return & Params: Num(3) Size(0x168)

	// Object Name: Function Lobby_Control_Comp.Lobby_Control_Comp_C.OnTouchStarted
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	struct FEventReply OnTouchStarted(struct FGeometry MyGeometry, struct FPointerEvent& InTouchEvent); // Offset: 0x103e7af64 // Return & Params: Num(3) Size(0x168)

	// Object Name: Function Lobby_Control_Comp.Lobby_Control_Comp_C.AniCamera
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void AniCamera(int from, int to, bool bShoudDouble); // Offset: 0x103e7af64 // Return & Params: Num(3) Size(0x9)

	// Object Name: Function Lobby_Control_Comp.Lobby_Control_Comp_C.GetCamera
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetCamera(struct ACameraActor*& Camera); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Lobby_Control_Comp.Lobby_Control_Comp_C.Tick
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0x3c)

	// Object Name: Function Lobby_Control_Comp.Lobby_Control_Comp_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_Control_Comp.Lobby_Control_Comp_C.ExecuteUbergraph_Lobby_Control_Comp
	// Flags: [HasDefaults]
	void ExecuteUbergraph_Lobby_Control_Comp(int EntryPoint); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Lobby_Control_Comp.Lobby_Control_Comp_C.OnLobbyEndedDispatcher__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnLobbyEndedDispatcher__DelegateSignature(float X, float Y); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Lobby_Control_Comp.Lobby_Control_Comp_C.OnTouchStartedDispatcher__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnTouchStartedDispatcher__DelegateSignature(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_Control_Comp.Lobby_Control_Comp_C.OnTouchEndedDispatcher__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnTouchEndedDispatcher__DelegateSignature(float OffSetX, float OffSetY); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0x8)
};

