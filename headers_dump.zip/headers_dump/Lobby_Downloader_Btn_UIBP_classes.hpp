#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Lobby_Downloader_Btn_UIBP.Lobby_Downloader_Btn_UIBP_C
// Size: 0x240 // Inherited bytes: 0x218
struct ULobby_Downloader_Btn_UIBP_C : UUserWidget {
	// Fields
	struct UCommon_DragDrop_Item_C* CommonDragDropItem; // Offset: 0x218 // Size: 0x08
	struct UImage* Image_Progress; // Offset: 0x220 // Size: 0x08
	struct UImage* Image_RedDot; // Offset: 0x228 // Size: 0x08
	struct UCanvasPanel* Panel_Drag; // Offset: 0x230 // Size: 0x08
	struct UScaleBox* ScaleBox_Downloader; // Offset: 0x238 // Size: 0x08
};

