#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Lobby_Left_Message_UIBP.Lobby_Left_Message_UIBP_C
// Size: 0x3e0 // Inherited bytes: 0x218
struct ULobby_Left_Message_UIBP_C : UUserWidget {
	// Fields
	struct UImage* Alliance_Reddot; // Offset: 0x218 // Size: 0x08
	struct UButton* Button_Achievement; // Offset: 0x220 // Size: 0x08
	struct UButton* Button_Alliance; // Offset: 0x228 // Size: 0x08
	struct UButton* Button_Club; // Offset: 0x230 // Size: 0x08
	struct UButton* Button_Corps; // Offset: 0x238 // Size: 0x08
	struct UButton* Button_CV; // Offset: 0x240 // Size: 0x08
	struct UButton* Button_Detail; // Offset: 0x248 // Size: 0x08
	struct UButton* Button_Moment; // Offset: 0x250 // Size: 0x08
	struct UButton* Button_Music; // Offset: 0x258 // Size: 0x08
	struct UButton* Button_PVE; // Offset: 0x260 // Size: 0x08
	struct UButton* Button_Relation; // Offset: 0x268 // Size: 0x08
	struct UButton* Button_RP; // Offset: 0x270 // Size: 0x08
	struct UButton* Button_ScoreActive; // Offset: 0x278 // Size: 0x08
	struct UButton* Button_ScoreNotActive; // Offset: 0x280 // Size: 0x08
	struct UButton* Button_Upvote; // Offset: 0x288 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Ban; // Offset: 0x290 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_IPX; // Offset: 0x298 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Rp; // Offset: 0x2a0 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Score; // Offset: 0x2a8 // Size: 0x08
	struct UCommon_Avatar_BP_C* Common_Avatar_BP_3; // Offset: 0x2b0 // Size: 0x08
	struct UImage* Image_1; // Offset: 0x2b8 // Size: 0x08
	struct UImage* Image_8; // Offset: 0x2c0 // Size: 0x08
	struct UImage* Image_9; // Offset: 0x2c8 // Size: 0x08
	struct UImage* Image_13; // Offset: 0x2d0 // Size: 0x08
	struct UImage* Image_16; // Offset: 0x2d8 // Size: 0x08
	struct UImage* Image_23; // Offset: 0x2e0 // Size: 0x08
	struct UImage* Image_25; // Offset: 0x2e8 // Size: 0x08
	struct UImage* Image_Alliance; // Offset: 0x2f0 // Size: 0x08
	struct UImage* Image_CropsLogo; // Offset: 0x2f8 // Size: 0x08
	struct UImage* Image_Flag; // Offset: 0x300 // Size: 0x08
	struct UImage* Image_Moment; // Offset: 0x308 // Size: 0x08
	struct UImage* Image_Music; // Offset: 0x310 // Size: 0x08
	struct UImage* Image_Relation_Reddot; // Offset: 0x318 // Size: 0x08
	struct UImage* Image_ScoreLevel; // Offset: 0x320 // Size: 0x08
	struct ULobby_Left_Record_RP_UIBP_C* Lobby_Left_Record_RP_UIBP; // Offset: 0x328 // Size: 0x08
	struct UImage* Moment_Reddot; // Offset: 0x330 // Size: 0x08
	struct UCanvasPanel* NewbieGuide_Mode; // Offset: 0x338 // Size: 0x08
	struct UReddot_Anchor_C* Reddot_Anchor; // Offset: 0x340 // Size: 0x08
	struct UImage* showinfo_reddot; // Offset: 0x348 // Size: 0x08
	struct UTextBlock* TextBlock_1; // Offset: 0x350 // Size: 0x08
	struct UTextBlock* TextBlock_2; // Offset: 0x358 // Size: 0x08
	struct UTextBlock* TextBlock_4; // Offset: 0x360 // Size: 0x08
	struct UTextBlock* TextBlock_5; // Offset: 0x368 // Size: 0x08
	struct UTextBlock* TextBlock_7; // Offset: 0x370 // Size: 0x08
	struct UTextBlock* TextBlock_Achievement; // Offset: 0x378 // Size: 0x08
	struct UTextBlock* TextBlock_Alliance; // Offset: 0x380 // Size: 0x08
	struct UTextBlock* TextBlock_Corps; // Offset: 0x388 // Size: 0x08
	struct UTextBlock* TextBlock_Moment; // Offset: 0x390 // Size: 0x08
	struct UTextBlock* TextBlock_Player2; // Offset: 0x398 // Size: 0x08
	struct UTextBlock* TextBlock_PlayerId2; // Offset: 0x3a0 // Size: 0x08
	struct UTextBlock* TextBlock_PVE; // Offset: 0x3a8 // Size: 0x08
	struct UTextBlock* TextBlock_Relation; // Offset: 0x3b0 // Size: 0x08
	struct UTextBlock* TextBlock_RP; // Offset: 0x3b8 // Size: 0x08
	struct UTextBlock* TextBlock_Score; // Offset: 0x3c0 // Size: 0x08
	struct UTextBlock* TextBlock_Upvote; // Offset: 0x3c8 // Size: 0x08
	struct UUnknowPass_ContinuousBuy_BP_C* UnknowPass_ContinuousBuy_BP; // Offset: 0x3d0 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_Score; // Offset: 0x3d8 // Size: 0x08
};

