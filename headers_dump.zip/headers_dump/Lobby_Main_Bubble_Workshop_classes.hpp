#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Lobby_Main_Bubble_Workshop.Lobby_Main_Bubble_Workshop_C
// Size: 0x230 // Inherited bytes: 0x218
struct ULobby_Main_Bubble_Workshop_C : UUserWidget {
	// Fields
	struct UButton* Button_LabVideo; // Offset: 0x218 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_LabVideoBanner; // Offset: 0x220 // Size: 0x08
	struct UImage* Image_ResearchBanner; // Offset: 0x228 // Size: 0x08
};

