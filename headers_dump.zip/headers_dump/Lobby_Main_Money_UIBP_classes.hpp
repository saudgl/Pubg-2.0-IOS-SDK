#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Lobby_Main_Money_UIBP.Lobby_Main_Money_UIBP_C
// Size: 0x2d0 // Inherited bytes: 0x218
struct ULobby_Main_Money_UIBP_C : UUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x218 // Size: 0x08
	struct UButton* Btn_Silver; // Offset: 0x220 // Size: 0x08
	struct UButton* Btn_UC; // Offset: 0x228 // Size: 0x08
	struct UButton* Btn_Zhupai; // Offset: 0x230 // Size: 0x08
	struct UButton* Button_Diamond; // Offset: 0x238 // Size: 0x08
	struct UButton* Button_subscribe; // Offset: 0x240 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Diamond; // Offset: 0x248 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Silver; // Offset: 0x250 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Subscribe; // Offset: 0x258 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Zhupai; // Offset: 0x260 // Size: 0x08
	struct UImage* Image_1; // Offset: 0x268 // Size: 0x08
	struct UImage* Image_2; // Offset: 0x270 // Size: 0x08
	struct UImage* Image_4; // Offset: 0x278 // Size: 0x08
	struct UImage* Image_5; // Offset: 0x280 // Size: 0x08
	struct UImage* Image_6; // Offset: 0x288 // Size: 0x08
	struct UImage* Image_7; // Offset: 0x290 // Size: 0x08
	struct UImage* Image_12; // Offset: 0x298 // Size: 0x08
	struct UImage* Image_171; // Offset: 0x2a0 // Size: 0x08
	struct UReddot_Anchor_C* Reddot_Anchor; // Offset: 0x2a8 // Size: 0x08
	struct UTextBlock* TextBlock_diamond; // Offset: 0x2b0 // Size: 0x08
	struct UTextBlock* TextBlock_silver; // Offset: 0x2b8 // Size: 0x08
	struct UTextBlock* Txt_uc; // Offset: 0x2c0 // Size: 0x08
	struct UTextBlock* Txt_zhupai; // Offset: 0x2c8 // Size: 0x08

	// Functions

	// Object Name: Function Lobby_Main_Money_UIBP.Lobby_Main_Money_UIBP_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_Main_Money_UIBP.Lobby_Main_Money_UIBP_C.ExecuteUbergraph_Lobby_Main_Money_UIBP
	// Flags: [None]
	void ExecuteUbergraph_Lobby_Main_Money_UIBP(int EntryPoint); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x4)
};

