#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Lobby_Main_Pet_UIBP.Lobby_Main_Pet_UIBP_C
// Size: 0x410 // Inherited bytes: 0x3d0
struct ULobby_Main_Pet_UIBP_C : UUAEUserWidget {
	// Fields
	struct UWidgetAnimation* DX_Transitions_Enter; // Offset: 0x3d0 // Size: 0x08
	struct UWidgetAnimation* DX_Transitions_StartEnter; // Offset: 0x3d8 // Size: 0x08
	struct UButton* BtnClose; // Offset: 0x3e0 // Size: 0x08
	struct UButton* BtnPetAction; // Offset: 0x3e8 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Root; // Offset: 0x3f0 // Size: 0x08
	struct UOverlay* Overlay_1; // Offset: 0x3f8 // Size: 0x08
	struct UOverlay* Overlay_2; // Offset: 0x400 // Size: 0x08
	struct UWidgetSwitcher* WS_PetAction; // Offset: 0x408 // Size: 0x08
};

