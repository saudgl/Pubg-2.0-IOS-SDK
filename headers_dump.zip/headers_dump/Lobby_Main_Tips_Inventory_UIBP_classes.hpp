#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Lobby_Main_Tips_Inventory_UIBP.Lobby_Main_Tips_Inventory_UIBP_C
// Size: 0x220 // Inherited bytes: 0x218
struct ULobby_Main_Tips_Inventory_UIBP_C : UUserWidget {
	// Fields
	struct UCanvasPanel* Panel_Wardrobe_DownloadTips; // Offset: 0x218 // Size: 0x08
};

