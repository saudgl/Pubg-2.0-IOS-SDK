#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Lobby_Main_Tips_Workshop_UIBP.Lobby_Main_Tips_Workshop_UIBP_C
// Size: 0x230 // Inherited bytes: 0x218
struct ULobby_Main_Tips_Workshop_UIBP_C : UUserWidget {
	// Fields
	struct UImage* Image_125; // Offset: 0x218 // Size: 0x08
	struct UCanvasPanel* LabNewbieTips; // Offset: 0x220 // Size: 0x08
	struct UTextBlock* TextBlock_LabNewTips; // Offset: 0x228 // Size: 0x08
};

