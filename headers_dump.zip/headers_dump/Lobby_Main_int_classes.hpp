#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass Lobby_Main_int.Lobby_Main_int_C
// Size: 0x4b0 // Inherited bytes: 0x440
struct ALobby_Main_int_C : ALuaLevelScriptActor {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x440 // Size: 0x08
	struct UFrontendUtils* frontUtils; // Offset: 0x448 // Size: 0x08
	bool blockBackScene; // Offset: 0x450 // Size: 0x01
	char pad_0x451[0x7]; // Offset: 0x451 // Size: 0x07
	struct FName lastSceneCamera; // Offset: 0x458 // Size: 0x08
	struct USettingConfig_C* SetConfig; // Offset: 0x460 // Size: 0x08
	struct FScriptMulticastDelegate Dispatcher_OpenBox; // Offset: 0x468 // Size: 0x10
	struct FVector2D viewportSize; // Offset: 0x478 // Size: 0x08
	float accumTime; // Offset: 0x480 // Size: 0x04
	int folderDevice; // Offset: 0x484 // Size: 0x04
	struct ASkyLight* SkyLight_1_EdGraph_4_RefProperty; // Offset: 0x488 // Size: 0x08
	struct APointLight* PointLight_0_EdGraph_4_RefProperty; // Offset: 0x490 // Size: 0x08
	struct ADirectionalLight* DirectionalLight_0_EdGraph_4_RefProperty; // Offset: 0x498 // Size: 0x08
	struct ACameraActor* LobbySecondCam_EdGraph_4_RefProperty; // Offset: 0x4a0 // Size: 0x08
	struct ACameraActor* LobbyFirstCam_EdGraph_4_RefProperty; // Offset: 0x4a8 // Size: 0x08

	// Functions

	// Object Name: Function Lobby_Main_int.Lobby_Main_int_C.RegistPersistLevelObjs
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void RegistPersistLevelObjs(struct UFrontendUtils* Utils); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Lobby_Main_int.Lobby_Main_int_C.InpActEvt_Android_Back_K2Node_InputKeyEvent_6
	// Flags: [BlueprintEvent]
	void InpActEvt_Android_Back_K2Node_InputKeyEvent_6(struct FKey Key); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function Lobby_Main_int.Lobby_Main_int_C.InpActEvt_B_K2Node_InputKeyEvent_5
	// Flags: [BlueprintEvent]
	void InpActEvt_B_K2Node_InputKeyEvent_5(struct FKey Key); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function Lobby_Main_int.Lobby_Main_int_C.InpActEvt_N_K2Node_InputKeyEvent_4
	// Flags: [BlueprintEvent]
	void InpActEvt_N_K2Node_InputKeyEvent_4(struct FKey Key); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function Lobby_Main_int.Lobby_Main_int_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveBeginPlay(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_Main_int.Lobby_Main_int_C.InpAxisKeyEvt_RotationRate_K2Node_InputVectorAxisEvent_1
	// Flags: [BlueprintEvent]
	void InpAxisKeyEvt_RotationRate_K2Node_InputVectorAxisEvent_1(struct FVector AxisValue); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function Lobby_Main_int.Lobby_Main_int_C.ReceiveTick
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveTick(float DeltaSeconds); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Lobby_Main_int.Lobby_Main_int_C.ExecuteUbergraph_Lobby_Main_int
	// Flags: [HasDefaults]
	void ExecuteUbergraph_Lobby_Main_int(int EntryPoint); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Lobby_Main_int.Lobby_Main_int_C.Dispatcher_OpenBox__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void Dispatcher_OpenBox__DelegateSignature(struct ASkeletalMeshActor* NewParam); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x8)
};

