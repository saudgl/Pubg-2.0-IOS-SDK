#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Lobby_Mid_Binner_More_UIBP.Lobby_Mid_Binner_More_UIBP_C
// Size: 0x441 // Inherited bytes: 0x3d0
struct ULobby_Mid_Binner_More_UIBP_C : UUAEUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x3d0 // Size: 0x08
	struct UWidgetAnimation* NewAnimation_2; // Offset: 0x3d8 // Size: 0x08
	struct UHorizontalBox* DotPanel; // Offset: 0x3e0 // Size: 0x08
	struct ULoopScrollBox* LoopScrollBox_1; // Offset: 0x3e8 // Size: 0x08
	struct TArray<struct ULobby_Activity_BtnItem_C*> ActivityBtnList; // Offset: 0x3f0 // Size: 0x10
	struct FTimerHandle BtnListMoveTimer; // Offset: 0x400 // Size: 0x08
	float ActivityBtnItemLen; // Offset: 0x408 // Size: 0x04
	char pad_0x40C[0x4]; // Offset: 0x40c // Size: 0x04
	struct FTimerHandle BtnPlayingAnimTimer; // Offset: 0x410 // Size: 0x08
	float BtnListPlayAnimTarget; // Offset: 0x418 // Size: 0x04
	bool BtnListIsLastWindow; // Offset: 0x41c // Size: 0x01
	char pad_0x41D[0x3]; // Offset: 0x41d // Size: 0x03
	struct FScriptMulticastDelegate EventDispatcherClickItem; // Offset: 0x420 // Size: 0x10
	float alignOffset; // Offset: 0x430 // Size: 0x04
	int pageCount; // Offset: 0x434 // Size: 0x04
	bool bNextDir; // Offset: 0x438 // Size: 0x01
	bool bAniIng; // Offset: 0x439 // Size: 0x01
	char pad_0x43A[0x2]; // Offset: 0x43a // Size: 0x02
	float preOffset; // Offset: 0x43c // Size: 0x04
	bool isUserScrolling; // Offset: 0x440 // Size: 0x01

	// Functions

	// Object Name: Function Lobby_Mid_Binner_More_UIBP.Lobby_Mid_Binner_More_UIBP_C.GetOffset
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetOffset(float& Offset); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Lobby_Mid_Binner_More_UIBP.Lobby_Mid_Binner_More_UIBP_C.GetCurrentIndex
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetCurrentIndex(int& Index); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Lobby_Mid_Binner_More_UIBP.Lobby_Mid_Binner_More_UIBP_C.OnClickActivityItem
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnClickActivityItem(struct ULobby_Activity_BtnItem_C* Item); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Lobby_Mid_Binner_More_UIBP.Lobby_Mid_Binner_More_UIBP_C.UpdateCurrentPage
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void UpdateCurrentPage(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_Mid_Binner_More_UIBP.Lobby_Mid_Binner_More_UIBP_C.SetActivityListPageCount
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetActivityListPageCount(int pageCount); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Lobby_Mid_Binner_More_UIBP.Lobby_Mid_Binner_More_UIBP_C.Tick
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0x3c)

	// Object Name: Function Lobby_Mid_Binner_More_UIBP.Lobby_Mid_Binner_More_UIBP_C.ExecuteUbergraph_Lobby_Mid_Binner_More_UIBP
	// Flags: [HasDefaults]
	void ExecuteUbergraph_Lobby_Mid_Binner_More_UIBP(int EntryPoint); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Lobby_Mid_Binner_More_UIBP.Lobby_Mid_Binner_More_UIBP_C.EventDispatcherClickItem__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void EventDispatcherClickItem__DelegateSignature(int ID, struct FString JumpUrl); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0x18)
};

