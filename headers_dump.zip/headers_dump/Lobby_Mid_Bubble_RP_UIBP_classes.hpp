#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Lobby_Mid_Bubble_RP_UIBP.Lobby_Mid_Bubble_RP_UIBP_C
// Size: 0x248 // Inherited bytes: 0x218
struct ULobby_Mid_Bubble_RP_UIBP_C : UUserWidget {
	// Fields
	struct UButton* Button_PassBubble; // Offset: 0x218 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Rp_Bubble; // Offset: 0x220 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_RPAct_Bubble; // Offset: 0x228 // Size: 0x08
	struct UImage* Image_bubble; // Offset: 0x230 // Size: 0x08
	struct UTextBlock* TextBlock_Tips; // Offset: 0x238 // Size: 0x08
	struct UUTRichTextBlock* UTRichTextBlock_PassBubble; // Offset: 0x240 // Size: 0x08
};

