#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Lobby_Mid_News.Lobby_Mid_News_C
// Size: 0x418 // Inherited bytes: 0x3d0
struct ULobby_Mid_News_C : UUAEUserWidget {
	// Fields
	struct UCanvasPanel* Base; // Offset: 0x3d0 // Size: 0x08
	struct UButton* Button; // Offset: 0x3d8 // Size: 0x08
	struct UImage* Icon1; // Offset: 0x3e0 // Size: 0x08
	struct UImage* Icon2; // Offset: 0x3e8 // Size: 0x08
	struct UImage* Icon3; // Offset: 0x3f0 // Size: 0x08
	struct UImage* Icon4; // Offset: 0x3f8 // Size: 0x08
	struct UImage* RedPoint; // Offset: 0x400 // Size: 0x08
	struct UCanvasPanel* Root; // Offset: 0x408 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_Type; // Offset: 0x410 // Size: 0x08
};

