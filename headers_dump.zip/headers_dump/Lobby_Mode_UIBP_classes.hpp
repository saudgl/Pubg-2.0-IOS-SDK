#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Lobby_Mode_UIBP.Lobby_Mode_UIBP_C
// Size: 0x2c0 // Inherited bytes: 0x218
struct ULobby_Mode_UIBP_C : UUserWidget {
	// Fields
	struct UWidgetAnimation* Animation_LoadingLoop; // Offset: 0x218 // Size: 0x08
	struct UWidgetAnimation* Animation_Seletion; // Offset: 0x220 // Size: 0x08
	struct UButton* Button_1; // Offset: 0x228 // Size: 0x08
	struct UButton* Button_Enter; // Offset: 0x230 // Size: 0x08
	struct UButton* Button_RankLimitTip; // Offset: 0x238 // Size: 0x08
	struct UButton* Button_Tips_ChangeMode; // Offset: 0x240 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Activity; // Offset: 0x248 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Loading; // Offset: 0x250 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_RankLimit; // Offset: 0x258 // Size: 0x08
	struct UImage* Image_bg; // Offset: 0x260 // Size: 0x08
	struct UImage* Image_Mode_PlayerCnt; // Offset: 0x268 // Size: 0x08
	struct UImage* Image_Team; // Offset: 0x270 // Size: 0x08
	struct UTextBlock* Text_MapName; // Offset: 0x278 // Size: 0x08
	struct UTextBlock* Text_ModelName; // Offset: 0x280 // Size: 0x08
	struct UTextBlock* Text_PerspectiveType; // Offset: 0x288 // Size: 0x08
	struct UTextBlock* TextBlock_Activity; // Offset: 0x290 // Size: 0x08
	struct UTextBlock* TextBlock_Mode; // Offset: 0x298 // Size: 0x08
	struct UTextBlock* TextBlock_Pers; // Offset: 0x2a0 // Size: 0x08
	struct UUTRichTextBlock* TextBlock_RankLimit; // Offset: 0x2a8 // Size: 0x08
	struct UTextBlock* TextBlock_TeamCnt; // Offset: 0x2b0 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_Mode; // Offset: 0x2b8 // Size: 0x08
};

