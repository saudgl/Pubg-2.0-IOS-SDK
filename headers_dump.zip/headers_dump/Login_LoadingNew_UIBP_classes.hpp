#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Login_LoadingNew_UIBP.Login_LoadingNew_UIBP_C
// Size: 0x468 // Inherited bytes: 0x3d0
struct ULogin_LoadingNew_UIBP_C : UUAEUserWidget {
	// Fields
	struct UWidgetAnimation* Loading_anima; // Offset: 0x3d0 // Size: 0x08
	struct UWeakRefImage* BackImage; // Offset: 0x3d8 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_4; // Offset: 0x3e0 // Size: 0x08
	struct UGridPanel* GridPanel_Root; // Offset: 0x3e8 // Size: 0x08
	struct UHorizontalBox* HorizontalBox_3; // Offset: 0x3f0 // Size: 0x08
	struct UImage* Image_1; // Offset: 0x3f8 // Size: 0x08
	struct UImage* Image_2; // Offset: 0x400 // Size: 0x08
	struct UImage* Image_3; // Offset: 0x408 // Size: 0x08
	struct UImage* Image_4; // Offset: 0x410 // Size: 0x08
	struct UImage* Image_8; // Offset: 0x418 // Size: 0x08
	struct UImage* ImageLogo; // Offset: 0x420 // Size: 0x08
	struct UCanvasPanel* Panel_FreeTraffic; // Offset: 0x428 // Size: 0x08
	struct UProgressBar* ProgressBar_Loading; // Offset: 0x430 // Size: 0x08
	struct UUTRichTextBlock* RichText_LoadingTip; // Offset: 0x438 // Size: 0x08
	struct USetting_CarrierCooperation_UIBP_C* Setting_CarrierCooperation_UIBP; // Offset: 0x440 // Size: 0x08
	struct UTextBlock* TextBlock_Check; // Offset: 0x448 // Size: 0x08
	struct UTextBlock* TextBlock_Dot; // Offset: 0x450 // Size: 0x08
	struct UTextBlock* TextBlock_GameTime; // Offset: 0x458 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_1; // Offset: 0x460 // Size: 0x08
};

