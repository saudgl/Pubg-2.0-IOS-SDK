#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass MaskBoxItem.MaskBoxItem_C
// Size: 0x230 // Inherited bytes: 0x218
struct UMaskBoxItem_C : UUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x218 // Size: 0x08
	struct UImage* Image_1; // Offset: 0x220 // Size: 0x08
	struct UMaskBox* MaskBox; // Offset: 0x228 // Size: 0x08

	// Functions

	// Object Name: Function MaskBoxItem.MaskBoxItem_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MaskBoxItem.MaskBoxItem_C.ExecuteUbergraph_MaskBoxItem
	// Flags: [None]
	void ExecuteUbergraph_MaskBoxItem(int EntryPoint); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x4)
};

