#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class MediaAssets.MediaSource
// Size: 0x30 // Inherited bytes: 0x28
struct UMediaSource : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08

	// Functions

	// Object Name: Function MediaAssets.MediaSource.Validate
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool Validate(); // Offset: 0x10549ccb4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MediaAssets.MediaSource.GetUrl
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetUrl(); // Offset: 0x10549cc48 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class MediaAssets.BaseMediaSource
// Size: 0x38 // Inherited bytes: 0x30
struct UBaseMediaSource : UMediaSource {
	// Fields
	struct FName PlayerName; // Offset: 0x30 // Size: 0x08
};

// Object Name: Class MediaAssets.FileMediaSource
// Size: 0x50 // Inherited bytes: 0x38
struct UFileMediaSource : UBaseMediaSource {
	// Fields
	struct FString FilePath; // Offset: 0x38 // Size: 0x10
	bool PrecacheFile; // Offset: 0x48 // Size: 0x01
	char pad_0x49[0x7]; // Offset: 0x49 // Size: 0x07

	// Functions

	// Object Name: Function MediaAssets.FileMediaSource.SetFilePath
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFilePath(struct FString Path); // Offset: 0x1054984a8 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class MediaAssets.MediaBlueprintFunctionLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UMediaBlueprintFunctionLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function MediaAssets.MediaBlueprintFunctionLibrary.EnumerateWebcamCaptureDevices
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void EnumerateWebcamCaptureDevices(struct TArray<struct FMediaCaptureDevice>& OutDevices, int Filter); // Offset: 0x105498b74 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function MediaAssets.MediaBlueprintFunctionLibrary.EnumerateVideoCaptureDevices
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void EnumerateVideoCaptureDevices(struct TArray<struct FMediaCaptureDevice>& OutDevices, int Filter); // Offset: 0x105498a90 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function MediaAssets.MediaBlueprintFunctionLibrary.EnumerateAudioCaptureDevices
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void EnumerateAudioCaptureDevices(struct TArray<struct FMediaCaptureDevice>& OutDevices, int Filter); // Offset: 0x1054989ac // Return & Params: Num(2) Size(0x14)
};

// Object Name: Class MediaAssets.MediaPlayer
// Size: 0x138 // Inherited bytes: 0x28
struct UMediaPlayer : UObject {
	// Fields
	struct FScriptMulticastDelegate OnEndReached; // Offset: 0x28 // Size: 0x10
	struct FScriptMulticastDelegate OnMediaClosed; // Offset: 0x38 // Size: 0x10
	struct FScriptMulticastDelegate OnMediaOpened; // Offset: 0x48 // Size: 0x10
	struct FScriptMulticastDelegate OnMediaOpenFailed; // Offset: 0x58 // Size: 0x10
	struct FScriptMulticastDelegate OnPlaybackResumed; // Offset: 0x68 // Size: 0x10
	struct FScriptMulticastDelegate OnPlaybackSuspended; // Offset: 0x78 // Size: 0x10
	struct FScriptMulticastDelegate OnSeekCompleted; // Offset: 0x88 // Size: 0x10
	struct FScriptMulticastDelegate OnTracksChanged; // Offset: 0x98 // Size: 0x10
	struct FScriptMulticastDelegate OnMediaPlayFirstFrame; // Offset: 0xa8 // Size: 0x10
	struct FTimespan CacheAhead; // Offset: 0xb8 // Size: 0x08
	struct FTimespan CacheBehind; // Offset: 0xc0 // Size: 0x08
	struct FTimespan CacheBehindGame; // Offset: 0xc8 // Size: 0x08
	bool NativeAudioOut; // Offset: 0xd0 // Size: 0x01
	bool PlayOnOpen; // Offset: 0xd1 // Size: 0x01
	char Shuffle : 1; // Offset: 0xd2 // Size: 0x01
	char Loop : 1; // Offset: 0xd2 // Size: 0x01
	char pad_0xD2_2 : 6; // Offset: 0xd2 // Size: 0x01
	char pad_0xD3[0x5]; // Offset: 0xd3 // Size: 0x05
	struct UMediaPlaylist* Playlist; // Offset: 0xd8 // Size: 0x08
	int PlaylistIndex; // Offset: 0xe0 // Size: 0x04
	float HorizontalFieldOfView; // Offset: 0xe4 // Size: 0x04
	float VerticalFieldOfView; // Offset: 0xe8 // Size: 0x04
	struct FRotator ViewRotation; // Offset: 0xec // Size: 0x0c
	char pad_0xF8[0x28]; // Offset: 0xf8 // Size: 0x28
	struct FGuid PlayerGuid; // Offset: 0x120 // Size: 0x10
	char pad_0x130[0x8]; // Offset: 0x130 // Size: 0x08

	// Functions

	// Object Name: Function MediaAssets.MediaPlayer.SupportsSeeking
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool SupportsSeeking(); // Offset: 0x10549acac // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MediaAssets.MediaPlayer.SupportsScrubbing
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool SupportsScrubbing(); // Offset: 0x10549ac78 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MediaAssets.MediaPlayer.SupportsRate
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool SupportsRate(float Rate, bool Unthinned); // Offset: 0x10549aba8 // Return & Params: Num(3) Size(0x6)

	// Object Name: Function MediaAssets.MediaPlayer.SetViewRotation
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	bool SetViewRotation(struct FRotator& Rotation, bool Absolute); // Offset: 0x10549aacc // Return & Params: Num(3) Size(0xe)

	// Object Name: Function MediaAssets.MediaPlayer.SetViewField
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetViewField(float Horizontal, float Vertical, bool Absolute); // Offset: 0x10549a9c4 // Return & Params: Num(4) Size(0xa)

	// Object Name: Function MediaAssets.MediaPlayer.SetVideoTrackFrameRate
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetVideoTrackFrameRate(int TrackIndex, int FormatIndex, float FrameRate); // Offset: 0x10549a8c4 // Return & Params: Num(4) Size(0xd)

	// Object Name: Function MediaAssets.MediaPlayer.SetTrackFormat
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetTrackFormat(enum class EMediaPlayerTrack TrackType, int TrackIndex, int FormatIndex); // Offset: 0x10549a7c4 // Return & Params: Num(4) Size(0xd)

	// Object Name: Function MediaAssets.MediaPlayer.SetRate
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetRate(float Rate); // Offset: 0x10549a738 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function MediaAssets.MediaPlayer.SetLooping
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetLooping(bool Looping); // Offset: 0x10549a6a4 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function MediaAssets.MediaPlayer.SetDesiredPlayerName
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDesiredPlayerName(struct FName PlayerName); // Offset: 0x10549a628 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function MediaAssets.MediaPlayer.SelectTrack
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SelectTrack(enum class EMediaPlayerTrack TrackType, int TrackIndex); // Offset: 0x10549a560 // Return & Params: Num(3) Size(0x9)

	// Object Name: Function MediaAssets.MediaPlayer.Seek
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	bool Seek(struct FTimespan& Time); // Offset: 0x10549a4c8 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function MediaAssets.MediaPlayer.Rewind
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool Rewind(); // Offset: 0x10549a494 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MediaAssets.MediaPlayer.Reopen
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool Reopen(); // Offset: 0x10549a460 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MediaAssets.MediaPlayer.Previous
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool Previous(); // Offset: 0x10549a42c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MediaAssets.MediaPlayer.Play
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool Play(); // Offset: 0x10549a3f8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MediaAssets.MediaPlayer.Pause
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool Pause(); // Offset: 0x10549a3c4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MediaAssets.MediaPlayer.OpenURL
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool OpenURL(struct FString URL); // Offset: 0x10549a31c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function MediaAssets.MediaPlayer.OpenSource
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool OpenSource(struct UMediaSource* MediaSource); // Offset: 0x10549a290 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function MediaAssets.MediaPlayer.OpenPlaylistIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool OpenPlaylistIndex(struct UMediaPlaylist* InPlaylist, int Index); // Offset: 0x10549a1c8 // Return & Params: Num(3) Size(0xd)

	// Object Name: Function MediaAssets.MediaPlayer.OpenPlaylist
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool OpenPlaylist(struct UMediaPlaylist* InPlaylist); // Offset: 0x10549a13c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function MediaAssets.MediaPlayer.OpenFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool OpenFile(struct FString FilePath); // Offset: 0x10549a094 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function MediaAssets.MediaPlayer.Next
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool Next(); // Offset: 0x10549a060 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MediaAssets.MediaPlayer.IsReady
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsReady(); // Offset: 0x10549a02c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MediaAssets.MediaPlayer.IsPreparing
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsPreparing(); // Offset: 0x105499ff8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MediaAssets.MediaPlayer.IsPlaying
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsPlaying(); // Offset: 0x105499fc4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MediaAssets.MediaPlayer.IsPaused
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsPaused(); // Offset: 0x105499f90 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MediaAssets.MediaPlayer.IsLooping
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsLooping(); // Offset: 0x105499f5c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MediaAssets.MediaPlayer.IsConnecting
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsConnecting(); // Offset: 0x105499f28 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MediaAssets.MediaPlayer.IsBuffering
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsBuffering(); // Offset: 0x105499ef4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MediaAssets.MediaPlayer.HasError
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasError(); // Offset: 0x105499ec0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MediaAssets.MediaPlayer.GetViewRotation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FRotator GetViewRotation(); // Offset: 0x105499e88 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function MediaAssets.MediaPlayer.GetVideoTrackType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetVideoTrackType(int TrackIndex, int FormatIndex); // Offset: 0x105499d9c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function MediaAssets.MediaPlayer.GetVideoTrackFrameRates
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FFloatRange GetVideoTrackFrameRates(int TrackIndex, int FormatIndex); // Offset: 0x105499cb8 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function MediaAssets.MediaPlayer.GetVideoTrackFrameRate
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetVideoTrackFrameRate(int TrackIndex, int FormatIndex); // Offset: 0x105499bf4 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function MediaAssets.MediaPlayer.GetVideoTrackDimensions
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FIntPoint GetVideoTrackDimensions(int TrackIndex, int FormatIndex); // Offset: 0x105499b30 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function MediaAssets.MediaPlayer.GetVideoTrackAspectRatio
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetVideoTrackAspectRatio(int TrackIndex, int FormatIndex); // Offset: 0x105499a6c // Return & Params: Num(3) Size(0xc)

	// Object Name: Function MediaAssets.MediaPlayer.GetVerticalFieldOfView
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetVerticalFieldOfView(); // Offset: 0x105499a38 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MediaAssets.MediaPlayer.GetUrl
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetUrl(); // Offset: 0x105499a00 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function MediaAssets.MediaPlayer.GetTrackLanguage
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetTrackLanguage(enum class EMediaPlayerTrack TrackType, int TrackIndex); // Offset: 0x105499910 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function MediaAssets.MediaPlayer.GetTrackFormat
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetTrackFormat(enum class EMediaPlayerTrack TrackType, int TrackIndex); // Offset: 0x105499848 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function MediaAssets.MediaPlayer.GetTrackDisplayName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FText GetTrackDisplayName(enum class EMediaPlayerTrack TrackType, int TrackIndex); // Offset: 0x105499758 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function MediaAssets.MediaPlayer.GetTime
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FTimespan GetTime(); // Offset: 0x105499724 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function MediaAssets.MediaPlayer.GetSupportedRates
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetSupportedRates(struct TArray<struct FFloatRange>& OutRates, bool Unthinned); // Offset: 0x105499628 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function MediaAssets.MediaPlayer.GetSelectedTrack
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetSelectedTrack(enum class EMediaPlayerTrack TrackType); // Offset: 0x10549959c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MediaAssets.MediaPlayer.GetRate
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetRate(); // Offset: 0x105499568 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MediaAssets.MediaPlayer.GetPlaylistIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetPlaylistIndex(); // Offset: 0x10549954c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MediaAssets.MediaPlayer.GetPlaylist
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UMediaPlaylist* GetPlaylist(); // Offset: 0x105499530 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function MediaAssets.MediaPlayer.GetPlayerName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FName GetPlayerName(); // Offset: 0x1054994fc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function MediaAssets.MediaPlayer.GetNumTracks
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetNumTracks(enum class EMediaPlayerTrack TrackType); // Offset: 0x105499470 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MediaAssets.MediaPlayer.GetNumTrackFormats
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetNumTrackFormats(enum class EMediaPlayerTrack TrackType, int TrackIndex); // Offset: 0x1054993a8 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function MediaAssets.MediaPlayer.GetMediaName
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FText GetMediaName(); // Offset: 0x10549933c // Return & Params: Num(1) Size(0x18)

	// Object Name: Function MediaAssets.MediaPlayer.GetHorizontalFieldOfView
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetHorizontalFieldOfView(); // Offset: 0x105499308 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MediaAssets.MediaPlayer.GetDuration
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FTimespan GetDuration(); // Offset: 0x1054992d4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function MediaAssets.MediaPlayer.GetDesiredPlayerName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FName GetDesiredPlayerName(); // Offset: 0x1054992a0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function MediaAssets.MediaPlayer.GetAudioTrackType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetAudioTrackType(int TrackIndex, int FormatIndex); // Offset: 0x1054991b4 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function MediaAssets.MediaPlayer.GetAudioTrackSampleRate
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetAudioTrackSampleRate(int TrackIndex, int FormatIndex); // Offset: 0x1054990f0 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function MediaAssets.MediaPlayer.GetAudioTrackChannels
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetAudioTrackChannels(int TrackIndex, int FormatIndex); // Offset: 0x10549902c // Return & Params: Num(3) Size(0xc)

	// Object Name: Function MediaAssets.MediaPlayer.Close
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Close(); // Offset: 0x105499018 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MediaAssets.MediaPlayer.CanPlayUrl
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool CanPlayUrl(struct FString URL); // Offset: 0x105498f70 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function MediaAssets.MediaPlayer.CanPlaySource
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool CanPlaySource(struct UMediaSource* MediaSource); // Offset: 0x105498ee4 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function MediaAssets.MediaPlayer.CanPause
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool CanPause(); // Offset: 0x105498eb0 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class MediaAssets.MediaPlaylist
// Size: 0x40 // Inherited bytes: 0x28
struct UMediaPlaylist : UObject {
	// Fields
	char Loop : 1; // Offset: 0x28 // Size: 0x01
	char pad_0x28_1 : 7; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
	struct TArray<struct UMediaSource*> Items; // Offset: 0x30 // Size: 0x10

	// Functions

	// Object Name: Function MediaAssets.MediaPlaylist.Replace
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool Replace(int Index, struct UMediaSource* Replacement); // Offset: 0x10549c5a0 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function MediaAssets.MediaPlaylist.RemoveAt
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool RemoveAt(int Index); // Offset: 0x10549c514 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function MediaAssets.MediaPlaylist.Remove
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool Remove(struct UMediaSource* MediaSource); // Offset: 0x10549c488 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function MediaAssets.MediaPlaylist.Num
	// Flags: [Final|Native|Public|BlueprintCallable]
	int Num(); // Offset: 0x10549c46c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MediaAssets.MediaPlaylist.Insert
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Insert(struct UMediaSource* MediaSource, int Index); // Offset: 0x10549c3b4 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function MediaAssets.MediaPlaylist.GetRandom
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct UMediaSource* GetRandom(int& OutIndex); // Offset: 0x10549c318 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function MediaAssets.MediaPlaylist.GetPrevious
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct UMediaSource* GetPrevious(int& InOutIndex); // Offset: 0x10549c27c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function MediaAssets.MediaPlaylist.GetNext
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct UMediaSource* GetNext(int& InOutIndex); // Offset: 0x10549c1e0 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function MediaAssets.MediaPlaylist.Get
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UMediaSource* Get(int Index); // Offset: 0x10549c154 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function MediaAssets.MediaPlaylist.AddUrl
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool AddUrl(struct FString URL); // Offset: 0x10549c0ac // Return & Params: Num(2) Size(0x11)

	// Object Name: Function MediaAssets.MediaPlaylist.AddFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool AddFile(struct FString FilePath); // Offset: 0x10549c004 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function MediaAssets.MediaPlaylist.Add
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool Add(struct UMediaSource* MediaSource); // Offset: 0x10549bf78 // Return & Params: Num(2) Size(0x9)
};

// Object Name: Class MediaAssets.MediaSoundComponent
// Size: 0x680 // Inherited bytes: 0x600
struct UMediaSoundComponent : USynthComponent {
	// Fields
	enum class EMediaSoundChannels Channels; // Offset: 0x600 // Size: 0x04
	char pad_0x604[0x4]; // Offset: 0x604 // Size: 0x04
	struct UMediaPlayer* MediaPlayer; // Offset: 0x608 // Size: 0x08
	char pad_0x610[0x70]; // Offset: 0x610 // Size: 0x70
};

// Object Name: Class MediaAssets.MediaTexture
// Size: 0x158 // Inherited bytes: 0xe8
struct UMediaTexture : UTexture {
	// Fields
	enum class TextureAddress AddressX; // Offset: 0xe8 // Size: 0x01
	enum class TextureAddress AddressY; // Offset: 0xe9 // Size: 0x01
	bool AutoClear; // Offset: 0xea // Size: 0x01
	char pad_0xEB[0x1]; // Offset: 0xeb // Size: 0x01
	struct FLinearColor ClearColor; // Offset: 0xec // Size: 0x10
	char pad_0xFC[0x4]; // Offset: 0xfc // Size: 0x04
	struct UMediaPlayer* MediaPlayer; // Offset: 0x100 // Size: 0x08
	char pad_0x108[0x50]; // Offset: 0x108 // Size: 0x50

	// Functions

	// Object Name: Function MediaAssets.MediaTexture.GetWidth
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetWidth(); // Offset: 0x10549ceb4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MediaAssets.MediaTexture.GetHeight
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetHeight(); // Offset: 0x10549ce80 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MediaAssets.MediaTexture.GetAspectRatio
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetAspectRatio(); // Offset: 0x10549ce4c // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class MediaAssets.PlatformMediaSource
// Size: 0x38 // Inherited bytes: 0x30
struct UPlatformMediaSource : UMediaSource {
	// Fields
	struct UMediaSource* MediaSource; // Offset: 0x30 // Size: 0x08
};

// Object Name: Class MediaAssets.StreamMediaSource
// Size: 0x48 // Inherited bytes: 0x38
struct UStreamMediaSource : UBaseMediaSource {
	// Fields
	struct FString StreamUrl; // Offset: 0x38 // Size: 0x10
};

