#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Newbie_Banner_Item.Newbie_Banner_Item_C
// Size: 0x458 // Inherited bytes: 0x3d0
struct UNewbie_Banner_Item_C : UUAEUserWidget {
	// Fields
	struct UWidgetAnimation* Anim_loading_loop; // Offset: 0x3d0 // Size: 0x08
	struct UWidgetAnimation* AwardPickAnimation; // Offset: 0x3d8 // Size: 0x08
	struct UCanvasPanel* Activity; // Offset: 0x3e0 // Size: 0x08
	struct UTextBlock* ActivityName; // Offset: 0x3e8 // Size: 0x08
	struct UButton* Button_Activity; // Offset: 0x3f0 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_3; // Offset: 0x3f8 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_name; // Offset: 0x400 // Size: 0x08
	struct UImage* Image_Activity; // Offset: 0x408 // Size: 0x08
	struct UImage* Image_CountDown; // Offset: 0x410 // Size: 0x08
	struct UCanvasPanel* Panel_Download; // Offset: 0x418 // Size: 0x08
	struct UTextBlock* UnLockLevel; // Offset: 0x420 // Size: 0x08
	struct FScriptMulticastDelegate ItemMoveLeftDispatcher; // Offset: 0x428 // Size: 0x10
	struct FScriptMulticastDelegate ItemMoveRightDispatcher; // Offset: 0x438 // Size: 0x10
	struct FScriptMulticastDelegate ItemClickDispatcher; // Offset: 0x448 // Size: 0x10

	// Functions

	// Object Name: Function Newbie_Banner_Item.Newbie_Banner_Item_C.ItemClickDispatcher__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void ItemClickDispatcher__DelegateSignature(struct ULobby_Activity_BtnItem_C* Item); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Newbie_Banner_Item.Newbie_Banner_Item_C.ItemMoveRightDispatcher__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void ItemMoveRightDispatcher__DelegateSignature(struct ULobby_Activity_BtnItem_C* Item); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Newbie_Banner_Item.Newbie_Banner_Item_C.ItemMoveLeftDispatcher__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void ItemMoveLeftDispatcher__DelegateSignature(struct ULobby_Activity_BtnItem_C* Item); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x8)
};

