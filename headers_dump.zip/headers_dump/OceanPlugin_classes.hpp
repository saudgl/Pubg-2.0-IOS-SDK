#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class OceanPlugin.AdvancedBuoyancyComponent
// Size: 0x3e0 // Inherited bytes: 0x2d0
struct UAdvancedBuoyancyComponent : USceneComponent {
	// Fields
	bool bUseDrag; // Offset: 0x2c9 // Size: 0x01
	bool bDebugOn; // Offset: 0x2ca // Size: 0x01
	struct AOceanManager* TheOcean; // Offset: 0x2d0 // Size: 0x08
	float WaterDensity; // Offset: 0x2d8 // Size: 0x04
	float Gravity; // Offset: 0x2dc // Size: 0x04
	float MeshDensity; // Offset: 0x2e0 // Size: 0x04
	char pad_0x2E6[0x12]; // Offset: 0x2e6 // Size: 0x12
	struct UStaticMeshComponent* BuoyantMesh; // Offset: 0x2f8 // Size: 0x08
	struct FTransform MeshTransform; // Offset: 0x300 // Size: 0x30
	float FalseVolume; // Offset: 0x330 // Size: 0x04
	float BuoyancyReductionCoefficient; // Offset: 0x334 // Size: 0x04
	float BuoyancyPitchReductionCoefficient; // Offset: 0x338 // Size: 0x04
	float DensityCorrection; // Offset: 0x33c // Size: 0x04
	float DensityCorrectionModifier; // Offset: 0x340 // Size: 0x04
	float SubmergedVolume; // Offset: 0x344 // Size: 0x04
	float ImpactCoefficient; // Offset: 0x348 // Size: 0x04
	struct FVector DragCoefficient; // Offset: 0x34c // Size: 0x0c
	struct FVector SuctionCoefficient; // Offset: 0x358 // Size: 0x0c
	float ViscousDragCoefficient; // Offset: 0x364 // Size: 0x04
	float MaxSlamAcceleration; // Offset: 0x368 // Size: 0x04
	char pad_0x36C[0x4]; // Offset: 0x36c // Size: 0x04
	struct TArray<struct FVector> AdvancedGridHeight; // Offset: 0x370 // Size: 0x10
	struct TArray<struct FForceTriangle> SubmergedTris; // Offset: 0x380 // Size: 0x10
	struct TArray<float> TriSizes; // Offset: 0x390 // Size: 0x10
	struct TArray<float> TriSubmergedArea; // Offset: 0x3a0 // Size: 0x10
	char pad_0x3B0[0x30]; // Offset: 0x3b0 // Size: 0x30

	// Functions

	// Object Name: Function OceanPlugin.AdvancedBuoyancyComponent.TriangleArea
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	float TriangleArea(struct FVector A, struct FVector B, struct FVector C); // Offset: 0x102273fe8 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function OceanPlugin.AdvancedBuoyancyComponent.SplitTriangle
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	struct TArray<struct FForceTriangle> SplitTriangle(struct FBuoyancyVertex H, struct FBuoyancyVertex M, struct FBuoyancyVertex L, struct FVector InArrow); // Offset: 0x102273e30 // Return & Params: Num(5) Size(0x50)

	// Object Name: Function OceanPlugin.AdvancedBuoyancyComponent.SetMeshDensity
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMeshDensity(float NewDensity, float NewWaterDensity); // Offset: 0x102273d7c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function OceanPlugin.AdvancedBuoyancyComponent.GetOceanDepthFromGrid
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	float GetOceanDepthFromGrid(struct FVector Position, bool bJustGetHeightAtLocation); // Offset: 0x102273cac // Return & Params: Num(3) Size(0x14)

	// Object Name: Function OceanPlugin.AdvancedBuoyancyComponent.GetOcean
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GetOcean(); // Offset: 0x102273c98 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function OceanPlugin.AdvancedBuoyancyComponent.DrawDebugStuff
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void DrawDebugStuff(struct FForceTriangle TriForce, struct FColor DebugColor); // Offset: 0x102273b9c // Return & Params: Num(2) Size(0x70)

	// Object Name: Function OceanPlugin.AdvancedBuoyancyComponent.ApplySlamForce
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void ApplySlamForce(struct FVector SlamForce, struct FVector TriCenter); // Offset: 0x102273ae4 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function OceanPlugin.AdvancedBuoyancyComponent.ApplyForce
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ApplyForce(struct FForceTriangle TriForce); // Offset: 0x102273a20 // Return & Params: Num(1) Size(0x6c)
};

// Object Name: Class OceanPlugin.BuoyancyComponent
// Size: 0x1e0 // Inherited bytes: 0x150
struct UBuoyancyComponent : UMovementComponent {
	// Fields
	struct AOceanManager* OceanManager; // Offset: 0x150 // Size: 0x08
	float MeshDensity; // Offset: 0x158 // Size: 0x04
	float FluidDensity; // Offset: 0x15c // Size: 0x04
	float FluidLinearDamping; // Offset: 0x160 // Size: 0x04
	float FluidAngularDamping; // Offset: 0x164 // Size: 0x04
	struct FVector VelocityDamper; // Offset: 0x168 // Size: 0x0c
	bool ClampMaxVelocity; // Offset: 0x174 // Size: 0x01
	char pad_0x175[0x3]; // Offset: 0x175 // Size: 0x03
	float MaxUnderwaterVelocity; // Offset: 0x178 // Size: 0x04
	float TestPointRadius; // Offset: 0x17c // Size: 0x04
	struct TArray<struct FVector> TestPoints; // Offset: 0x180 // Size: 0x10
	struct TArray<float> PointDensityOverride; // Offset: 0x190 // Size: 0x10
	bool DrawDebugPoints; // Offset: 0x1a0 // Size: 0x01
	bool EnableStayUprightConstraint; // Offset: 0x1a1 // Size: 0x01
	char pad_0x1A2[0x2]; // Offset: 0x1a2 // Size: 0x02
	float StayUprightStiffness; // Offset: 0x1a4 // Size: 0x04
	float StayUprightDamping; // Offset: 0x1a8 // Size: 0x04
	struct FRotator StayUprightDesiredRotation; // Offset: 0x1ac // Size: 0x0c
	bool EnableWaveForces; // Offset: 0x1b8 // Size: 0x01
	char pad_0x1B9[0x3]; // Offset: 0x1b9 // Size: 0x03
	float WaveForceMultiplier; // Offset: 0x1bc // Size: 0x04
	char pad_0x1C0[0x20]; // Offset: 0x1c0 // Size: 0x20
};

// Object Name: Class OceanPlugin.BuoyancyForceComponent
// Size: 0x590 // Inherited bytes: 0x2d0
struct UBuoyancyForceComponent : USceneComponent {
	// Fields
	struct FScriptMulticastDelegate OnContactWater; // Offset: 0x2d0 // Size: 0x10
	struct FScriptMulticastDelegate OnEnterWater; // Offset: 0x2e0 // Size: 0x10
	bool bUseBuoyancyEvent; // Offset: 0x2f0 // Size: 0x01
	char pad_0x2F1[0x7]; // Offset: 0x2f1 // Size: 0x07
	struct AOceanManager* OceanManager; // Offset: 0x2f8 // Size: 0x08
	float MeshDensity; // Offset: 0x300 // Size: 0x04
	float FluidDensity; // Offset: 0x304 // Size: 0x04
	float FluidLinearDamping; // Offset: 0x308 // Size: 0x04
	float FluidAngularDamping; // Offset: 0x30c // Size: 0x04
	struct FVector VelocityDamper; // Offset: 0x310 // Size: 0x0c
	bool ClampMaxVelocity; // Offset: 0x31c // Size: 0x01
	char pad_0x31D[0x3]; // Offset: 0x31d // Size: 0x03
	float MaxUnderwaterVelocity; // Offset: 0x320 // Size: 0x04
	float TestPointRadius; // Offset: 0x324 // Size: 0x04
	struct TArray<struct FVector> TestPoints; // Offset: 0x328 // Size: 0x10
	bool ApplyForceToBones; // Offset: 0x338 // Size: 0x01
	bool SnapToSurfaceIfNoPhysics; // Offset: 0x339 // Size: 0x01
	bool TwoGerstnerIterations; // Offset: 0x33a // Size: 0x01
	char pad_0x33B[0x5]; // Offset: 0x33b // Size: 0x05
	struct TArray<float> PointDensityOverride; // Offset: 0x340 // Size: 0x10
	struct TArray<struct FStructBoneOverride> BoneOverride; // Offset: 0x350 // Size: 0x10
	bool DrawDebugPoints; // Offset: 0x360 // Size: 0x01
	bool DrawDebugSeaLevel; // Offset: 0x361 // Size: 0x01
	bool EnableStayUprightConstraint; // Offset: 0x362 // Size: 0x01
	char pad_0x363[0x1]; // Offset: 0x363 // Size: 0x01
	float StayUprightStiffness; // Offset: 0x364 // Size: 0x04
	float StayUprightDamping; // Offset: 0x368 // Size: 0x04
	struct FRotator StayUprightDesiredRotation; // Offset: 0x36c // Size: 0x0c
	bool EnableWaveForces; // Offset: 0x378 // Size: 0x01
	char pad_0x379[0x3]; // Offset: 0x379 // Size: 0x03
	float WaveForceMultiplier; // Offset: 0x37c // Size: 0x04
	struct USceneComponent* UpdatedComponent; // Offset: 0x380 // Size: 0x08
	enum class ETickingGroup TickGroup; // Offset: 0x388 // Size: 0x01
	bool EnableCustomWaveForce; // Offset: 0x389 // Size: 0x01
	char pad_0x38A[0x2]; // Offset: 0x38a // Size: 0x02
	struct FVector CustomWaveForceTestPointOffset; // Offset: 0x38c // Size: 0x0c
	struct TArray<struct UWaterBoxComponent*> CandidateWaterBoxes; // Offset: 0x398 // Size: 0x10
	char pad_0x3A8[0x1b8]; // Offset: 0x3a8 // Size: 0x1b8
	struct UPhysicsConstraintComponent* UprightConstraintComp; // Offset: 0x560 // Size: 0x08
	char pad_0x568[0x28]; // Offset: 0x568 // Size: 0x28

	// Functions

	// Object Name: Function OceanPlugin.BuoyancyForceComponent.TickBuoyancyForce
	// Flags: [Native|Public|BlueprintCallable]
	void TickBuoyancyForce(float DeltaTime); // Offset: 0x102274924 // Return & Params: Num(1) Size(0x4)

	// Object Name: DelegateFunction OceanPlugin.BuoyancyForceComponent.OnEnterWaterDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnEnterWaterDelegate__DelegateSignature(bool IsUnderWater); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x1)

	// Object Name: DelegateFunction OceanPlugin.BuoyancyForceComponent.OnContactWaterDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnContactWaterDelegate__DelegateSignature(bool IsContactingWater); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function OceanPlugin.BuoyancyForceComponent.NativeSetEnableCustomWaveForce
	// Flags: [Final|Native|Public|BlueprintCallable]
	void NativeSetEnableCustomWaveForce(bool bEnable); // Offset: 0x1022748a0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function OceanPlugin.BuoyancyForceComponent.IsEntirelyUnderWater
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsEntirelyUnderWater(); // Offset: 0x102274868 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function OceanPlugin.BuoyancyForceComponent.IsContactedWater
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsContactedWater(); // Offset: 0x102274844 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function OceanPlugin.BuoyancyForceComponent.EndableUprightConstraint
	// Flags: [Final|RequiredAPI|Native|Public|BlueprintCallable]
	void EndableUprightConstraint(bool bEnable); // Offset: 0x1022747c0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function OceanPlugin.BuoyancyForceComponent.CheckPointInWater
	// Flags: [Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable]
	bool CheckPointInWater(struct FVector Point, bool isWorldPosition); // Offset: 0x1022746f0 // Return & Params: Num(3) Size(0xe)
};

// Object Name: Class OceanPlugin.BuoyantMeshComponent
// Size: 0x8a0 // Inherited bytes: 0x830
struct UBuoyantMeshComponent : UStaticMeshComponent {
	// Fields
	char pad_0x830[0x8]; // Offset: 0x830 // Size: 0x08
	bool bVerticalForcesOnly; // Offset: 0x838 // Size: 0x01
	bool bUseWaterPatch; // Offset: 0x839 // Size: 0x01
	bool bUseStaticForces; // Offset: 0x83a // Size: 0x01
	bool bUseDynamicForces; // Offset: 0x83b // Size: 0x01
	char pad_0x83C[0x4]; // Offset: 0x83c // Size: 0x04
	struct AOceanManager* OceanManager; // Offset: 0x840 // Size: 0x08
	bool bDrawForceArrows; // Offset: 0x848 // Size: 0x01
	bool bDrawWaterline; // Offset: 0x849 // Size: 0x01
	bool bDrawVertices; // Offset: 0x84a // Size: 0x01
	bool bDrawTriangles; // Offset: 0x84b // Size: 0x01
	bool bDrawSubtriangles; // Offset: 0x84c // Size: 0x01
	char pad_0x84D[0x3]; // Offset: 0x84d // Size: 0x03
	float ForceArrowSize; // Offset: 0x850 // Size: 0x04
	bool bOverrideMeshDensity; // Offset: 0x854 // Size: 0x01
	char pad_0x855[0x3]; // Offset: 0x855 // Size: 0x03
	float MeshDensity; // Offset: 0x858 // Size: 0x04
	bool bOverrideMass; // Offset: 0x85c // Size: 0x01
	char pad_0x85D[0x3]; // Offset: 0x85d // Size: 0x03
	float Mass; // Offset: 0x860 // Size: 0x04
	float WaterDensity; // Offset: 0x864 // Size: 0x04
	char pad_0x868[0x28]; // Offset: 0x868 // Size: 0x28
	struct UWaterHeightmapComponent* WaterHeightmap; // Offset: 0x890 // Size: 0x08
	char pad_0x898[0x8]; // Offset: 0x898 // Size: 0x08
};

// Object Name: Class OceanPlugin.FishManager
// Size: 0x420 // Inherited bytes: 0x3c8
struct AFishManager : AActor {
	// Fields
	struct TArray<struct UObject*> flockTypes; // Offset: 0x3c8 // Size: 0x10
	struct TArray<float> numInFlock; // Offset: 0x3d8 // Size: 0x10
	float minZ; // Offset: 0x3e8 // Size: 0x04
	float maxZ; // Offset: 0x3ec // Size: 0x04
	float underwaterBoxLength; // Offset: 0x3f0 // Size: 0x04
	bool attachToPlayer; // Offset: 0x3f4 // Size: 0x01
	bool DebugMode; // Offset: 0x3f5 // Size: 0x01
	char pad_0x3F6[0x2]; // Offset: 0x3f6 // Size: 0x02
	struct UObject* PlayerType; // Offset: 0x3f8 // Size: 0x08
	struct AActor* Player; // Offset: 0x400 // Size: 0x08
	char pad_0x408[0x18]; // Offset: 0x408 // Size: 0x18
};

// Object Name: Class OceanPlugin.FlockFish
// Size: 0x5a8 // Inherited bytes: 0x428
struct AFlockFish : APawn {
	// Fields
	char pad_0x428[0x10]; // Offset: 0x428 // Size: 0x10
	struct USphereComponent* FishInteractionSphere; // Offset: 0x438 // Size: 0x08
	bool isLeader; // Offset: 0x440 // Size: 0x01
	char pad_0x441[0x7]; // Offset: 0x441 // Size: 0x07
	struct TArray<struct UObject*> enemyTypes; // Offset: 0x448 // Size: 0x10
	struct TArray<struct UObject*> preyTypes; // Offset: 0x458 // Size: 0x10
	struct UObject* neighborType; // Offset: 0x468 // Size: 0x08
	float followDist; // Offset: 0x470 // Size: 0x04
	float Speed; // Offset: 0x474 // Size: 0x04
	float MaxSpeed; // Offset: 0x478 // Size: 0x04
	float TurnSpeed; // Offset: 0x47c // Size: 0x04
	float turnFrequency; // Offset: 0x480 // Size: 0x04
	float hungerResetTime; // Offset: 0x484 // Size: 0x04
	float distBehindSpeedUpRange; // Offset: 0x488 // Size: 0x04
	float SeperationDistanceMultiplier; // Offset: 0x48c // Size: 0x04
	float FleeDistanceMultiplier; // Offset: 0x490 // Size: 0x04
	float FleeAccelerationMultiplier; // Offset: 0x494 // Size: 0x04
	float ChaseAccelerationMultiplier; // Offset: 0x498 // Size: 0x04
	float SeekDecelerationMultiplier; // Offset: 0x49c // Size: 0x04
	float AvoidForceMultiplier; // Offset: 0x4a0 // Size: 0x04
	float AvoidanceForce; // Offset: 0x4a4 // Size: 0x04
	struct UObject* PlayerType; // Offset: 0x4a8 // Size: 0x08
	struct FVector underwaterMin; // Offset: 0x4b0 // Size: 0x0c
	struct FVector underwaterMax; // Offset: 0x4bc // Size: 0x0c
	float CustomZSeekMin; // Offset: 0x4c8 // Size: 0x04
	float CustomZSeekMax; // Offset: 0x4cc // Size: 0x04
	float NumNeighborsToEvaluate; // Offset: 0x4d0 // Size: 0x04
	float UpdateEveryTick; // Offset: 0x4d4 // Size: 0x04
	char pad_0x4D8[0x10]; // Offset: 0x4d8 // Size: 0x10
	bool DebugMode; // Offset: 0x4e8 // Size: 0x01
	char pad_0x4E9[0xf]; // Offset: 0x4e9 // Size: 0x0f
	struct AActor* Leader; // Offset: 0x4f8 // Size: 0x08
	struct TArray<struct AActor*> neighbors; // Offset: 0x500 // Size: 0x10
	struct TArray<struct AActor*> nearbyEnemies; // Offset: 0x510 // Size: 0x10
	struct TArray<struct AActor*> nearbyPrey; // Offset: 0x520 // Size: 0x10
	struct TArray<struct AActor*> nearbyFriends; // Offset: 0x530 // Size: 0x10
	struct AActor* fleeTarget; // Offset: 0x540 // Size: 0x08
	struct AActor* preyTarget; // Offset: 0x548 // Size: 0x08
	char pad_0x550[0x50]; // Offset: 0x550 // Size: 0x50
	struct AActor* FishManager; // Offset: 0x5a0 // Size: 0x08

	// Functions

	// Object Name: Function OceanPlugin.FlockFish.OnEndOverlap
	// Flags: [Final|Native|Protected]
	void OnEndOverlap(struct UPrimitiveComponent* activatedComp, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int OtherBodyIndex); // Offset: 0x102275128 // Return & Params: Num(4) Size(0x1c)

	// Object Name: Function OceanPlugin.FlockFish.OnBeginOverlap
	// Flags: [Final|Native|Protected|HasOutParms]
	void OnBeginOverlap(struct UPrimitiveComponent* activatedComp, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Offset: 0x102274f50 // Return & Params: Num(6) Size(0xa8)
};

// Object Name: Class OceanPlugin.InfiniteSystemComponent
// Size: 0x2f0 // Inherited bytes: 0x2d0
struct UInfiniteSystemComponent : USceneComponent {
	// Fields
	bool UpdateInEditor; // Offset: 0x2c9 // Size: 0x01
	enum class EFollowMethod FollowMethod; // Offset: 0x2ca // Size: 0x01
	float GridSnapSize; // Offset: 0x2cc // Size: 0x04
	float MaxLookAtDistance; // Offset: 0x2d0 // Size: 0x04
	bool ScaleByDistance; // Offset: 0x2d4 // Size: 0x01
	float ScaleDistanceFactor; // Offset: 0x2d8 // Size: 0x04
	float ScaleStartDistance; // Offset: 0x2dc // Size: 0x04
	float ScaleMin; // Offset: 0x2e0 // Size: 0x04
	float ScaleMax; // Offset: 0x2e4 // Size: 0x04
	char pad_0x2EB[0x5]; // Offset: 0x2eb // Size: 0x05
};

// Object Name: Class OceanPlugin.OceanManager
// Size: 0x4c0 // Inherited bytes: 0x3c8
struct AOceanManager : AActor {
	// Fields
	bool EnableGerstnerWaves; // Offset: 0x3c8 // Size: 0x01
	char pad_0x3C9[0x3]; // Offset: 0x3c9 // Size: 0x03
	struct FVector GlobalWaveDirection; // Offset: 0x3cc // Size: 0x0c
	float GlobalWaveSpeed; // Offset: 0x3d8 // Size: 0x04
	float GlobalWaveAmplitude; // Offset: 0x3dc // Size: 0x04
	float DistanceCheckAbove; // Offset: 0x3e0 // Size: 0x04
	float DistanceCheckBelow; // Offset: 0x3e4 // Size: 0x04
	struct TArray<struct FWaveParameter> WaveClusters; // Offset: 0x3e8 // Size: 0x10
	struct TArray<struct FWaveSetParameters> WaveSetOffsetsOverride; // Offset: 0x3f8 // Size: 0x10
	float NetWorkTimeOffset; // Offset: 0x408 // Size: 0x04
	bool bEnableLandscapeModulation; // Offset: 0x40c // Size: 0x01
	char pad_0x40D[0x3]; // Offset: 0x40d // Size: 0x03
	float ModulationStartHeight; // Offset: 0x410 // Size: 0x04
	float ModulationMaxHeight; // Offset: 0x414 // Size: 0x04
	float ModulationPower; // Offset: 0x418 // Size: 0x04
	char pad_0x41C[0x4]; // Offset: 0x41c // Size: 0x04
	struct ALandscape* Landscape; // Offset: 0x420 // Size: 0x08
	struct UTexture2D* HeightmapTexture; // Offset: 0x428 // Size: 0x08
	char pad_0x430[0x28]; // Offset: 0x430 // Size: 0x28
	bool bShouldCorrectTime; // Offset: 0x458 // Size: 0x01
	char pad_0x459[0x3]; // Offset: 0x459 // Size: 0x03
	float CorrectTimeInterval; // Offset: 0x45c // Size: 0x04
	char pad_0x460[0x4]; // Offset: 0x460 // Size: 0x04
	float ReplicatedWorldRealTimeSeconds; // Offset: 0x464 // Size: 0x04
	float ServerWorldRealTimeSecondsDelta; // Offset: 0x468 // Size: 0x04
	char pad_0x46C[0x4]; // Offset: 0x46c // Size: 0x04
	struct FScriptMulticastDelegate OnReplicatedWorldRealTimeSeconds; // Offset: 0x470 // Size: 0x10
	bool bEnableWaterBoxModulation; // Offset: 0x480 // Size: 0x01
	char pad_0x481[0x7]; // Offset: 0x481 // Size: 0x07
	struct TArray<struct FBox> WaterBoxes; // Offset: 0x488 // Size: 0x10
	char pad_0x498[0x4]; // Offset: 0x498 // Size: 0x04
	bool bEnableWaterTransformModulation; // Offset: 0x49c // Size: 0x01
	char pad_0x49D[0x3]; // Offset: 0x49d // Size: 0x03
	struct TArray<struct FTransform> WaterTransforms; // Offset: 0x4a0 // Size: 0x10
	struct TArray<struct FVector> WaterBoxExtends; // Offset: 0x4b0 // Size: 0x10

	// Functions

	// Object Name: Function OceanPlugin.OceanManager.OnRep_ReplicatedWorldRealTimeSeconds
	// Flags: [Final|Native|Public]
	void OnRep_ReplicatedWorldRealTimeSeconds(); // Offset: 0x1022758ac // Return & Params: Num(0) Size(0x0)

	// Object Name: Function OceanPlugin.OceanManager.LoadLandscapeHeightmap
	// Flags: [Final|Native|Public|BlueprintCallable]
	void LoadLandscapeHeightmap(struct UTexture2D* Tex2D); // Offset: 0x102275830 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function OceanPlugin.OceanManager.GetHeightmapPixel
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FLinearColor GetHeightmapPixel(float U, float V); // Offset: 0x102275760 // Return & Params: Num(3) Size(0x18)
};

// Object Name: Class OceanPlugin.SegmentOceanManager
// Size: 0x5b0 // Inherited bytes: 0x4c0
struct ASegmentOceanManager : AOceanManager {
	// Fields
	struct TArray<struct UWaterBoxComponent*> CandidateWaterBoxes; // Offset: 0x4c0 // Size: 0x10
	struct TMap<struct UWaterBoxComponent*, struct FSegmentWaterBox> SegmentdWaterBoxes; // Offset: 0x4d0 // Size: 0x50
	char pad_0x520[0x84]; // Offset: 0x520 // Size: 0x84
	float FrequencyScale; // Offset: 0x5a4 // Size: 0x04
	char pad_0x5A8[0x8]; // Offset: 0x5a8 // Size: 0x08

	// Functions

	// Object Name: Function OceanPlugin.SegmentOceanManager.RemoveBoxComponent
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RemoveBoxComponent(struct UWaterBoxComponent* InBoxComponent); // Offset: 0x102275dd0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function OceanPlugin.SegmentOceanManager.AddBoxComponent
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddBoxComponent(struct UWaterBoxComponent* InBoxComponent, struct USplineComponent* InDirectionSpline); // Offset: 0x102275d1c // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class OceanPlugin.TimeManager
// Size: 0x490 // Inherited bytes: 0x3c8
struct ATimeManager : AActor {
	// Fields
	struct FTimeDate CurrentLocalTime; // Offset: 0x3c8 // Size: 0x1c
	float latitude; // Offset: 0x3e4 // Size: 0x04
	float longitude; // Offset: 0x3e8 // Size: 0x04
	int OffsetUTC; // Offset: 0x3ec // Size: 0x04
	int OffsetDST; // Offset: 0x3f0 // Size: 0x04
	bool bAllowDaylightSavings; // Offset: 0x3f4 // Size: 0x01
	bool bDaylightSavingsActive; // Offset: 0x3f5 // Size: 0x01
	char pad_0x3F6[0x2]; // Offset: 0x3f6 // Size: 0x02
	float TimeScaleMultiplier; // Offset: 0x3f8 // Size: 0x04
	float SolarTime; // Offset: 0x3fc // Size: 0x04
	float LocalClockTime; // Offset: 0x400 // Size: 0x04
	float TimeCorrection; // Offset: 0x404 // Size: 0x04
	int LSTM; // Offset: 0x408 // Size: 0x04
	int DayOfYear; // Offset: 0x40c // Size: 0x04
	float EoT; // Offset: 0x410 // Size: 0x04
	float SolarAltAngle; // Offset: 0x414 // Size: 0x04
	float SolarDeclination; // Offset: 0x418 // Size: 0x04
	float SolarAzimuth; // Offset: 0x41c // Size: 0x04
	float SolarHRA; // Offset: 0x420 // Size: 0x04
	float SiderealTime; // Offset: 0x424 // Size: 0x04
	float LunarAltAngle; // Offset: 0x428 // Size: 0x04
	float LunarHRA; // Offset: 0x42c // Size: 0x04
	float LunarDeclination; // Offset: 0x430 // Size: 0x04
	float LunarAzimuth; // Offset: 0x434 // Size: 0x04
	float LunarRightAsc; // Offset: 0x438 // Size: 0x04
	float LunarElapsedDays; // Offset: 0x43c // Size: 0x04
	float EcLongitude; // Offset: 0x440 // Size: 0x04
	float EcLatitude; // Offset: 0x444 // Size: 0x04
	float EcDistance; // Offset: 0x448 // Size: 0x04
	float PartL; // Offset: 0x44c // Size: 0x04
	float PartM; // Offset: 0x450 // Size: 0x04
	float PartF; // Offset: 0x454 // Size: 0x04
	char pad_0x458[0x38]; // Offset: 0x458 // Size: 0x38

	// Functions

	// Object Name: Function OceanPlugin.TimeManager.SetCurrentLocalTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetCurrentLocalTime(float Time); // Offset: 0x1022765c8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function OceanPlugin.TimeManager.IsLeapYear
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsLeapYear(int Year); // Offset: 0x10227653c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function OceanPlugin.TimeManager.InitializeCalendar
	// Flags: [Final|Native|Public|BlueprintCallable]
	void InitializeCalendar(struct FTimeDate Time); // Offset: 0x1022764b4 // Return & Params: Num(1) Size(0x1c)

	// Object Name: Function OceanPlugin.TimeManager.IncrementTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void IncrementTime(float DeltaSeconds); // Offset: 0x102276438 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function OceanPlugin.TimeManager.GetYearPhase
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	float GetYearPhase(); // Offset: 0x102276404 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function OceanPlugin.TimeManager.GetElapsedDayInMinutes
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetElapsedDayInMinutes(); // Offset: 0x1022763d0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function OceanPlugin.TimeManager.GetDaysInYear
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetDaysInYear(int Year); // Offset: 0x102276344 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function OceanPlugin.TimeManager.GetDaysInMonth
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetDaysInMonth(int Year, int Month); // Offset: 0x102276280 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function OceanPlugin.TimeManager.GetDayPhase
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	float GetDayPhase(); // Offset: 0x10227624c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function OceanPlugin.TimeManager.GetDayOfYear
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetDayOfYear(struct FTimeDate Time); // Offset: 0x1022761b4 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function OceanPlugin.TimeManager.CalculateSunAngle
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	struct FRotator CalculateSunAngle(); // Offset: 0x10227617c // Return & Params: Num(1) Size(0xc)

	// Object Name: Function OceanPlugin.TimeManager.CalculateMoonPhase
	// Flags: [Final|Native|Public|BlueprintCallable]
	float CalculateMoonPhase(); // Offset: 0x102276148 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function OceanPlugin.TimeManager.CalculateMoonAngle
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	struct FRotator CalculateMoonAngle(); // Offset: 0x102276110 // Return & Params: Num(1) Size(0xc)
};

// Object Name: Class OceanPlugin.WaterBoxComponent
// Size: 0x7f0 // Inherited bytes: 0x730
struct UWaterBoxComponent : UBoxComponent {
	// Fields
	float AcceptHigherZ; // Offset: 0x72c // Size: 0x04
	struct FVector Direction; // Offset: 0x730 // Size: 0x0c
	float SpeedValue; // Offset: 0x73c // Size: 0x04
	float WaveForceMultiplier; // Offset: 0x740 // Size: 0x04
	struct TArray<struct FTrippleWaveParameter> TrippleWaveClusters; // Offset: 0x748 // Size: 0x10
	float TimeScaleOffset; // Offset: 0x758 // Size: 0x04
	float Offset; // Offset: 0x75c // Size: 0x04
	bool UseSplineDirection; // Offset: 0x760 // Size: 0x01
	char pad_0x761[0x3]; // Offset: 0x761 // Size: 0x03
	float SpeedAttenuationFromSpline; // Offset: 0x764 // Size: 0x04
	bool UseSplineZ; // Offset: 0x768 // Size: 0x01
	char pad_0x769[0x3]; // Offset: 0x769 // Size: 0x03
	float ZOffset; // Offset: 0x76c // Size: 0x04
	float CellSizeX; // Offset: 0x770 // Size: 0x04
	float CellSizeY; // Offset: 0x774 // Size: 0x04
	struct TMap<float, struct FWaterBoxCell> Cells; // Offset: 0x778 // Size: 0x50
	int KeyFactor; // Offset: 0x7c8 // Size: 0x04
	char pad_0x7CC[0x24]; // Offset: 0x7cc // Size: 0x24
};

// Object Name: Class OceanPlugin.WaterHeightmapComponent
// Size: 0x188 // Inherited bytes: 0x110
struct UWaterHeightmapComponent : UActorComponent {
	// Fields
	float DesiredCellSize; // Offset: 0x110 // Size: 0x04
	bool bOnlyCollidingComponents; // Offset: 0x114 // Size: 0x01
	char pad_0x115[0x3]; // Offset: 0x115 // Size: 0x03
	float GridSizeMultiplier; // Offset: 0x118 // Size: 0x04
	bool bDrawUsedTriangles; // Offset: 0x11c // Size: 0x01
	bool bDrawHeightmap; // Offset: 0x11d // Size: 0x01
	char pad_0x11E[0x62]; // Offset: 0x11e // Size: 0x62
	struct AOceanManager* OceanManager; // Offset: 0x180 // Size: 0x08
};

