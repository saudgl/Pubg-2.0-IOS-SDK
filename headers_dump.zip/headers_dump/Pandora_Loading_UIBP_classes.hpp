#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Pandora_Loading_UIBP.Pandora_Loading_UIBP_C
// Size: 0x228 // Inherited bytes: 0x218
struct UPandora_Loading_UIBP_C : UUserWidget {
	// Fields
	struct UButton* Button_Bg; // Offset: 0x218 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_2; // Offset: 0x220 // Size: 0x08
};

