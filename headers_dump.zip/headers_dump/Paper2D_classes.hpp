#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class Paper2D.MaterialExpressionSpriteTextureSampler
// Size: 0x1d8 // Inherited bytes: 0x1b8
struct UMaterialExpressionSpriteTextureSampler : UMaterialExpressionTextureSampleParameter2D {
	// Fields
	bool bSampleAdditionalTextures; // Offset: 0x1b8 // Size: 0x01
	char pad_0x1B9[0x3]; // Offset: 0x1b9 // Size: 0x03
	int AdditionalSlotIndex; // Offset: 0x1bc // Size: 0x04
	struct FText SlotDisplayName; // Offset: 0x1c0 // Size: 0x18
};

// Object Name: Class Paper2D.PaperCharacter
// Size: 0x810 // Inherited bytes: 0x800
struct APaperCharacter : ACharacter {
	// Fields
	struct UPaperFlipbookComponent* Sprite; // Offset: 0x800 // Size: 0x08
	char pad_0x808[0x8]; // Offset: 0x808 // Size: 0x08
};

// Object Name: Class Paper2D.PaperFlipbook
// Size: 0x50 // Inherited bytes: 0x28
struct UPaperFlipbook : UObject {
	// Fields
	float FramesPerSecond; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct TArray<struct FPaperFlipbookKeyFrame> KeyFrames; // Offset: 0x30 // Size: 0x10
	struct UMaterialInterface* DefaultMaterial; // Offset: 0x40 // Size: 0x08
	enum class EFlipbookCollisionMode CollisionSource; // Offset: 0x48 // Size: 0x01
	char pad_0x49[0x7]; // Offset: 0x49 // Size: 0x07

	// Functions

	// Object Name: Function Paper2D.PaperFlipbook.IsValidKeyFrameIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsValidKeyFrameIndex(int Index); // Offset: 0x102372db0 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Paper2D.PaperFlipbook.GetTotalDuration
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetTotalDuration(); // Offset: 0x102372d7c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Paper2D.PaperFlipbook.GetSpriteAtTime
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UPaperSprite* GetSpriteAtTime(float Time, bool bClampToEnds); // Offset: 0x102372cac // Return & Params: Num(3) Size(0x10)

	// Object Name: Function Paper2D.PaperFlipbook.GetSpriteAtFrame
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UPaperSprite* GetSpriteAtFrame(int FrameIndex); // Offset: 0x102372c20 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Paper2D.PaperFlipbook.GetNumKeyFrames
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetNumKeyFrames(); // Offset: 0x102372c04 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Paper2D.PaperFlipbook.GetNumFrames
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetNumFrames(); // Offset: 0x102372bd0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Paper2D.PaperFlipbook.GetKeyFrameIndexAtTime
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetKeyFrameIndexAtTime(float Time, bool bClampToEnds); // Offset: 0x102372b00 // Return & Params: Num(3) Size(0xc)
};

// Object Name: Class Paper2D.PaperFlipbookActor
// Size: 0x3d0 // Inherited bytes: 0x3c8
struct APaperFlipbookActor : AActor {
	// Fields
	struct UPaperFlipbookComponent* RenderComponent; // Offset: 0x3c8 // Size: 0x08
};

// Object Name: Class Paper2D.PaperFlipbookComponent
// Size: 0x770 // Inherited bytes: 0x730
struct UPaperFlipbookComponent : UMeshComponent {
	// Fields
	struct UPaperFlipbook* SourceFlipbook; // Offset: 0x728 // Size: 0x08
	struct UMaterialInterface* Material; // Offset: 0x730 // Size: 0x08
	float PlayRate; // Offset: 0x738 // Size: 0x04
	char bLooping : 1; // Offset: 0x73c // Size: 0x01
	char bReversePlayback : 1; // Offset: 0x73c // Size: 0x01
	char bPlaying : 1; // Offset: 0x73c // Size: 0x01
	float AccumulatedTime; // Offset: 0x740 // Size: 0x04
	int CachedFrameIndex; // Offset: 0x744 // Size: 0x04
	struct FLinearColor SpriteColor; // Offset: 0x748 // Size: 0x10
	struct UBodySetup* CachedBodySetup; // Offset: 0x758 // Size: 0x08
	struct FScriptMulticastDelegate OnFinishedPlaying; // Offset: 0x760 // Size: 0x10

	// Functions

	// Object Name: Function Paper2D.PaperFlipbookComponent.Stop
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Stop(); // Offset: 0x10237391c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Paper2D.PaperFlipbookComponent.SetSpriteColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetSpriteColor(struct FLinearColor NewColor); // Offset: 0x1023738a0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Paper2D.PaperFlipbookComponent.SetPlayRate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPlayRate(float NewRate); // Offset: 0x102373824 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Paper2D.PaperFlipbookComponent.SetPlaybackPositionInFrames
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPlaybackPositionInFrames(int NewFramePosition, bool bFireEvents); // Offset: 0x102373768 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Paper2D.PaperFlipbookComponent.SetPlaybackPosition
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPlaybackPosition(float NewPosition, bool bFireEvents); // Offset: 0x1023736a8 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Paper2D.PaperFlipbookComponent.SetNewTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetNewTime(float NewTime); // Offset: 0x10237362c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Paper2D.PaperFlipbookComponent.SetLooping
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLooping(bool bNewLooping); // Offset: 0x1023735a8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Paper2D.PaperFlipbookComponent.SetFlipbook
	// Flags: [Native|Public|BlueprintCallable]
	bool SetFlipbook(struct UPaperFlipbook* NewFlipbook); // Offset: 0x102373514 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Paper2D.PaperFlipbookComponent.ReverseFromEnd
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ReverseFromEnd(); // Offset: 0x102373500 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Paper2D.PaperFlipbookComponent.Reverse
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Reverse(); // Offset: 0x1023734ec // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Paper2D.PaperFlipbookComponent.PlayFromStart
	// Flags: [Final|Native|Public|BlueprintCallable]
	void PlayFromStart(); // Offset: 0x1023734d8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Paper2D.PaperFlipbookComponent.Play
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Play(); // Offset: 0x1023734c4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Paper2D.PaperFlipbookComponent.OnRep_SourceFlipbook
	// Flags: [Final|Native|Protected]
	void OnRep_SourceFlipbook(struct UPaperFlipbook* OldFlipbook); // Offset: 0x102373448 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Paper2D.PaperFlipbookComponent.IsReversing
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsReversing(); // Offset: 0x102373414 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Paper2D.PaperFlipbookComponent.IsPlaying
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsPlaying(); // Offset: 0x1023733e0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Paper2D.PaperFlipbookComponent.IsLooping
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsLooping(); // Offset: 0x1023733ac // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Paper2D.PaperFlipbookComponent.GetPlayRate
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetPlayRate(); // Offset: 0x102373378 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Paper2D.PaperFlipbookComponent.GetPlaybackPositionInFrames
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetPlaybackPositionInFrames(); // Offset: 0x102373344 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Paper2D.PaperFlipbookComponent.GetPlaybackPosition
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetPlaybackPosition(); // Offset: 0x102373310 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Paper2D.PaperFlipbookComponent.GetFlipbookLengthInFrames
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetFlipbookLengthInFrames(); // Offset: 0x1023732dc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Paper2D.PaperFlipbookComponent.GetFlipbookLength
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetFlipbookLength(); // Offset: 0x1023732a8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Paper2D.PaperFlipbookComponent.GetFlipbookFramerate
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetFlipbookFramerate(); // Offset: 0x102373274 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Paper2D.PaperFlipbookComponent.GetFlipbook
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure]
	struct UPaperFlipbook* GetFlipbook(); // Offset: 0x102373238 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Paper2D.PaperGroupedSpriteActor
// Size: 0x3d0 // Inherited bytes: 0x3c8
struct APaperGroupedSpriteActor : AActor {
	// Fields
	struct UPaperGroupedSpriteComponent* RenderComponent; // Offset: 0x3c8 // Size: 0x08
};

// Object Name: Class Paper2D.PaperGroupedSpriteComponent
// Size: 0x760 // Inherited bytes: 0x730
struct UPaperGroupedSpriteComponent : UMeshComponent {
	// Fields
	struct TArray<struct UMaterialInterface*> InstanceMaterials; // Offset: 0x728 // Size: 0x10
	struct TArray<struct FSpriteInstanceData> PerInstanceSpriteData; // Offset: 0x738 // Size: 0x10
	char pad_0x750[0x10]; // Offset: 0x750 // Size: 0x10

	// Functions

	// Object Name: Function Paper2D.PaperGroupedSpriteComponent.UpdateInstanceTransform
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	bool UpdateInstanceTransform(int InstanceIndex, struct FTransform& NewInstanceTransform, bool bWorldSpace, bool bMarkRenderStateDirty, bool bTeleport); // Offset: 0x102374764 // Return & Params: Num(6) Size(0x44)

	// Object Name: Function Paper2D.PaperGroupedSpriteComponent.UpdateInstanceColor
	// Flags: [Native|Public|HasDefaults|BlueprintCallable]
	bool UpdateInstanceColor(int InstanceIndex, struct FLinearColor NewInstanceColor, bool bMarkRenderStateDirty); // Offset: 0x102374650 // Return & Params: Num(4) Size(0x16)

	// Object Name: Function Paper2D.PaperGroupedSpriteComponent.SortInstancesAlongAxis
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SortInstancesAlongAxis(struct FVector WorldSpaceSortAxis); // Offset: 0x1023745d4 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function Paper2D.PaperGroupedSpriteComponent.RemoveInstance
	// Flags: [Native|Public|BlueprintCallable]
	bool RemoveInstance(int InstanceIndex); // Offset: 0x102374540 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Paper2D.PaperGroupedSpriteComponent.GetInstanceTransform
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	bool GetInstanceTransform(int InstanceIndex, struct FTransform& OutInstanceTransform, bool bWorldSpace); // Offset: 0x10237440c // Return & Params: Num(4) Size(0x42)

	// Object Name: Function Paper2D.PaperGroupedSpriteComponent.GetInstanceCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetInstanceCount(); // Offset: 0x1023743d8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Paper2D.PaperGroupedSpriteComponent.ClearInstances
	// Flags: [Native|Public|BlueprintCallable]
	void ClearInstances(); // Offset: 0x1023743bc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Paper2D.PaperGroupedSpriteComponent.AddInstance
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	int AddInstance(struct FTransform& Transform, struct UPaperSprite* Sprite, bool bWorldSpace, struct FLinearColor Color); // Offset: 0x102374244 // Return & Params: Num(5) Size(0x50)
};

// Object Name: Class Paper2D.PaperRuntimeSettings
// Size: 0x30 // Inherited bytes: 0x28
struct UPaperRuntimeSettings : UObject {
	// Fields
	bool bEnableSpriteAtlasGroups; // Offset: 0x28 // Size: 0x01
	bool bEnableTerrainSplineEditing; // Offset: 0x29 // Size: 0x01
	bool bResizeSpriteDataToMatchTextures; // Offset: 0x2a // Size: 0x01
	char pad_0x2B[0x5]; // Offset: 0x2b // Size: 0x05
};

// Object Name: Class Paper2D.PaperSprite
// Size: 0xc0 // Inherited bytes: 0x28
struct UPaperSprite : UObject {
	// Fields
	char pad_0x28[0x10]; // Offset: 0x28 // Size: 0x10
	struct FVector2D SourceUV; // Offset: 0x38 // Size: 0x08
	struct FVector2D SourceDimension; // Offset: 0x40 // Size: 0x08
	struct UTexture2D* SourceTexture; // Offset: 0x48 // Size: 0x08
	struct TArray<struct UTexture*> AdditionalSourceTextures; // Offset: 0x50 // Size: 0x10
	struct FVector2D BakedSourceUV; // Offset: 0x60 // Size: 0x08
	struct FVector2D BakedSourceDimension; // Offset: 0x68 // Size: 0x08
	struct UTexture2D* BakedSourceTexture; // Offset: 0x70 // Size: 0x08
	struct UMaterialInterface* DefaultMaterial; // Offset: 0x78 // Size: 0x08
	struct UMaterialInterface* AlternateMaterial; // Offset: 0x80 // Size: 0x08
	struct TArray<struct FPaperSpriteSocket> Sockets; // Offset: 0x88 // Size: 0x10
	enum class ESpriteCollisionMode SpriteCollisionDomain; // Offset: 0x98 // Size: 0x01
	char pad_0x99[0x3]; // Offset: 0x99 // Size: 0x03
	float PixelsPerUnrealUnit; // Offset: 0x9c // Size: 0x04
	struct UBodySetup* BodySetup; // Offset: 0xa0 // Size: 0x08
	int AlternateMaterialSplitIndex; // Offset: 0xa8 // Size: 0x04
	char pad_0xAC[0x4]; // Offset: 0xac // Size: 0x04
	struct TArray<struct FVector4> BakedRenderData; // Offset: 0xb0 // Size: 0x10
};

// Object Name: Class Paper2D.PaperSpriteActor
// Size: 0x3d0 // Inherited bytes: 0x3c8
struct APaperSpriteActor : AActor {
	// Fields
	struct UPaperSpriteComponent* RenderComponent; // Offset: 0x3c8 // Size: 0x08
};

// Object Name: Class Paper2D.PaperSpriteAtlas
// Size: 0x28 // Inherited bytes: 0x28
struct UPaperSpriteAtlas : UObject {
};

// Object Name: Class Paper2D.PaperSpriteBlueprintLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UPaperSpriteBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function Paper2D.PaperSpriteBlueprintLibrary.MakeBrushFromSprite
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FSlateBrush MakeBrushFromSprite(struct UPaperSprite* Sprite, int Width, int Height); // Offset: 0x1023752b4 // Return & Params: Num(4) Size(0xc8)
};

// Object Name: Class Paper2D.PaperSpriteComponent
// Size: 0x750 // Inherited bytes: 0x730
struct UPaperSpriteComponent : UMeshComponent {
	// Fields
	struct UPaperSprite* SourceSprite; // Offset: 0x728 // Size: 0x08
	struct UMaterialInterface* MaterialOverride; // Offset: 0x730 // Size: 0x08
	struct FLinearColor SpriteColor; // Offset: 0x738 // Size: 0x10

	// Functions

	// Object Name: Function Paper2D.PaperSpriteComponent.SetSpriteColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetSpriteColor(struct FLinearColor NewColor); // Offset: 0x1023755f0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Paper2D.PaperSpriteComponent.SetSprite
	// Flags: [Native|Public|BlueprintCallable]
	bool SetSprite(struct UPaperSprite* NewSprite); // Offset: 0x10237555c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Paper2D.PaperSpriteComponent.GetSprite
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure]
	struct UPaperSprite* GetSprite(); // Offset: 0x102375520 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Paper2D.PaperTerrainActor
// Size: 0x3e0 // Inherited bytes: 0x3c8
struct APaperTerrainActor : AActor {
	// Fields
	struct USceneComponent* DummyRoot; // Offset: 0x3c8 // Size: 0x08
	struct UPaperTerrainSplineComponent* SplineComponent; // Offset: 0x3d0 // Size: 0x08
	struct UPaperTerrainComponent* RenderComponent; // Offset: 0x3d8 // Size: 0x08
};

// Object Name: Class Paper2D.PaperTerrainComponent
// Size: 0x760 // Inherited bytes: 0x700
struct UPaperTerrainComponent : UPrimitiveComponent {
	// Fields
	struct UPaperTerrainMaterial* TerrainMaterial; // Offset: 0x700 // Size: 0x08
	bool bClosedSpline; // Offset: 0x708 // Size: 0x01
	bool bFilledSpline; // Offset: 0x709 // Size: 0x01
	char pad_0x70A[0x6]; // Offset: 0x70a // Size: 0x06
	struct UPaperTerrainSplineComponent* AssociatedSpline; // Offset: 0x710 // Size: 0x08
	int RandomSeed; // Offset: 0x718 // Size: 0x04
	float SegmentOverlapAmount; // Offset: 0x71c // Size: 0x04
	struct FLinearColor TerrainColor; // Offset: 0x720 // Size: 0x10
	int ReparamStepsPerSegment; // Offset: 0x730 // Size: 0x04
	enum class ESpriteCollisionMode SpriteCollisionDomain; // Offset: 0x734 // Size: 0x01
	char pad_0x735[0x3]; // Offset: 0x735 // Size: 0x03
	float CollisionThickness; // Offset: 0x738 // Size: 0x04
	char pad_0x73C[0x4]; // Offset: 0x73c // Size: 0x04
	struct UBodySetup* CachedBodySetup; // Offset: 0x740 // Size: 0x08
	char pad_0x748[0x18]; // Offset: 0x748 // Size: 0x18

	// Functions

	// Object Name: Function Paper2D.PaperTerrainComponent.SetTerrainColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetTerrainColor(struct FLinearColor NewColor); // Offset: 0x10237594c // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class Paper2D.PaperTerrainMaterial
// Size: 0x48 // Inherited bytes: 0x30
struct UPaperTerrainMaterial : UDataAsset {
	// Fields
	struct TArray<struct FPaperTerrainMaterialRule> Rules; // Offset: 0x30 // Size: 0x10
	struct UPaperSprite* InteriorFill; // Offset: 0x40 // Size: 0x08
};

// Object Name: Class Paper2D.PaperTerrainSplineComponent
// Size: 0x800 // Inherited bytes: 0x7f0
struct UPaperTerrainSplineComponent : USplineComponent {
	// Fields
	char pad_0x7F0[0x10]; // Offset: 0x7f0 // Size: 0x10
};

// Object Name: Class Paper2D.PaperTileLayer
// Size: 0x98 // Inherited bytes: 0x28
struct UPaperTileLayer : UObject {
	// Fields
	struct FText LayerName; // Offset: 0x28 // Size: 0x18
	int LayerWidth; // Offset: 0x40 // Size: 0x04
	int LayerHeight; // Offset: 0x44 // Size: 0x04
	char bHiddenInGame : 1; // Offset: 0x48 // Size: 0x01
	char bLayerCollides : 1; // Offset: 0x48 // Size: 0x01
	char bOverrideCollisionThickness : 1; // Offset: 0x48 // Size: 0x01
	char bOverrideCollisionOffset : 1; // Offset: 0x48 // Size: 0x01
	char pad_0x48_4 : 4; // Offset: 0x48 // Size: 0x01
	char pad_0x49[0x3]; // Offset: 0x49 // Size: 0x03
	float CollisionThicknessOverride; // Offset: 0x4c // Size: 0x04
	float CollisionOffsetOverride; // Offset: 0x50 // Size: 0x04
	struct FLinearColor LayerColor; // Offset: 0x54 // Size: 0x10
	int AllocatedWidth; // Offset: 0x64 // Size: 0x04
	int AllocatedHeight; // Offset: 0x68 // Size: 0x04
	char pad_0x6C[0x4]; // Offset: 0x6c // Size: 0x04
	struct TArray<struct FPaperTileInfo> AllocatedCells; // Offset: 0x70 // Size: 0x10
	struct UPaperTileSet* TileSet; // Offset: 0x80 // Size: 0x08
	struct TArray<int> AllocatedGrid; // Offset: 0x88 // Size: 0x10
};

// Object Name: Class Paper2D.PaperTileMap
// Size: 0xa8 // Inherited bytes: 0x28
struct UPaperTileMap : UObject {
	// Fields
	int MapWidth; // Offset: 0x28 // Size: 0x04
	int MapHeight; // Offset: 0x2c // Size: 0x04
	int TileWidth; // Offset: 0x30 // Size: 0x04
	int TileHeight; // Offset: 0x34 // Size: 0x04
	float PixelsPerUnrealUnit; // Offset: 0x38 // Size: 0x04
	float SeparationPerTileX; // Offset: 0x3c // Size: 0x04
	float SeparationPerTileY; // Offset: 0x40 // Size: 0x04
	float SeparationPerLayer; // Offset: 0x44 // Size: 0x04
	struct UPaperTileSet* SelectedTileSet; // Offset: 0x48 // Size: 0x28
	struct UMaterialInterface* Material; // Offset: 0x70 // Size: 0x08
	struct TArray<struct UPaperTileLayer*> TileLayers; // Offset: 0x78 // Size: 0x10
	float CollisionThickness; // Offset: 0x88 // Size: 0x04
	enum class ESpriteCollisionMode SpriteCollisionDomain; // Offset: 0x8c // Size: 0x01
	enum class ETileMapProjectionMode ProjectionMode; // Offset: 0x8d // Size: 0x01
	char pad_0x8E[0x2]; // Offset: 0x8e // Size: 0x02
	int HexSideLength; // Offset: 0x90 // Size: 0x04
	char pad_0x94[0x4]; // Offset: 0x94 // Size: 0x04
	struct UBodySetup* BodySetup; // Offset: 0x98 // Size: 0x08
	int LayerNameIndex; // Offset: 0xa0 // Size: 0x04
	char pad_0xA4[0x4]; // Offset: 0xa4 // Size: 0x04
};

// Object Name: Class Paper2D.PaperTileMapActor
// Size: 0x3d0 // Inherited bytes: 0x3c8
struct APaperTileMapActor : AActor {
	// Fields
	struct UPaperTileMapComponent* RenderComponent; // Offset: 0x3c8 // Size: 0x08
};

// Object Name: Class Paper2D.PaperTileMapComponent
// Size: 0x780 // Inherited bytes: 0x730
struct UPaperTileMapComponent : UMeshComponent {
	// Fields
	int MapWidth; // Offset: 0x728 // Size: 0x04
	int MapHeight; // Offset: 0x72c // Size: 0x04
	int TileWidth; // Offset: 0x730 // Size: 0x04
	int TileHeight; // Offset: 0x734 // Size: 0x04
	struct UPaperTileSet* DefaultLayerTileSet; // Offset: 0x738 // Size: 0x08
	struct UMaterialInterface* Material; // Offset: 0x740 // Size: 0x08
	struct TArray<struct UPaperTileLayer*> TileLayers; // Offset: 0x748 // Size: 0x10
	struct FLinearColor TileMapColor; // Offset: 0x758 // Size: 0x10
	int UseSingleLayerIndex; // Offset: 0x768 // Size: 0x04
	bool bUseSingleLayer; // Offset: 0x76c // Size: 0x01
	struct UPaperTileMap* TileMap; // Offset: 0x770 // Size: 0x08
	char pad_0x77D[0x3]; // Offset: 0x77d // Size: 0x03

	// Functions

	// Object Name: Function Paper2D.PaperTileMapComponent.SetTileMapColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetTileMapColor(struct FLinearColor NewColor); // Offset: 0x1023771e0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Paper2D.PaperTileMapComponent.SetTileMap
	// Flags: [Native|Public|BlueprintCallable]
	bool SetTileMap(struct UPaperTileMap* NewTileMap); // Offset: 0x10237714c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Paper2D.PaperTileMapComponent.SetTile
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTile(int X, int Y, int Layer, struct FPaperTileInfo NewValue); // Offset: 0x102377018 // Return & Params: Num(4) Size(0x20)

	// Object Name: Function Paper2D.PaperTileMapComponent.SetLayerColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetLayerColor(struct FLinearColor NewColor, int Layer); // Offset: 0x102376f60 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Paper2D.PaperTileMapComponent.SetLayerCollision
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLayerCollision(int Layer, bool bHasCollision, bool bOverrideThickness, float CustomThickness, bool bOverrideOffset, float CustomOffset, bool bRebuildCollision); // Offset: 0x102376d4c // Return & Params: Num(7) Size(0x15)

	// Object Name: Function Paper2D.PaperTileMapComponent.SetDefaultCollisionThickness
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDefaultCollisionThickness(float Thickness, bool bRebuildCollision); // Offset: 0x102376c8c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Paper2D.PaperTileMapComponent.ResizeMap
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ResizeMap(int NewWidthInTiles, int NewHeightInTiles); // Offset: 0x102376bd8 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Paper2D.PaperTileMapComponent.RebuildCollision
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RebuildCollision(); // Offset: 0x102376bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Paper2D.PaperTileMapComponent.OwnsTileMap
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool OwnsTileMap(); // Offset: 0x102376b90 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Paper2D.PaperTileMapComponent.MakeTileMapEditable
	// Flags: [Final|Native|Public|BlueprintCallable]
	void MakeTileMapEditable(); // Offset: 0x102376b7c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Paper2D.PaperTileMapComponent.GetTilePolygon
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetTilePolygon(int TileX, int TileY, struct TArray<struct FVector>& Points, int LayerIndex, bool bWorldSpace); // Offset: 0x1023769d0 // Return & Params: Num(5) Size(0x1d)

	// Object Name: Function Paper2D.PaperTileMapComponent.GetTileMapColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FLinearColor GetTileMapColor(); // Offset: 0x102376990 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Paper2D.PaperTileMapComponent.GetTileCornerPosition
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector GetTileCornerPosition(int TileX, int TileY, int LayerIndex, bool bWorldSpace); // Offset: 0x10237684c // Return & Params: Num(5) Size(0x1c)

	// Object Name: Function Paper2D.PaperTileMapComponent.GetTileCenterPosition
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector GetTileCenterPosition(int TileX, int TileY, int LayerIndex, bool bWorldSpace); // Offset: 0x102376708 // Return & Params: Num(5) Size(0x1c)

	// Object Name: Function Paper2D.PaperTileMapComponent.GetTile
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FPaperTileInfo GetTile(int X, int Y, int Layer); // Offset: 0x102376604 // Return & Params: Num(4) Size(0x20)

	// Object Name: Function Paper2D.PaperTileMapComponent.GetMapSize
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void GetMapSize(int& MapWidth, int& MapHeight, int& NumLayers); // Offset: 0x1023764d8 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Paper2D.PaperTileMapComponent.GetLayerColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FLinearColor GetLayerColor(int Layer); // Offset: 0x102376440 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Paper2D.PaperTileMapComponent.CreateNewTileMap
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CreateNewTileMap(int MapWidth, int MapHeight, int TileWidth, int TileHeight, float PixelsPerUnrealUnit, bool bCreateLayer); // Offset: 0x102376294 // Return & Params: Num(6) Size(0x15)

	// Object Name: Function Paper2D.PaperTileMapComponent.AddNewLayer
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UPaperTileLayer* AddNewLayer(); // Offset: 0x102376260 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Paper2D.PaperTileSet
// Size: 0xa8 // Inherited bytes: 0x28
struct UPaperTileSet : UObject {
	// Fields
	struct FIntPoint TileSize; // Offset: 0x28 // Size: 0x08
	struct UTexture2D* TileSheet; // Offset: 0x30 // Size: 0x08
	struct TArray<struct UTexture*> AdditionalSourceTextures; // Offset: 0x38 // Size: 0x10
	struct FIntMargin BorderMargin; // Offset: 0x48 // Size: 0x10
	struct FIntPoint PerTileSpacing; // Offset: 0x58 // Size: 0x08
	struct FIntPoint DrawingOffset; // Offset: 0x60 // Size: 0x08
	int WidthInTiles; // Offset: 0x68 // Size: 0x04
	int HeightInTiles; // Offset: 0x6c // Size: 0x04
	int AllocatedWidth; // Offset: 0x70 // Size: 0x04
	int AllocatedHeight; // Offset: 0x74 // Size: 0x04
	struct TArray<struct FPaperTileMetadata> PerTileData; // Offset: 0x78 // Size: 0x10
	struct TArray<struct FPaperTileSetTerrain> Terrains; // Offset: 0x88 // Size: 0x10
	int TileWidth; // Offset: 0x98 // Size: 0x04
	int TileHeight; // Offset: 0x9c // Size: 0x04
	int Margin; // Offset: 0xa0 // Size: 0x04
	int Spacing; // Offset: 0xa4 // Size: 0x04
};

// Object Name: Class Paper2D.TileMapBlueprintLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UTileMapBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function Paper2D.TileMapBlueprintLibrary.MakeTile
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FPaperTileInfo MakeTile(int TileIndex, struct UPaperTileSet* TileSet, bool bFlipH, bool bFlipV, bool bFlipD); // Offset: 0x10237adc4 // Return & Params: Num(6) Size(0x28)

	// Object Name: Function Paper2D.TileMapBlueprintLibrary.GetTileUserData
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FName GetTileUserData(struct FPaperTileInfo Tile); // Offset: 0x10237ad40 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Paper2D.TileMapBlueprintLibrary.GetTileTransform
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FTransform GetTileTransform(struct FPaperTileInfo Tile); // Offset: 0x10237aca8 // Return & Params: Num(2) Size(0x40)

	// Object Name: Function Paper2D.TileMapBlueprintLibrary.BreakTile
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	void BreakTile(struct FPaperTileInfo Tile, int& TileIndex, struct UPaperTileSet*& TileSet, bool& bFlipH, bool& bFlipV, bool& bFlipD); // Offset: 0x10237aaa0 // Return & Params: Num(6) Size(0x23)
};

