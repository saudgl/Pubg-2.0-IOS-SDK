#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class PhotonDestructible.FracturedMesh
// Size: 0x70 // Inherited bytes: 0x28
struct UFracturedMesh : UObject {
	// Fields
	struct TArray<struct UFracturedFragmentInfo*> FracturedFragmentInfo; // Offset: 0x28 // Size: 0x10
	int ClipPlaneMaterialIndex; // Offset: 0x38 // Size: 0x04
	enum class EFracturedAxis FracturedClipAxis; // Offset: 0x3c // Size: 0x01
	char pad_0x3D[0x33]; // Offset: 0x3d // Size: 0x33
};

// Object Name: Class PhotonDestructible.FracturedMeshSettings
// Size: 0x28 // Inherited bytes: 0x28
struct UFracturedMeshSettings : UObject {
};

// Object Name: Class PhotonDestructible.FracturedSkeletalMesh
// Size: 0x3e0 // Inherited bytes: 0x358
struct UFracturedSkeletalMesh : USkeletalMesh {
	// Fields
	struct UFracturedMesh* FracturedMesh; // Offset: 0x358 // Size: 0x08
	char GenerateNormalSimplifiedLOD : 1; // Offset: 0x360 // Size: 0x01
	char pad_0x360_1 : 7; // Offset: 0x360 // Size: 0x01
	char pad_0x361[0x7]; // Offset: 0x361 // Size: 0x07
	struct TArray<struct FKConvexElem> NormalConvexElemForCollision; // Offset: 0x368 // Size: 0x10
	char pad_0x378[0x68]; // Offset: 0x378 // Size: 0x68
};

// Object Name: Class PhotonDestructible.FracturedSkeletalMeshActor
// Size: 0x420 // Inherited bytes: 0x3c8
struct AFracturedSkeletalMeshActor : AActor {
	// Fields
	char pad_0x3C8[0x8]; // Offset: 0x3c8 // Size: 0x08
	struct UFracturedSkinnedMeshComponent* FracturedSkinnedMeshComponent; // Offset: 0x3d0 // Size: 0x08
	float SingleFragmentHP; // Offset: 0x3d8 // Size: 0x04
	char EnableImpactDamage : 1; // Offset: 0x3dc // Size: 0x01
	char pad_0x3DC_1 : 7; // Offset: 0x3dc // Size: 0x01
	char pad_0x3DD[0x3]; // Offset: 0x3dd // Size: 0x03
	float ImpactDamageValue; // Offset: 0x3e0 // Size: 0x04
	float ImpactImpulseForce; // Offset: 0x3e4 // Size: 0x04
	struct FFSkeletalMeshNetData FSMNetData; // Offset: 0x3e8 // Size: 0x38

	// Functions

	// Object Name: Function PhotonDestructible.FracturedSkeletalMeshActor.Server_OnActorHitAction
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	void Server_OnActorHitAction(struct AActor* SelfActor, struct AActor* OtherActor, struct FVector NormalImpulse, struct FHitResult& Hit); // Offset: 0x102416750 // Return & Params: Num(4) Size(0xa8)

	// Object Name: Function PhotonDestructible.FracturedSkeletalMeshActor.OnRep_FSMNetData
	// Flags: [Final|Native|Public]
	void OnRep_FSMNetData(); // Offset: 0x10241673c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function PhotonDestructible.FracturedSkeletalMeshActor.Client_OnImpact
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public|HasDefaults]
	void Client_OnImpact(int FragmentIndex, struct FVector ImpactWorldPos, struct FVector ImpactWorldDir, float ImpulseForce, float InFirstImpactTime); // Offset: 0x1024165d4 // Return & Params: Num(5) Size(0x24)
};

// Object Name: Class PhotonDestructible.FracturedSkinnedMeshComponent
// Size: 0x960 // Inherited bytes: 0x8a0
struct UFracturedSkinnedMeshComponent : USkinnedMeshComponent {
	// Fields
	char pad_0x8A0[0x50]; // Offset: 0x8a0 // Size: 0x50
	enum class EFracturedMeshDestructibleAction DestructibleAction; // Offset: 0x8f0 // Size: 0x01
	enum class EFracturedImpactEffType ImpactEffType; // Offset: 0x8f1 // Size: 0x01
	char pad_0x8F2[0x2]; // Offset: 0x8f2 // Size: 0x02
	float ImpactEffSpreadOutFactor; // Offset: 0x8f4 // Size: 0x04
	float ShowFracturedMaxDistance; // Offset: 0x8f8 // Size: 0x04
	float ShowFracturedMaxDistanceBuffer; // Offset: 0x8fc // Size: 0x04
	float ShowFracturedTime; // Offset: 0x900 // Size: 0x04
	char RemovePhysicsIfFragmentHidden : 1; // Offset: 0x904 // Size: 0x01
	char pad_0x904_1 : 7; // Offset: 0x904 // Size: 0x01
	char pad_0x905[0x3]; // Offset: 0x905 // Size: 0x03
	struct UFracturedSkeletalMesh* FracturedMesh; // Offset: 0x908 // Size: 0x08
	struct UBodySetup* BodySetup; // Offset: 0x910 // Size: 0x08
	char pad_0x918[0x48]; // Offset: 0x918 // Size: 0x48
};

// Object Name: Class PhotonDestructible.FracturedStaticMesh
// Size: 0x230 // Inherited bytes: 0x1b8
struct UFracturedStaticMesh : UStaticMesh {
	// Fields
	struct UFracturedMesh* FracturedMesh; // Offset: 0x1b8 // Size: 0x08
	char UseUnDestructedTriangle : 1; // Offset: 0x1c0 // Size: 0x01
	char DistanceFieldEightBit : 1; // Offset: 0x1c0 // Size: 0x01
	char pad_0x1C0_2 : 6; // Offset: 0x1c0 // Size: 0x01
	char pad_0x1C1[0x6f]; // Offset: 0x1c1 // Size: 0x6f
};

// Object Name: Class PhotonDestructible.FracturedStaticMeshActor
// Size: 0x400 // Inherited bytes: 0x3c8
struct AFracturedStaticMeshActor : AActor {
	// Fields
	char pad_0x3C8[0x8]; // Offset: 0x3c8 // Size: 0x08
	struct UFracturedStaticMeshComponent* FracturedStaticMeshComponent; // Offset: 0x3d0 // Size: 0x08
	float SingleFragmentHP; // Offset: 0x3d8 // Size: 0x04
	char EnableImpactDamage : 1; // Offset: 0x3dc // Size: 0x01
	char pad_0x3DC_1 : 7; // Offset: 0x3dc // Size: 0x01
	char pad_0x3DD[0x3]; // Offset: 0x3dd // Size: 0x03
	float ImpactDamageValue; // Offset: 0x3e0 // Size: 0x04
	char pad_0x3E4[0x4]; // Offset: 0x3e4 // Size: 0x04
	struct FFStaticMeshNetData FSMNetData; // Offset: 0x3e8 // Size: 0x18

	// Functions

	// Object Name: Function PhotonDestructible.FracturedStaticMeshActor.Server_OnActorRadiusHitAction
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	void Server_OnActorRadiusHitAction(struct AActor* SelfActor, struct AActor* OtherActor, struct FVector& WorldImpactPoint, float Radius); // Offset: 0x1024172cc // Return & Params: Num(4) Size(0x20)

	// Object Name: Function PhotonDestructible.FracturedStaticMeshActor.Server_OnActorHitAction
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	void Server_OnActorHitAction(struct AActor* SelfActor, struct AActor* OtherActor, struct FVector NormalImpulse, struct FHitResult& Hit); // Offset: 0x10241717c // Return & Params: Num(4) Size(0xa8)

	// Object Name: Function PhotonDestructible.FracturedStaticMeshActor.OnRep_FSMNetData
	// Flags: [Final|Native|Public]
	void OnRep_FSMNetData(); // Offset: 0x102417168 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function PhotonDestructible.FracturedStaticMeshActor.Client_OnFragmentsHPChanged
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public|HasDefaults]
	void Client_OnFragmentsHPChanged(struct TArray<int> FragmentsIndex, struct TArray<float> FragmentsChangedHP, struct FVector WorldImpactPoint, float Radius); // Offset: 0x102416ff8 // Return & Params: Num(4) Size(0x30)

	// Object Name: Function PhotonDestructible.FracturedStaticMeshActor.Client_OnFragmentHPChanged
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public|HasDefaults]
	void Client_OnFragmentHPChanged(int FragmentIndex, float FragmentHP, struct FVector WorldImpactPoint); // Offset: 0x102416f00 // Return & Params: Num(3) Size(0x14)
};

// Object Name: Class PhotonDestructible.FracturedStaticMeshComponent
// Size: 0x910 // Inherited bytes: 0x830
struct UFracturedStaticMeshComponent : UStaticMeshComponent {
	// Fields
	char pad_0x830[0x4d]; // Offset: 0x830 // Size: 0x4d
	enum class EFracturedMeshConnectionType CheckConnectionType; // Offset: 0x87d // Size: 0x01
	char pad_0x87E[0x2]; // Offset: 0x87e // Size: 0x02
	struct UFracturedStaticMesh* FracturedMesh; // Offset: 0x880 // Size: 0x08
	enum class ECollisionEnabled NormalCollisionEnabled; // Offset: 0x888 // Size: 0x01
	char pad_0x889[0x7]; // Offset: 0x889 // Size: 0x07
	struct FName NormalCollisionProfileName; // Offset: 0x890 // Size: 0x08
	enum class ECollisionEnabled AllBrokenCollisionEnabled; // Offset: 0x898 // Size: 0x01
	char pad_0x899[0x7]; // Offset: 0x899 // Size: 0x07
	struct FName AllBrokenCollisionProfileName; // Offset: 0x8a0 // Size: 0x08
	float ShowFracturedMaxDistance; // Offset: 0x8a8 // Size: 0x04
	float ShowFracturedMaxDistanceBuffer; // Offset: 0x8ac // Size: 0x04
	char EnableFracturedMeshDecal : 1; // Offset: 0x8b0 // Size: 0x01
	char pad_0x8B0_1 : 7; // Offset: 0x8b0 // Size: 0x01
	char pad_0x8B1[0x3]; // Offset: 0x8b1 // Size: 0x03
	float FracturedMeshDecalFactor; // Offset: 0x8b4 // Size: 0x04
	int FracturedMeshDecalMaterialIndex; // Offset: 0x8b8 // Size: 0x04
	char pad_0x8BC[0x4]; // Offset: 0x8bc // Size: 0x04
	struct UMaterialInterface* FracturedMeshDecalMaterial; // Offset: 0x8c0 // Size: 0x08
	struct UMaterialInterface* FracturedMeshDecalNormalMaterial; // Offset: 0x8c8 // Size: 0x08
	float ShowDecalMaxDistance; // Offset: 0x8d0 // Size: 0x04
	float ShowDecalMaxDistanceBuffer; // Offset: 0x8d4 // Size: 0x04
	struct UBodySetup* ThisBodySetup; // Offset: 0x8d8 // Size: 0x08
	char pad_0x8E0[0x30]; // Offset: 0x8e0 // Size: 0x30
};

// Object Name: Class PhotonDestructible.FEdgeData
// Size: 0x28 // Inherited bytes: 0x28
struct UFEdgeData : UObject {
};

// Object Name: Class PhotonDestructible.FracturedFragmentInfo
// Size: 0x80 // Inherited bytes: 0x28
struct UFracturedFragmentInfo : UObject {
	// Fields
	struct TArray<struct FKConvexElem> ConvexElemForCollision; // Offset: 0x28 // Size: 0x10
	struct FVector CenterPoint; // Offset: 0x38 // Size: 0x0c
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
	struct TArray<int> neighbors; // Offset: 0x48 // Size: 0x10
	struct TArray<struct FPlane> FacePlaneData; // Offset: 0x58 // Size: 0x10
	struct TArray<struct FVector> PolygonVertex; // Offset: 0x68 // Size: 0x10
	char CanDestroy : 1; // Offset: 0x78 // Size: 0x01
	char HasTriangle : 1; // Offset: 0x78 // Size: 0x01
	char IsBorder : 1; // Offset: 0x78 // Size: 0x01
	char pad_0x78_3 : 5; // Offset: 0x78 // Size: 0x01
	char pad_0x79[0x7]; // Offset: 0x79 // Size: 0x07
};

// Object Name: Class PhotonDestructible.MaterialExpressionObjectLocalPosition
// Size: 0x60 // Inherited bytes: 0x60
struct UMaterialExpressionObjectLocalPosition : UMaterialExpression {
};

// Object Name: Class PhotonDestructible.MaterialExpressionGetPDInstancedSurfaceMask
// Size: 0x60 // Inherited bytes: 0x60
struct UMaterialExpressionGetPDInstancedSurfaceMask : UMaterialExpression {
};

// Object Name: Class PhotonDestructible.PhotonDestructibleAtlasPool
// Size: 0x120 // Inherited bytes: 0x110
struct UPhotonDestructibleAtlasPool : UActorComponent {
	// Fields
	char pad_0x110[0x10]; // Offset: 0x110 // Size: 0x10
};

// Object Name: Class PhotonDestructible.PhotonDestructibleMgr
// Size: 0x3f0 // Inherited bytes: 0x3c8
struct APhotonDestructibleMgr : AActor {
	// Fields
	struct UPhotonDestructibleTexturePool* TexturePool; // Offset: 0x3c8 // Size: 0x08
	struct UPhotonDestructibleAtlasPool* AtlasPool; // Offset: 0x3d0 // Size: 0x08
	struct UPhotonDestructibleTexture2DArrayManager* Texture2DArrayManager; // Offset: 0x3d8 // Size: 0x08
	struct UPhotonDestructibleSurfaceConfig* SurfaceConfig; // Offset: 0x3e0 // Size: 0x08
	struct UPhotonDestructiblePuppetMgr* PuppetMgr; // Offset: 0x3e8 // Size: 0x08
};

// Object Name: Class PhotonDestructible.PhotonDestructiblePuppet
// Size: 0x2e0 // Inherited bytes: 0x2d0
struct UPhotonDestructiblePuppet : USceneComponent {
	// Fields
	struct FGuid TargetPuppetGUID; // Offset: 0x2cc // Size: 0x10

	// Functions

	// Object Name: Function PhotonDestructible.PhotonDestructiblePuppet.TriggerPuppetEvent
	// Flags: [Native|Public|BlueprintCallable]
	void TriggerPuppetEvent(int EventId); // Offset: 0x102417e8c // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class PhotonDestructible.PhotonDestructiblePuppetContainer
// Size: 0x2f0 // Inherited bytes: 0x2d0
struct UPhotonDestructiblePuppetContainer : USceneComponent {
	// Fields
	struct TArray<struct FGuid> TargetsPuppetGUID; // Offset: 0x2d0 // Size: 0x10
	struct TArray<struct FString> TargetsName; // Offset: 0x2e0 // Size: 0x10

	// Functions

	// Object Name: Function PhotonDestructible.PhotonDestructiblePuppetContainer.TriggerPuppetEvent
	// Flags: [Native|Public|BlueprintCallable]
	void TriggerPuppetEvent(struct FString ObjectName, int EventId); // Offset: 0x102418064 // Return & Params: Num(2) Size(0x14)
};

// Object Name: Class PhotonDestructible.PhotonDestructiblePuppetMgr
// Size: 0x160 // Inherited bytes: 0x110
struct UPhotonDestructiblePuppetMgr : UActorComponent {
	// Fields
	char pad_0x110[0x50]; // Offset: 0x110 // Size: 0x50

	// Functions

	// Object Name: Function PhotonDestructible.PhotonDestructiblePuppetMgr.Client_TriggerPuppetEvent
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public|HasDefaults]
	void Client_TriggerPuppetEvent(struct FGuid PuppetGUID, int EventId); // Offset: 0x1024182ec // Return & Params: Num(2) Size(0x14)
};

// Object Name: Class PhotonDestructible.PhotonDestructiblePuppetTarget
// Size: 0x28 // Inherited bytes: 0x28
struct UPhotonDestructiblePuppetTarget : UInterface {
};

// Object Name: Class PhotonDestructible.PhotonDestructibleSurfaceActor
// Size: 0x3d8 // Inherited bytes: 0x3c8
struct APhotonDestructibleSurfaceActor : AActor {
	// Fields
	char pad_0x3C8[0x8]; // Offset: 0x3c8 // Size: 0x08
	struct UPhotonDestructibleSurfaceComponent* SurfaceComponent; // Offset: 0x3d0 // Size: 0x08
};

// Object Name: Class PhotonDestructible.PhotonDestructibleInstancedSurfaceActor
// Size: 0x3d8 // Inherited bytes: 0x3c8
struct APhotonDestructibleInstancedSurfaceActor : AActor {
	// Fields
	char pad_0x3C8[0x8]; // Offset: 0x3c8 // Size: 0x08
	struct UPhotonDestructibleInstancedSurfaceComponent* InstancedSurfaceComponent; // Offset: 0x3d0 // Size: 0x08
};

// Object Name: Class PhotonDestructible.PhotonDestructibleSurfaceActorBase
// Size: 0x28 // Inherited bytes: 0x28
struct UPhotonDestructibleSurfaceActorBase : UInterface {
};

// Object Name: Class PhotonDestructible.PhotonDestructibleInstancedSurfaceActorBase
// Size: 0x28 // Inherited bytes: 0x28
struct UPhotonDestructibleInstancedSurfaceActorBase : UInterface {
};

// Object Name: Class PhotonDestructible.PhotonDestructibleSurfaceComponent
// Size: 0x8b0 // Inherited bytes: 0x830
struct UPhotonDestructibleSurfaceComponent : UStaticMeshComponent {
	// Fields
	char pad_0x830[0x18]; // Offset: 0x830 // Size: 0x18
	enum class EFracturedAxis MaskUAxis; // Offset: 0x848 // Size: 0x01
	enum class EFracturedAxis MaskVAxis; // Offset: 0x849 // Size: 0x01
	char pad_0x84A[0x6]; // Offset: 0x84a // Size: 0x06
	struct UTexture2D* MaskTexture2D; // Offset: 0x850 // Size: 0x08
	struct FPDSurfaceNetData SurfaceNetData; // Offset: 0x858 // Size: 0x18
	struct FGuid TargetPuppetGUID; // Offset: 0x870 // Size: 0x10
	char pad_0x880[0x30]; // Offset: 0x880 // Size: 0x30

	// Functions

	// Object Name: Function PhotonDestructible.PhotonDestructibleSurfaceComponent.Server_ProcessHit
	// Flags: [Final|Native|Public|HasOutParms]
	void Server_ProcessHit(struct FPhotonDestructibleSurfaceHitData& HitData); // Offset: 0x102418c04 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function PhotonDestructible.PhotonDestructibleSurfaceComponent.OnRep_SurfaceNetData
	// Flags: [Final|Native|Public]
	void OnRep_SurfaceNetData(); // Offset: 0x102418bf0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function PhotonDestructible.PhotonDestructibleSurfaceComponent.Client_OnProcessHit
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public]
	void Client_OnProcessHit(struct FPhotonDestructibleSurfaceHitData HitData); // Offset: 0x102418b5c // Return & Params: Num(1) Size(0x18)
};

// Object Name: Class PhotonDestructible.PhotonDestructibleInstancedSurfaceComponent
// Size: 0xae0 // Inherited bytes: 0xa70
struct UPhotonDestructibleInstancedSurfaceComponent : UHierarchicalInstancedStaticMeshComponent {
	// Fields
	char pad_0xA70[0x18]; // Offset: 0xa70 // Size: 0x18
	enum class EFracturedAxis MaskUAxis; // Offset: 0xa88 // Size: 0x01
	enum class EFracturedAxis MaskVAxis; // Offset: 0xa89 // Size: 0x01
	char pad_0xA8A[0x6]; // Offset: 0xa8a // Size: 0x06
	struct UMaterialInterface* Texture2DArrayMaterial; // Offset: 0xa90 // Size: 0x08
	struct UMaterialInterface* AtlasMaterial; // Offset: 0xa98 // Size: 0x08
	struct FPDSurfaceNetData SurfaceNetData; // Offset: 0xaa0 // Size: 0x18
	struct TArray<struct FGuid> TargetPuppetGUID; // Offset: 0xab8 // Size: 0x10
	char pad_0xAC8[0x18]; // Offset: 0xac8 // Size: 0x18

	// Functions

	// Object Name: Function PhotonDestructible.PhotonDestructibleInstancedSurfaceComponent.Server_ProcessHit
	// Flags: [Final|Native|Public|HasOutParms]
	void Server_ProcessHit(struct FPhotonDestructibleSurfaceHitData& HitData); // Offset: 0x102418f84 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function PhotonDestructible.PhotonDestructibleInstancedSurfaceComponent.OnRep_SurfaceNetData
	// Flags: [Final|Native|Public]
	void OnRep_SurfaceNetData(); // Offset: 0x102418f70 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function PhotonDestructible.PhotonDestructibleInstancedSurfaceComponent.Client_OnProcessHit
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public]
	void Client_OnProcessHit(struct FPhotonDestructibleSurfaceHitData HitData); // Offset: 0x102418edc // Return & Params: Num(1) Size(0x18)
};

// Object Name: Class PhotonDestructible.PhotonDestructibleSurfaceBase
// Size: 0x28 // Inherited bytes: 0x28
struct UPhotonDestructibleSurfaceBase : UInterface {
};

// Object Name: Class PhotonDestructible.PhotonDestructibleSurfaceConfig
// Size: 0x120 // Inherited bytes: 0x110
struct UPhotonDestructibleSurfaceConfig : UActorComponent {
	// Fields
	struct TArray<struct UPhotonDestructibleSurfaceMask*> TextureMaskData; // Offset: 0x110 // Size: 0x10
};

// Object Name: Class PhotonDestructible.PhotonDestructibleSurfaceMask
// Size: 0x48 // Inherited bytes: 0x28
struct UPhotonDestructibleSurfaceMask : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	struct FIntPoint MaskSize; // Offset: 0x30 // Size: 0x08
	char pad_0x38[0x10]; // Offset: 0x38 // Size: 0x10
};

// Object Name: Class PhotonDestructible.PhotonDestructibleTexture2DArrayManager
// Size: 0x138 // Inherited bytes: 0x110
struct UPhotonDestructibleTexture2DArrayManager : UActorComponent {
	// Fields
	char pad_0x110[0x28]; // Offset: 0x110 // Size: 0x28
};

// Object Name: Class PhotonDestructible.PhotonDestructibleTexturePool
// Size: 0x130 // Inherited bytes: 0x110
struct UPhotonDestructibleTexturePool : UActorComponent {
	// Fields
	char pad_0x110[0x20]; // Offset: 0x110 // Size: 0x20
};

