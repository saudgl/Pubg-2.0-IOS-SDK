#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass Pickup_Jacket_633_int.Pickup_Jacket_633_int_C
// Size: 0x808 // Inherited bytes: 0x800
struct APickup_Jacket_633_int_C : APickUpWrapperActor {
	// Fields
	struct UStaticMeshComponent* Bag_03_icon; // Offset: 0x800 // Size: 0x08

	// Functions

	// Object Name: Function Pickup_Jacket_633_int.Pickup_Jacket_633_int_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)
};

