#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass PlaneAvatarHandleBase_BP.PlaneAvatarHandleBase_BP_C
// Size: 0x1c8 // Inherited bytes: 0x1c0
struct UPlaneAvatarHandleBase_BP_C : UBackpackPlaneAvatarHandle {
	// Fields
	struct ACharacter* PlaneActorClass; // Offset: 0x1c0 // Size: 0x08
};

