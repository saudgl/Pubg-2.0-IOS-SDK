#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class ProceduralMeshComponent.ProceduralMeshComponent
// Size: 0x790 // Inherited bytes: 0x730
struct UProceduralMeshComponent : UMeshComponent {
	// Fields
	bool bUseComplexAsSimpleCollision; // Offset: 0x730 // Size: 0x01
	bool bUseAsyncCooking; // Offset: 0x731 // Size: 0x01
	char pad_0x732[0x6]; // Offset: 0x732 // Size: 0x06
	struct UBodySetup* ProcMeshBodySetup; // Offset: 0x738 // Size: 0x08
	struct TArray<struct FProcMeshSection> ProcMeshSections; // Offset: 0x740 // Size: 0x10
	struct TArray<struct FKConvexElem> CollisionConvexElems; // Offset: 0x750 // Size: 0x10
	struct FBoxSphereBounds LocalBounds; // Offset: 0x760 // Size: 0x1c
	char pad_0x77C[0x4]; // Offset: 0x77c // Size: 0x04
	struct TArray<struct UBodySetup*> AsyncBodySetupQueue; // Offset: 0x780 // Size: 0x10

	// Functions

	// Object Name: Function ProceduralMeshComponent.ProceduralMeshComponent.UpdateMeshSection_LinearColor
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void UpdateMeshSection_LinearColor(int SectionIndex, struct TArray<struct FVector>& Vertices, struct TArray<struct FVector>& Normals, struct TArray<struct FVector2D>& UV0, struct TArray<struct FLinearColor>& VertexColors, struct TArray<struct FProcMeshTangent>& Tangents); // Offset: 0x10253c580 // Return & Params: Num(6) Size(0x58)

	// Object Name: Function ProceduralMeshComponent.ProceduralMeshComponent.UpdateMeshSection
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void UpdateMeshSection(int SectionIndex, struct TArray<struct FVector>& Vertices, struct TArray<struct FVector>& Normals, struct TArray<struct FVector2D>& UV0, struct TArray<struct FColor>& VertexColors, struct TArray<struct FProcMeshTangent>& Tangents); // Offset: 0x10253c2ec // Return & Params: Num(6) Size(0x58)

	// Object Name: Function ProceduralMeshComponent.ProceduralMeshComponent.SetMeshSectionVisible
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMeshSectionVisible(int SectionIndex, bool bNewVisibility); // Offset: 0x10253c230 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function ProceduralMeshComponent.ProceduralMeshComponent.IsMeshSectionVisible
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsMeshSectionVisible(int SectionIndex); // Offset: 0x10253c1a4 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function ProceduralMeshComponent.ProceduralMeshComponent.GetNumSections
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetNumSections(); // Offset: 0x10253c170 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function ProceduralMeshComponent.ProceduralMeshComponent.CreateMeshSection_LinearColor
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void CreateMeshSection_LinearColor(int SectionIndex, struct TArray<struct FVector>& Vertices, struct TArray<int>& Triangles, struct TArray<struct FVector>& Normals, struct TArray<struct FVector2D>& UV0, struct TArray<struct FLinearColor>& VertexColors, struct TArray<struct FProcMeshTangent>& Tangents, bool bCreateCollision); // Offset: 0x10253be1c // Return & Params: Num(8) Size(0x69)

	// Object Name: Function ProceduralMeshComponent.ProceduralMeshComponent.CreateMeshSection
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void CreateMeshSection(int SectionIndex, struct TArray<struct FVector>& Vertices, struct TArray<int>& Triangles, struct TArray<struct FVector>& Normals, struct TArray<struct FVector2D>& UV0, struct TArray<struct FColor>& VertexColors, struct TArray<struct FProcMeshTangent>& Tangents, bool bCreateCollision); // Offset: 0x10253bac8 // Return & Params: Num(8) Size(0x69)

	// Object Name: Function ProceduralMeshComponent.ProceduralMeshComponent.ClearMeshSection
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearMeshSection(int SectionIndex); // Offset: 0x10253ba4c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function ProceduralMeshComponent.ProceduralMeshComponent.ClearCollisionConvexMeshes
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearCollisionConvexMeshes(); // Offset: 0x10253ba38 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ProceduralMeshComponent.ProceduralMeshComponent.ClearAllMeshSections
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearAllMeshSections(); // Offset: 0x10253ba24 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ProceduralMeshComponent.ProceduralMeshComponent.AddCollisionConvexMesh
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddCollisionConvexMesh(struct TArray<struct FVector> ConvexVerts); // Offset: 0x10253b940 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class ProceduralMeshComponent.KismetProceduralMeshLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UKismetProceduralMeshLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function ProceduralMeshComponent.KismetProceduralMeshLibrary.SliceProceduralMesh
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SliceProceduralMesh(struct UProceduralMeshComponent* InProcMesh, struct FVector PlanePosition, struct FVector PlaneNormal, bool bCreateOtherHalf, struct UProceduralMeshComponent*& OutOtherHalfProcMesh, enum class EProcMeshSliceCapOption CapOption, struct UMaterialInterface* CapMaterial); // Offset: 0x10253b1e8 // Return & Params: Num(7) Size(0x40)

	// Object Name: Function ProceduralMeshComponent.KismetProceduralMeshLibrary.GetSectionFromStaticMesh
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetSectionFromStaticMesh(struct UStaticMesh* InMesh, int LODIndex, int SectionIndex, struct TArray<struct FVector>& Vertices, struct TArray<int>& Triangles, struct TArray<struct FVector>& Normals, struct TArray<struct FVector2D>& UVs, struct TArray<struct FProcMeshTangent>& Tangents); // Offset: 0x10253aee8 // Return & Params: Num(8) Size(0x60)

	// Object Name: Function ProceduralMeshComponent.KismetProceduralMeshLibrary.GenerateBoxMesh
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void GenerateBoxMesh(struct FVector BoxRadius, struct TArray<struct FVector>& Vertices, struct TArray<int>& Triangles, struct TArray<struct FVector>& Normals, struct TArray<struct FVector2D>& UVs, struct TArray<struct FProcMeshTangent>& Tangents); // Offset: 0x10253ac5c // Return & Params: Num(6) Size(0x60)

	// Object Name: Function ProceduralMeshComponent.KismetProceduralMeshLibrary.CreateGridMeshTriangles
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void CreateGridMeshTriangles(int NumX, int NumY, bool bWinding, struct TArray<int>& Triangles); // Offset: 0x10253ab00 // Return & Params: Num(4) Size(0x20)

	// Object Name: Function ProceduralMeshComponent.KismetProceduralMeshLibrary.CopyProceduralMeshFromStaticMeshComponent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void CopyProceduralMeshFromStaticMeshComponent(struct UStaticMeshComponent* StaticMeshComponent, int LODIndex, struct UProceduralMeshComponent* ProcMeshComponent, bool bCreateCollision); // Offset: 0x10253a9d0 // Return & Params: Num(4) Size(0x19)

	// Object Name: Function ProceduralMeshComponent.KismetProceduralMeshLibrary.ConvertQuadToTriangles
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void ConvertQuadToTriangles(struct TArray<int>& Triangles, int Vert0, int Vert1, int Vert2, int Vert3); // Offset: 0x10253a834 // Return & Params: Num(5) Size(0x20)

	// Object Name: Function ProceduralMeshComponent.KismetProceduralMeshLibrary.CalculateTangentsForMesh
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void CalculateTangentsForMesh(struct TArray<struct FVector>& Vertices, struct TArray<int>& Triangles, struct TArray<struct FVector2D>& UVs, struct TArray<struct FVector>& Normals, struct TArray<struct FProcMeshTangent>& Tangents); // Offset: 0x10253a5e4 // Return & Params: Num(5) Size(0x50)
};

