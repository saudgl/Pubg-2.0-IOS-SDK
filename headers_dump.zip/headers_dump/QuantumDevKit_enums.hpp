#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum QuantumDevKit.EQuantumFirebaseRemoteConfigStatus
enum class EQuantumFirebaseRemoteConfigStatus : int32 {
	kUnfetched = -1,
	kFetchedSuccessfully = 0,
	kFetchedFailed = 1,
	EQuantumFirebaseRemoteConfigStatus_MAX = 2
};

