#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass RankSmall_Integral_Name_Star_UIBP.RankSmall_Integral_Name_Star_UIBP_C
// Size: 0x248 // Inherited bytes: 0x218
struct URankSmall_Integral_Name_Star_UIBP_C : UUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x218 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Star; // Offset: 0x220 // Size: 0x08
	struct UImage* Image_Icon; // Offset: 0x228 // Size: 0x08
	struct UImage* Image_Star; // Offset: 0x230 // Size: 0x08
	struct UTextBlock* TextBlock_Rank; // Offset: 0x238 // Size: 0x08
	struct UTextBlock* TextBlock_Star; // Offset: 0x240 // Size: 0x08

	// Functions

	// Object Name: Function RankSmall_Integral_Name_Star_UIBP.RankSmall_Integral_Name_Star_UIBP_C.SetRankText
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetRankText(struct FSlateColor Color, struct FSlateColor ShadowColor, struct FSlateFontInfo FontInfo); // Offset: 0x103e7af64 // Return & Params: Num(3) Size(0xa8)

	// Object Name: Function RankSmall_Integral_Name_Star_UIBP.RankSmall_Integral_Name_Star_UIBP_C.SetRankIntegral
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetRankIntegral(struct FBP_STRUCT_RankIntegralLevel_type RankIntegralLevel_Info); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0xe8)

	// Object Name: Function RankSmall_Integral_Name_Star_UIBP.RankSmall_Integral_Name_Star_UIBP_C.ExecuteUbergraph_RankSmall_Integral_Name_Star_UIBP
	// Flags: [HasDefaults]
	void ExecuteUbergraph_RankSmall_Integral_Name_Star_UIBP(int EntryPoint); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x4)
};

