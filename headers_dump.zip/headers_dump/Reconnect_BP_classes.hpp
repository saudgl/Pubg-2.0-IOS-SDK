#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Reconnect_BP.Reconnect_BP_C
// Size: 0x40b // Inherited bytes: 0x3d0
struct UReconnect_BP_C : UUAEUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x3d0 // Size: 0x08
	struct UReconnect_UIBP_C* Reconnect_UIBP; // Offset: 0x3d8 // Size: 0x08
	struct UTextBlock* TextNumber; // Offset: 0x3e0 // Size: 0x08
	struct UTextBlock* TextInfo; // Offset: 0x3e8 // Size: 0x08
	struct UHorizontalBox* BoxText; // Offset: 0x3f0 // Size: 0x08
	bool isShowText; // Offset: 0x3f8 // Size: 0x01
	char pad_0x3F9[0x3]; // Offset: 0x3f9 // Size: 0x03
	int StartTime; // Offset: 0x3fc // Size: 0x04
	float lastTickTime; // Offset: 0x400 // Size: 0x04
	float curTickTIme; // Offset: 0x404 // Size: 0x04
	bool canCrtlFromLua; // Offset: 0x408 // Size: 0x01
	bool BIsShowAnim; // Offset: 0x409 // Size: 0x01
	bool bImmediatelyShow; // Offset: 0x40a // Size: 0x01

	// Functions

	// Object Name: Function Reconnect_BP.Reconnect_BP_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Reconnect_BP.Reconnect_BP_C.ExecuteUbergraph_Reconnect_BP
	// Flags: [None]
	void ExecuteUbergraph_Reconnect_BP(int EntryPoint); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x4)
};

