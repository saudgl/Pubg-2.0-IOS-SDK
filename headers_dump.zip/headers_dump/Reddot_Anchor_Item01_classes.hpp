#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Reddot_Anchor_Item01.Reddot_Anchor_Item01_C
// Size: 0x294 // Inherited bytes: 0x288
struct UReddot_Anchor_Item01_C : ULuaUserWidget {
	// Fields
	struct UWidgetAnimation* Breathing; // Offset: 0x288 // Size: 0x08
	int PosTemplate; // Offset: 0x290 // Size: 0x04
};

