#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Reddot_Anchor.Reddot_Anchor_C
// Size: 0x294 // Inherited bytes: 0x288
struct UReddot_Anchor_C : ULuaUserWidget {
	// Fields
	struct UCanvasPanel* CanvasPanel_Anchor; // Offset: 0x288 // Size: 0x08
	int PosTemplate; // Offset: 0x290 // Size: 0x04
};

