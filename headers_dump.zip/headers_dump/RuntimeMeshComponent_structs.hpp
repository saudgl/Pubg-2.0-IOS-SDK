#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct RuntimeMeshComponent.RuntimeMeshTangent
// Size: 0x10 // Inherited bytes: 0x00
struct FRuntimeMeshTangent {
	// Fields
	struct FVector TangentX; // Offset: 0x00 // Size: 0x0c
	bool bFlipTangentY; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
};

// Object Name: ScriptStruct RuntimeMeshComponent.RuntimeMeshComponentPrePhysicsTickFunction
// Size: 0x58 // Inherited bytes: 0x50
struct FRuntimeMeshComponentPrePhysicsTickFunction : FTickFunction {
	// Fields
	char pad_0x50[0x8]; // Offset: 0x50 // Size: 0x08
};

// Object Name: ScriptStruct RuntimeMeshComponent.RuntimeConvexCollisionSection
// Size: 0x30 // Inherited bytes: 0x00
struct FRuntimeConvexCollisionSection {
	// Fields
	struct TArray<struct FVector> VertexBuffer; // Offset: 0x00 // Size: 0x10
	struct FBox BoundingBox; // Offset: 0x10 // Size: 0x1c
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct RuntimeMeshComponent.RuntimeMeshCollisionSection
// Size: 0x20 // Inherited bytes: 0x00
struct FRuntimeMeshCollisionSection {
	// Fields
	struct TArray<struct FVector> VertexBuffer; // Offset: 0x00 // Size: 0x10
	struct TArray<int> IndexBuffer; // Offset: 0x10 // Size: 0x10
};

