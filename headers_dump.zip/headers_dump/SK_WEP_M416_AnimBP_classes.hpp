#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: AnimBlueprintGeneratedClass SK_WEP_M416_AnimBP.SK_WEP_M416_AnimBP_C
// Size: 0x7e0 // Inherited bytes: 0x430
struct USK_WEP_M416_AnimBP_C : UWeaponAnimInstanceBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x430 // Size: 0x08
	struct FAnimNode_Root AnimGraphNode_Root_B7FBE3A14BF1790E725C1FAD5B729681; // Offset: 0x438 // Size: 0x50
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_A4F3B9EF433A4BF183431B882C8B6CBA; // Offset: 0x488 // Size: 0x48
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_DBF5C9FE49CCDA52042A0CBA453258BB; // Offset: 0x4d0 // Size: 0x48
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_9C75EB044F253338DE9CCA940AE68844; // Offset: 0x518 // Size: 0x70
	struct FAnimNode_Root AnimGraphNode_StateResult_2E53306243BB8EEF8A66E2954B605AE2; // Offset: 0x588 // Size: 0x50
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_11B8DD4F43558B51BA6C9181D3465E2D; // Offset: 0x5d8 // Size: 0x70
	struct FAnimNode_Root AnimGraphNode_StateResult_DA43943D4A76C179F483ADADB012B51B; // Offset: 0x648 // Size: 0x50
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine_344EBB0E4AD7C89A485D84B82399E97D; // Offset: 0x698 // Size: 0xd8
	struct FAnimNode_Slot AnimGraphNode_Slot_163652544349750545F55EBE5F84D217; // Offset: 0x770 // Size: 0x70

	// Functions

	// Object Name: Function SK_WEP_M416_AnimBP.SK_WEP_M416_AnimBP_C.HandleWeaponStateChanged
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void HandleWeaponStateChanged(enum class EFreshWeaponStateType Selection); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function SK_WEP_M416_AnimBP.SK_WEP_M416_AnimBP_C.PlayFireAnim
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void PlayFireAnim(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SK_WEP_M416_AnimBP.SK_WEP_M416_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_SK_WEP_M416_AnimBP_AnimGraphNode_TransitionResult_DBF5C9FE49CCDA52042A0CBA453258BB
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_SK_WEP_M416_AnimBP_AnimGraphNode_TransitionResult_DBF5C9FE49CCDA52042A0CBA453258BB(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SK_WEP_M416_AnimBP.SK_WEP_M416_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_SK_WEP_M416_AnimBP_AnimGraphNode_SequencePlayer_9C75EB044F253338DE9CCA940AE68844
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_SK_WEP_M416_AnimBP_AnimGraphNode_SequencePlayer_9C75EB044F253338DE9CCA940AE68844(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SK_WEP_M416_AnimBP.SK_WEP_M416_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_SK_WEP_M416_AnimBP_AnimGraphNode_TransitionResult_A4F3B9EF433A4BF183431B882C8B6CBA
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_SK_WEP_M416_AnimBP_AnimGraphNode_TransitionResult_A4F3B9EF433A4BF183431B882C8B6CBA(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SK_WEP_M416_AnimBP.SK_WEP_M416_AnimBP_C.OnWeaponChangeState
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnWeaponChangeState(enum class EFreshWeaponStateType CurState); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function SK_WEP_M416_AnimBP.SK_WEP_M416_AnimBP_C.BlueprintInitializeAnimation
	// Flags: [Event|Public|BlueprintEvent]
	void BlueprintInitializeAnimation(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SK_WEP_M416_AnimBP.SK_WEP_M416_AnimBP_C.ExecuteUbergraph_SK_WEP_M416_AnimBP
	// Flags: [None]
	void ExecuteUbergraph_SK_WEP_M416_AnimBP(int EntryPoint); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x4)
};

