#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Setting_CarrierCooperation_UIBP.Setting_CarrierCooperation_UIBP_C
// Size: 0x238 // Inherited bytes: 0x218
struct USetting_CarrierCooperation_UIBP_C : UUserWidget {
	// Fields
	struct UButton* Button_Tips; // Offset: 0x218 // Size: 0x08
	struct UCanvasPanel* Panel_Tips; // Offset: 0x220 // Size: 0x08
	struct UTextBlock* Text_Tips; // Offset: 0x228 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_1; // Offset: 0x230 // Size: 0x08
};

