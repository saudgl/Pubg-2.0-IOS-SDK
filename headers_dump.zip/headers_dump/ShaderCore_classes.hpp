#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class ShaderCore.ShaderGroupSettings
// Size: 0xa0 // Inherited bytes: 0x28
struct UShaderGroupSettings : UObject {
	// Fields
	struct TArray<struct FShaderGroupDesc> Groups_IOS; // Offset: 0x28 // Size: 0x10
	struct TArray<struct FShaderGroupDesc> Groups_AOS; // Offset: 0x38 // Size: 0x10
	char pad_0x48[0x58]; // Offset: 0x48 // Size: 0x58
};

