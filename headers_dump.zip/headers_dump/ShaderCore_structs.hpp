#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct ShaderCore.ShaderGroupDesc
// Size: 0x60 // Inherited bytes: 0x00
struct FShaderGroupDesc {
	// Fields
	struct FString Name; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FString> Exclude; // Offset: 0x10 // Size: 0x10
	struct TArray<struct FString> Include; // Offset: 0x20 // Size: 0x10
	struct TArray<struct FString> IncludePath; // Offset: 0x30 // Size: 0x10
	struct TArray<struct FString> Prerequisite; // Offset: 0x40 // Size: 0x10
	struct TArray<struct FString> Parent; // Offset: 0x50 // Size: 0x10
};

