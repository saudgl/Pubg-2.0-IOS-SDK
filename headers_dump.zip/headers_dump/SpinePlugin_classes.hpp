#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class SpinePlugin.SpineAtlasAsset
// Size: 0x58 // Inherited bytes: 0x28
struct USpineAtlasAsset : UObject {
	// Fields
	struct TArray<struct UTexture2D*> atlasPages; // Offset: 0x28 // Size: 0x10
	char pad_0x38[0x8]; // Offset: 0x38 // Size: 0x08
	struct FString rawData; // Offset: 0x40 // Size: 0x10
	struct FName atlasFileName; // Offset: 0x50 // Size: 0x08
};

// Object Name: Class SpinePlugin.SpineBoneDriverComponent
// Size: 0x300 // Inherited bytes: 0x2d0
struct USpineBoneDriverComponent : USceneComponent {
	// Fields
	struct AActor* Target; // Offset: 0x2d0 // Size: 0x08
	struct FString BoneName; // Offset: 0x2d8 // Size: 0x10
	bool UseComponentTransform; // Offset: 0x2e8 // Size: 0x01
	bool UsePosition; // Offset: 0x2e9 // Size: 0x01
	bool UseRotation; // Offset: 0x2ea // Size: 0x01
	bool UseScale; // Offset: 0x2eb // Size: 0x01
	char pad_0x2EC[0x14]; // Offset: 0x2ec // Size: 0x14

	// Functions

	// Object Name: Function SpinePlugin.SpineBoneDriverComponent.BeforeUpdateWorldTransform
	// Flags: [Final|Native|Protected]
	void BeforeUpdateWorldTransform(struct USpineSkeletonComponent* Skeleton); // Offset: 0x10252b170 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class SpinePlugin.SpineBoneFollowerComponent
// Size: 0x2f0 // Inherited bytes: 0x2d0
struct USpineBoneFollowerComponent : USceneComponent {
	// Fields
	struct AActor* Target; // Offset: 0x2d0 // Size: 0x08
	struct FString BoneName; // Offset: 0x2d8 // Size: 0x10
	bool UseComponentTransform; // Offset: 0x2e8 // Size: 0x01
	bool UsePosition; // Offset: 0x2e9 // Size: 0x01
	bool UseRotation; // Offset: 0x2ea // Size: 0x01
	bool UseScale; // Offset: 0x2eb // Size: 0x01
	char pad_0x2EC[0x4]; // Offset: 0x2ec // Size: 0x04
};

// Object Name: Class SpinePlugin.TrackEntry
// Size: 0x90 // Inherited bytes: 0x28
struct UTrackEntry : UObject {
	// Fields
	struct FScriptMulticastDelegate animationStart; // Offset: 0x28 // Size: 0x10
	struct FScriptMulticastDelegate AnimationInterrupt; // Offset: 0x38 // Size: 0x10
	struct FScriptMulticastDelegate AnimationEvent; // Offset: 0x48 // Size: 0x10
	struct FScriptMulticastDelegate AnimationComplete; // Offset: 0x58 // Size: 0x10
	struct FScriptMulticastDelegate animationEnd; // Offset: 0x68 // Size: 0x10
	struct FScriptMulticastDelegate AnimationDispose; // Offset: 0x78 // Size: 0x10
	char pad_0x88[0x8]; // Offset: 0x88 // Size: 0x08

	// Functions

	// Object Name: Function SpinePlugin.TrackEntry.SetTrackTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTrackTime(float trackTime); // Offset: 0x10252c204 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.SetTrackEnd
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTrackEnd(float trackEnd); // Offset: 0x10252c188 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.SetTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTimeScale(float TimeScale); // Offset: 0x10252c10c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.SetMixTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMixTime(float mixTime); // Offset: 0x10252c090 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.SetMixDuration
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMixDuration(float mixDuration); // Offset: 0x10252c014 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.SetLoop
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLoop(bool Loop); // Offset: 0x10252bf90 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function SpinePlugin.TrackEntry.SetEventThreshold
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetEventThreshold(float eventThreshold); // Offset: 0x10252bf14 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.SetDrawOrderThreshold
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDrawOrderThreshold(float drawOrderThreshold); // Offset: 0x10252be98 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.SetDelay
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDelay(float Delay); // Offset: 0x10252be1c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.SetAttachmentThreshold
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAttachmentThreshold(float attachmentThreshold); // Offset: 0x10252bda0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.SetAnimationStart
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAnimationStart(float animationStart); // Offset: 0x10252bd24 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.SetAnimationLast
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAnimationLast(float animationLast); // Offset: 0x10252bca8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.SetAnimationEnd
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAnimationEnd(float animationEnd); // Offset: 0x10252bc2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.SetAlpha
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAlpha(float Alpha); // Offset: 0x10252bbb0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.isValidAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	float isValidAnimation(); // Offset: 0x10252bb84 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.GetTrackTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetTrackTime(); // Offset: 0x10252bb50 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.GetTrackIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetTrackIndex(); // Offset: 0x10252bb1c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.GetTrackEnd
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetTrackEnd(); // Offset: 0x10252bae8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.GetTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetTimeScale(); // Offset: 0x10252bab4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.GetMixTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetMixTime(); // Offset: 0x10252ba80 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.GetMixDuration
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetMixDuration(); // Offset: 0x10252ba4c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.GetLoop
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetLoop(); // Offset: 0x10252ba18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function SpinePlugin.TrackEntry.GetEventThreshold
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetEventThreshold(); // Offset: 0x10252b9e4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.GetDrawOrderThreshold
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetDrawOrderThreshold(); // Offset: 0x10252b9b0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.GetDelay
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetDelay(); // Offset: 0x10252b97c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.GetAttachmentThreshold
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetAttachmentThreshold(); // Offset: 0x10252b948 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.GetAnimationStart
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetAnimationStart(); // Offset: 0x10252b914 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.getAnimationName
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString getAnimationName(); // Offset: 0x10252b8b0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SpinePlugin.TrackEntry.GetAnimationLast
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetAnimationLast(); // Offset: 0x10252b87c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.GetAnimationEnd
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetAnimationEnd(); // Offset: 0x10252b848 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.getAnimationDuration
	// Flags: [Final|Native|Public|BlueprintCallable]
	float getAnimationDuration(); // Offset: 0x10252b814 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.GetAlpha
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetAlpha(); // Offset: 0x10252b7e0 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class SpinePlugin.SpineSkeletonComponent
// Size: 0x160 // Inherited bytes: 0x110
struct USpineSkeletonComponent : UActorComponent {
	// Fields
	struct USpineAtlasAsset* Atlas; // Offset: 0x110 // Size: 0x08
	struct USpineSkeletonDataAsset* SkeletonData; // Offset: 0x118 // Size: 0x08
	struct FScriptMulticastDelegate BeforeUpdateWorldTransform; // Offset: 0x120 // Size: 0x10
	struct FScriptMulticastDelegate AfterUpdateWorldTransform; // Offset: 0x130 // Size: 0x10
	char pad_0x140[0x20]; // Offset: 0x140 // Size: 0x20

	// Functions

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.UpdateWorldTransform
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UpdateWorldTransform(); // Offset: 0x10252e3e8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.SetToSetupPose
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetToSetupPose(); // Offset: 0x10252e3d4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.SetSlotsToSetupPose
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSlotsToSetupPose(); // Offset: 0x10252e3c0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.SetSkin
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetSkin(struct FString SkinName); // Offset: 0x10252e2f4 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.SetScaleY
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetScaleY(float ScaleY); // Offset: 0x10252e278 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.SetScaleX
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetScaleX(float ScaleX); // Offset: 0x10252e1fc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.SetBoneWorldPosition
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SetBoneWorldPosition(struct FString BoneName, struct FVector& Position); // Offset: 0x10252e118 // Return & Params: Num(2) Size(0x1c)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.SetBonesToSetupPose
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBonesToSetupPose(); // Offset: 0x10252e104 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.SetAttachment
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetAttachment(struct FString SlotName, struct FString AttachmentName); // Offset: 0x10252dfc0 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.HasSlot
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool HasSlot(struct FString SlotName); // Offset: 0x10252def4 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.HasSkin
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool HasSkin(struct FString SkinName); // Offset: 0x10252de28 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.HasBone
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool HasBone(struct FString BoneName); // Offset: 0x10252dd5c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.HasAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool HasAnimation(struct FString AnimationName); // Offset: 0x10252dc90 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.GetSlots
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	void GetSlots(struct TArray<struct FString>& Slots); // Offset: 0x10252dbe8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.GetSkins
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	void GetSkins(struct TArray<struct FString>& Skins); // Offset: 0x10252db40 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.GetScaleY
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetScaleY(); // Offset: 0x10252db0c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.GetScaleX
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetScaleX(); // Offset: 0x10252dad8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.GetBoneWorldTransform
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	struct FTransform GetBoneWorldTransform(struct FString BoneName); // Offset: 0x10252da18 // Return & Params: Num(2) Size(0x40)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.GetBones
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	void GetBones(struct TArray<struct FString>& Bones); // Offset: 0x10252d970 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.GetAnimations
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	void GetAnimations(struct TArray<struct FString>& Animations); // Offset: 0x10252d8c8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.getAnimationDuration
	// Flags: [Final|Native|Public|BlueprintCallable]
	float getAnimationDuration(struct FString AnimationName); // Offset: 0x10252d7fc // Return & Params: Num(2) Size(0x14)
};

// Object Name: Class SpinePlugin.SpineSkeletonAnimationComponent
// Size: 0x260 // Inherited bytes: 0x160
struct USpineSkeletonAnimationComponent : USpineSkeletonComponent {
	// Fields
	struct FScriptMulticastDelegate animationStart; // Offset: 0x160 // Size: 0x10
	struct FScriptMulticastDelegate AnimationInterrupt; // Offset: 0x170 // Size: 0x10
	struct FScriptMulticastDelegate AnimationEvent; // Offset: 0x180 // Size: 0x10
	struct FScriptMulticastDelegate AnimationComplete; // Offset: 0x190 // Size: 0x10
	struct FScriptMulticastDelegate animationEnd; // Offset: 0x1a0 // Size: 0x10
	struct FScriptMulticastDelegate AnimationDispose; // Offset: 0x1b0 // Size: 0x10
	struct FString PreviewAnimation; // Offset: 0x1c0 // Size: 0x10
	struct FString PreviewSkin; // Offset: 0x1d0 // Size: 0x10
	char pad_0x1E0[0x8]; // Offset: 0x1e0 // Size: 0x08
	struct TSet<struct UTrackEntry*> trackEntries; // Offset: 0x1e8 // Size: 0x50
	bool bAutoPlaying; // Offset: 0x238 // Size: 0x01
	char pad_0x239[0x27]; // Offset: 0x239 // Size: 0x27

	// Functions

	// Object Name: Function SpinePlugin.SpineSkeletonAnimationComponent.SetTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTimeScale(float TimeScale); // Offset: 0x10252d2e8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineSkeletonAnimationComponent.SetPlaybackTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPlaybackTime(float InPlaybackTime, bool bCallDelegates); // Offset: 0x10252d228 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function SpinePlugin.SpineSkeletonAnimationComponent.SetEmptyAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UTrackEntry* SetEmptyAnimation(int TrackIndex, float mixDuration); // Offset: 0x10252d160 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function SpinePlugin.SpineSkeletonAnimationComponent.SetAutoPlay
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAutoPlay(bool bInAutoPlays); // Offset: 0x10252d0dc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function SpinePlugin.SpineSkeletonAnimationComponent.SetAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UTrackEntry* SetAnimation(int TrackIndex, struct FString AnimationName, bool Loop); // Offset: 0x10252cf88 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function SpinePlugin.SpineSkeletonAnimationComponent.GetTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetTimeScale(); // Offset: 0x10252cf54 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineSkeletonAnimationComponent.GetCurrent
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UTrackEntry* GetCurrent(int TrackIndex); // Offset: 0x10252cec8 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function SpinePlugin.SpineSkeletonAnimationComponent.ClearTracks
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearTracks(); // Offset: 0x10252ceb4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpinePlugin.SpineSkeletonAnimationComponent.ClearTrack
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearTrack(int TrackIndex); // Offset: 0x10252ce38 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineSkeletonAnimationComponent.AddEmptyAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UTrackEntry* AddEmptyAnimation(int TrackIndex, float mixDuration, float Delay); // Offset: 0x10252cd38 // Return & Params: Num(4) Size(0x18)

	// Object Name: Function SpinePlugin.SpineSkeletonAnimationComponent.AddAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UTrackEntry* AddAnimation(int TrackIndex, struct FString AnimationName, bool Loop, float Delay); // Offset: 0x10252cba4 // Return & Params: Num(5) Size(0x28)
};

// Object Name: Class SpinePlugin.SpineSkeletonDataAsset
// Size: 0xc0 // Inherited bytes: 0x28
struct USpineSkeletonDataAsset : UObject {
	// Fields
	float DefaultMix; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct TArray<struct FSpineAnimationStateMixData> MixData; // Offset: 0x30 // Size: 0x10
	struct TArray<struct FString> Bones; // Offset: 0x40 // Size: 0x10
	struct TArray<struct FString> Slots; // Offset: 0x50 // Size: 0x10
	struct TArray<struct FString> Skins; // Offset: 0x60 // Size: 0x10
	struct TArray<struct FString> Animations; // Offset: 0x70 // Size: 0x10
	struct TArray<struct FString> Events; // Offset: 0x80 // Size: 0x10
	struct TArray<char> rawData; // Offset: 0x90 // Size: 0x10
	struct FName skeletonDataFileName; // Offset: 0xa0 // Size: 0x08
	char pad_0xA8[0x18]; // Offset: 0xa8 // Size: 0x18
};

// Object Name: Class SpinePlugin.SpineSkeletonRendererComponent
// Size: 0xb50 // Inherited bytes: 0x790
struct USpineSkeletonRendererComponent : UProceduralMeshComponent {
	// Fields
	struct UMaterialInterface* NormalBlendMaterial; // Offset: 0x790 // Size: 0x08
	struct UMaterialInterface* AdditiveBlendMaterial; // Offset: 0x798 // Size: 0x08
	struct UMaterialInterface* MultiplyBlendMaterial; // Offset: 0x7a0 // Size: 0x08
	struct UMaterialInterface* ScreenBlendMaterial; // Offset: 0x7a8 // Size: 0x08
	struct TArray<struct UMaterialInstanceDynamic*> atlasNormalBlendMaterials; // Offset: 0x7b0 // Size: 0x10
	char pad_0x7C0[0x50]; // Offset: 0x7c0 // Size: 0x50
	struct TArray<struct UMaterialInstanceDynamic*> atlasAdditiveBlendMaterials; // Offset: 0x810 // Size: 0x10
	char pad_0x820[0x50]; // Offset: 0x820 // Size: 0x50
	struct TArray<struct UMaterialInstanceDynamic*> atlasMultiplyBlendMaterials; // Offset: 0x870 // Size: 0x10
	char pad_0x880[0x50]; // Offset: 0x880 // Size: 0x50
	struct TArray<struct UMaterialInstanceDynamic*> atlasScreenBlendMaterials; // Offset: 0x8d0 // Size: 0x10
	char pad_0x8E0[0x50]; // Offset: 0x8e0 // Size: 0x50
	float DepthOffset; // Offset: 0x930 // Size: 0x04
	char pad_0x934[0x4]; // Offset: 0x934 // Size: 0x04
	struct FName TextureParameterName; // Offset: 0x938 // Size: 0x08
	struct FLinearColor Color; // Offset: 0x940 // Size: 0x10
	bool bCreateCollision; // Offset: 0x950 // Size: 0x01
	char pad_0x951[0x1ff]; // Offset: 0x951 // Size: 0x1ff
};

// Object Name: Class SpinePlugin.SpineWidget
// Size: 0x690 // Inherited bytes: 0x100
struct USpineWidget : UWidget {
	// Fields
	float Scale; // Offset: 0x100 // Size: 0x04
	char pad_0x104[0x4]; // Offset: 0x104 // Size: 0x04
	struct USpineAtlasAsset* Atlas; // Offset: 0x108 // Size: 0x08
	struct USpineSkeletonDataAsset* SkeletonData; // Offset: 0x110 // Size: 0x08
	struct UMaterialInterface* NormalBlendMaterial; // Offset: 0x118 // Size: 0x08
	struct UMaterialInterface* AdditiveBlendMaterial; // Offset: 0x120 // Size: 0x08
	struct UMaterialInterface* MultiplyBlendMaterial; // Offset: 0x128 // Size: 0x08
	struct UMaterialInterface* ScreenBlendMaterial; // Offset: 0x130 // Size: 0x08
	struct FName TextureParameterName; // Offset: 0x138 // Size: 0x08
	float DepthOffset; // Offset: 0x140 // Size: 0x04
	struct FLinearColor Color; // Offset: 0x144 // Size: 0x10
	char pad_0x154[0x4]; // Offset: 0x154 // Size: 0x04
	struct FSlateBrush Brush; // Offset: 0x158 // Size: 0xb8
	struct FScriptMulticastDelegate BeforeUpdateWorldTransform; // Offset: 0x210 // Size: 0x10
	struct FScriptMulticastDelegate AfterUpdateWorldTransform; // Offset: 0x220 // Size: 0x10
	struct FScriptMulticastDelegate animationStart; // Offset: 0x230 // Size: 0x10
	struct FScriptMulticastDelegate AnimationInterrupt; // Offset: 0x240 // Size: 0x10
	struct FScriptMulticastDelegate AnimationEvent; // Offset: 0x250 // Size: 0x10
	struct FScriptMulticastDelegate AnimationComplete; // Offset: 0x260 // Size: 0x10
	struct FScriptMulticastDelegate animationEnd; // Offset: 0x270 // Size: 0x10
	struct FScriptMulticastDelegate AnimationDispose; // Offset: 0x280 // Size: 0x10
	char pad_0x290[0x38]; // Offset: 0x290 // Size: 0x38
	struct TArray<struct UMaterialInstanceDynamic*> atlasNormalBlendMaterials; // Offset: 0x2c8 // Size: 0x10
	char pad_0x2D8[0x50]; // Offset: 0x2d8 // Size: 0x50
	struct TArray<struct UMaterialInstanceDynamic*> atlasAdditiveBlendMaterials; // Offset: 0x328 // Size: 0x10
	char pad_0x338[0x50]; // Offset: 0x338 // Size: 0x50
	struct TArray<struct UMaterialInstanceDynamic*> atlasMultiplyBlendMaterials; // Offset: 0x388 // Size: 0x10
	char pad_0x398[0x50]; // Offset: 0x398 // Size: 0x50
	struct TArray<struct UMaterialInstanceDynamic*> atlasScreenBlendMaterials; // Offset: 0x3e8 // Size: 0x10
	char pad_0x3F8[0x240]; // Offset: 0x3f8 // Size: 0x240
	struct TSet<struct UTrackEntry*> trackEntries; // Offset: 0x638 // Size: 0x50
	bool bAutoPlaying; // Offset: 0x688 // Size: 0x01
	char pad_0x689[0x7]; // Offset: 0x689 // Size: 0x07

	// Functions

	// Object Name: Function SpinePlugin.SpineWidget.UpdateWorldTransform
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UpdateWorldTransform(); // Offset: 0x1025301c0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpinePlugin.SpineWidget.Tick
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Tick(float DeltaTime, bool CallDelegates); // Offset: 0x102530100 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function SpinePlugin.SpineWidget.SetToSetupPose
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetToSetupPose(); // Offset: 0x1025300ec // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpinePlugin.SpineWidget.SetTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTimeScale(float TimeScale); // Offset: 0x102530070 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineWidget.SetSlotsToSetupPose
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSlotsToSetupPose(); // Offset: 0x10253005c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpinePlugin.SpineWidget.SetSkin
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetSkin(struct FString SkinName); // Offset: 0x10252ff90 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function SpinePlugin.SpineWidget.SetScaleY
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetScaleY(float ScaleY); // Offset: 0x10252ff14 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineWidget.SetScaleX
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetScaleX(float ScaleX); // Offset: 0x10252fe98 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineWidget.SetScale
	// Flags: [Native|Public|BlueprintCallable]
	void SetScale(float InScale); // Offset: 0x10252fe14 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineWidget.SetPlaybackTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPlaybackTime(float InPlaybackTime, bool bCallDelegates); // Offset: 0x10252fd54 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function SpinePlugin.SpineWidget.SetEmptyAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UTrackEntry* SetEmptyAnimation(int TrackIndex, float mixDuration); // Offset: 0x10252fc8c // Return & Params: Num(3) Size(0x10)

	// Object Name: Function SpinePlugin.SpineWidget.SetColor
	// Flags: [Native|Public|HasDefaults|BlueprintCallable]
	void SetColor(struct FLinearColor InColor); // Offset: 0x10252fc08 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SpinePlugin.SpineWidget.SetBonesToSetupPose
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBonesToSetupPose(); // Offset: 0x10252fbf4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpinePlugin.SpineWidget.SetAutoPlay
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAutoPlay(bool bInAutoPlays); // Offset: 0x10252fb70 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function SpinePlugin.SpineWidget.SetAttachment
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetAttachment(struct FString SlotName, struct FString AttachmentName); // Offset: 0x10252fa2c // Return & Params: Num(3) Size(0x21)

	// Object Name: Function SpinePlugin.SpineWidget.SetAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UTrackEntry* SetAnimation(int TrackIndex, struct FString AnimationName, bool Loop); // Offset: 0x10252f8d8 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function SpinePlugin.SpineWidget.HasSlot
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool HasSlot(struct FString SlotName); // Offset: 0x10252f80c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function SpinePlugin.SpineWidget.HasSkin
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool HasSkin(struct FString SkinName); // Offset: 0x10252f740 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function SpinePlugin.SpineWidget.HasBone
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool HasBone(struct FString BoneName); // Offset: 0x10252f674 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function SpinePlugin.SpineWidget.HasAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool HasAnimation(struct FString AnimationName); // Offset: 0x10252f5a8 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function SpinePlugin.SpineWidget.GetTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetTimeScale(); // Offset: 0x10252f574 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineWidget.GetSlots
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	void GetSlots(struct TArray<struct FString>& Slots); // Offset: 0x10252f4cc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SpinePlugin.SpineWidget.GetSkins
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	void GetSkins(struct TArray<struct FString>& Skins); // Offset: 0x10252f424 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SpinePlugin.SpineWidget.GetScaleY
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetScaleY(); // Offset: 0x10252f3f0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineWidget.GetScaleX
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetScaleX(); // Offset: 0x10252f3bc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineWidget.GetScale
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetScale(); // Offset: 0x10252f388 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineWidget.GetCurrent
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UTrackEntry* GetCurrent(int TrackIndex); // Offset: 0x10252f2fc // Return & Params: Num(2) Size(0x10)

	// Object Name: Function SpinePlugin.SpineWidget.GetColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FLinearColor GetColor(); // Offset: 0x10252f2bc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SpinePlugin.SpineWidget.GetBones
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	void GetBones(struct TArray<struct FString>& Bones); // Offset: 0x10252f214 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SpinePlugin.SpineWidget.GetAnimations
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	void GetAnimations(struct TArray<struct FString>& Animations); // Offset: 0x10252f16c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SpinePlugin.SpineWidget.getAnimationDuration
	// Flags: [Final|Native|Public|BlueprintCallable]
	float getAnimationDuration(struct FString AnimationName); // Offset: 0x10252f0a0 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function SpinePlugin.SpineWidget.ClearTracks
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearTracks(); // Offset: 0x10252f08c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpinePlugin.SpineWidget.ClearTrack
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearTrack(int TrackIndex); // Offset: 0x10252f010 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineWidget.AddEmptyAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UTrackEntry* AddEmptyAnimation(int TrackIndex, float mixDuration, float Delay); // Offset: 0x10252ef10 // Return & Params: Num(4) Size(0x18)

	// Object Name: Function SpinePlugin.SpineWidget.AddAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UTrackEntry* AddAnimation(int TrackIndex, struct FString AnimationName, bool Loop, float Delay); // Offset: 0x10252ed7c // Return & Params: Num(5) Size(0x28)
};

