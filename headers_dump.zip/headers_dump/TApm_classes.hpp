#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class TApm.TApmHelper
// Size: 0x28 // Inherited bytes: 0x28
struct UTApmHelper : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function TApm.TApmHelper.ValidateDevice
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString ValidateDevice(); // Offset: 0x1022885cc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function TApm.TApmHelper.UpdateGameStatusToVmp
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void UpdateGameStatusToVmp(int Key, struct FString Value); // Offset: 0x1022884d8 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function TApm.TApmHelper.SetVersionIden
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetVersionIden(struct FString versionName); // Offset: 0x102288424 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function TApm.TApmHelper.SetUserId
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetUserId(struct FString userId); // Offset: 0x102288370 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function TApm.TApmHelper.SetTragetFrameRate
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetTragetFrameRate(int Target); // Offset: 0x1022882fc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function TApm.TApmHelper.SetQuality
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetQuality(int Quality); // Offset: 0x102288288 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function TApm.TApmHelper.SetPssManualMode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetPssManualMode(); // Offset: 0x102288274 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function TApm.TApmHelper.SetLocale
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetLocale(struct FString Locale); // Offset: 0x1022881c0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function TApm.TApmHelper.SetDeviceLevel
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetDeviceLevel(int DeviceLevel); // Offset: 0x10228814c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function TApm.TApmHelper.setAffinityForThread
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void setAffinityForThread(int tid); // Offset: 0x1022880d8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function TApm.TApmHelper.requestResourceGuarantee
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void requestResourceGuarantee(int Condition, int loadType, int applyType); // Offset: 0x102287ff0 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function TApm.TApmHelper.RequestPssSample
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void RequestPssSample(); // Offset: 0x102287fdc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function TApm.TApmHelper.ReleaseStepEventContext
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ReleaseStepEventContext(); // Offset: 0x102287fc8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function TApm.TApmHelper.RegisterRomCallBackMeta
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void RegisterRomCallBackMeta(struct FString OpenID, struct FString ZoneID); // Offset: 0x102287e9c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function TApm.TApmHelper.PutKVS
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PutKVS(struct FString Key, struct FString Value); // Offset: 0x102287d70 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function TApm.TApmHelper.PutKVI
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PutKVI(struct FString Key, int Value); // Offset: 0x102287c7c // Return & Params: Num(2) Size(0x14)

	// Object Name: Function TApm.TApmHelper.PutKVD
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PutKVD(struct FString Key, float Value); // Offset: 0x102287b88 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function TApm.TApmHelper.PostValueS
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PostValueS(struct FString catgory, struct FString Key, struct FString Value); // Offset: 0x1022879e4 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function TApm.TApmHelper.PostValueI3
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PostValueI3(struct FString catgory, struct FString Key, int A, int B, int C); // Offset: 0x1022877fc // Return & Params: Num(5) Size(0x2c)

	// Object Name: Function TApm.TApmHelper.PostValueI2
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PostValueI2(struct FString catgory, struct FString Key, int A, int B); // Offset: 0x102287654 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function TApm.TApmHelper.PostValueI1
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PostValueI1(struct FString catgory, struct FString Key, int A); // Offset: 0x1022874e8 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function TApm.TApmHelper.PostValueF3
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PostValueF3(struct FString catgory, struct FString Key, float A, float B, float C); // Offset: 0x102287300 // Return & Params: Num(5) Size(0x2c)

	// Object Name: Function TApm.TApmHelper.PostValueF2
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PostValueF2(struct FString catgory, struct FString Key, float A, float B); // Offset: 0x102287158 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function TApm.TApmHelper.PostValueF1
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PostValueF1(struct FString catgory, struct FString Key, float A); // Offset: 0x102286fec // Return & Params: Num(3) Size(0x24)

	// Object Name: Function TApm.TApmHelper.PostTrackState
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PostTrackState(float X, float Y, float Z, float Pitch, float Yaw, float Roll); // Offset: 0x102286e54 // Return & Params: Num(6) Size(0x18)

	// Object Name: Function TApm.TApmHelper.PostStreamEvent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PostStreamEvent(int stepId, int Status, int code, struct FString Info); // Offset: 0x102286cdc // Return & Params: Num(4) Size(0x20)

	// Object Name: Function TApm.TApmHelper.PostStepEvent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PostStepEvent(struct FString eventCategory, int stepId, int Status, int code, struct FString Msg, struct FString extraKey); // Offset: 0x102286a68 // Return & Params: Num(6) Size(0x40)

	// Object Name: Function TApm.TApmHelper.PostNTL
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PostNTL(int latency); // Offset: 0x1022869f4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function TApm.TApmHelper.PostLargeValueS
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PostLargeValueS(struct FString catgory, struct FString Key, struct FString Value); // Offset: 0x102286850 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function TApm.TApmHelper.PostLagStatus
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PostLagStatus(float Distance); // Offset: 0x1022867dc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function TApm.TApmHelper.PostGameStatusToTGPASS
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PostGameStatusToTGPASS(struct FString Key, struct FString Value); // Offset: 0x1022866b0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function TApm.TApmHelper.PostGameStatusToTGPASMap
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PostGameStatusToTGPASMap(struct FString Key, struct TMap<struct FString, struct FString> mapData); // Offset: 0x10228657c // Return & Params: Num(2) Size(0x60)

	// Object Name: Function TApm.TApmHelper.PostGameStatusToTGPAIS
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PostGameStatusToTGPAIS(int Key, struct FString Value); // Offset: 0x102286488 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function TApm.TApmHelper.PostFrame
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PostFrame(float DeltaTime); // Offset: 0x102286414 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function TApm.TApmHelper.PostEvent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PostEvent(int Key, struct FString Info, bool savetolocal); // Offset: 0x1022862d8 // Return & Params: Num(3) Size(0x19)

	// Object Name: Function TApm.TApmHelper.MarkLevelLoadCompleted
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void MarkLevelLoadCompleted(); // Offset: 0x1022862c4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function TApm.TApmHelper.MarkLevelLoad
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void MarkLevelLoad(struct FString SceneName, int Quality); // Offset: 0x1022861d0 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function TApm.TApmHelper.MarkLevelFin
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void MarkLevelFin(); // Offset: 0x1022861bc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function TApm.TApmHelper.MarkHideLoadingUI
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void MarkHideLoadingUI(); // Offset: 0x1022861a8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function TApm.TApmHelper.MarkAppFinishLaunch
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void MarkAppFinishLaunch(); // Offset: 0x102286194 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function TApm.TApmHelper.LinkLastStepEventSession
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void LinkLastStepEventSession(struct FString eventCategory); // Offset: 0x1022860e0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function TApm.TApmHelper.InitTGPA
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void InitTGPA(); // Offset: 0x1022860cc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function TApm.TApmHelper.InitStepEventContext
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void InitStepEventContext(); // Offset: 0x1022860b8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function TApm.TApmHelper.GetOptCfgStr
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetOptCfgStr(); // Offset: 0x102286054 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function TApm.TApmHelper.GetDeviceLevelByQcc
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetDeviceLevelByQcc(struct FString ConfigName, struct FString GPUFamily); // Offset: 0x102285f20 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function TApm.TApmHelper.GetDeviceLevel
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetDeviceLevel(); // Offset: 0x102285eec // Return & Params: Num(1) Size(0x4)

	// Object Name: Function TApm.TApmHelper.GetDataFromTGPA
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetDataFromTGPA(struct FString Key, struct FString Value); // Offset: 0x102285d90 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function TApm.TApmHelper.EndTupleWrap
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void EndTupleWrap(); // Offset: 0x102285d7c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function TApm.TApmHelper.EndTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void EndTag(); // Offset: 0x102285d68 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function TApm.TApmHelper.EndExclude
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void EndExclude(); // Offset: 0x102285d54 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function TApm.TApmHelper.EnableDebugMode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void EnableDebugMode(); // Offset: 0x102285d40 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function TApm.TApmHelper.DumpEvent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DumpEvent(struct FString dumpfile); // Offset: 0x102285c8c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function TApm.TApmHelper.cancelAffinityForThread
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void cancelAffinityForThread(int tid); // Offset: 0x102285c18 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function TApm.TApmHelper.BeginTupleWrap
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void BeginTupleWrap(struct FString Key); // Offset: 0x102285b64 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function TApm.TApmHelper.BeginExclude
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void BeginExclude(); // Offset: 0x102285b50 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function TApm.TApmHelper.AddTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void AddTag(struct FString TagName); // Offset: 0x102285a9c // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class TApm.TApmSceneMarker
// Size: 0x28 // Inherited bytes: 0x28
struct UTApmSceneMarker : UObject {
	// Functions

	// Object Name: Function TApm.TApmSceneMarker.SetEnable
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetEnable(bool Enabled); // Offset: 0x102289778 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function TApm.TApmSceneMarker.MarkOPScene
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void MarkOPScene(int ID); // Offset: 0x102289704 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function TApm.TApmSceneMarker.MarkFlowScene
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void MarkFlowScene(int ID); // Offset: 0x102289690 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function TApm.TApmSceneMarker.CancelOPScene
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void CancelOPScene(int ID); // Offset: 0x10228961c // Return & Params: Num(1) Size(0x4)
};

