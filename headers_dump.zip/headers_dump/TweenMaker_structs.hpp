#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct TweenMaker.ParallelTween
// Size: 0x20 // Inherited bytes: 0x00
struct FParallelTween {
	// Fields
	struct TArray<struct UBaseTween*> ParallelTweens; // Offset: 0x00 // Size: 0x10
	char pad_0x10[0x10]; // Offset: 0x10 // Size: 0x10
};

