#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class UAETrigger.LevelEventListener
// Size: 0x100 // Inherited bytes: 0x28
struct ULevelEventListener : UObject {
	// Fields
	struct FString EventName; // Offset: 0x28 // Size: 0x10
	struct TMap<struct FString, struct FName> RelevantListenerCallbacks; // Offset: 0x38 // Size: 0x50
	struct TSet<struct FString> ObjectRelevantEvents; // Offset: 0x88 // Size: 0x50
	struct AActor* ListenerEntity; // Offset: 0xd8 // Size: 0x08
	struct TArray<struct UProperty*> Params; // Offset: 0xe0 // Size: 0x10
	char pad_0xF0[0x10]; // Offset: 0xf0 // Size: 0x10
};

// Object Name: Class UAETrigger.ActorEventListener
// Size: 0x118 // Inherited bytes: 0x100
struct UActorEventListener : ULevelEventListener {
	// Fields
	char pad_0x100[0x18]; // Offset: 0x100 // Size: 0x18
};

// Object Name: Class UAETrigger.FlowNodeBase
// Size: 0x88 // Inherited bytes: 0x28
struct UFlowNodeBase : UObject {
	// Fields
	struct UFlowNodeBase* NextFlowNode; // Offset: 0x28 // Size: 0x08
	struct FUFlowNodeRepData RepData; // Offset: 0x30 // Size: 0x18
	char pad_0x48[0x18]; // Offset: 0x48 // Size: 0x18
	bool IsActive; // Offset: 0x60 // Size: 0x01
	bool DefaltActive; // Offset: 0x61 // Size: 0x01
	char pad_0x62[0x6]; // Offset: 0x62 // Size: 0x06
	struct UTriggersFlowBase* CarriedFlow; // Offset: 0x68 // Size: 0x08
	enum class EFlowNodeType NodeType; // Offset: 0x70 // Size: 0x01
	char pad_0x71[0x7]; // Offset: 0x71 // Size: 0x07
	struct TArray<struct UUAETriggerObject*> TriggerObjects; // Offset: 0x78 // Size: 0x10
};

// Object Name: Class UAETrigger.AndFlowNode
// Size: 0xd8 // Inherited bytes: 0x88
struct UAndFlowNode : UFlowNodeBase {
	// Fields
	char pad_0x88[0x50]; // Offset: 0x88 // Size: 0x50
};

// Object Name: Class UAETrigger.BranchFlowNode
// Size: 0x88 // Inherited bytes: 0x88
struct UBranchFlowNode : UFlowNodeBase {
};

// Object Name: Class UAETrigger.TriggerEventWrapperInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UTriggerEventWrapperInterface : UInterface {
};

// Object Name: Class UAETrigger.LevelEventCenter
// Size: 0xe0 // Inherited bytes: 0x28
struct ULevelEventCenter : UObject {
	// Fields
	char pad_0x28[0x10]; // Offset: 0x28 // Size: 0x10
	struct TMap<struct FString, struct UTriggerEvent*> TriggerEvents; // Offset: 0x38 // Size: 0x50
	char pad_0x88[0x8]; // Offset: 0x88 // Size: 0x08
	struct TMap<struct FString, struct FLevelEventListenerList> EventListeners; // Offset: 0x90 // Size: 0x50
};

// Object Name: Class UAETrigger.LevelEventCenterFunctionLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct ULevelEventCenterFunctionLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function UAETrigger.LevelEventCenterFunctionLibrary.QuickFireLevelEventWithTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void QuickFireLevelEventWithTag(struct FString EventFuncName, struct AActor* PlayerActor, struct FString Tag); // Offset: 0x1022aad2c // Return & Params: Num(3) Size(0x28)

	// Object Name: Function UAETrigger.LevelEventCenterFunctionLibrary.QuickFireLevelEvent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void QuickFireLevelEvent(struct FString EventFuncName, struct AActor* PlayerActor, struct FString PlayerKey, struct FString EventTag); // Offset: 0x1022aab44 // Return & Params: Num(4) Size(0x38)
};

// Object Name: Class UAETrigger.OrFlowNode
// Size: 0x88 // Inherited bytes: 0x88
struct UOrFlowNode : UFlowNodeBase {
};

// Object Name: Class UAETrigger.SequenceFlowNode
// Size: 0x90 // Inherited bytes: 0x88
struct USequenceFlowNode : UFlowNodeBase {
	// Fields
	char pad_0x88[0x8]; // Offset: 0x88 // Size: 0x08
};

// Object Name: Class UAETrigger.SubBranchFlowNode
// Size: 0x88 // Inherited bytes: 0x88
struct USubBranchFlowNode : UFlowNodeBase {
};

// Object Name: Class UAETrigger.TriggerAction
// Size: 0x90 // Inherited bytes: 0x28
struct UTriggerAction : UObject {
	// Fields
	struct UVariableSet* DataSource; // Offset: 0x28 // Size: 0x08
	char pad_0x30[0x8]; // Offset: 0x30 // Size: 0x08
	bool bEnableActionTick; // Offset: 0x38 // Size: 0x01
	enum class EUAETriggerActionExecPolicy ExecPolicy; // Offset: 0x39 // Size: 0x01
	char pad_0x3A[0x6]; // Offset: 0x3a // Size: 0x06
	struct UUAETriggerObject* ParentTrigger; // Offset: 0x40 // Size: 0x08
	struct AUAELevelDirector* ActionOuterActor; // Offset: 0x48 // Size: 0x08
	char pad_0x50[0x24]; // Offset: 0x50 // Size: 0x24
	bool bSupportNetRep; // Offset: 0x74 // Size: 0x01
	char pad_0x75[0x1b]; // Offset: 0x75 // Size: 0x1b
};

// Object Name: Class UAETrigger.TriggerAction_CallFunction
// Size: 0xa0 // Inherited bytes: 0x90
struct UTriggerAction_CallFunction : UTriggerAction {
	// Fields
	char pad_0x90[0x10]; // Offset: 0x90 // Size: 0x10
};

// Object Name: Class UAETrigger.TriggerCondition
// Size: 0x58 // Inherited bytes: 0x28
struct UTriggerCondition : UObject {
	// Fields
	struct UVariableSet* DataSource; // Offset: 0x28 // Size: 0x08
	struct TArray<struct UTriggerCondition*> ChildConditions; // Offset: 0x30 // Size: 0x10
	char pad_0x40[0x10]; // Offset: 0x40 // Size: 0x10
	struct UUAETriggerObject* ParentTrigger; // Offset: 0x50 // Size: 0x08

	// Functions

	// Object Name: Function UAETrigger.TriggerCondition.AddChildCondition
	// Flags: [Final|Native|Public]
	void AddChildCondition(struct UTriggerCondition* NewChildCond); // Offset: 0x1022ab754 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class UAETrigger.TriggerCondition_Comparison
// Size: 0x58 // Inherited bytes: 0x58
struct UTriggerCondition_Comparison : UTriggerCondition {
};

// Object Name: Class UAETrigger.TriggerEvent
// Size: 0xa8 // Inherited bytes: 0x28
struct UTriggerEvent : UObject {
	// Fields
	struct FString EventName; // Offset: 0x28 // Size: 0x10
	struct UObject* EventInstigator; // Offset: 0x38 // Size: 0x08
	char pad_0x40[0x10]; // Offset: 0x40 // Size: 0x10
	struct TMap<struct FString, struct FTriggerEventListenerTrigger> RelevantListener; // Offset: 0x50 // Size: 0x50
	char pad_0xA0[0x8]; // Offset: 0xa0 // Size: 0x08
};

// Object Name: Class UAETrigger.TriggerEvent_Implementable
// Size: 0x138 // Inherited bytes: 0xa8
struct UTriggerEvent_Implementable : UTriggerEvent {
	// Fields
	char pad_0xA8[0x10]; // Offset: 0xa8 // Size: 0x10
	struct TArray<struct UProperty*> Params; // Offset: 0xb8 // Size: 0x10
	char pad_0xC8[0x18]; // Offset: 0xc8 // Size: 0x18
	struct UFunction* CachedAreaEventFunc; // Offset: 0xe0 // Size: 0x08
	struct TMap<struct FString, struct FEventFuncListenerTrigger> EventFuncListener; // Offset: 0xe8 // Size: 0x50
};

// Object Name: Class UAETrigger.TriggerEventBroadcastInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UTriggerEventBroadcastInterface : UInterface {
};

// Object Name: Class UAETrigger.TriggersFlowBase
// Size: 0x90 // Inherited bytes: 0x28
struct UTriggersFlowBase : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	struct AUAELevelDirector* OwnerLevelDirector; // Offset: 0x30 // Size: 0x08
	struct TMap<struct FString, struct UFlowNodeBase*> Nodes; // Offset: 0x38 // Size: 0x50
	bool IsRun; // Offset: 0x88 // Size: 0x01
	char pad_0x89[0x7]; // Offset: 0x89 // Size: 0x07
};

// Object Name: Class UAETrigger.TriggersFlowMultiNodes
// Size: 0x90 // Inherited bytes: 0x90
struct UTriggersFlowMultiNodes : UTriggersFlowBase {
};

// Object Name: Class UAETrigger.TriggersFlowTree
// Size: 0xb8 // Inherited bytes: 0x90
struct UTriggersFlowTree : UTriggersFlowBase {
	// Fields
	struct UFlowNodeBase* RootNode; // Offset: 0x90 // Size: 0x08
	struct UFlowNodeBase* TailNode; // Offset: 0x98 // Size: 0x08
	struct UFlowNodeBase* CurrentNode; // Offset: 0xa0 // Size: 0x08
	struct UFlowNodeBase* SubNode; // Offset: 0xa8 // Size: 0x08
	char pad_0xB0[0x8]; // Offset: 0xb0 // Size: 0x08
};

// Object Name: Class UAETrigger.UAELevelDirector
// Size: 0x588 // Inherited bytes: 0x3c8
struct AUAELevelDirector : AActor {
	// Fields
	bool IsEnable; // Offset: 0x3c8 // Size: 0x01
	bool ClientEnvEnabled; // Offset: 0x3c9 // Size: 0x01
	bool ServerEnvEnabled; // Offset: 0x3ca // Size: 0x01
	char pad_0x3CB[0x5]; // Offset: 0x3cb // Size: 0x05
	struct TArray<struct FLevelDirectorInstAction> InstanceActions; // Offset: 0x3d0 // Size: 0x10
	struct TArray<struct FString> ClassPaths; // Offset: 0x3e0 // Size: 0x10
	struct FString ConfigFilePath; // Offset: 0x3f0 // Size: 0x10
	struct AUAELevelDirector_PlayerRepInfo* PlayerRepInfoClass; // Offset: 0x400 // Size: 0x08
	struct FString ClientConfigFilePath; // Offset: 0x408 // Size: 0x10
	struct FUAELevelDirectorRepData LevelDirectorRepData; // Offset: 0x418 // Size: 0x18
	struct TMap<uint32_t, struct AUAELevelDirector_PlayerRepInfo*> AllPlayersRepInfo; // Offset: 0x430 // Size: 0x50
	struct TArray<struct UUAETriggerFuncLib*> FunctionLibList; // Offset: 0x480 // Size: 0x10
	struct UTriggersFlowBase* TriggersFlowTree; // Offset: 0x490 // Size: 0x08
	struct TMap<struct FString, struct UUAETriggerObject*> TriggerObjectMap; // Offset: 0x498 // Size: 0x50
	struct UVariableSet* AllVariableSet; // Offset: 0x4e8 // Size: 0x08
	struct UUAETriggerParamFuncLib* TriggerParamFuncLib; // Offset: 0x4f0 // Size: 0x08
	struct ULevelEventCenter* LevelEventCenter; // Offset: 0x4f8 // Size: 0x08
	struct FString DescData; // Offset: 0x500 // Size: 0x10
	struct AUAELevelDirector_PlayerRepInfo* CurLevelDirector_PlayerRepInfo; // Offset: 0x510 // Size: 0x08
	struct TMap<uint32_t, struct AUAELevelDirector_PlayerRepInfo*> HistoryLevelDirector_PlayerRepInfos; // Offset: 0x518 // Size: 0x50
	char pad_0x568[0x8]; // Offset: 0x568 // Size: 0x08
	struct FTaskRepData TaskData; // Offset: 0x570 // Size: 0x18

	// Functions

	// Object Name: Function UAETrigger.UAELevelDirector.StartLevelDirector
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool StartLevelDirector(); // Offset: 0x1022adb48 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UAETrigger.UAELevelDirector.SetTriggerRunType
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTriggerRunType(struct FString TriggerName, enum class EUAETriggerRunType RunType); // Offset: 0x1022ada4c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function UAETrigger.UAELevelDirector.SetEnable
	// Flags: [Final|Native|Public]
	void SetEnable(bool Enab); // Offset: 0x1022ad9cc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UAETrigger.UAELevelDirector.S2Sim_CallExcuteAction
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public]
	void S2Sim_CallExcuteAction(); // Offset: 0x1022ad9b0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UAETrigger.UAELevelDirector.RequestTriggerComplete
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void RequestTriggerComplete(struct UUAETriggerObject* CompleteTrigger); // Offset: 0x1022ad904 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UAETrigger.UAELevelDirector.OnRep_LevelDirectorData
	// Flags: [Final|Native|Private]
	void OnRep_LevelDirectorData(); // Offset: 0x1022ad8f0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UAETrigger.UAELevelDirector.InitialLevelDirector
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	bool InitialLevelDirector(); // Offset: 0x1022ad8b4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UAETrigger.UAELevelDirector.GetTrigger
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UUAETriggerObject* GetTrigger(struct FString NodeName, struct FString TriggerName); // Offset: 0x1022ad770 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function UAETrigger.UAELevelDirector.GetHasBeenInit
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetHasBeenInit(); // Offset: 0x1022ad73c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UAETrigger.UAELevelDirector.GetDataSet
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UVariableSet* GetDataSet(); // Offset: 0x1022ad708 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UAETrigger.UAELevelDirector.GetCurTaskID
	// Flags: [Final|Native|Public]
	int GetCurTaskID(); // Offset: 0x1022ad6d4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UAETrigger.UAELevelDirector.ForceExecuteTrigger
	// Flags: [Final|Native|Public]
	void ForceExecuteTrigger(struct FString TriggerName); // Offset: 0x1022ad618 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UAETrigger.UAELevelDirector.FlowControllSubControll
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool FlowControllSubControll(struct TArray<struct FString>& TriggerNames, struct FString NodeName); // Offset: 0x1022ad4e4 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function UAETrigger.UAELevelDirector.FlowControllOr
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool FlowControllOr(struct TArray<struct FString>& TriggerNames, struct FString NodeName); // Offset: 0x1022ad3b0 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function UAETrigger.UAELevelDirector.FlowControllOneSequence
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool FlowControllOneSequence(struct FString TriggerName, struct FString NodeName); // Offset: 0x1022ad26c // Return & Params: Num(3) Size(0x21)

	// Object Name: Function UAETrigger.UAELevelDirector.FlowControllMultiSequence
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool FlowControllMultiSequence(struct TArray<struct FString>& TriggerNames, struct FString NodeName); // Offset: 0x1022ad138 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function UAETrigger.UAELevelDirector.FlowControllAnd
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool FlowControllAnd(struct TArray<struct FString>& TriggerNames, struct FString NodeName, bool DefaultActive); // Offset: 0x1022acfb4 // Return & Params: Num(4) Size(0x22)

	// Object Name: Function UAETrigger.UAELevelDirector.DeactiveTrigger
	// Flags: [Final|Native|Public|BlueprintCallable]
	void DeactiveTrigger(struct FString NodeName, struct FString TriggerName); // Offset: 0x1022ace80 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function UAETrigger.UAELevelDirector.DeactiveNode
	// Flags: [Final|Native|Public|BlueprintCallable]
	void DeactiveNode(struct FString NodeName); // Offset: 0x1022acdc4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UAETrigger.UAELevelDirector.ClientExecuteAction
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public]
	void ClientExecuteAction(struct FString ActionClassName, int64_t UId, struct TArray<struct FTriggerParamRepData> RepParams, bool IsKeep, bool IsRevert, struct AUAELevelDirector_PlayerRepInfo* InLevelDirector_PlayerRepInfo); // Offset: 0x1022acbb8 // Return & Params: Num(6) Size(0x38)

	// Object Name: Function UAETrigger.UAELevelDirector.AddEventToTrigger
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddEventToTrigger(struct FString TriggerName, struct UObject* Event); // Offset: 0x1022acabc // Return & Params: Num(2) Size(0x18)

	// Object Name: Function UAETrigger.UAELevelDirector.AddConditionToTrigger
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UTriggerCondition* AddConditionToTrigger(struct FString TriggerName, struct UObject* Condition); // Offset: 0x1022ac9b0 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function UAETrigger.UAELevelDirector.AddActionToTrigger
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UTriggerAction* AddActionToTrigger(struct FString TriggerName, struct UObject* Action); // Offset: 0x1022ac8a4 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function UAETrigger.UAELevelDirector.ActiveTrigger
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ActiveTrigger(struct FString NodeName, struct FString TriggerName); // Offset: 0x1022ac770 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function UAETrigger.UAELevelDirector.ActiveNode
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ActiveNode(struct FString NodeName); // Offset: 0x1022ac6b4 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class UAETrigger.UAELevelDirector_PlayerRepInfo
// Size: 0x440 // Inherited bytes: 0x3c8
struct AUAELevelDirector_PlayerRepInfo : AInfo {
	// Fields
	struct TArray<struct FTriggerActionRepData> ActionRepDatas; // Offset: 0x3c8 // Size: 0x10
	uint32_t UniqueId; // Offset: 0x3d8 // Size: 0x04
	char pad_0x3DC[0x4]; // Offset: 0x3dc // Size: 0x04
	struct AUAELevelDirector* RelevantLevelDirector; // Offset: 0x3e0 // Size: 0x08
	char pad_0x3E8[0x58]; // Offset: 0x3e8 // Size: 0x58

	// Functions

	// Object Name: Function UAETrigger.UAELevelDirector_PlayerRepInfo.OnRep_LevelDirector
	// Flags: [Final|Native|Private]
	void OnRep_LevelDirector(); // Offset: 0x1022ae5c4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UAETrigger.UAELevelDirector_PlayerRepInfo.OnRep_ActionRepDatas
	// Flags: [Final|Native|Private]
	void OnRep_ActionRepDatas(); // Offset: 0x1022ae5b0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UAETrigger.UAELevelDirector_PlayerRepInfo.ClientExecuteAction
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public]
	void ClientExecuteAction(struct FTriggerActionRepData InActionRepData); // Offset: 0x1022ae508 // Return & Params: Num(1) Size(0x30)
};

// Object Name: Class UAETrigger.UAELevelDirectorBlueprint
// Size: 0xd8 // Inherited bytes: 0xd8
struct UUAELevelDirectorBlueprint : UBlueprint {
};

// Object Name: Class UAETrigger.UAELevelEventCenterInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UUAELevelEventCenterInterface : UInterface {
};

// Object Name: Class UAETrigger.UAETriggerArea
// Size: 0x3e8 // Inherited bytes: 0x3c8
struct AUAETriggerArea : AActor {
	// Fields
	struct TArray<struct FTriggerAreaEvent> Enter_EventsList; // Offset: 0x3c8 // Size: 0x10
	struct TArray<struct FTriggerAreaEvent> Leave_EventsList; // Offset: 0x3d8 // Size: 0x10

	// Functions

	// Object Name: Function UAETrigger.UAETriggerArea.OnTriggerExit
	// Flags: [Native|Protected]
	void OnTriggerExit(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int OtherBodyIndex); // Offset: 0x1022aebc4 // Return & Params: Num(4) Size(0x1c)

	// Object Name: Function UAETrigger.UAETriggerArea.OnTriggerEnter
	// Flags: [Native|Protected|HasOutParms]
	void OnTriggerEnter(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Offset: 0x1022ae9e4 // Return & Params: Num(6) Size(0xa8)
};

// Object Name: Class UAETrigger.UAETriggerArea_Sphere
// Size: 0x3f0 // Inherited bytes: 0x3e8
struct AUAETriggerArea_Sphere : AUAETriggerArea {
	// Fields
	struct USphereComponent* SphereCollisionComponent; // Offset: 0x3e8 // Size: 0x08
};

// Object Name: Class UAETrigger.UAETriggerArea_Box
// Size: 0x3f0 // Inherited bytes: 0x3e8
struct AUAETriggerArea_Box : AUAETriggerArea {
	// Fields
	struct UBoxComponent* BoxCollision; // Offset: 0x3e8 // Size: 0x08
};

// Object Name: Class UAETrigger.UAETriggerAreaComponent
// Size: 0x770 // Inherited bytes: 0x700
struct UUAETriggerAreaComponent : UPrimitiveComponent {
	// Fields
	char pad_0x700[0x8]; // Offset: 0x700 // Size: 0x08
	float CheckFrequency; // Offset: 0x708 // Size: 0x04
	char pad_0x70C[0x4]; // Offset: 0x70c // Size: 0x04
	struct TArray<struct FName> CanTriggeredTags; // Offset: 0x710 // Size: 0x10
	float EnterAreaColdTime; // Offset: 0x720 // Size: 0x04
	char pad_0x724[0x4]; // Offset: 0x724 // Size: 0x04
	struct TArray<struct FTriggerAreaEvent> Enter_EventsList; // Offset: 0x728 // Size: 0x10
	float LeaveAreaColdTime; // Offset: 0x738 // Size: 0x04
	char pad_0x73C[0x4]; // Offset: 0x73c // Size: 0x04
	struct TArray<struct FTriggerAreaEvent> Leave_EventsList; // Offset: 0x740 // Size: 0x10
	struct FColor ShapeColor; // Offset: 0x750 // Size: 0x04
	char pad_0x754[0xc]; // Offset: 0x754 // Size: 0x0c
	struct TArray<struct AActor*> CachedEnterAreaActors; // Offset: 0x760 // Size: 0x10
};

// Object Name: Class UAETrigger.UAETriggerAreaComponent_Box
// Size: 0x7a0 // Inherited bytes: 0x770
struct UUAETriggerAreaComponent_Box : UUAETriggerAreaComponent {
	// Fields
	struct FVector BoxExtent; // Offset: 0x770 // Size: 0x0c
	char pad_0x77C[0x24]; // Offset: 0x77c // Size: 0x24
};

// Object Name: Class UAETrigger.UAETriggerAreaComponent_Sphere
// Size: 0x770 // Inherited bytes: 0x770
struct UUAETriggerAreaComponent_Sphere : UUAETriggerAreaComponent {
};

// Object Name: Class UAETrigger.UAETriggerFuncLib
// Size: 0x40 // Inherited bytes: 0x28
struct UUAETriggerFuncLib : UObject {
	// Fields
	struct TArray<struct FTriggerClassItem> ClassItemList; // Offset: 0x28 // Size: 0x10
	struct UVariableSet* DataSet; // Offset: 0x38 // Size: 0x08

	// Functions

	// Object Name: Function UAETrigger.UAETriggerFuncLib.GetLastIteratorActor
	// Flags: [Final|Native|Public]
	struct AActor* GetLastIteratorActor(); // Offset: 0x1022af7a8 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class UAETrigger.UAETriggerParamFuncLib
// Size: 0x40 // Inherited bytes: 0x40
struct UUAETriggerParamFuncLib : UUAETriggerFuncLib {
};

// Object Name: Class UAETrigger.UAETriggerEventFuncLib
// Size: 0x40 // Inherited bytes: 0x40
struct UUAETriggerEventFuncLib : UUAETriggerFuncLib {
};

// Object Name: Class UAETrigger.UAETriggerObject
// Size: 0x1c8 // Inherited bytes: 0x28
struct UUAETriggerObject : UObject {
	// Fields
	enum class EUAETriggerRunType RunType; // Offset: 0x28 // Size: 0x01
	enum class EUAETriggerObjectType TriggerObjectType; // Offset: 0x29 // Size: 0x01
	char pad_0x2A[0x2]; // Offset: 0x2a // Size: 0x02
	int EventDelayTime; // Offset: 0x2c // Size: 0x04
	int ActionDelayTime; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
	struct FString TriggerName; // Offset: 0x38 // Size: 0x10
	struct AActor* OuterActor; // Offset: 0x48 // Size: 0x08
	struct TArray<struct UObject*> TriggerEventsClass; // Offset: 0x50 // Size: 0x10
	struct TArray<struct UTriggerAction*> TriggerActions; // Offset: 0x60 // Size: 0x10
	struct TArray<struct UTriggerCondition*> TriggerConditions; // Offset: 0x70 // Size: 0x10
	struct UFlowNodeBase* CarrierFlowNode; // Offset: 0x80 // Size: 0x08
	bool bActive; // Offset: 0x88 // Size: 0x01
	char pad_0x89[0x17]; // Offset: 0x89 // Size: 0x17
	struct FTimerHandle TimerHandle_EventDelay; // Offset: 0xa0 // Size: 0x08
	struct FTimerHandle TimerHandle_ActionDelay; // Offset: 0xa8 // Size: 0x08
	struct UTriggerEvent* CurEvent; // Offset: 0xb0 // Size: 0x08
	struct FString DelayEventName; // Offset: 0xb8 // Size: 0x10
	struct FString FiredEventName; // Offset: 0xc8 // Size: 0x10
	struct TSet<struct UTriggerEvent*> TriggeredEvents; // Offset: 0xd8 // Size: 0x50
	struct TSet<struct UTriggerAction*> CompleteActions; // Offset: 0x128 // Size: 0x50
	bool IsEnableCheckDo; // Offset: 0x178 // Size: 0x01
	char pad_0x179[0x7]; // Offset: 0x179 // Size: 0x07
	struct AUAELevelDirector* OwnerLevelDirector; // Offset: 0x180 // Size: 0x08
	char pad_0x188[0x18]; // Offset: 0x188 // Size: 0x18
	bool bEnableTick; // Offset: 0x1a0 // Size: 0x01
	char pad_0x1A1[0x3]; // Offset: 0x1a1 // Size: 0x03
	float TickInterval; // Offset: 0x1a4 // Size: 0x04
	bool bShouldReplicateAction; // Offset: 0x1a8 // Size: 0x01
	bool bCacheParamToTriggerObject; // Offset: 0x1a9 // Size: 0x01
	char pad_0x1AA[0x6]; // Offset: 0x1aa // Size: 0x06
	struct TArray<struct UProperty*> eventParams; // Offset: 0x1b0 // Size: 0x10
	char pad_0x1C0[0x8]; // Offset: 0x1c0 // Size: 0x08
};

// Object Name: Class UAETrigger.VariableSet
// Size: 0xd0 // Inherited bytes: 0x28
struct UVariableSet : UObject {
	// Fields
	char pad_0x28[0x50]; // Offset: 0x28 // Size: 0x50
	struct FVariableSetCachedActors DataActors; // Offset: 0x78 // Size: 0x58
};

