#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum UAETrigger.EUAETriggerActionExecPolicy
enum class EUAETriggerActionExecPolicy : uint8 {
	ExecOnServer = 0,
	ExecOnFilterClientWithKeep = 1,
	ExecOnClientWithBroadCast = 2,
	ExecOnFilterClientsWithBroadCast = 3,
	EUAETriggerActionExecPolicy_MAX = 4
};

// Object Name: Enum UAETrigger.EUAETriggerActionState
enum class EUAETriggerActionState : uint8 {
	Running = 0,
	Deactive = 1,
	EUAETriggerActionState_MAX = 2
};

// Object Name: Enum UAETrigger.EFlowTreeType
enum class EFlowTreeType : uint8 {
	Sequence = 0,
	EFlowTreeType_MAX = 1
};

// Object Name: Enum UAETrigger.EUAETriggerObjectType
enum class EUAETriggerObjectType : uint8 {
	Normal = 0,
	EventDelay = 1,
	EUAETriggerObjectType_MAX = 2
};

// Object Name: Enum UAETrigger.EUAETriggerRunType
enum class EUAETriggerRunType : uint8 {
	RunOnDS = 0,
	RunOnClient = 1,
	EUAETriggerRunType_MAX = 2
};

// Object Name: Enum UAETrigger.EFlowNodeType
enum class EFlowNodeType : uint8 {
	None = 0,
	Sequence = 1,
	Or = 2,
	And = 3,
	SubBranch = 4,
	EFlowNodeType_MAX = 5
};

// Object Name: Enum UAETrigger.UAETParamType
enum class UAETParamType : uint8 {
	Invalid = 0,
	Int32 = 1,
	UInt32 = 2,
	Float = 3,
	String = 4,
	Boolean = 5,
	Vector = 6,
	Rotator = 7,
	Actor = 8,
	Func = 9,
	Event = 10,
	Compare = 11,
	Array = 12,
	Object = 13,
	KeyMap = 14,
	UAETParamType_MAX = 15
};

