#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass UICommonFunctionLibrary.UICommonFunctionLibrary_C
// Size: 0x28 // Inherited bytes: 0x28
struct UUICommonFunctionLibrary_C : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function UICommonFunctionLibrary.UICommonFunctionLibrary_C.SetAdaptation_ScreenHole
	// Flags: [Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetAdaptation_ScreenHole(struct UWidget* Widget, struct UObject* __WorldContext); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UICommonFunctionLibrary.UICommonFunctionLibrary_C.SetIPXAdaptation
	// Flags: [Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetIPXAdaptation(struct UWidget* Widget, struct UObject* __WorldContext); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UICommonFunctionLibrary.UICommonFunctionLibrary_C.SetAdaptationByOffset
	// Flags: [Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetAdaptationByOffset(struct UWidget* Widget, struct UObject* __WorldContext); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UICommonFunctionLibrary.UICommonFunctionLibrary_C.SetAdaptation_Lobby
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void SetAdaptation_Lobby(struct UWidget* Widget, struct UObject* __WorldContext); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UICommonFunctionLibrary.UICommonFunctionLibrary_C.FormatSecondsToString
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void FormatSecondsToString(int Seconds, struct UObject* __WorldContext, struct FText& Ret); // Offset: 0x103e7af64 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function UICommonFunctionLibrary.UICommonFunctionLibrary_C.SetSquareFixedScslr
	// Flags: [Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetSquareFixedScslr(struct UWidget* Widget, struct UObject* __WorldContext); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UICommonFunctionLibrary.UICommonFunctionLibrary_C.SetAdaptation
	// Flags: [Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetAdaptation(struct UWidget* Widget, struct UObject* __WorldContext); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UICommonFunctionLibrary.UICommonFunctionLibrary_C.SetTabStyle
	// Flags: [Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetTabStyle(bool isCheck, struct UTextBlock* Text, struct UImage* Icon, struct FColor onColor, struct FColor offColor, struct UObject* __WorldContext); // Offset: 0x103e7af64 // Return & Params: Num(6) Size(0x28)
};

