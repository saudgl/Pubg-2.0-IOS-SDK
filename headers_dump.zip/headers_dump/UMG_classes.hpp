#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class UMG.Visual
// Size: 0x28 // Inherited bytes: 0x28
struct UVisual : UObject {
};

// Object Name: Class UMG.Widget
// Size: 0x100 // Inherited bytes: 0x28
struct UWidget : UVisual {
	// Fields
	struct UPanelSlot* Slot; // Offset: 0x28 // Size: 0x08
	DelegateProperty bIsEnabledDelegate; // Offset: 0x30 // Size: 0x10
	struct FText ToolTipText; // Offset: 0x40 // Size: 0x18
	DelegateProperty ToolTipTextDelegate; // Offset: 0x58 // Size: 0x10
	struct UWidget* ToolTipWidget; // Offset: 0x68 // Size: 0x08
	DelegateProperty ToolTipWidgetDelegate; // Offset: 0x70 // Size: 0x10
	DelegateProperty VisibilityDelegate; // Offset: 0x80 // Size: 0x10
	struct FWidgetTransform RenderTransform; // Offset: 0x90 // Size: 0x1c
	struct FVector2D RenderTransformPivot; // Offset: 0xac // Size: 0x08
	char bIsVariable : 1; // Offset: 0xb4 // Size: 0x01
	char bCreatedByConstructionScript : 1; // Offset: 0xb4 // Size: 0x01
	char bIsEnabled : 1; // Offset: 0xb4 // Size: 0x01
	char bOverride_Cursor : 1; // Offset: 0xb4 // Size: 0x01
	char bIsVolatile : 1; // Offset: 0xb4 // Size: 0x01
	char bWriteSceneZBuffer : 1; // Offset: 0xb4 // Size: 0x01
	char pad_0xB4_6 : 2; // Offset: 0xb4 // Size: 0x01
	char UsedLayerPolicy; // Offset: 0xb5 // Size: 0x01
	char PreservedLayerNum; // Offset: 0xb6 // Size: 0x01
	enum class EMouseCursor Cursor; // Offset: 0xb7 // Size: 0x01
	enum class EWidgetClipping Clipping; // Offset: 0xb8 // Size: 0x01
	enum class ESlateVisibility Visibility; // Offset: 0xb9 // Size: 0x01
	bool bVisiblePass; // Offset: 0xba // Size: 0x01
	enum class EWidgetVisible WidgetVisible; // Offset: 0xbb // Size: 0x01
	char pad_0xBC[0x4]; // Offset: 0xbc // Size: 0x04
	struct UWidgetNavigation* Navigation; // Offset: 0xc0 // Size: 0x08
	char pad_0xC8[0x28]; // Offset: 0xc8 // Size: 0x28
	struct TArray<struct UPropertyBinding*> NativeBindings; // Offset: 0xf0 // Size: 0x10

	// Functions

	// Object Name: Function UMG.Widget.SetWidgetRender
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetWidgetRender(enum class EWidgetVisible InWidgetVisible); // Offset: 0x1048e6ce4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Widget.SetVisibility
	// Flags: [Native|Public|BlueprintCallable]
	void SetVisibility(enum class ESlateVisibility InVisibility); // Offset: 0x1048e6c60 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Widget.SetUserFocus
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetUserFocus(struct APlayerController* PlayerController); // Offset: 0x1048e6be4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Widget.SetToolTipText
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetToolTipText(struct FText& InToolTipText); // Offset: 0x1048e6b38 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.Widget.SetToolTip
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetToolTip(struct UWidget* Widget); // Offset: 0x1048e6abc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Widget.SetRenderTranslation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetRenderTranslation(struct FVector2D Translation); // Offset: 0x1048e6a44 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Widget.SetRenderTransformPivot
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetRenderTransformPivot(struct FVector2D Pivot); // Offset: 0x1048e69cc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Widget.SetRenderTransform
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetRenderTransform(struct FWidgetTransform InTransform); // Offset: 0x1048e6920 // Return & Params: Num(1) Size(0x1c)

	// Object Name: Function UMG.Widget.SetRenderShear
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetRenderShear(struct FVector2D Shear); // Offset: 0x1048e68a8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Widget.SetRenderScale
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetRenderScale(struct FVector2D Scale); // Offset: 0x1048e6830 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Widget.SetRenderAngle
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetRenderAngle(float Angle); // Offset: 0x1048e67b4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.Widget.SetNavigationRule
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetNavigationRule(enum class EUINavigation Direction, enum class EUINavigationRule Rule, struct FName WidgetToFocus); // Offset: 0x1048e66c0 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function UMG.Widget.SetKeyboardFocus
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetKeyboardFocus(); // Offset: 0x1048e66ac // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.Widget.SetIsEnabled
	// Flags: [Native|Public|BlueprintCallable]
	void SetIsEnabled(bool bInIsEnabled); // Offset: 0x1048e6620 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Widget.SetCursor
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetCursor(enum class EMouseCursor InCursor); // Offset: 0x1048e65a4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Widget.SetClipping
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetClipping(enum class EWidgetClipping InClipping); // Offset: 0x1048e6528 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Widget.SetAllNavigationRules
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAllNavigationRules(enum class EUINavigationRule Rule, struct FName WidgetToFocus); // Offset: 0x1048e6470 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.Widget.ResetCursor
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ResetCursor(); // Offset: 0x1048e645c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.Widget.RemoveFromParent
	// Flags: [Native|Public|BlueprintCallable]
	void RemoveFromParent(); // Offset: 0x1048e6440 // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction UMG.Widget.OnReply__DelegateSignature
	// Flags: [Public|Delegate]
	struct FEventReply OnReply__DelegateSignature(); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0xb8)

	// Object Name: DelegateFunction UMG.Widget.OnPointerEvent__DelegateSignature
	// Flags: [Public|Delegate|HasOutParms]
	struct FEventReply OnPointerEvent__DelegateSignature(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Offset: 0x103e7af64 // Return & Params: Num(3) Size(0x168)

	// Object Name: Function UMG.Widget.IsVisible
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsVisible(); // Offset: 0x1048e640c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Widget.IsHovered
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsHovered(); // Offset: 0x1048e63d8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Widget.InvalidateLayoutAndVolatility
	// Flags: [Final|Native|Public|BlueprintCallable]
	void InvalidateLayoutAndVolatility(); // Offset: 0x1048e63c4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.Widget.HasUserFocusedDescendants
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasUserFocusedDescendants(struct APlayerController* PlayerController); // Offset: 0x1048e6338 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function UMG.Widget.HasUserFocus
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasUserFocus(struct APlayerController* PlayerController); // Offset: 0x1048e62ac // Return & Params: Num(2) Size(0x9)

	// Object Name: Function UMG.Widget.HasMouseCapture
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasMouseCapture(); // Offset: 0x1048e6278 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Widget.HasKeyboardFocus
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasKeyboardFocus(); // Offset: 0x1048e6244 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Widget.HasFocusedDescendants
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasFocusedDescendants(); // Offset: 0x1048e6210 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Widget.HasAnyUserFocus
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasAnyUserFocus(); // Offset: 0x1048e61dc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Widget.GetWidgetRender
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class EWidgetVisible GetWidgetRender(); // Offset: 0x1048e61a8 // Return & Params: Num(1) Size(0x1)

	// Object Name: DelegateFunction UMG.Widget.GetWidget__DelegateSignature
	// Flags: [Public|Delegate]
	struct UWidget* GetWidget__DelegateSignature(); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Widget.GetVisibility
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class ESlateVisibility GetVisibility(); // Offset: 0x1048e6174 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Widget.GetTheTemplate
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UWidget* GetTheTemplate(); // Offset: 0x1048e6140 // Return & Params: Num(1) Size(0x8)

	// Object Name: DelegateFunction UMG.Widget.GetText__DelegateSignature
	// Flags: [Public|Delegate]
	struct FText GetText__DelegateSignature(); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x18)

	// Object Name: DelegateFunction UMG.Widget.GetSlateVisibility__DelegateSignature
	// Flags: [Public|Delegate]
	enum class ESlateVisibility GetSlateVisibility__DelegateSignature(); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x1)

	// Object Name: DelegateFunction UMG.Widget.GetSlateColor__DelegateSignature
	// Flags: [Public|Delegate]
	struct FSlateColor GetSlateColor__DelegateSignature(); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x28)

	// Object Name: DelegateFunction UMG.Widget.GetSlateBrush__DelegateSignature
	// Flags: [Public|Delegate]
	struct FSlateBrush GetSlateBrush__DelegateSignature(); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0xb8)

	// Object Name: Function UMG.Widget.GetParent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UPanelWidget* GetParent(); // Offset: 0x1048e610c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Widget.GetOwningPlayer
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct APlayerController* GetOwningPlayer(); // Offset: 0x1048e60d0 // Return & Params: Num(1) Size(0x8)

	// Object Name: DelegateFunction UMG.Widget.GetMouseCursor__DelegateSignature
	// Flags: [Public|Delegate]
	enum class EMouseCursor GetMouseCursor__DelegateSignature(); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x1)

	// Object Name: DelegateFunction UMG.Widget.GetLinearColor__DelegateSignature
	// Flags: [Public|Delegate|HasDefaults]
	struct FLinearColor GetLinearColor__DelegateSignature(); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.Widget.GetIsEnabled
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool GetIsEnabled(); // Offset: 0x1048e609c // Return & Params: Num(1) Size(0x1)

	// Object Name: DelegateFunction UMG.Widget.GetInt32__DelegateSignature
	// Flags: [Public|Delegate]
	int GetInt32__DelegateSignature(); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x4)

	// Object Name: DelegateFunction UMG.Widget.GetFloat__DelegateSignature
	// Flags: [Public|Delegate]
	float GetFloat__DelegateSignature(); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.Widget.GetDesiredSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector2D GetDesiredSize(); // Offset: 0x1048e6064 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Widget.GetClipping
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class EWidgetClipping GetClipping(); // Offset: 0x1048e6030 // Return & Params: Num(1) Size(0x1)

	// Object Name: DelegateFunction UMG.Widget.GetCheckBoxState__DelegateSignature
	// Flags: [Public|Delegate]
	enum class ECheckBoxState GetCheckBoxState__DelegateSignature(); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Widget.GetCachedGeometry
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FGeometry GetCachedGeometry(); // Offset: 0x1048e5ff8 // Return & Params: Num(1) Size(0x38)

	// Object Name: Function UMG.Widget.GetCachedAllottedGeometry
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FGeometry GetCachedAllottedGeometry(); // Offset: 0x1048e5fc0 // Return & Params: Num(1) Size(0x38)

	// Object Name: DelegateFunction UMG.Widget.GetBool__DelegateSignature
	// Flags: [Public|Delegate]
	bool GetBool__DelegateSignature(); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x1)

	// Object Name: DelegateFunction UMG.Widget.GenerateWidgetForString__DelegateSignature
	// Flags: [Public|Delegate]
	struct UWidget* GenerateWidgetForString__DelegateSignature(struct FString Item); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0x18)

	// Object Name: DelegateFunction UMG.Widget.GenerateWidgetForObject__DelegateSignature
	// Flags: [Public|Delegate]
	struct UWidget* GenerateWidgetForObject__DelegateSignature(struct UObject* Item); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.Widget.ForceVolatile
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ForceVolatile(bool bForce); // Offset: 0x1048e5f3c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Widget.ForceLayoutPrepass
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ForceLayoutPrepass(); // Offset: 0x1048e5f28 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.Widget.AdaptationWidgetSlot
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void AdaptationWidgetSlot(struct FMargin& InOffset); // Offset: 0x1048e5e9c // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class UMG.UserWidget
// Size: 0x218 // Inherited bytes: 0x100
struct UUserWidget : UWidget {
	// Fields
	char pad_0x100[0x8]; // Offset: 0x100 // Size: 0x08
	struct FLinearColor ColorAndOpacity; // Offset: 0x108 // Size: 0x10
	DelegateProperty ColorAndOpacityDelegate; // Offset: 0x118 // Size: 0x10
	struct FSlateColor ForegroundColor; // Offset: 0x128 // Size: 0x28
	DelegateProperty ForegroundColorDelegate; // Offset: 0x150 // Size: 0x10
	struct FMargin Padding; // Offset: 0x160 // Size: 0x10
	struct TArray<struct UUMGSequencePlayer*> ActiveSequencePlayers; // Offset: 0x170 // Size: 0x10
	struct TArray<struct UUMGSequencePlayer*> StoppedSequencePlayers; // Offset: 0x180 // Size: 0x10
	struct TArray<struct FNamedSlotBinding> NamedSlotBindings; // Offset: 0x190 // Size: 0x10
	struct UWidgetTree* WidgetTree; // Offset: 0x1a0 // Size: 0x08
	int Priority; // Offset: 0x1a8 // Size: 0x04
	char bSupportsKeyboardFocus : 1; // Offset: 0x1ac // Size: 0x01
	char bIsFocusable : 1; // Offset: 0x1ac // Size: 0x01
	char bStopAction : 1; // Offset: 0x1ac // Size: 0x01
	char bCanEverTick : 1; // Offset: 0x1ac // Size: 0x01
	char bCanEverPaint : 1; // Offset: 0x1ac // Size: 0x01
	char bDontPaintWhenChildEmpty : 1; // Offset: 0x1ac // Size: 0x01
	char pad_0x1AC_6 : 1; // Offset: 0x1ac // Size: 0x01
	char bCookedWidgetTree : 1; // Offset: 0x1ac // Size: 0x01
	bool needAutoPlay; // Offset: 0x1ad // Size: 0x01
	bool isAutoLoop; // Offset: 0x1ae // Size: 0x01
	char pad_0x1AF[0x1]; // Offset: 0x1af // Size: 0x01
	struct TArray<struct FName> autoPlayNameList; // Offset: 0x1b0 // Size: 0x10
	struct UInputComponent* InputComponent; // Offset: 0x1c0 // Size: 0x08
	char pad_0x1C8[0x50]; // Offset: 0x1c8 // Size: 0x50

	// Functions

	// Object Name: Function UMG.UserWidget.UnregisterInputComponent
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void UnregisterInputComponent(); // Offset: 0x1048e172c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.UserWidget.Tick
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0x3c)

	// Object Name: Function UMG.UserWidget.StopListeningForInputAction
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void StopListeningForInputAction(struct FName ActionName, enum class EInputEvent EventType); // Offset: 0x1048e166c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function UMG.UserWidget.StopListeningForAllInputActions
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void StopListeningForAllInputActions(); // Offset: 0x1048e1658 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.UserWidget.StopAnimation
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void StopAnimation(struct UWidgetAnimation* InAnimation); // Offset: 0x1048e15dc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.SetPositionInViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|HasDefaults|BlueprintCallable]
	void SetPositionInViewport(struct FVector2D Position, bool bRemoveDPIScale); // Offset: 0x1048e1520 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function UMG.UserWidget.SetPlaybackSpeed
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void SetPlaybackSpeed(struct UWidgetAnimation* InAnimation, float PlaybackSpeed); // Offset: 0x1048e1468 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function UMG.UserWidget.SetPadding
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x1048e13e8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.UserWidget.SetOwningPlayer
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void SetOwningPlayer(struct APlayerController* LocalPlayerController); // Offset: 0x1048e136c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.SetOwningLocalPlayer
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void SetOwningLocalPlayer(struct ULocalPlayer* LocalPlayer); // Offset: 0x1048e12f0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.SetNumLoopsToPlay
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void SetNumLoopsToPlay(struct UWidgetAnimation* InAnimation, int NumLoopsToPlay); // Offset: 0x1048e1238 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function UMG.UserWidget.SetInputActionPriority
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void SetInputActionPriority(int NewPriority); // Offset: 0x1048e11bc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.UserWidget.SetInputActionBlocking
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void SetInputActionBlocking(bool bShouldBlock); // Offset: 0x1048e1138 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.UserWidget.SetForegroundColor
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void SetForegroundColor(struct FSlateColor InForegroundColor); // Offset: 0x1048e1034 // Return & Params: Num(1) Size(0x28)

	// Object Name: Function UMG.UserWidget.SetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDontPaintWhenChildEmpty(bool Enable); // Offset: 0x1048e0fb0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.UserWidget.SetDesiredSizeInViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|HasDefaults|BlueprintCallable]
	void SetDesiredSizeInViewport(struct FVector2D Size); // Offset: 0x1048e0f38 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.SetColorAndOpacity
	// Flags: [Final|BlueprintCosmetic|Native|Public|HasDefaults|BlueprintCallable]
	void SetColorAndOpacity(struct FLinearColor InColorAndOpacity); // Offset: 0x1048e0ebc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.UserWidget.SetAnchorsInViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void SetAnchorsInViewport(struct FAnchors Anchors); // Offset: 0x1048e0e3c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.UserWidget.SetAlignmentInViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|HasDefaults|BlueprintCallable]
	void SetAlignmentInViewport(struct FVector2D Alignment); // Offset: 0x1048e0dc4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.ReverseAnimation
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void ReverseAnimation(struct UWidgetAnimation* InAnimation); // Offset: 0x1048e0d48 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.RemoveFromViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void RemoveFromViewport(); // Offset: 0x1048e0d34 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.UserWidget.RegisterInputComponent
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void RegisterInputComponent(); // Offset: 0x1048e0d20 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.UserWidget.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.UserWidget.PlaySound
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void PlaySound(struct USoundBase* SoundToPlay); // Offset: 0x1048e0ca4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.PlayAnimationTo
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void PlayAnimationTo(struct UWidgetAnimation* InAnimation, float StartAtTime, float EndAtTime, int NumLoopsToPlay, enum class EUMGSequencePlayMode PlayMode, float PlaybackSpeed); // Offset: 0x1048e0b00 // Return & Params: Num(6) Size(0x1c)

	// Object Name: Function UMG.UserWidget.PlayAnimation
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void PlayAnimation(struct UWidgetAnimation* InAnimation, float StartAtTime, int NumLoopsToPlay, enum class EUMGSequencePlayMode PlayMode, float PlaybackSpeed); // Offset: 0x1048e0994 // Return & Params: Num(5) Size(0x18)

	// Object Name: Function UMG.UserWidget.PauseAnimation
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	float PauseAnimation(struct UWidgetAnimation* InAnimation); // Offset: 0x1048e0908 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function UMG.UserWidget.OnTouchStarted
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	struct FEventReply OnTouchStarted(struct FGeometry MyGeometry, struct FPointerEvent& InTouchEvent); // Offset: 0x103e7af64 // Return & Params: Num(3) Size(0x168)

	// Object Name: Function UMG.UserWidget.OnTouchMoved
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	struct FEventReply OnTouchMoved(struct FGeometry MyGeometry, struct FPointerEvent& InTouchEvent); // Offset: 0x103e7af64 // Return & Params: Num(3) Size(0x168)

	// Object Name: Function UMG.UserWidget.OnTouchGesture
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	struct FEventReply OnTouchGesture(struct FGeometry MyGeometry, struct FPointerEvent& GestureEvent); // Offset: 0x103e7af64 // Return & Params: Num(3) Size(0x168)

	// Object Name: Function UMG.UserWidget.OnTouchEnded
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	struct FEventReply OnTouchEnded(struct FGeometry MyGeometry, struct FPointerEvent& InTouchEvent); // Offset: 0x103e7af64 // Return & Params: Num(3) Size(0x168)

	// Object Name: Function UMG.UserWidget.OnRemovedFromFocusPath
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void OnRemovedFromFocusPath(struct FFocusEvent InFocusEvent); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.OnPreviewMouseButtonDown
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	struct FEventReply OnPreviewMouseButtonDown(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Offset: 0x103e7af64 // Return & Params: Num(3) Size(0x168)

	// Object Name: Function UMG.UserWidget.OnPreviewKeyDown
	// Flags: [Event|Public|BlueprintEvent]
	struct FEventReply OnPreviewKeyDown(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent); // Offset: 0x103e7af64 // Return & Params: Num(3) Size(0x130)

	// Object Name: Function UMG.UserWidget.OnPaint
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent|Const]
	void OnPaint(struct FPaintContext& Context); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x30)

	// Object Name: Function UMG.UserWidget.OnMouseWheel
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	struct FEventReply OnMouseWheel(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Offset: 0x103e7af64 // Return & Params: Num(3) Size(0x168)

	// Object Name: Function UMG.UserWidget.OnMouseMove
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	struct FEventReply OnMouseMove(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Offset: 0x103e7af64 // Return & Params: Num(3) Size(0x168)

	// Object Name: Function UMG.UserWidget.OnMouseLeave
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	void OnMouseLeave(struct FPointerEvent& MouseEvent); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x78)

	// Object Name: Function UMG.UserWidget.OnMouseEnter
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	void OnMouseEnter(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0xb0)

	// Object Name: Function UMG.UserWidget.OnMouseCaptureLost
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void OnMouseCaptureLost(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.UserWidget.OnMouseButtonUp
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	struct FEventReply OnMouseButtonUp(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Offset: 0x103e7af64 // Return & Params: Num(3) Size(0x168)

	// Object Name: Function UMG.UserWidget.OnMouseButtonDown
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	struct FEventReply OnMouseButtonDown(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Offset: 0x103e7af64 // Return & Params: Num(3) Size(0x168)

	// Object Name: Function UMG.UserWidget.OnMouseButtonDoubleClick
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	struct FEventReply OnMouseButtonDoubleClick(struct FGeometry InMyGeometry, struct FPointerEvent& InMouseEvent); // Offset: 0x103e7af64 // Return & Params: Num(3) Size(0x168)

	// Object Name: Function UMG.UserWidget.OnMotionDetected
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	struct FEventReply OnMotionDetected(struct FGeometry MyGeometry, struct FMotionEvent InMotionEvent); // Offset: 0x103e7af64 // Return & Params: Num(3) Size(0x140)

	// Object Name: Function UMG.UserWidget.OnKeyUp
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	struct FEventReply OnKeyUp(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent); // Offset: 0x103e7af64 // Return & Params: Num(3) Size(0x130)

	// Object Name: Function UMG.UserWidget.OnKeyDown
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	struct FEventReply OnKeyDown(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent); // Offset: 0x103e7af64 // Return & Params: Num(3) Size(0x130)

	// Object Name: Function UMG.UserWidget.OnKeyChar
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	struct FEventReply OnKeyChar(struct FGeometry MyGeometry, struct FCharacterEvent InCharacterEvent); // Offset: 0x103e7af64 // Return & Params: Num(3) Size(0x118)

	// Object Name: Function UMG.UserWidget.OnFocusReceived
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	struct FEventReply OnFocusReceived(struct FGeometry MyGeometry, struct FFocusEvent InFocusEvent); // Offset: 0x103e7af64 // Return & Params: Num(3) Size(0xf8)

	// Object Name: Function UMG.UserWidget.OnFocusLost
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void OnFocusLost(struct FFocusEvent InFocusEvent); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.OnDrop
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	bool OnDrop(struct FGeometry MyGeometry, struct FPointerEvent PointerEvent, struct UDragDropOperation* Operation); // Offset: 0x103e7af64 // Return & Params: Num(4) Size(0xb9)

	// Object Name: Function UMG.UserWidget.OnDragOver
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	bool OnDragOver(struct FGeometry MyGeometry, struct FPointerEvent PointerEvent, struct UDragDropOperation* Operation); // Offset: 0x103e7af64 // Return & Params: Num(4) Size(0xb9)

	// Object Name: Function UMG.UserWidget.OnDragLeave
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void OnDragLeave(struct FPointerEvent PointerEvent, struct UDragDropOperation* Operation); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0x80)

	// Object Name: Function UMG.UserWidget.OnDragEnter
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void OnDragEnter(struct FGeometry MyGeometry, struct FPointerEvent PointerEvent, struct UDragDropOperation* Operation); // Offset: 0x103e7af64 // Return & Params: Num(3) Size(0xb8)

	// Object Name: Function UMG.UserWidget.OnDragDetected
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	void OnDragDetected(struct FGeometry MyGeometry, struct FPointerEvent& PointerEvent, struct UDragDropOperation*& Operation); // Offset: 0x103e7af64 // Return & Params: Num(3) Size(0xb8)

	// Object Name: Function UMG.UserWidget.OnDragCancelled
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	void OnDragCancelled(struct FPointerEvent& PointerEvent, struct UDragDropOperation* Operation); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0x80)

	// Object Name: Function UMG.UserWidget.OnAnimationStarted
	// Flags: [BlueprintCosmetic|Native|Event|Public|BlueprintEvent]
	void OnAnimationStarted(struct UWidgetAnimation* Animation); // Offset: 0x1048e0884 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.OnAnimationFinished
	// Flags: [BlueprintCosmetic|Native|Event|Public|BlueprintEvent]
	void OnAnimationFinished(struct UWidgetAnimation* Animation); // Offset: 0x1048e0800 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.OnAnalogValueChanged
	// Flags: [Event|Public|BlueprintEvent]
	struct FEventReply OnAnalogValueChanged(struct FGeometry MyGeometry, struct FAnalogInputEvent InAnalogInputEvent); // Offset: 0x103e7af64 // Return & Params: Num(3) Size(0x138)

	// Object Name: Function UMG.UserWidget.OnAddedToFocusPath
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void OnAddedToFocusPath(struct FFocusEvent InFocusEvent); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.ListenForInputAction
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void ListenForInputAction(struct FName ActionName, enum class EInputEvent EventType, bool bConsume, DelegateProperty Callback); // Offset: 0x1048e06a4 // Return & Params: Num(4) Size(0x20)

	// Object Name: Function UMG.UserWidget.IsPlayingAnimation
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsPlayingAnimation(); // Offset: 0x1048e0680 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.UserWidget.IsListeningForInputAction
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure|Const]
	bool IsListeningForInputAction(struct FName ActionName); // Offset: 0x1048e05f4 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function UMG.UserWidget.IsInViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsInViewport(); // Offset: 0x1048e05c0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.UserWidget.IsInteractable
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent|Const]
	bool IsInteractable(); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.UserWidget.IsAnyAnimationPlaying
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsAnyAnimationPlaying(); // Offset: 0x1048e058c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.UserWidget.IsAnimationPlayingForward
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	bool IsAnimationPlayingForward(struct UWidgetAnimation* InAnimation); // Offset: 0x1048e0500 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function UMG.UserWidget.IsAnimationPlaying
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsAnimationPlaying(struct UWidgetAnimation* InAnimation); // Offset: 0x1048e0474 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function UMG.UserWidget.GetWidgetFromName
	// Flags: [Final|Native|Public|HasOutParms|Const]
	struct UWidget* GetWidgetFromName(struct FName& Name); // Offset: 0x1048e03d8 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.UserWidget.GetOwningPlayerPawn
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct APawn* GetOwningPlayerPawn(); // Offset: 0x1048e03a4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.GetOwningPlayer
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct APlayerController* GetOwningPlayer(); // Offset: 0x1048e0368 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.GetOwningLocalPlayer
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct ULocalPlayer* GetOwningLocalPlayer(); // Offset: 0x1048e0334 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.GetIsVisible
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool GetIsVisible(); // Offset: 0x1048e0300 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.UserWidget.GetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetDontPaintWhenChildEmpty(); // Offset: 0x1048e02cc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.UserWidget.GetAnimationCurrentTime
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetAnimationCurrentTime(struct UWidgetAnimation* InAnimation); // Offset: 0x1048e0240 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function UMG.UserWidget.GetAnchorsInViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FAnchors GetAnchorsInViewport(); // Offset: 0x1048e0200 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.UserWidget.GetAlignmentInViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector2D GetAlignmentInViewport(); // Offset: 0x1048e01c8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.Destruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Destruct(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.UserWidget.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.UserWidget.AddToViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void AddToViewport(int ZOrder); // Offset: 0x1048e014c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.UserWidget.AddToPlayerScreen
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	bool AddToPlayerScreen(int ZOrder); // Offset: 0x1048e00c0 // Return & Params: Num(2) Size(0x5)
};

// Object Name: Class UMG.PanelWidget
// Size: 0x118 // Inherited bytes: 0x100
struct UPanelWidget : UWidget {
	// Fields
	struct TArray<struct UPanelSlot*> Slots; // Offset: 0x100 // Size: 0x10
	char pad_0x110[0x8]; // Offset: 0x110 // Size: 0x08

	// Functions

	// Object Name: Function UMG.PanelWidget.RemoveChildAt
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool RemoveChildAt(int Index); // Offset: 0x1048d2a64 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function UMG.PanelWidget.RemoveChild
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool RemoveChild(struct UWidget* Content); // Offset: 0x1048d29d8 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function UMG.PanelWidget.HasChild
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasChild(struct UWidget* Content); // Offset: 0x1048d294c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function UMG.PanelWidget.HasAnyChildren
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasAnyChildren(); // Offset: 0x1048d2918 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.PanelWidget.GetChildrenCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetChildrenCount(); // Offset: 0x1048d28e4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.PanelWidget.GetChildIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetChildIndex(struct UWidget* Content); // Offset: 0x1048d2858 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function UMG.PanelWidget.GetChildAt
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UWidget* GetChildAt(int Index); // Offset: 0x1048d27cc // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.PanelWidget.ClearChildren
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearChildren(); // Offset: 0x1048d27b8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.PanelWidget.AddChild
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UPanelSlot* AddChild(struct UWidget* Content); // Offset: 0x1048d272c // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class UMG.CanvasPanel
// Size: 0x130 // Inherited bytes: 0x118
struct UCanvasPanel : UPanelWidget {
	// Fields
	char pad_0x118[0x10]; // Offset: 0x118 // Size: 0x10
	bool bDontPaintWhenChildEmpty; // Offset: 0x128 // Size: 0x01
	char pad_0x129[0x7]; // Offset: 0x129 // Size: 0x07

	// Functions

	// Object Name: Function UMG.CanvasPanel.SetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void SetDontPaintWhenChildEmpty(bool Enable); // Offset: 0x1048c8030 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.CanvasPanel.GetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Protected|BlueprintCallable]
	bool GetDontPaintWhenChildEmpty(); // Offset: 0x1048c7ffc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.CanvasPanel.AddChildToCanvas
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UCanvasPanelSlot* AddChildToCanvas(struct UWidget* Content); // Offset: 0x1048c7f70 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class UMG.ScrollBox
// Size: 0xb28 // Inherited bytes: 0x118
struct UScrollBox : UPanelWidget {
	// Fields
	struct FScrollBoxStyle WidgetStyle; // Offset: 0x118 // Size: 0x2e8
	struct FScrollBarStyle WidgetBarStyle; // Offset: 0x400 // Size: 0x680
	struct USlateWidgetStyleAsset* Style; // Offset: 0xa80 // Size: 0x08
	struct USlateWidgetStyleAsset* BarStyle; // Offset: 0xa88 // Size: 0x08
	enum class EOrientation Orientation; // Offset: 0xa90 // Size: 0x01
	enum class ESlateVisibility ScrollBarVisibility; // Offset: 0xa91 // Size: 0x01
	enum class EConsumeMouseWheel ConsumeMouseWheel; // Offset: 0xa92 // Size: 0x01
	char pad_0xA93[0x1]; // Offset: 0xa93 // Size: 0x01
	struct FVector2D ScrollbarThickness; // Offset: 0xa94 // Size: 0x08
	bool AlwaysShowScrollbar; // Offset: 0xa9c // Size: 0x01
	bool AllowOverscroll; // Offset: 0xa9d // Size: 0x01
	enum class EDescendantScrollDestination NavigationDestination; // Offset: 0xa9e // Size: 0x01
	char pad_0xA9F[0x1]; // Offset: 0xa9f // Size: 0x01
	float NavigationScrollPadding; // Offset: 0xaa0 // Size: 0x04
	float EdgePadding; // Offset: 0xaa4 // Size: 0x04
	bool bAllowRightClickDragScrolling; // Offset: 0xaa8 // Size: 0x01
	bool bDontPaintWhenChildEmpty; // Offset: 0xaa9 // Size: 0x01
	char pad_0xAAA[0x6]; // Offset: 0xaaa // Size: 0x06
	struct FScriptMulticastDelegate OnUserScrolled; // Offset: 0xab0 // Size: 0x10
	struct FScriptMulticastDelegate OnUserScrolledUnused; // Offset: 0xac0 // Size: 0x10
	struct FScriptMulticastDelegate OnBeginScroll; // Offset: 0xad0 // Size: 0x10
	struct FScriptMulticastDelegate OnEndScroll; // Offset: 0xae0 // Size: 0x10
	struct FScriptMulticastDelegate OnTouchStartEvent; // Offset: 0xaf0 // Size: 0x10
	struct FScriptMulticastDelegate OnTouchEndEvent; // Offset: 0xb00 // Size: 0x10
	char pad_0xB10[0x18]; // Offset: 0xb10 // Size: 0x18

	// Functions

	// Object Name: Function UMG.ScrollBox.StopScroll
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StopScroll(); // Offset: 0x1048d6a30 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.ScrollBox.SetScrollOffset
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetScrollOffset(float NewScrollOffset); // Offset: 0x1048d69b4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.ScrollBox.SetScrollBarVisibility
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetScrollBarVisibility(enum class ESlateVisibility NewScrollBarVisibility); // Offset: 0x1048d6938 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ScrollBox.SetScrollbarThickness
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SetScrollbarThickness(struct FVector2D& NewScrollbarThickness); // Offset: 0x1048d68b0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.ScrollBox.SetOrientation
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetOrientation(enum class EOrientation NewOrientation); // Offset: 0x1048d6834 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ScrollBox.SetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDontPaintWhenChildEmpty(bool Enable); // Offset: 0x1048d67b0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ScrollBox.SetAlwaysShowScrollbar
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAlwaysShowScrollbar(bool NewAlwaysShowScrollbar); // Offset: 0x1048d672c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ScrollBox.SetAllowOverscroll
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAllowOverscroll(bool NewAllowOverscroll); // Offset: 0x1048d66a8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ScrollBox.ScrollWidgetIntoView
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ScrollWidgetIntoView(struct UWidget* WidgetToFind, bool AnimateScroll, enum class EDescendantScrollDestination ScrollDestination); // Offset: 0x1048d65a4 // Return & Params: Num(3) Size(0xa)

	// Object Name: Function UMG.ScrollBox.ScrollToStart
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ScrollToStart(); // Offset: 0x1048d6590 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.ScrollBox.ScrollToEnd
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ScrollToEnd(); // Offset: 0x1048d657c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.ScrollBox.GetScrollOffset
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetScrollOffset(); // Offset: 0x1048d6548 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.ScrollBox.GetScrollEndOffset
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetScrollEndOffset(); // Offset: 0x1048d6514 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.ScrollBox.GetIsScrolling
	// Flags: [Final|Native|Public]
	bool GetIsScrolling(); // Offset: 0x1048d64ec // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ScrollBox.GetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetDontPaintWhenChildEmpty(); // Offset: 0x1048d64b8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ScrollBox.GetCacheOverscrollOffset
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetCacheOverscrollOffset(); // Offset: 0x1048d6484 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class UMG.ComboBoxString
// Size: 0x1050 // Inherited bytes: 0x100
struct UComboBoxString : UWidget {
	// Fields
	struct TArray<struct FString> DefaultOptions; // Offset: 0x100 // Size: 0x10
	struct FString SelectedOption; // Offset: 0x110 // Size: 0x10
	struct FComboBoxStyle WidgetStyle; // Offset: 0x120 // Size: 0x4f8
	struct FTableRowStyle ItemStyle; // Offset: 0x618 // Size: 0x8f8
	struct FMargin ContentPadding; // Offset: 0xf10 // Size: 0x10
	float MaxListHeight; // Offset: 0xf20 // Size: 0x04
	bool HasDownArrow; // Offset: 0xf24 // Size: 0x01
	bool EnableGamepadNavigationMode; // Offset: 0xf25 // Size: 0x01
	char pad_0xF26[0x2]; // Offset: 0xf26 // Size: 0x02
	struct FSlateFontInfo Font; // Offset: 0xf28 // Size: 0x58
	struct FSlateColor ForegroundColor; // Offset: 0xf80 // Size: 0x28
	bool bIsFocusable; // Offset: 0xfa8 // Size: 0x01
	char pad_0xFA9[0x7]; // Offset: 0xfa9 // Size: 0x07
	DelegateProperty OnGenerateWidgetEvent; // Offset: 0xfb0 // Size: 0x10
	char pad_0xFC0[0x20]; // Offset: 0xfc0 // Size: 0x20
	struct FScriptMulticastDelegate OnSelectionChanged; // Offset: 0xfe0 // Size: 0x10
	struct FScriptMulticastDelegate OnOpening; // Offset: 0xff0 // Size: 0x10
	char pad_0x1000[0x50]; // Offset: 0x1000 // Size: 0x50

	// Functions

	// Object Name: Function UMG.ComboBoxString.SetSelectedOption
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSelectedOption(struct FString Option); // Offset: 0x1048ca218 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.ComboBoxString.RemoveOption
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool RemoveOption(struct FString Option); // Offset: 0x1048ca170 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function UMG.ComboBoxString.RefreshOptions
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RefreshOptions(); // Offset: 0x1048ca15c // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction UMG.ComboBoxString.OnSelectionChangedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnSelectionChangedEvent__DelegateSignature(struct FString SelectedItem, enum class ESelectInfo SelectionType); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0x11)

	// Object Name: DelegateFunction UMG.ComboBoxString.OnOpeningEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnOpeningEvent__DelegateSignature(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.ComboBoxString.GetSelectedOption
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetSelectedOption(); // Offset: 0x1048ca0f8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.ComboBoxString.GetOptionCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetOptionCount(); // Offset: 0x1048ca0c4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.ComboBoxString.GetOptionAtIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetOptionAtIndex(int Index); // Offset: 0x1048ca010 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function UMG.ComboBoxString.FindOptionIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int FindOptionIndex(struct FString Option); // Offset: 0x1048c9f68 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function UMG.ComboBoxString.CloseComboBox
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CloseComboBox(); // Offset: 0x1048c9f54 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.ComboBoxString.ClearSelection
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearSelection(); // Offset: 0x1048c9f40 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.ComboBoxString.ClearOptions
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearOptions(); // Offset: 0x1048c9f2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.ComboBoxString.AddOption
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddOption(struct FString Option); // Offset: 0x1048c9e94 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class UMG.PanelSlot
// Size: 0x38 // Inherited bytes: 0x28
struct UPanelSlot : UVisual {
	// Fields
	struct UPanelWidget* Parent; // Offset: 0x28 // Size: 0x08
	struct UWidget* Content; // Offset: 0x30 // Size: 0x08
};

// Object Name: Class UMG.WidgetComponent
// Size: 0x850 // Inherited bytes: 0x730
struct UWidgetComponent : UMeshComponent {
	// Fields
	enum class EWidgetSpace Space; // Offset: 0x725 // Size: 0x01
	enum class EWidgetTimingPolicy TimingPolicy; // Offset: 0x726 // Size: 0x01
	struct UUserWidget* WidgetClass; // Offset: 0x728 // Size: 0x08
	struct FIntPoint DrawSize; // Offset: 0x730 // Size: 0x08
	bool bManuallyRedraw; // Offset: 0x738 // Size: 0x01
	bool bRedrawRequested; // Offset: 0x739 // Size: 0x01
	float RedrawTime; // Offset: 0x73c // Size: 0x04
	struct FIntPoint CurrentDrawSize; // Offset: 0x748 // Size: 0x08
	bool bDrawAtDesiredSize; // Offset: 0x750 // Size: 0x01
	char pad_0x751[0x3]; // Offset: 0x751 // Size: 0x03
	struct FVector2D Pivot; // Offset: 0x754 // Size: 0x08
	bool bReceiveHardwareInput; // Offset: 0x75c // Size: 0x01
	bool bWindowFocusable; // Offset: 0x75d // Size: 0x01
	char pad_0x75E[0x2]; // Offset: 0x75e // Size: 0x02
	struct ULocalPlayer* OwnerPlayer; // Offset: 0x760 // Size: 0x08
	struct FLinearColor BackgroundColor; // Offset: 0x768 // Size: 0x10
	struct FLinearColor TintColorAndOpacity; // Offset: 0x778 // Size: 0x10
	float OpacityFromTexture; // Offset: 0x788 // Size: 0x04
	enum class EWidgetBlendMode BlendMode; // Offset: 0x78c // Size: 0x01
	bool bIsTwoSided; // Offset: 0x78d // Size: 0x01
	bool TickWhenOffscreen; // Offset: 0x78e // Size: 0x01
	char pad_0x78F[0x1]; // Offset: 0x78f // Size: 0x01
	struct UUserWidget* Widget; // Offset: 0x790 // Size: 0x08
	char pad_0x798[0x20]; // Offset: 0x798 // Size: 0x20
	struct UBodySetup* BodySetup; // Offset: 0x7b8 // Size: 0x08
	struct UMaterialInterface* TranslucentMaterial; // Offset: 0x7c0 // Size: 0x08
	struct UMaterialInterface* TranslucentMaterial_OneSided; // Offset: 0x7c8 // Size: 0x08
	struct UMaterialInterface* OpaqueMaterial; // Offset: 0x7d0 // Size: 0x08
	struct UMaterialInterface* OpaqueMaterial_OneSided; // Offset: 0x7d8 // Size: 0x08
	struct UMaterialInterface* MaskedMaterial; // Offset: 0x7e0 // Size: 0x08
	struct UMaterialInterface* MaskedMaterial_OneSided; // Offset: 0x7e8 // Size: 0x08
	struct UTextureRenderTarget2D* RenderTarget; // Offset: 0x7f0 // Size: 0x08
	struct UMaterialInstanceDynamic* MaterialInstance; // Offset: 0x7f8 // Size: 0x08
	bool bAddedToScreen; // Offset: 0x800 // Size: 0x01
	bool bEditTimeUsable; // Offset: 0x801 // Size: 0x01
	char pad_0x802[0x6]; // Offset: 0x802 // Size: 0x06
	struct FName SharedLayerName; // Offset: 0x808 // Size: 0x08
	int LayerZOrder; // Offset: 0x810 // Size: 0x04
	enum class EWidgetGeometryMode GeometryMode; // Offset: 0x814 // Size: 0x01
	char pad_0x815[0x3]; // Offset: 0x815 // Size: 0x03
	float CylinderArcAngle; // Offset: 0x818 // Size: 0x04
	char pad_0x81C[0x34]; // Offset: 0x81c // Size: 0x34

	// Functions

	// Object Name: Function UMG.WidgetComponent.SetWidget
	// Flags: [Native|Public|BlueprintCallable]
	void SetWidget(struct UUserWidget* Widget); // Offset: 0x1048ec5dc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WidgetComponent.SetTintColorAndOpacity
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetTintColorAndOpacity(struct FLinearColor NewTintColorAndOpacity); // Offset: 0x1048ec560 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.WidgetComponent.SetOwnerPlayer
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetOwnerPlayer(struct ULocalPlayer* LocalPlayer); // Offset: 0x1048ec4e4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WidgetComponent.SetDrawSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetDrawSize(struct FVector2D Size); // Offset: 0x1048ec46c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WidgetComponent.SetBackgroundColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetBackgroundColor(struct FLinearColor NewBackgroundColor); // Offset: 0x1048ec3f0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.WidgetComponent.RequestRedraw
	// Flags: [Native|Public|BlueprintCallable]
	void RequestRedraw(); // Offset: 0x1048ec3d4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.WidgetComponent.GetUserWidgetObject
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UUserWidget* GetUserWidgetObject(); // Offset: 0x1048ec3a0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WidgetComponent.GetRenderTarget
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UTextureRenderTarget2D* GetRenderTarget(); // Offset: 0x1048ec36c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WidgetComponent.GetOwnerPlayer
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct ULocalPlayer* GetOwnerPlayer(); // Offset: 0x1048ec338 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WidgetComponent.GetMaterialInstance
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UMaterialInstanceDynamic* GetMaterialInstance(); // Offset: 0x1048ec304 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WidgetComponent.GetDrawSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector2D GetDrawSize(); // Offset: 0x1048ec2cc // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class UMG.Slider
// Size: 0x498 // Inherited bytes: 0x100
struct USlider : UWidget {
	// Fields
	float Value; // Offset: 0x100 // Size: 0x04
	char pad_0x104[0x4]; // Offset: 0x104 // Size: 0x04
	DelegateProperty ValueDelegate; // Offset: 0x108 // Size: 0x10
	struct FSliderStyle WidgetStyle; // Offset: 0x118 // Size: 0x2f0
	enum class EOrientation Orientation; // Offset: 0x408 // Size: 0x01
	char pad_0x409[0x3]; // Offset: 0x409 // Size: 0x03
	struct FLinearColor SliderBarColor; // Offset: 0x40c // Size: 0x10
	struct FLinearColor SliderHandleColor; // Offset: 0x41c // Size: 0x10
	bool IndentHandle; // Offset: 0x42c // Size: 0x01
	bool Locked; // Offset: 0x42d // Size: 0x01
	char pad_0x42E[0x2]; // Offset: 0x42e // Size: 0x02
	float StepSize; // Offset: 0x430 // Size: 0x04
	bool IsFocusable; // Offset: 0x434 // Size: 0x01
	char pad_0x435[0x3]; // Offset: 0x435 // Size: 0x03
	struct FScriptMulticastDelegate OnMouseCaptureBegin; // Offset: 0x438 // Size: 0x10
	struct FScriptMulticastDelegate OnMouseCaptureEnd; // Offset: 0x448 // Size: 0x10
	struct FScriptMulticastDelegate OnControllerCaptureBegin; // Offset: 0x458 // Size: 0x10
	struct FScriptMulticastDelegate OnControllerCaptureEnd; // Offset: 0x468 // Size: 0x10
	struct FScriptMulticastDelegate OnValueChanged; // Offset: 0x478 // Size: 0x10
	char pad_0x488[0x10]; // Offset: 0x488 // Size: 0x10

	// Functions

	// Object Name: Function UMG.Slider.SetValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetValue(float InValue); // Offset: 0x1048d9b18 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.Slider.SetStepSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetStepSize(float InValue); // Offset: 0x1048d9a9c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.Slider.SetSliderHandleColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetSliderHandleColor(struct FLinearColor InValue); // Offset: 0x1048d9a20 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.Slider.SetSliderBarColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetSliderBarColor(struct FLinearColor InValue); // Offset: 0x1048d99a4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.Slider.SetLocked
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLocked(bool InValue); // Offset: 0x1048d9920 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Slider.SetIndentHandle
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIndentHandle(bool InValue); // Offset: 0x1048d989c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Slider.GetValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetValue(); // Offset: 0x1048d9868 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class UMG.ContentWidget
// Size: 0x118 // Inherited bytes: 0x118
struct UContentWidget : UPanelWidget {
	// Functions

	// Object Name: Function UMG.ContentWidget.SetContent
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UPanelSlot* SetContent(struct UWidget* Content); // Offset: 0x1048ca6fc // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.ContentWidget.GetContentSlot
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UPanelSlot* GetContentSlot(); // Offset: 0x1048ca6c8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.ContentWidget.GetContent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UWidget* GetContent(); // Offset: 0x1048ca694 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class UMG.Button
// Size: 0x518 // Inherited bytes: 0x118
struct UButton : UContentWidget {
	// Fields
	struct USlateWidgetStyleAsset* Style; // Offset: 0x118 // Size: 0x08
	struct FButtonStyle WidgetStyle; // Offset: 0x120 // Size: 0x338
	struct FLinearColor ColorAndOpacity; // Offset: 0x458 // Size: 0x10
	struct FLinearColor BackgroundColor; // Offset: 0x468 // Size: 0x10
	enum class EButtonClickMethod ClickMethod; // Offset: 0x478 // Size: 0x01
	enum class EButtonTouchMethod TouchMethod; // Offset: 0x479 // Size: 0x01
	bool IsFocusable; // Offset: 0x47a // Size: 0x01
	bool IsPassMouseEvent; // Offset: 0x47b // Size: 0x01
	float nClickCd; // Offset: 0x47c // Size: 0x04
	bool bTouchPass; // Offset: 0x480 // Size: 0x01
	char pad_0x481[0x7]; // Offset: 0x481 // Size: 0x07
	struct FScriptMulticastDelegate OnClicked; // Offset: 0x488 // Size: 0x10
	struct FScriptMulticastDelegate OnPressed; // Offset: 0x498 // Size: 0x10
	struct FScriptMulticastDelegate OnReleased; // Offset: 0x4a8 // Size: 0x10
	struct FScriptMulticastDelegate OnHovered; // Offset: 0x4b8 // Size: 0x10
	struct FScriptMulticastDelegate OnUnhovered; // Offset: 0x4c8 // Size: 0x10
	struct FScriptMulticastDelegate OnPressedParam; // Offset: 0x4d8 // Size: 0x10
	DelegateProperty OnMouseButtonDownEvent; // Offset: 0x4e8 // Size: 0x10
	enum class EButtonOnClickSound OnClickSoundType; // Offset: 0x4f8 // Size: 0x01
	char pad_0x4F9[0x1f]; // Offset: 0x4f9 // Size: 0x1f

	// Functions

	// Object Name: Function UMG.Button.SetTouchMethod
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTouchMethod(enum class EButtonTouchMethod InTouchMethod); // Offset: 0x1048c7864 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Button.SetStyle
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetStyle(struct FButtonStyle& InStyle); // Offset: 0x1048c77b0 // Return & Params: Num(1) Size(0x338)

	// Object Name: Function UMG.Button.SetOnClickSound
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetOnClickSound(DelegateProperty onSound); // Offset: 0x1048c7728 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.Button.SetColorAndOpacity
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetColorAndOpacity(struct FLinearColor InColorAndOpacity); // Offset: 0x1048c76ac // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.Button.SetClickSoundType
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetClickSoundType(enum class EButtonOnClickSound onSoundType); // Offset: 0x1048c7630 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Button.SetClickMethod
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetClickMethod(enum class EButtonClickMethod InClickMethod); // Offset: 0x1048c75b4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Button.SetBackgroundColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetBackgroundColor(struct FLinearColor InBackgroundColor); // Offset: 0x1048c7538 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.Button.Release
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Release(); // Offset: 0x1048c7524 // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction UMG.Button.OnButtonSoundEvent__DelegateSignature
	// Flags: [Public|Delegate]
	void OnButtonSoundEvent__DelegateSignature(char Sound); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Button.IsPressed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsPressed(); // Offset: 0x1048c74f0 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.AsyncTaskDownloadImage
// Size: 0x48 // Inherited bytes: 0x28
struct UAsyncTaskDownloadImage : UBlueprintAsyncActionBase {
	// Fields
	struct FScriptMulticastDelegate OnSuccess; // Offset: 0x28 // Size: 0x10
	struct FScriptMulticastDelegate OnFail; // Offset: 0x38 // Size: 0x10

	// Functions

	// Object Name: Function UMG.AsyncTaskDownloadImage.DownloadImage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAsyncTaskDownloadImage* DownloadImage(struct FString URL); // Offset: 0x1048c51c4 // Return & Params: Num(2) Size(0x18)
};

// Object Name: Class UMG.BackgroundBlur
// Size: 0x2c8 // Inherited bytes: 0x118
struct UBackgroundBlur : UContentWidget {
	// Fields
	struct FMargin Padding; // Offset: 0x114 // Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x124 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x125 // Size: 0x01
	bool bApplyAlphaToBlur; // Offset: 0x126 // Size: 0x01
	float BlurStrength; // Offset: 0x128 // Size: 0x04
	bool bOverrideAutoRadiusCalculation; // Offset: 0x12c // Size: 0x01
	enum class EBlurType BlurType; // Offset: 0x12d // Size: 0x01
	float BlurDirection; // Offset: 0x130 // Size: 0x04
	struct FVector2D BlurCenter; // Offset: 0x134 // Size: 0x08
	int BlurRadius; // Offset: 0x13c // Size: 0x04
	struct UTexture* BlurMask; // Offset: 0x140 // Size: 0x08
	struct FSlateBrush LowQualityFallbackBrush; // Offset: 0x148 // Size: 0xb8
	struct FSlateBrush BlurMaskBrush; // Offset: 0x200 // Size: 0xb8
	char pad_0x2B9[0xf]; // Offset: 0x2b9 // Size: 0x0f

	// Functions

	// Object Name: Function UMG.BackgroundBlur.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x1048c5874 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.BackgroundBlur.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x1048c57f4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.BackgroundBlur.SetLowQualityFallbackBrush
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetLowQualityFallbackBrush(struct FSlateBrush& InBrush); // Offset: 0x1048c5748 // Return & Params: Num(1) Size(0xb8)

	// Object Name: Function UMG.BackgroundBlur.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x1048c56cc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.BackgroundBlur.SetBlurStrength
	// Flags: [Native|Public|BlueprintCallable]
	void SetBlurStrength(float InStrength); // Offset: 0x1048c5648 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.BackgroundBlur.SetBlurRadius
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBlurRadius(int InBlurRadius); // Offset: 0x1048c55cc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.BackgroundBlur.SetBlurMask
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBlurMask(struct UTexture* InTexture); // Offset: 0x1048c5550 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.BackgroundBlur.SetBlurDirection
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBlurDirection(float InDirection); // Offset: 0x1048c54d4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.BackgroundBlur.SetBlurCenter
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetBlurCenter(struct FVector2D InCenter); // Offset: 0x1048c545c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.BackgroundBlur.SetApplyAlphaToBlur
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetApplyAlphaToBlur(bool bInApplyAlphaToBlur); // Offset: 0x1048c53d8 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.BackgroundBlurSlot
// Size: 0x60 // Inherited bytes: 0x38
struct UBackgroundBlurSlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 // Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x48 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x49 // Size: 0x01
	char pad_0x4A[0x16]; // Offset: 0x4a // Size: 0x16

	// Functions

	// Object Name: Function UMG.BackgroundBlurSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x1048c5de4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.BackgroundBlurSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x1048c5d64 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.BackgroundBlurSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x1048c5ce8 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.PropertyBinding
// Size: 0x48 // Inherited bytes: 0x28
struct UPropertyBinding : UObject {
	// Fields
	struct TWeakObjectPtr<struct UObject> SourceObject; // Offset: 0x28 // Size: 0x08
	struct FDynamicPropertyPath SourcePath; // Offset: 0x30 // Size: 0x10
	struct FName DestinationProperty; // Offset: 0x40 // Size: 0x08
};

// Object Name: Class UMG.BoolBinding
// Size: 0x48 // Inherited bytes: 0x48
struct UBoolBinding : UPropertyBinding {
	// Functions

	// Object Name: Function UMG.BoolBinding.GetValue
	// Flags: [Final|Native|Public|Const]
	bool GetValue(); // Offset: 0x1048c6034 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.Border
// Size: 0x290 // Inherited bytes: 0x118
struct UBorder : UContentWidget {
	// Fields
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x111 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x112 // Size: 0x01
	char bShowEffectWhenDisabled : 1; // Offset: 0x113 // Size: 0x01
	struct FLinearColor ContentColorAndOpacity; // Offset: 0x114 // Size: 0x10
	DelegateProperty ContentColorAndOpacityDelegate; // Offset: 0x128 // Size: 0x10
	struct FMargin Padding; // Offset: 0x138 // Size: 0x10
	struct FSlateBrush Background; // Offset: 0x148 // Size: 0xb8
	DelegateProperty BackgroundDelegate; // Offset: 0x200 // Size: 0x10
	struct FLinearColor BrushColor; // Offset: 0x210 // Size: 0x10
	DelegateProperty BrushColorDelegate; // Offset: 0x220 // Size: 0x10
	struct FVector2D DesiredSizeScale; // Offset: 0x230 // Size: 0x08
	DelegateProperty OnMouseButtonDownEvent; // Offset: 0x238 // Size: 0x10
	DelegateProperty OnMouseButtonUpEvent; // Offset: 0x248 // Size: 0x10
	DelegateProperty OnMouseMoveEvent; // Offset: 0x258 // Size: 0x10
	DelegateProperty OnMouseDoubleClickEvent; // Offset: 0x268 // Size: 0x10
	bool bDontPaintWhenChildEmpty; // Offset: 0x278 // Size: 0x01
	bool bDontPaintWhenAlphaZero; // Offset: 0x279 // Size: 0x01
	char pad_0x27C_1 : 7; // Offset: 0x27c // Size: 0x01
	char pad_0x27D[0x13]; // Offset: 0x27d // Size: 0x13

	// Functions

	// Object Name: Function UMG.Border.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x1048c67fc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Border.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x1048c677c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.Border.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x1048c6700 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Border.SetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDontPaintWhenChildEmpty(bool Enable); // Offset: 0x1048c667c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Border.SetDontPaintWhenAlphaZero
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDontPaintWhenAlphaZero(bool Enable); // Offset: 0x1048c65f8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Border.SetDesiredSizeScale
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetDesiredSizeScale(struct FVector2D InScale); // Offset: 0x1048c6580 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Border.SetContentColorAndOpacity
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetContentColorAndOpacity(struct FLinearColor InContentColorAndOpacity); // Offset: 0x1048c6504 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.Border.SetBrushFromTexture
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBrushFromTexture(struct UTexture2D* Texture); // Offset: 0x1048c6488 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Border.SetBrushFromMaterial
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBrushFromMaterial(struct UMaterialInterface* Material); // Offset: 0x1048c640c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Border.SetBrushFromAsset
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBrushFromAsset(struct USlateBrushAsset* Asset); // Offset: 0x1048c6390 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Border.SetBrushColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetBrushColor(struct FLinearColor InBrushColor); // Offset: 0x1048c6314 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.Border.SetBrush
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetBrush(struct FSlateBrush& InBrush); // Offset: 0x1048c6268 // Return & Params: Num(1) Size(0xb8)

	// Object Name: Function UMG.Border.GetDynamicMaterial
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UMaterialInstanceDynamic* GetDynamicMaterial(); // Offset: 0x1048c6234 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Border.GetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetDontPaintWhenChildEmpty(); // Offset: 0x1048c6200 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Border.GetDontPaintWhenAlphaZero
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetDontPaintWhenAlphaZero(); // Offset: 0x1048c61cc // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.BorderSlot
// Size: 0x60 // Inherited bytes: 0x38
struct UBorderSlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 // Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x48 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x49 // Size: 0x01
	char pad_0x4A[0x16]; // Offset: 0x4a // Size: 0x16

	// Functions

	// Object Name: Function UMG.BorderSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x1048c6ea4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.BorderSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x1048c6e24 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.BorderSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x1048c6da8 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.BrushBinding
// Size: 0x50 // Inherited bytes: 0x48
struct UBrushBinding : UPropertyBinding {
	// Fields
	char pad_0x48[0x8]; // Offset: 0x48 // Size: 0x08

	// Functions

	// Object Name: Function UMG.BrushBinding.GetValue
	// Flags: [Final|Native|Public|Const]
	struct FSlateBrush GetValue(); // Offset: 0x1048c70f8 // Return & Params: Num(1) Size(0xb8)
};

// Object Name: Class UMG.ButtonSlot
// Size: 0x60 // Inherited bytes: 0x38
struct UButtonSlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 // Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x48 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x49 // Size: 0x01
	char pad_0x4A[0x16]; // Offset: 0x4a // Size: 0x16

	// Functions

	// Object Name: Function UMG.ButtonSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x1048c7d24 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ButtonSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x1048c7ca4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.ButtonSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x1048c7c28 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.CanvasPanelSlot
// Size: 0x70 // Inherited bytes: 0x38
struct UCanvasPanelSlot : UPanelSlot {
	// Fields
	struct FAnchorData LayoutData; // Offset: 0x38 // Size: 0x28
	bool bAutoSize; // Offset: 0x60 // Size: 0x01
	bool bSupportNotch; // Offset: 0x61 // Size: 0x01
	char pad_0x62[0x2]; // Offset: 0x62 // Size: 0x02
	int ZOrder; // Offset: 0x64 // Size: 0x04
	char pad_0x68[0x8]; // Offset: 0x68 // Size: 0x08

	// Functions

	// Object Name: Function UMG.CanvasPanelSlot.SetZOrder
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetZOrder(int InZOrder); // Offset: 0x1048c8a78 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.CanvasPanelSlot.SetSupportNotch
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSupportNotch(bool InSupportNotch); // Offset: 0x1048c89f4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.CanvasPanelSlot.SetSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetSize(struct FVector2D InSize); // Offset: 0x1048c897c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.CanvasPanelSlot.SetPosition
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetPosition(struct FVector2D InPosition); // Offset: 0x1048c8904 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.CanvasPanelSlot.SetOffsets
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetOffsets(struct FMargin InOffset); // Offset: 0x1048c8884 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.CanvasPanelSlot.SetMinimum
	// Flags: [Final|Native|Public|HasDefaults]
	void SetMinimum(struct FVector2D InMinimumAnchors); // Offset: 0x1048c880c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.CanvasPanelSlot.SetMaximum
	// Flags: [Final|Native|Public|HasDefaults]
	void SetMaximum(struct FVector2D InMaximumAnchors); // Offset: 0x1048c8794 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.CanvasPanelSlot.SetLayout
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetLayout(struct FAnchorData& InLayoutData); // Offset: 0x1048c8704 // Return & Params: Num(1) Size(0x28)

	// Object Name: Function UMG.CanvasPanelSlot.SetAutoSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAutoSize(bool InbAutoSize); // Offset: 0x1048c8680 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.CanvasPanelSlot.SetAnchors
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAnchors(struct FAnchors InAnchors); // Offset: 0x1048c8600 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.CanvasPanelSlot.SetAlignment
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetAlignment(struct FVector2D InAlignment); // Offset: 0x1048c8588 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.CanvasPanelSlot.GetZOrder
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetZOrder(); // Offset: 0x1048c8554 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.CanvasPanelSlot.GetSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector2D GetSize(); // Offset: 0x1048c851c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.CanvasPanelSlot.GetPosition
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector2D GetPosition(); // Offset: 0x1048c84e4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.CanvasPanelSlot.GetOffsets
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FMargin GetOffsets(); // Offset: 0x1048c84a4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.CanvasPanelSlot.GetLayout
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FAnchorData GetLayout(); // Offset: 0x1048c8454 // Return & Params: Num(1) Size(0x28)

	// Object Name: Function UMG.CanvasPanelSlot.GetAutoSize
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool GetAutoSize(); // Offset: 0x1048c8420 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.CanvasPanelSlot.GetAnchors
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FAnchors GetAnchors(); // Offset: 0x1048c83e0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.CanvasPanelSlot.GetAlignment
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector2D GetAlignment(); // Offset: 0x1048c83a8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.CanvasPanelSlot.GeSupportNotch
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool GeSupportNotch(); // Offset: 0x1048c8374 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.CheckBox
// Size: 0x910 // Inherited bytes: 0x118
struct UCheckBox : UContentWidget {
	// Fields
	enum class ECheckBoxState CheckedState; // Offset: 0x111 // Size: 0x01
	DelegateProperty CheckedStateDelegate; // Offset: 0x118 // Size: 0x10
	struct FCheckBoxStyle WidgetStyle; // Offset: 0x128 // Size: 0x730
	struct USlateWidgetStyleAsset* Style; // Offset: 0x858 // Size: 0x08
	struct USlateBrushAsset* UncheckedImage; // Offset: 0x860 // Size: 0x08
	struct USlateBrushAsset* UncheckedHoveredImage; // Offset: 0x868 // Size: 0x08
	struct USlateBrushAsset* UncheckedPressedImage; // Offset: 0x870 // Size: 0x08
	struct USlateBrushAsset* CheckedImage; // Offset: 0x878 // Size: 0x08
	struct USlateBrushAsset* CheckedHoveredImage; // Offset: 0x880 // Size: 0x08
	struct USlateBrushAsset* CheckedPressedImage; // Offset: 0x888 // Size: 0x08
	struct USlateBrushAsset* UndeterminedImage; // Offset: 0x890 // Size: 0x08
	struct USlateBrushAsset* UndeterminedHoveredImage; // Offset: 0x898 // Size: 0x08
	struct USlateBrushAsset* UndeterminedPressedImage; // Offset: 0x8a0 // Size: 0x08
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x8a8 // Size: 0x01
	char pad_0x8AA[0x2]; // Offset: 0x8aa // Size: 0x02
	struct FMargin Padding; // Offset: 0x8ac // Size: 0x10
	char pad_0x8BC[0x4]; // Offset: 0x8bc // Size: 0x04
	struct FSlateColor BorderBackgroundColor; // Offset: 0x8c0 // Size: 0x28
	bool IsFocusable; // Offset: 0x8e8 // Size: 0x01
	char pad_0x8E9[0x7]; // Offset: 0x8e9 // Size: 0x07
	struct FScriptMulticastDelegate OnCheckStateChanged; // Offset: 0x8f0 // Size: 0x10
	char pad_0x900[0x10]; // Offset: 0x900 // Size: 0x10

	// Functions

	// Object Name: Function UMG.CheckBox.SetIsChecked
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIsChecked(bool InIsChecked); // Offset: 0x1048c92b4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.CheckBox.SetCheckedState
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetCheckedState(enum class ECheckBoxState InCheckedState); // Offset: 0x1048c9238 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.CheckBox.IsPressed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsPressed(); // Offset: 0x1048c9204 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.CheckBox.IsChecked
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsChecked(); // Offset: 0x1048c91d0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.CheckBox.GetCheckedState
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class ECheckBoxState GetCheckedState(); // Offset: 0x1048c919c // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.CheckedStateBinding
// Size: 0x50 // Inherited bytes: 0x48
struct UCheckedStateBinding : UPropertyBinding {
	// Fields
	char pad_0x48[0x8]; // Offset: 0x48 // Size: 0x08

	// Functions

	// Object Name: Function UMG.CheckedStateBinding.GetValue
	// Flags: [Final|Native|Public|Const]
	enum class ECheckBoxState GetValue(); // Offset: 0x1048c95bc // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.CircularThrobber
// Size: 0x1e8 // Inherited bytes: 0x100
struct UCircularThrobber : UWidget {
	// Fields
	int NumberOfPieces; // Offset: 0x100 // Size: 0x04
	float Period; // Offset: 0x104 // Size: 0x04
	float Radius; // Offset: 0x108 // Size: 0x04
	char pad_0x10C[0x4]; // Offset: 0x10c // Size: 0x04
	struct USlateBrushAsset* PieceImage; // Offset: 0x110 // Size: 0x08
	struct FSlateBrush Image; // Offset: 0x118 // Size: 0xb8
	bool bEnableRadius; // Offset: 0x1d0 // Size: 0x01
	char pad_0x1D1[0x17]; // Offset: 0x1d1 // Size: 0x17

	// Functions

	// Object Name: Function UMG.CircularThrobber.SetRadius
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetRadius(float InRadius); // Offset: 0x1048c983c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.CircularThrobber.SetPeriod
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPeriod(float InPeriod); // Offset: 0x1048c97c0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.CircularThrobber.SetNumberOfPieces
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetNumberOfPieces(int InNumberOfPieces); // Offset: 0x1048c9744 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class UMG.ColorBinding
// Size: 0x50 // Inherited bytes: 0x48
struct UColorBinding : UPropertyBinding {
	// Fields
	char pad_0x48[0x8]; // Offset: 0x48 // Size: 0x08

	// Functions

	// Object Name: Function UMG.ColorBinding.GetSlateValue
	// Flags: [Final|Native|Public|Const]
	struct FSlateColor GetSlateValue(); // Offset: 0x1048c9ad8 // Return & Params: Num(1) Size(0x28)

	// Object Name: Function UMG.ColorBinding.GetLinearValue
	// Flags: [Final|Native|Public|HasDefaults|Const]
	struct FLinearColor GetLinearValue(); // Offset: 0x1048c9a98 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class UMG.ComboBox
// Size: 0x138 // Inherited bytes: 0x100
struct UComboBox : UWidget {
	// Fields
	struct TArray<struct UObject*> Items; // Offset: 0x100 // Size: 0x10
	DelegateProperty OnGenerateWidgetEvent; // Offset: 0x110 // Size: 0x10
	bool bIsFocusable; // Offset: 0x120 // Size: 0x01
	char pad_0x121[0x17]; // Offset: 0x121 // Size: 0x17
};

// Object Name: Class UMG.DragDropOperation
// Size: 0x88 // Inherited bytes: 0x28
struct UDragDropOperation : UObject {
	// Fields
	struct FString Tag; // Offset: 0x28 // Size: 0x10
	struct UObject* Payload; // Offset: 0x38 // Size: 0x08
	struct UWidget* DefaultDragVisual; // Offset: 0x40 // Size: 0x08
	enum class EDragPivot Pivot; // Offset: 0x48 // Size: 0x01
	char pad_0x49[0x3]; // Offset: 0x49 // Size: 0x03
	struct FVector2D Offset; // Offset: 0x4c // Size: 0x08
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
	struct FScriptMulticastDelegate OnDrop; // Offset: 0x58 // Size: 0x10
	struct FScriptMulticastDelegate OnDragCancelled; // Offset: 0x68 // Size: 0x10
	struct FScriptMulticastDelegate OnDragged; // Offset: 0x78 // Size: 0x10

	// Functions

	// Object Name: Function UMG.DragDropOperation.Drop
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	void Drop(struct FPointerEvent& PointerEvent); // Offset: 0x1048cae0c // Return & Params: Num(1) Size(0x78)

	// Object Name: Function UMG.DragDropOperation.Dragged
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	void Dragged(struct FPointerEvent& PointerEvent); // Offset: 0x1048cad14 // Return & Params: Num(1) Size(0x78)

	// Object Name: Function UMG.DragDropOperation.DragCancelled
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	void DragCancelled(struct FPointerEvent& PointerEvent); // Offset: 0x1048cac1c // Return & Params: Num(1) Size(0x78)
};

// Object Name: Class UMG.EditableText
// Size: 0x4e8 // Inherited bytes: 0x100
struct UEditableText : UWidget {
	// Fields
	struct FText Text; // Offset: 0x100 // Size: 0x18
	DelegateProperty TextDelegate; // Offset: 0x118 // Size: 0x10
	struct FText HintText; // Offset: 0x128 // Size: 0x18
	DelegateProperty HintTextDelegate; // Offset: 0x140 // Size: 0x10
	struct FEditableTextStyle WidgetStyle; // Offset: 0x150 // Size: 0x2b0
	struct USlateWidgetStyleAsset* Style; // Offset: 0x400 // Size: 0x08
	struct USlateBrushAsset* BackgroundImageSelected; // Offset: 0x408 // Size: 0x08
	struct USlateBrushAsset* BackgroundImageComposing; // Offset: 0x410 // Size: 0x08
	struct USlateBrushAsset* CaretImage; // Offset: 0x418 // Size: 0x08
	struct FSlateFontInfo Font; // Offset: 0x420 // Size: 0x58
	struct FSlateColor ColorAndOpacity; // Offset: 0x478 // Size: 0x28
	bool IsReadOnly; // Offset: 0x4a0 // Size: 0x01
	bool IsPassword; // Offset: 0x4a1 // Size: 0x01
	char pad_0x4A2[0x2]; // Offset: 0x4a2 // Size: 0x02
	float MinimumDesiredWidth; // Offset: 0x4a4 // Size: 0x04
	bool IsCaretMovedWhenGainFocus; // Offset: 0x4a8 // Size: 0x01
	bool SelectAllTextWhenFocused; // Offset: 0x4a9 // Size: 0x01
	bool RevertTextOnEscape; // Offset: 0x4aa // Size: 0x01
	bool ClearKeyboardFocusOnCommit; // Offset: 0x4ab // Size: 0x01
	bool SelectAllTextOnCommit; // Offset: 0x4ac // Size: 0x01
	bool AllowContextMenu; // Offset: 0x4ad // Size: 0x01
	enum class EVirtualKeyboardType KeyboardType; // Offset: 0x4ae // Size: 0x01
	char pad_0x4AF[0x1]; // Offset: 0x4af // Size: 0x01
	struct FShapedTextOptions ShapedTextOptions; // Offset: 0x4b0 // Size: 0x04
	char pad_0x4B4[0x4]; // Offset: 0x4b4 // Size: 0x04
	struct FScriptMulticastDelegate OnTextChanged; // Offset: 0x4b8 // Size: 0x10
	struct FScriptMulticastDelegate OnTextCommitted; // Offset: 0x4c8 // Size: 0x10
	char pad_0x4D8[0x10]; // Offset: 0x4d8 // Size: 0x10

	// Functions

	// Object Name: Function UMG.EditableText.SetText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetText(struct FText InText); // Offset: 0x1048cb53c // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.EditableText.SetIsReadOnly
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIsReadOnly(bool InbIsReadyOnly); // Offset: 0x1048cb4b8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.EditableText.SetIsPassword
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIsPassword(bool InbIsPassword); // Offset: 0x1048cb434 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.EditableText.SetHintText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHintText(struct FText InHintText); // Offset: 0x1048cb374 // Return & Params: Num(1) Size(0x18)

	// Object Name: DelegateFunction UMG.EditableText.OnEditableTextCommittedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnEditableTextCommittedEvent__DelegateSignature(struct FText& Text, enum class ETextCommit CommitMethod); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0x19)

	// Object Name: DelegateFunction UMG.EditableText.OnEditableTextChangedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnEditableTextChangedEvent__DelegateSignature(struct FText& Text); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.EditableText.GetText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FText GetText(); // Offset: 0x1048cb310 // Return & Params: Num(1) Size(0x18)
};

// Object Name: Class UMG.EditableTextBox
// Size: 0xca0 // Inherited bytes: 0x100
struct UEditableTextBox : UWidget {
	// Fields
	struct FText Text; // Offset: 0x100 // Size: 0x18
	DelegateProperty TextDelegate; // Offset: 0x118 // Size: 0x10
	struct FEditableTextBoxStyle WidgetStyle; // Offset: 0x128 // Size: 0xa68
	struct USlateWidgetStyleAsset* Style; // Offset: 0xb90 // Size: 0x08
	struct FText HintText; // Offset: 0xb98 // Size: 0x18
	DelegateProperty HintTextDelegate; // Offset: 0xbb0 // Size: 0x10
	struct FSlateFontInfo Font; // Offset: 0xbc0 // Size: 0x58
	struct FLinearColor ForegroundColor; // Offset: 0xc18 // Size: 0x10
	struct FLinearColor BackgroundColor; // Offset: 0xc28 // Size: 0x10
	struct FLinearColor ReadOnlyForegroundColor; // Offset: 0xc38 // Size: 0x10
	bool IsReadOnly; // Offset: 0xc48 // Size: 0x01
	bool IsPassword; // Offset: 0xc49 // Size: 0x01
	char pad_0xC4A[0x2]; // Offset: 0xc4a // Size: 0x02
	float MinimumDesiredWidth; // Offset: 0xc4c // Size: 0x04
	struct FMargin Padding; // Offset: 0xc50 // Size: 0x10
	bool IsCaretMovedWhenGainFocus; // Offset: 0xc60 // Size: 0x01
	bool SelectAllTextWhenFocused; // Offset: 0xc61 // Size: 0x01
	bool RevertTextOnEscape; // Offset: 0xc62 // Size: 0x01
	bool ClearKeyboardFocusOnCommit; // Offset: 0xc63 // Size: 0x01
	bool SelectAllTextOnCommit; // Offset: 0xc64 // Size: 0x01
	bool AllowContextMenu; // Offset: 0xc65 // Size: 0x01
	enum class EVirtualKeyboardType KeyboardType; // Offset: 0xc66 // Size: 0x01
	char pad_0xC67[0x1]; // Offset: 0xc67 // Size: 0x01
	struct FShapedTextOptions ShapedTextOptions; // Offset: 0xc68 // Size: 0x04
	char pad_0xC6C[0x4]; // Offset: 0xc6c // Size: 0x04
	struct FScriptMulticastDelegate OnTextChanged; // Offset: 0xc70 // Size: 0x10
	struct FScriptMulticastDelegate OnTextCommitted; // Offset: 0xc80 // Size: 0x10
	char pad_0xC90[0x10]; // Offset: 0xc90 // Size: 0x10

	// Functions

	// Object Name: Function UMG.EditableTextBox.SetText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetText(struct FText InText); // Offset: 0x1048cd094 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.EditableTextBox.SetIsReadOnly
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIsReadOnly(bool bReadOnly); // Offset: 0x1048cd010 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.EditableTextBox.SetHintText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHintText(struct FText InText); // Offset: 0x1048ccf50 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.EditableTextBox.SetError
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetError(struct FText InError); // Offset: 0x1048cce90 // Return & Params: Num(1) Size(0x18)

	// Object Name: DelegateFunction UMG.EditableTextBox.OnEditableTextBoxCommittedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnEditableTextBoxCommittedEvent__DelegateSignature(struct FText& Text, enum class ETextCommit CommitMethod); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0x19)

	// Object Name: DelegateFunction UMG.EditableTextBox.OnEditableTextBoxChangedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnEditableTextBoxChangedEvent__DelegateSignature(struct FText& Text); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.EditableTextBox.HasError
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasError(); // Offset: 0x1048cce5c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.EditableTextBox.GetText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FText GetText(); // Offset: 0x1048ccdf8 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.EditableTextBox.ClearError
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearError(); // Offset: 0x1048ccde4 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class UMG.ExpandableArea
// Size: 0x3c0 // Inherited bytes: 0x100
struct UExpandableArea : UWidget {
	// Fields
	char pad_0x100[0x8]; // Offset: 0x100 // Size: 0x08
	struct FExpandableAreaStyle Style; // Offset: 0x108 // Size: 0x180
	struct FSlateBrush BorderBrush; // Offset: 0x288 // Size: 0xb8
	struct FSlateColor BorderColor; // Offset: 0x340 // Size: 0x28
	bool bIsExpanded; // Offset: 0x368 // Size: 0x01
	char pad_0x369[0x3]; // Offset: 0x369 // Size: 0x03
	float MaxHeight; // Offset: 0x36c // Size: 0x04
	struct FMargin HeaderPadding; // Offset: 0x370 // Size: 0x10
	struct FMargin AreaPadding; // Offset: 0x380 // Size: 0x10
	struct FScriptMulticastDelegate OnExpansionChanged; // Offset: 0x390 // Size: 0x10
	struct UWidget* HeaderContent; // Offset: 0x3a0 // Size: 0x08
	struct UWidget* BodyContent; // Offset: 0x3a8 // Size: 0x08
	char pad_0x3B0[0x10]; // Offset: 0x3b0 // Size: 0x10

	// Functions

	// Object Name: Function UMG.ExpandableArea.SetIsExpanded_Animated
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIsExpanded_Animated(bool IsExpanded); // Offset: 0x1048cd568 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ExpandableArea.SetIsExpanded
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIsExpanded(bool IsExpanded); // Offset: 0x1048cd4e4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ExpandableArea.GetIsExpanded
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool GetIsExpanded(); // Offset: 0x1048cd4b0 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.FloatBinding
// Size: 0x48 // Inherited bytes: 0x48
struct UFloatBinding : UPropertyBinding {
	// Functions

	// Object Name: Function UMG.FloatBinding.GetValue
	// Flags: [Final|Native|Public|Const]
	float GetValue(); // Offset: 0x1048cd7f4 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class UMG.GridPanel
// Size: 0x150 // Inherited bytes: 0x118
struct UGridPanel : UPanelWidget {
	// Fields
	struct TArray<float> ColumnFill; // Offset: 0x118 // Size: 0x10
	struct TArray<float> RowFill; // Offset: 0x128 // Size: 0x10
	bool bDontPaintWhenChildEmpty; // Offset: 0x138 // Size: 0x01
	char pad_0x139[0x17]; // Offset: 0x139 // Size: 0x17

	// Functions

	// Object Name: Function UMG.GridPanel.SetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDontPaintWhenChildEmpty(bool Enable); // Offset: 0x1048cda3c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.GridPanel.GetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetDontPaintWhenChildEmpty(); // Offset: 0x1048cda08 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.GridPanel.AddChildToGrid
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UGridSlot* AddChildToGrid(struct UWidget* Content); // Offset: 0x1048cd97c // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class UMG.GridSlot
// Size: 0x70 // Inherited bytes: 0x38
struct UGridSlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 // Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x48 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x49 // Size: 0x01
	char pad_0x4A[0x2]; // Offset: 0x4a // Size: 0x02
	int Row; // Offset: 0x4c // Size: 0x04
	int RowSpan; // Offset: 0x50 // Size: 0x04
	int Column; // Offset: 0x54 // Size: 0x04
	int ColumnSpan; // Offset: 0x58 // Size: 0x04
	int Layer; // Offset: 0x5c // Size: 0x04
	struct FVector2D Nudge; // Offset: 0x60 // Size: 0x08
	char pad_0x68[0x8]; // Offset: 0x68 // Size: 0x08

	// Functions

	// Object Name: Function UMG.GridSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x1048ce068 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.GridSlot.SetRowSpan
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetRowSpan(int InRowSpan); // Offset: 0x1048cdfec // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.GridSlot.SetRow
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetRow(int InRow); // Offset: 0x1048cdf70 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.GridSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x1048cdef0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.GridSlot.SetLayer
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLayer(int InLayer); // Offset: 0x1048cde74 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.GridSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x1048cddf8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.GridSlot.SetColumnSpan
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetColumnSpan(int InColumnSpan); // Offset: 0x1048cdd7c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.GridSlot.SetColumn
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetColumn(int InColumn); // Offset: 0x1048cdd00 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class UMG.HorizontalBox
// Size: 0x128 // Inherited bytes: 0x118
struct UHorizontalBox : UPanelWidget {
	// Fields
	bool bDontPaintWhenChildEmpty; // Offset: 0x111 // Size: 0x01
	char pad_0x119[0xf]; // Offset: 0x119 // Size: 0x0f

	// Functions

	// Object Name: Function UMG.HorizontalBox.SetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void SetDontPaintWhenChildEmpty(bool Enable); // Offset: 0x1048ce4f8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.HorizontalBox.GetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Protected|BlueprintCallable]
	bool GetDontPaintWhenChildEmpty(); // Offset: 0x1048ce4c4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.HorizontalBox.AddChildToHorizontalBox
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UHorizontalBoxSlot* AddChildToHorizontalBox(struct UWidget* Content); // Offset: 0x1048ce438 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class UMG.HorizontalBoxSlot
// Size: 0x60 // Inherited bytes: 0x38
struct UHorizontalBoxSlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 // Size: 0x10
	struct FSlateChildSize Size; // Offset: 0x48 // Size: 0x08
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x50 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x51 // Size: 0x01
	char pad_0x52[0xe]; // Offset: 0x52 // Size: 0x0e

	// Functions

	// Object Name: Function UMG.HorizontalBoxSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x1048ce910 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.HorizontalBoxSlot.SetSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSize(struct FSlateChildSize InSize); // Offset: 0x1048ce878 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.HorizontalBoxSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x1048ce7f8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.HorizontalBoxSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x1048ce77c // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.Image
// Size: 0x248 // Inherited bytes: 0x100
struct UImage : UWidget {
	// Fields
	bool bIsEnhancedImage; // Offset: 0x100 // Size: 0x01
	char pad_0x101[0x7]; // Offset: 0x101 // Size: 0x07
	struct FSlateBrush Brush; // Offset: 0x108 // Size: 0xb8
	DelegateProperty BrushDelegate; // Offset: 0x1c0 // Size: 0x10
	struct FLinearColor ColorAndOpacity; // Offset: 0x1d0 // Size: 0x10
	DelegateProperty ColorAndOpacityDelegate; // Offset: 0x1e0 // Size: 0x10
	bool bIsUseEnhancedHitTest; // Offset: 0x1f0 // Size: 0x01
	bool bVersionImg; // Offset: 0x1f1 // Size: 0x01
	char pad_0x1F2[0x6]; // Offset: 0x1f2 // Size: 0x06
	struct FString imageSrcPath; // Offset: 0x1f8 // Size: 0x10
	float HitTestAreaRadius; // Offset: 0x208 // Size: 0x04
	char pad_0x20C[0x4]; // Offset: 0x20c // Size: 0x04
	DelegateProperty OnMouseButtonDownEvent; // Offset: 0x210 // Size: 0x10
	bool bDontPaintWhenAlphaZero; // Offset: 0x220 // Size: 0x01
	bool bDontPaintWhenColorZero; // Offset: 0x221 // Size: 0x01
	char pad_0x222[0x26]; // Offset: 0x222 // Size: 0x26

	// Functions

	// Object Name: Function UMG.Image.SetOpacity
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetOpacity(float InOpacity); // Offset: 0x1048cf17c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.Image.SetDontPaintWhenColorZero
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDontPaintWhenColorZero(bool Enable); // Offset: 0x1048cf0f8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Image.SetDontPaintWhenAlphaZero
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDontPaintWhenAlphaZero(bool Enable); // Offset: 0x1048cf074 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Image.SetColorAndOpacity
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetColorAndOpacity(struct FLinearColor InColorAndOpacity); // Offset: 0x1048ceff8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.Image.SetBrushFromTextureDynamic
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBrushFromTextureDynamic(struct UTexture2DDynamic* Texture, bool bMatchSize); // Offset: 0x1048cef38 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function UMG.Image.SetBrushFromTexture
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBrushFromTexture(struct UTexture2D* Texture, bool bMatchSize); // Offset: 0x1048cee78 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function UMG.Image.SetBrushFromPathAsync
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBrushFromPathAsync(struct FString ResourcePath); // Offset: 0x1048cede0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.Image.SetBrushFromMaterial
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBrushFromMaterial(struct UMaterialInterface* Material); // Offset: 0x1048ced64 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Image.SetBrushFromAsset
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBrushFromAsset(struct USlateBrushAsset* Asset); // Offset: 0x1048cece8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Image.SetBrush
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetBrush(struct FSlateBrush& InBrush); // Offset: 0x1048cec3c // Return & Params: Num(1) Size(0xb8)

	// Object Name: Function UMG.Image.GetDynamicMaterial
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UMaterialInstanceDynamic* GetDynamicMaterial(); // Offset: 0x1048cec08 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Image.GetDontPaintWhenColorZero
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetDontPaintWhenColorZero(); // Offset: 0x1048cebd4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Image.GetDontPaintWhenAlphaZero
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetDontPaintWhenAlphaZero(); // Offset: 0x1048ceba0 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.InputKeySelector
// Size: 0x798 // Inherited bytes: 0x100
struct UInputKeySelector : UWidget {
	// Fields
	struct FButtonStyle WidgetStyle; // Offset: 0x100 // Size: 0x338
	struct FTextBlockStyle TextStyle; // Offset: 0x438 // Size: 0x250
	struct FInputChord SelectedKey; // Offset: 0x688 // Size: 0x20
	struct FSlateFontInfo Font; // Offset: 0x6a8 // Size: 0x58
	struct FMargin Margin; // Offset: 0x700 // Size: 0x10
	struct FLinearColor ColorAndOpacity; // Offset: 0x710 // Size: 0x10
	struct FText KeySelectionText; // Offset: 0x720 // Size: 0x18
	struct FText NoKeySpecifiedText; // Offset: 0x738 // Size: 0x18
	bool bAllowModifierKeys; // Offset: 0x750 // Size: 0x01
	bool bAllowGamepadKeys; // Offset: 0x751 // Size: 0x01
	char pad_0x752[0x6]; // Offset: 0x752 // Size: 0x06
	struct TArray<struct FKey> EscapeKeys; // Offset: 0x758 // Size: 0x10
	struct FScriptMulticastDelegate OnKeySelected; // Offset: 0x768 // Size: 0x10
	struct FScriptMulticastDelegate OnIsSelectingKeyChanged; // Offset: 0x778 // Size: 0x10
	char pad_0x788[0x10]; // Offset: 0x788 // Size: 0x10

	// Functions

	// Object Name: Function UMG.InputKeySelector.SetTextBlockVisibility
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTextBlockVisibility(enum class ESlateVisibility InVisibility); // Offset: 0x1048cfb0c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.InputKeySelector.SetSelectedKey
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetSelectedKey(struct FInputChord& InSelectedKey); // Offset: 0x1048cfa50 // Return & Params: Num(1) Size(0x20)

	// Object Name: Function UMG.InputKeySelector.SetNoKeySpecifiedText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetNoKeySpecifiedText(struct FText InNoKeySpecifiedText); // Offset: 0x1048cf990 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.InputKeySelector.SetKeySelectionText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetKeySelectionText(struct FText InKeySelectionText); // Offset: 0x1048cf8d0 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.InputKeySelector.SetAllowModifierKeys
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAllowModifierKeys(bool bInAllowModifierKeys); // Offset: 0x1048cf84c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.InputKeySelector.SetAllowGamepadKeys
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAllowGamepadKeys(bool bInAllowGamepadKeys); // Offset: 0x1048cf7c8 // Return & Params: Num(1) Size(0x1)

	// Object Name: DelegateFunction UMG.InputKeySelector.OnKeySelected__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x20)

	// Object Name: DelegateFunction UMG.InputKeySelector.OnIsSelectingKeyChanged__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnIsSelectingKeyChanged__DelegateSignature(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.InputKeySelector.GetIsSelectingKey
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool GetIsSelectingKey(); // Offset: 0x1048cf794 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.Int32Binding
// Size: 0x48 // Inherited bytes: 0x48
struct UInt32Binding : UPropertyBinding {
	// Functions

	// Object Name: Function UMG.Int32Binding.GetValue
	// Flags: [Final|Native|Public|Const]
	int GetValue(); // Offset: 0x1048cfe58 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class UMG.InvalidationBox
// Size: 0x128 // Inherited bytes: 0x118
struct UInvalidationBox : UContentWidget {
	// Fields
	bool bCanCache; // Offset: 0x111 // Size: 0x01
	bool CacheRelativeTransforms; // Offset: 0x112 // Size: 0x01
	bool bDontPaintWhenChildEmpty; // Offset: 0x113 // Size: 0x01
	char pad_0x11B[0xd]; // Offset: 0x11b // Size: 0x0d

	// Functions

	// Object Name: Function UMG.InvalidationBox.SetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDontPaintWhenChildEmpty(bool Enable); // Offset: 0x1048d00e0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.InvalidationBox.SetCanCache
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetCanCache(bool CanCache); // Offset: 0x1048d005c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.InvalidationBox.InvalidateCache
	// Flags: [Final|Native|Public|BlueprintCallable]
	void InvalidateCache(); // Offset: 0x1048d0048 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.InvalidationBox.GetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetDontPaintWhenChildEmpty(); // Offset: 0x1048d0014 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.InvalidationBox.GetCanCache
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool GetCanCache(); // Offset: 0x1048cffe0 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.TableViewBase
// Size: 0x100 // Inherited bytes: 0x100
struct UTableViewBase : UWidget {
};

// Object Name: Class UMG.ListView
// Size: 0x140 // Inherited bytes: 0x100
struct UListView : UTableViewBase {
	// Fields
	float ItemHeight; // Offset: 0x100 // Size: 0x04
	char pad_0x104[0x4]; // Offset: 0x104 // Size: 0x04
	struct TArray<struct UObject*> Items; // Offset: 0x108 // Size: 0x10
	enum class ESelectionMode SelectionMode; // Offset: 0x118 // Size: 0x01
	char pad_0x119[0x7]; // Offset: 0x119 // Size: 0x07
	DelegateProperty OnGenerateRowEvent; // Offset: 0x120 // Size: 0x10
	char pad_0x130[0x10]; // Offset: 0x130 // Size: 0x10
};

// Object Name: Class UMG.MenuAnchor
// Size: 0x158 // Inherited bytes: 0x118
struct UMenuAnchor : UContentWidget {
	// Fields
	struct UUserWidget* MenuClass; // Offset: 0x118 // Size: 0x08
	DelegateProperty OnGetMenuContentEvent; // Offset: 0x120 // Size: 0x10
	enum class EMenuPlacement Placement; // Offset: 0x130 // Size: 0x01
	bool ShouldDeferPaintingAfterWindowContent; // Offset: 0x131 // Size: 0x01
	bool UseApplicationMenuStack; // Offset: 0x132 // Size: 0x01
	char pad_0x133[0x5]; // Offset: 0x133 // Size: 0x05
	struct FScriptMulticastDelegate OnMenuOpenChanged; // Offset: 0x138 // Size: 0x10
	char pad_0x148[0x10]; // Offset: 0x148 // Size: 0x10

	// Functions

	// Object Name: Function UMG.MenuAnchor.ToggleOpen
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ToggleOpen(bool bFocusOnOpen); // Offset: 0x1048d06c4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.MenuAnchor.ShouldOpenDueToClick
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool ShouldOpenDueToClick(); // Offset: 0x1048d0690 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.MenuAnchor.Open
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Open(bool bFocusMenu); // Offset: 0x1048d060c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.MenuAnchor.IsOpen
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsOpen(); // Offset: 0x1048d05d8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.MenuAnchor.HasOpenSubMenus
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasOpenSubMenus(); // Offset: 0x1048d05a4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.MenuAnchor.GetMenuPosition
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector2D GetMenuPosition(); // Offset: 0x1048d056c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.MenuAnchor.Close
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Close(); // Offset: 0x1048d0558 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class UMG.MouseCursorBinding
// Size: 0x48 // Inherited bytes: 0x48
struct UMouseCursorBinding : UPropertyBinding {
	// Functions

	// Object Name: Function UMG.MouseCursorBinding.GetValue
	// Flags: [Final|Native|Public|Const]
	enum class EMouseCursor GetValue(); // Offset: 0x1048d0a70 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.MovieScene2DTransformSection
// Size: 0x3c8 // Inherited bytes: 0xb0
struct UMovieScene2DTransformSection : UMovieSceneSection {
	// Fields
	char pad_0xB0[0x8]; // Offset: 0xb0 // Size: 0x08
	struct FRichCurve Translation[0x2]; // Offset: 0xb8 // Size: 0xe0
	struct FRichCurve Rotation; // Offset: 0x198 // Size: 0x70
	struct FRichCurve Scale[0x2]; // Offset: 0x208 // Size: 0xe0
	struct FRichCurve Shear[0x2]; // Offset: 0x2e8 // Size: 0xe0
};

// Object Name: Class UMG.MovieScene2DTransformTrack
// Size: 0x80 // Inherited bytes: 0x80
struct UMovieScene2DTransformTrack : UMovieScenePropertyTrack {
};

// Object Name: Class UMG.MovieSceneMarginSection
// Size: 0x278 // Inherited bytes: 0xb0
struct UMovieSceneMarginSection : UMovieSceneSection {
	// Fields
	char pad_0xB0[0x8]; // Offset: 0xb0 // Size: 0x08
	struct FRichCurve TopCurve; // Offset: 0xb8 // Size: 0x70
	struct FRichCurve LeftCurve; // Offset: 0x128 // Size: 0x70
	struct FRichCurve RightCurve; // Offset: 0x198 // Size: 0x70
	struct FRichCurve BottomCurve; // Offset: 0x208 // Size: 0x70
};

// Object Name: Class UMG.MovieSceneMarginTrack
// Size: 0x80 // Inherited bytes: 0x80
struct UMovieSceneMarginTrack : UMovieScenePropertyTrack {
};

// Object Name: Class UMG.MovieSceneWidgetMaterialTrack
// Size: 0x80 // Inherited bytes: 0x68
struct UMovieSceneWidgetMaterialTrack : UMovieSceneMaterialTrack {
	// Fields
	struct TArray<struct FName> BrushPropertyNamePath; // Offset: 0x68 // Size: 0x10
	struct FName TrackName; // Offset: 0x78 // Size: 0x08
};

// Object Name: Class UMG.TextLayoutWidget
// Size: 0x128 // Inherited bytes: 0x100
struct UTextLayoutWidget : UWidget {
	// Fields
	struct FShapedTextOptions ShapedTextOptions; // Offset: 0x100 // Size: 0x04
	enum class ETextJustify Justification; // Offset: 0x104 // Size: 0x01
	enum class ETextVerticalJustify VerticalJustification; // Offset: 0x105 // Size: 0x01
	bool AutoWrapText; // Offset: 0x106 // Size: 0x01
	char pad_0x107[0x1]; // Offset: 0x107 // Size: 0x01
	float WrapTextAt; // Offset: 0x108 // Size: 0x04
	enum class ETextWrappingPolicy WrappingPolicy; // Offset: 0x10c // Size: 0x01
	char pad_0x10D[0x3]; // Offset: 0x10d // Size: 0x03
	struct FMargin Margin; // Offset: 0x110 // Size: 0x10
	float LineHeightPercentage; // Offset: 0x120 // Size: 0x04
	char pad_0x124[0x4]; // Offset: 0x124 // Size: 0x04
};

// Object Name: Class UMG.MultiLineEditableText
// Size: 0x450 // Inherited bytes: 0x128
struct UMultiLineEditableText : UTextLayoutWidget {
	// Fields
	struct FText Text; // Offset: 0x128 // Size: 0x18
	struct FText HintText; // Offset: 0x140 // Size: 0x18
	DelegateProperty HintTextDelegate; // Offset: 0x158 // Size: 0x10
	struct FTextBlockStyle WidgetStyle; // Offset: 0x168 // Size: 0x250
	bool bIsReadOnly; // Offset: 0x3b8 // Size: 0x01
	char pad_0x3B9[0x7]; // Offset: 0x3b9 // Size: 0x07
	struct FSlateFontInfo Font; // Offset: 0x3c0 // Size: 0x58
	bool AllowContextMenu; // Offset: 0x418 // Size: 0x01
	char pad_0x419[0x7]; // Offset: 0x419 // Size: 0x07
	struct FScriptMulticastDelegate OnTextChanged; // Offset: 0x420 // Size: 0x10
	struct FScriptMulticastDelegate OnTextCommitted; // Offset: 0x430 // Size: 0x10
	char pad_0x440[0x10]; // Offset: 0x440 // Size: 0x10

	// Functions

	// Object Name: Function UMG.MultiLineEditableText.SetText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetText(struct FText InText); // Offset: 0x1048d1578 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.MultiLineEditableText.SetIsReadOnly
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIsReadOnly(bool bReadOnly); // Offset: 0x1048d14f4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.MultiLineEditableText.SetHintText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHintText(struct FText InText); // Offset: 0x1048d1434 // Return & Params: Num(1) Size(0x18)

	// Object Name: DelegateFunction UMG.MultiLineEditableText.OnMultiLineEditableTextCommittedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnMultiLineEditableTextCommittedEvent__DelegateSignature(struct FText& Text, enum class ETextCommit CommitMethod); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0x19)

	// Object Name: DelegateFunction UMG.MultiLineEditableText.OnMultiLineEditableTextChangedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnMultiLineEditableTextChangedEvent__DelegateSignature(struct FText& Text); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.MultiLineEditableText.GetText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FText GetText(); // Offset: 0x1048d13d0 // Return & Params: Num(1) Size(0x18)
};

// Object Name: Class UMG.MultiLineEditableTextBox
// Size: 0xee8 // Inherited bytes: 0x128
struct UMultiLineEditableTextBox : UTextLayoutWidget {
	// Fields
	struct FText Text; // Offset: 0x128 // Size: 0x18
	struct FText HintText; // Offset: 0x140 // Size: 0x18
	DelegateProperty HintTextDelegate; // Offset: 0x158 // Size: 0x10
	struct FEditableTextBoxStyle WidgetStyle; // Offset: 0x168 // Size: 0xa68
	struct FTextBlockStyle TextStyle; // Offset: 0xbd0 // Size: 0x250
	bool bIsReadOnly; // Offset: 0xe20 // Size: 0x01
	bool AllowContextMenu; // Offset: 0xe21 // Size: 0x01
	char pad_0xE22[0x6]; // Offset: 0xe22 // Size: 0x06
	struct USlateWidgetStyleAsset* Style; // Offset: 0xe28 // Size: 0x08
	struct FSlateFontInfo Font; // Offset: 0xe30 // Size: 0x58
	struct FLinearColor ForegroundColor; // Offset: 0xe88 // Size: 0x10
	struct FLinearColor BackgroundColor; // Offset: 0xe98 // Size: 0x10
	struct FLinearColor ReadOnlyForegroundColor; // Offset: 0xea8 // Size: 0x10
	struct FScriptMulticastDelegate OnTextChanged; // Offset: 0xeb8 // Size: 0x10
	struct FScriptMulticastDelegate OnTextCommitted; // Offset: 0xec8 // Size: 0x10
	char pad_0xED8[0x10]; // Offset: 0xed8 // Size: 0x10

	// Functions

	// Object Name: Function UMG.MultiLineEditableTextBox.SetText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetText(struct FText InText); // Offset: 0x1048d1b5c // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.MultiLineEditableTextBox.SetIsReadOnly
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIsReadOnly(bool bReadOnly); // Offset: 0x1048d1ad8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.MultiLineEditableTextBox.SetHintText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHintText(struct FText InText); // Offset: 0x1048d1a18 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.MultiLineEditableTextBox.SetError
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetError(struct FText InError); // Offset: 0x1048d1958 // Return & Params: Num(1) Size(0x18)

	// Object Name: DelegateFunction UMG.MultiLineEditableTextBox.OnMultiLineEditableTextBoxCommittedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnMultiLineEditableTextBoxCommittedEvent__DelegateSignature(struct FText& Text, enum class ETextCommit CommitMethod); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0x19)

	// Object Name: DelegateFunction UMG.MultiLineEditableTextBox.OnMultiLineEditableTextBoxChangedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnMultiLineEditableTextBoxChangedEvent__DelegateSignature(struct FText& Text); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.MultiLineEditableTextBox.GetText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FText GetText(); // Offset: 0x1048d18f4 // Return & Params: Num(1) Size(0x18)
};

// Object Name: Class UMG.NamedSlot
// Size: 0x128 // Inherited bytes: 0x118
struct UNamedSlot : UContentWidget {
	// Fields
	char pad_0x118[0x10]; // Offset: 0x118 // Size: 0x10
};

// Object Name: Class UMG.NamedSlotInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UNamedSlotInterface : UInterface {
};

// Object Name: Class UMG.NativeWidgetHost
// Size: 0x110 // Inherited bytes: 0x100
struct UNativeWidgetHost : UWidget {
	// Fields
	char pad_0x100[0x10]; // Offset: 0x100 // Size: 0x10
};

// Object Name: Class UMG.Overlay
// Size: 0x128 // Inherited bytes: 0x118
struct UOverlay : UPanelWidget {
	// Fields
	char pad_0x118[0x10]; // Offset: 0x118 // Size: 0x10

	// Functions

	// Object Name: Function UMG.Overlay.AddChildToOverlay
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UOverlaySlot* AddChildToOverlay(struct UWidget* Content); // Offset: 0x1048d2140 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class UMG.OverlaySlot
// Size: 0x58 // Inherited bytes: 0x38
struct UOverlaySlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 // Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x48 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x49 // Size: 0x01
	char pad_0x4A[0xe]; // Offset: 0x4a // Size: 0x0e

	// Functions

	// Object Name: Function UMG.OverlaySlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x1048d2420 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.OverlaySlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x1048d23a0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.OverlaySlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x1048d2324 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.ProgressBar
// Size: 0x3a0 // Inherited bytes: 0x100
struct UProgressBar : UWidget {
	// Fields
	struct FProgressBarStyle WidgetStyle; // Offset: 0x100 // Size: 0x230
	struct USlateWidgetStyleAsset* Style; // Offset: 0x330 // Size: 0x08
	struct USlateBrushAsset* BackgroundImage; // Offset: 0x338 // Size: 0x08
	struct USlateBrushAsset* FillImage; // Offset: 0x340 // Size: 0x08
	struct USlateBrushAsset* MarqueeImage; // Offset: 0x348 // Size: 0x08
	float percent; // Offset: 0x350 // Size: 0x04
	enum class EProgressBarFillType BarFillType; // Offset: 0x354 // Size: 0x01
	bool bIsMarquee; // Offset: 0x355 // Size: 0x01
	char pad_0x356[0x2]; // Offset: 0x356 // Size: 0x02
	struct FVector2D BorderPadding; // Offset: 0x358 // Size: 0x08
	DelegateProperty PercentDelegate; // Offset: 0x360 // Size: 0x10
	struct FLinearColor FillColorAndOpacity; // Offset: 0x370 // Size: 0x10
	DelegateProperty FillColorAndOpacityDelegate; // Offset: 0x380 // Size: 0x10
	char pad_0x390[0x10]; // Offset: 0x390 // Size: 0x10

	// Functions

	// Object Name: Function UMG.ProgressBar.SetPercent
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPercent(float InPercent); // Offset: 0x1048d4c04 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.ProgressBar.SetIsMarquee
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIsMarquee(bool InbIsMarquee); // Offset: 0x1048d4b80 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ProgressBar.SetFillColorAndOpacity
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetFillColorAndOpacity(struct FLinearColor InColor); // Offset: 0x1048d4b04 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class UMG.RetainerBox
// Size: 0x140 // Inherited bytes: 0x118
struct URetainerBox : UContentWidget {
	// Fields
	bool RenderOnInvalidation; // Offset: 0x111 // Size: 0x01
	bool RenderOnPhase; // Offset: 0x112 // Size: 0x01
	int Phase; // Offset: 0x114 // Size: 0x04
	int PhaseCount; // Offset: 0x118 // Size: 0x04
	struct UMaterialInterface* EffectMaterial; // Offset: 0x120 // Size: 0x08
	struct FName TextureParameter; // Offset: 0x128 // Size: 0x08
	char pad_0x132[0xe]; // Offset: 0x132 // Size: 0x0e

	// Functions

	// Object Name: Function UMG.RetainerBox.SkipCurrentFrameRender
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SkipCurrentFrameRender(); // Offset: 0x1048d509c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.RetainerBox.SetTextureParameter
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTextureParameter(struct FName TextureParameter); // Offset: 0x1048d5020 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.RetainerBox.SetEffectMaterial
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetEffectMaterial(struct UMaterialInterface* EffectMaterial); // Offset: 0x1048d4fa4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.RetainerBox.RequestRender
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RequestRender(); // Offset: 0x1048d4f90 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.RetainerBox.GetEffectMaterial
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UMaterialInstanceDynamic* GetEffectMaterial(); // Offset: 0x1048d4f5c // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class UMG.RichTextBlock
// Size: 0x428 // Inherited bytes: 0x128
struct URichTextBlock : UTextLayoutWidget {
	// Fields
	struct FText Text; // Offset: 0x128 // Size: 0x18
	DelegateProperty TextDelegate; // Offset: 0x140 // Size: 0x10
	struct FSlateFontInfo Font; // Offset: 0x150 // Size: 0x58
	struct FLinearColor Color; // Offset: 0x1a8 // Size: 0x10
	struct TArray<struct URichTextBlockDecorator*> Decorators; // Offset: 0x1b8 // Size: 0x10
	char pad_0x1C8[0x260]; // Offset: 0x1c8 // Size: 0x260
};

// Object Name: Class UMG.RichTextBlockDecorator
// Size: 0x30 // Inherited bytes: 0x28
struct URichTextBlockDecorator : UObject {
	// Fields
	bool bReveal; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x3]; // Offset: 0x29 // Size: 0x03
	int RevealedIndex; // Offset: 0x2c // Size: 0x04
};

// Object Name: Class UMG.SafeZone
// Size: 0x128 // Inherited bytes: 0x118
struct USafeZone : UContentWidget {
	// Fields
	bool PadLeft; // Offset: 0x111 // Size: 0x01
	bool PadRight; // Offset: 0x112 // Size: 0x01
	bool PadTop; // Offset: 0x113 // Size: 0x01
	bool PadBottom; // Offset: 0x114 // Size: 0x01
	char pad_0x11C[0xc]; // Offset: 0x11c // Size: 0x0c

	// Functions

	// Object Name: Function UMG.SafeZone.SetSidesToPad
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSidesToPad(bool InPadLeft, bool InPadRight, bool InPadTop, bool InPadBottom); // Offset: 0x1048d5514 // Return & Params: Num(4) Size(0x4)
};

// Object Name: Class UMG.SafeZoneSlot
// Size: 0x60 // Inherited bytes: 0x38
struct USafeZoneSlot : UPanelSlot {
	// Fields
	bool bIsTitleSafe; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x3]; // Offset: 0x39 // Size: 0x03
	struct FMargin SafeAreaScale; // Offset: 0x3c // Size: 0x10
	enum class EHorizontalAlignment HAlign; // Offset: 0x4c // Size: 0x01
	enum class EVerticalAlignment VAlign; // Offset: 0x4d // Size: 0x01
	char pad_0x4E[0x2]; // Offset: 0x4e // Size: 0x02
	struct FMargin Padding; // Offset: 0x50 // Size: 0x10
};

// Object Name: Class UMG.ScaleBox
// Size: 0x130 // Inherited bytes: 0x118
struct UScaleBox : UContentWidget {
	// Fields
	enum class EStretch Stretch; // Offset: 0x111 // Size: 0x01
	enum class EStretchDirection StretchDirection; // Offset: 0x112 // Size: 0x01
	float UserSpecifiedScale; // Offset: 0x114 // Size: 0x04
	float UserSpecifiedScaleBias; // Offset: 0x118 // Size: 0x04
	bool IgnoreInheritedScale; // Offset: 0x11c // Size: 0x01
	bool bSingleLayoutPass; // Offset: 0x11d // Size: 0x01
	char pad_0x124[0xc]; // Offset: 0x124 // Size: 0x0c

	// Functions

	// Object Name: Function UMG.ScaleBox.SetUserSpecifiedScaleBias
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetUserSpecifiedScaleBias(float InUserSpecifiedScaleBias); // Offset: 0x1048d5b24 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.ScaleBox.SetUserSpecifiedScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetUserSpecifiedScale(float InUserSpecifiedScale); // Offset: 0x1048d5aa8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.ScaleBox.SetStretchDirection
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetStretchDirection(enum class EStretchDirection InStretchDirection); // Offset: 0x1048d5a2c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ScaleBox.SetStretch
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetStretch(enum class EStretch InStretch); // Offset: 0x1048d59b0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ScaleBox.SetIgnoreInheritedScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIgnoreInheritedScale(bool bInIgnoreInheritedScale); // Offset: 0x1048d592c // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.ScaleBoxSlot
// Size: 0x60 // Inherited bytes: 0x38
struct UScaleBoxSlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 // Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x48 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x49 // Size: 0x01
	char pad_0x4A[0x16]; // Offset: 0x4a // Size: 0x16

	// Functions

	// Object Name: Function UMG.ScaleBoxSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x1048d5f18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ScaleBoxSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x1048d5e98 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.ScaleBoxSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x1048d5e1c // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.ScrollBar
// Size: 0x7a8 // Inherited bytes: 0x100
struct UScrollBar : UWidget {
	// Fields
	struct FScrollBarStyle WidgetStyle; // Offset: 0x100 // Size: 0x680
	struct USlateWidgetStyleAsset* Style; // Offset: 0x780 // Size: 0x08
	bool bAlwaysShowScrollbar; // Offset: 0x788 // Size: 0x01
	enum class EOrientation Orientation; // Offset: 0x789 // Size: 0x01
	char pad_0x78A[0x2]; // Offset: 0x78a // Size: 0x02
	struct FVector2D Thickness; // Offset: 0x78c // Size: 0x08
	char pad_0x794[0x14]; // Offset: 0x794 // Size: 0x14

	// Functions

	// Object Name: Function UMG.ScrollBar.SetState
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetState(float InOffsetFraction, float InThumbSizeFraction); // Offset: 0x1048d6168 // Return & Params: Num(2) Size(0x8)
};

// Object Name: Class UMG.ScrollBoxSlot
// Size: 0x58 // Inherited bytes: 0x38
struct UScrollBoxSlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 // Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x48 // Size: 0x01
	char pad_0x49[0xf]; // Offset: 0x49 // Size: 0x0f

	// Functions

	// Object Name: Function UMG.ScrollBoxSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x1048d708c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.ScrollBoxSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x1048d7010 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.ShareWidgetRT
// Size: 0x90 // Inherited bytes: 0x28
struct UShareWidgetRT : UObject {
	// Fields
	struct UTextureRenderTarget2D* RenderTarget; // Offset: 0x28 // Size: 0x08
	struct TSet<struct UObject*> AllSharedWidget; // Offset: 0x30 // Size: 0x50
	char pad_0x80[0x10]; // Offset: 0x80 // Size: 0x10
};

// Object Name: Class UMG.ShareWidgetRTManager
// Size: 0x418 // Inherited bytes: 0x3c8
struct AShareWidgetRTManager : AActor {
	// Fields
	struct TMap<struct UObject*, struct UShareWidgetRT*> SharedWidgetRTMap; // Offset: 0x3c8 // Size: 0x50
};

// Object Name: Class UMG.SizeBox
// Size: 0x140 // Inherited bytes: 0x118
struct USizeBox : UContentWidget {
	// Fields
	char bOverride_WidthOverride : 1; // Offset: 0x111 // Size: 0x01
	char bOverride_HeightOverride : 1; // Offset: 0x111 // Size: 0x01
	char bOverride_MinDesiredWidth : 1; // Offset: 0x111 // Size: 0x01
	char bOverride_MinDesiredHeight : 1; // Offset: 0x111 // Size: 0x01
	char bOverride_MaxDesiredWidth : 1; // Offset: 0x111 // Size: 0x01
	char bOverride_MaxDesiredHeight : 1; // Offset: 0x111 // Size: 0x01
	char bOverride_MaxAspectRatio : 1; // Offset: 0x111 // Size: 0x01
	char bDontPaintWhenChildEmpty : 1; // Offset: 0x111 // Size: 0x01
	float WidthOverride; // Offset: 0x114 // Size: 0x04
	float HeightOverride; // Offset: 0x118 // Size: 0x04
	float MinDesiredWidth; // Offset: 0x11c // Size: 0x04
	float MinDesiredHeight; // Offset: 0x120 // Size: 0x04
	float MaxDesiredWidth; // Offset: 0x124 // Size: 0x04
	float MaxDesiredHeight; // Offset: 0x128 // Size: 0x04
	float MaxAspectRatio; // Offset: 0x12c // Size: 0x04
	char pad_0x135[0xb]; // Offset: 0x135 // Size: 0x0b

	// Functions

	// Object Name: Function UMG.SizeBox.SetWidthOverride
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetWidthOverride(float InWidthOverride); // Offset: 0x1048d78b8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SizeBox.SetMinDesiredWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMinDesiredWidth(float InMinDesiredWidth); // Offset: 0x1048d783c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SizeBox.SetMinDesiredHeight
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMinDesiredHeight(float InMinDesiredHeight); // Offset: 0x1048d77c0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SizeBox.SetMaxDesiredWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMaxDesiredWidth(float InMaxDesiredWidth); // Offset: 0x1048d7744 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SizeBox.SetMaxDesiredHeight
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMaxDesiredHeight(float InMaxDesiredHeight); // Offset: 0x1048d76c8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SizeBox.SetMaxAspectRatio
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMaxAspectRatio(float InMaxAspectRatio); // Offset: 0x1048d764c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SizeBox.SetHeightOverride
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHeightOverride(float InHeightOverride); // Offset: 0x1048d75d0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SizeBox.SetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDontPaintWhenChildEmpty(bool Enable); // Offset: 0x1048d754c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.SizeBox.GetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetDontPaintWhenChildEmpty(); // Offset: 0x1048d7518 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.SizeBox.ClearWidthOverride
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearWidthOverride(); // Offset: 0x1048d7504 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.SizeBox.ClearMinDesiredWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearMinDesiredWidth(); // Offset: 0x1048d74f0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.SizeBox.ClearMinDesiredHeight
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearMinDesiredHeight(); // Offset: 0x1048d74dc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.SizeBox.ClearMaxDesiredWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearMaxDesiredWidth(); // Offset: 0x1048d74c8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.SizeBox.ClearMaxDesiredHeight
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearMaxDesiredHeight(); // Offset: 0x1048d74b4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.SizeBox.ClearMaxAspectRatio
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearMaxAspectRatio(); // Offset: 0x1048d74a0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.SizeBox.ClearHeightOverride
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearHeightOverride(); // Offset: 0x1048d748c // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class UMG.SizeBoxSlot
// Size: 0x60 // Inherited bytes: 0x38
struct USizeBoxSlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 // Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x48 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x49 // Size: 0x01
	char pad_0x4A[0x16]; // Offset: 0x4a // Size: 0x16

	// Functions

	// Object Name: Function UMG.SizeBoxSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x1048d7fdc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.SizeBoxSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x1048d7f5c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.SizeBoxSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x1048d7ee0 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.SlateBlueprintLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct USlateBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function UMG.SlateBlueprintLibrary.ScreenToWidgetLocal
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults]
	void ScreenToWidgetLocal(struct UObject* WorldContextObject, struct FGeometry& Geometry, struct FVector2D ScreenPosition, struct FVector2D& LocalCoordinate); // Offset: 0x1048d8c4c // Return & Params: Num(4) Size(0x50)

	// Object Name: Function UMG.SlateBlueprintLibrary.ScreenToWidgetAbsolute
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults]
	void ScreenToWidgetAbsolute(struct UObject* WorldContextObject, struct FVector2D ScreenPosition, struct FVector2D& AbsoluteCoordinate); // Offset: 0x1048d8b58 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function UMG.SlateBlueprintLibrary.ScreenToViewport
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults]
	void ScreenToViewport(struct UObject* WorldContextObject, struct FVector2D ScreenPosition, struct FVector2D& ViewportPosition); // Offset: 0x1048d8a64 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function UMG.SlateBlueprintLibrary.LocalToViewport
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	void LocalToViewport(struct UObject* WorldContextObject, struct FGeometry& Geometry, struct FVector2D LocalCoordinate, struct FVector2D& PixelPosition, struct FVector2D& ViewportPosition); // Offset: 0x1048d88d0 // Return & Params: Num(5) Size(0x58)

	// Object Name: Function UMG.SlateBlueprintLibrary.LocalToAbsolute
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FVector2D LocalToAbsolute(struct FGeometry& Geometry, struct FVector2D LocalCoordinate); // Offset: 0x1048d87fc // Return & Params: Num(3) Size(0x48)

	// Object Name: Function UMG.SlateBlueprintLibrary.IsUnderLocation
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	bool IsUnderLocation(struct FGeometry& Geometry, struct FVector2D& AbsoluteCoordinate); // Offset: 0x1048d871c // Return & Params: Num(3) Size(0x41)

	// Object Name: Function UMG.SlateBlueprintLibrary.GetLocalSize
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FVector2D GetLocalSize(struct FGeometry& Geometry); // Offset: 0x1048d8688 // Return & Params: Num(2) Size(0x40)

	// Object Name: Function UMG.SlateBlueprintLibrary.GetAbsoluteSize
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FVector2D GetAbsoluteSize(struct FGeometry& Geometry); // Offset: 0x1048d85f4 // Return & Params: Num(2) Size(0x40)

	// Object Name: Function UMG.SlateBlueprintLibrary.GetAbsolutePosition
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FVector2D GetAbsolutePosition(struct FGeometry& Geometry); // Offset: 0x1048d8560 // Return & Params: Num(2) Size(0x40)

	// Object Name: Function UMG.SlateBlueprintLibrary.EqualEqual_SlateBrush
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	bool EqualEqual_SlateBrush(struct FSlateBrush& A, struct FSlateBrush& B); // Offset: 0x1048d843c // Return & Params: Num(3) Size(0x171)

	// Object Name: Function UMG.SlateBlueprintLibrary.AbsoluteToViewport
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	void AbsoluteToViewport(struct UObject* WorldContextObject, struct FVector2D AbsoluteDesktopCoordinate, struct FVector2D& PixelPosition, struct FVector2D& ViewportPosition); // Offset: 0x1048d8300 // Return & Params: Num(4) Size(0x20)

	// Object Name: Function UMG.SlateBlueprintLibrary.AbsoluteToLocal
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FVector2D AbsoluteToLocal(struct FGeometry& Geometry, struct FVector2D AbsoluteCoordinate); // Offset: 0x1048d822c // Return & Params: Num(3) Size(0x48)
};

// Object Name: Class UMG.SlateDataSheet
// Size: 0x430 // Inherited bytes: 0x28
struct USlateDataSheet : UObject {
	// Fields
	struct UTexture2D* DataTexture; // Offset: 0x28 // Size: 0x08
	char pad_0x30[0x400]; // Offset: 0x30 // Size: 0x400
};

// Object Name: Class UMG.SlateVectorArtData
// Size: 0x60 // Inherited bytes: 0x28
struct USlateVectorArtData : UObject {
	// Fields
	struct TArray<struct FSlateMeshVertex> VertexData; // Offset: 0x28 // Size: 0x10
	struct TArray<uint32_t> IndexData; // Offset: 0x38 // Size: 0x10
	struct UMaterialInterface* Material; // Offset: 0x48 // Size: 0x08
	struct FVector2D ExtentMin; // Offset: 0x50 // Size: 0x08
	struct FVector2D ExtentMax; // Offset: 0x58 // Size: 0x08
};

// Object Name: Class UMG.Spacer
// Size: 0x118 // Inherited bytes: 0x100
struct USpacer : UWidget {
	// Fields
	struct FVector2D Size; // Offset: 0x100 // Size: 0x08
	char pad_0x108[0x10]; // Offset: 0x108 // Size: 0x10

	// Functions

	// Object Name: Function UMG.Spacer.SetSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetSize(struct FVector2D InSize); // Offset: 0x1048d9ea4 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class UMG.SpinBox
// Size: 0x5f8 // Inherited bytes: 0x100
struct USpinBox : UWidget {
	// Fields
	float Value; // Offset: 0x100 // Size: 0x04
	char pad_0x104[0x4]; // Offset: 0x104 // Size: 0x04
	DelegateProperty ValueDelegate; // Offset: 0x108 // Size: 0x10
	struct FSpinBoxStyle WidgetStyle; // Offset: 0x118 // Size: 0x3d8
	struct USlateWidgetStyleAsset* Style; // Offset: 0x4f0 // Size: 0x08
	float Delta; // Offset: 0x4f8 // Size: 0x04
	float SliderExponent; // Offset: 0x4fc // Size: 0x04
	struct FSlateFontInfo Font; // Offset: 0x500 // Size: 0x58
	enum class ETextJustify Justification; // Offset: 0x558 // Size: 0x01
	char pad_0x559[0x3]; // Offset: 0x559 // Size: 0x03
	float MinDesiredWidth; // Offset: 0x55c // Size: 0x04
	bool ClearKeyboardFocusOnCommit; // Offset: 0x560 // Size: 0x01
	bool SelectAllTextOnCommit; // Offset: 0x561 // Size: 0x01
	char pad_0x562[0x6]; // Offset: 0x562 // Size: 0x06
	struct FSlateColor ForegroundColor; // Offset: 0x568 // Size: 0x28
	struct FScriptMulticastDelegate OnValueChanged; // Offset: 0x590 // Size: 0x10
	struct FScriptMulticastDelegate OnValueCommitted; // Offset: 0x5a0 // Size: 0x10
	struct FScriptMulticastDelegate OnBeginSliderMovement; // Offset: 0x5b0 // Size: 0x10
	struct FScriptMulticastDelegate OnEndSliderMovement; // Offset: 0x5c0 // Size: 0x10
	char bOverride_MinValue : 1; // Offset: 0x5d0 // Size: 0x01
	char bOverride_MaxValue : 1; // Offset: 0x5d0 // Size: 0x01
	char bOverride_MinSliderValue : 1; // Offset: 0x5d0 // Size: 0x01
	char bOverride_MaxSliderValue : 1; // Offset: 0x5d0 // Size: 0x01
	char pad_0x5D0_4 : 4; // Offset: 0x5d0 // Size: 0x01
	char pad_0x5D1[0x3]; // Offset: 0x5d1 // Size: 0x03
	float MinValue; // Offset: 0x5d4 // Size: 0x04
	float MaxValue; // Offset: 0x5d8 // Size: 0x04
	float MinSliderValue; // Offset: 0x5dc // Size: 0x04
	float MaxSliderValue; // Offset: 0x5e0 // Size: 0x04
	char pad_0x5E4[0x14]; // Offset: 0x5e4 // Size: 0x14

	// Functions

	// Object Name: Function UMG.SpinBox.SetValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetValue(float NewValue); // Offset: 0x1048da5bc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SpinBox.SetMinValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMinValue(float NewValue); // Offset: 0x1048da540 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SpinBox.SetMinSliderValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMinSliderValue(float NewValue); // Offset: 0x1048da4c4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SpinBox.SetMaxValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMaxValue(float NewValue); // Offset: 0x1048da448 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SpinBox.SetMaxSliderValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMaxSliderValue(float NewValue); // Offset: 0x1048da3cc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SpinBox.SetForegroundColor
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetForegroundColor(struct FSlateColor InForegroundColor); // Offset: 0x1048da2c8 // Return & Params: Num(1) Size(0x28)

	// Object Name: DelegateFunction UMG.SpinBox.OnSpinBoxValueCommittedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnSpinBoxValueCommittedEvent__DelegateSignature(float InValue, enum class ETextCommit CommitMethod); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0x5)

	// Object Name: DelegateFunction UMG.SpinBox.OnSpinBoxValueChangedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnSpinBoxValueChangedEvent__DelegateSignature(float InValue); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x4)

	// Object Name: DelegateFunction UMG.SpinBox.OnSpinBoxBeginSliderMovement__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnSpinBoxBeginSliderMovement__DelegateSignature(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.SpinBox.GetValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetValue(); // Offset: 0x1048da294 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SpinBox.GetMinValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetMinValue(); // Offset: 0x1048da260 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SpinBox.GetMinSliderValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetMinSliderValue(); // Offset: 0x1048da22c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SpinBox.GetMaxValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetMaxValue(); // Offset: 0x1048da1f8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SpinBox.GetMaxSliderValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetMaxSliderValue(); // Offset: 0x1048da1c4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SpinBox.ClearMinValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearMinValue(); // Offset: 0x1048da1b0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.SpinBox.ClearMinSliderValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearMinSliderValue(); // Offset: 0x1048da19c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.SpinBox.ClearMaxValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearMaxValue(); // Offset: 0x1048da188 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.SpinBox.ClearMaxSliderValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearMaxSliderValue(); // Offset: 0x1048da174 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class UMG.StaticMeshWidget
// Size: 0x120 // Inherited bytes: 0x100
struct UStaticMeshWidget : UWidget {
	// Fields
	struct USlateVectorArtData* StaticMeshAsset; // Offset: 0x100 // Size: 0x08
	struct FVector2D MeshScale; // Offset: 0x108 // Size: 0x08
	char pad_0x110[0x10]; // Offset: 0x110 // Size: 0x10
};

// Object Name: Class UMG.TextBinding
// Size: 0x50 // Inherited bytes: 0x48
struct UTextBinding : UPropertyBinding {
	// Fields
	char pad_0x48[0x8]; // Offset: 0x48 // Size: 0x08

	// Functions

	// Object Name: Function UMG.TextBinding.GetTextValue
	// Flags: [Final|Native|Public|Const]
	struct FText GetTextValue(); // Offset: 0x1048dc554 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.TextBinding.GetStringValue
	// Flags: [Final|Native|Public|Const]
	struct FString GetStringValue(); // Offset: 0x1048dc4f0 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class UMG.TextBlock
// Size: 0x278 // Inherited bytes: 0x128
struct UTextBlock : UTextLayoutWidget {
	// Fields
	struct FText Text; // Offset: 0x128 // Size: 0x18
	DelegateProperty TextDelegate; // Offset: 0x140 // Size: 0x10
	struct FSlateColor ColorAndOpacity; // Offset: 0x150 // Size: 0x28
	DelegateProperty ColorAndOpacityDelegate; // Offset: 0x178 // Size: 0x10
	struct FSlateColor SelectColorAndOpacity; // Offset: 0x188 // Size: 0x28
	struct FSlateColor NoSelectColorAndOpacity; // Offset: 0x1b0 // Size: 0x28
	bool bHaveSelectColorAndOpacity; // Offset: 0x1d8 // Size: 0x01
	bool bIsSelected; // Offset: 0x1d9 // Size: 0x01
	char pad_0x1DA[0x6]; // Offset: 0x1da // Size: 0x06
	struct FSlateFontInfo Font; // Offset: 0x1e0 // Size: 0x58
	struct FVector2D ShadowOffset; // Offset: 0x238 // Size: 0x08
	struct FLinearColor ShadowColorAndOpacity; // Offset: 0x240 // Size: 0x10
	DelegateProperty ShadowColorAndOpacityDelegate; // Offset: 0x250 // Size: 0x10
	float MinDesiredWidth; // Offset: 0x260 // Size: 0x04
	bool AutoEllipsisText; // Offset: 0x264 // Size: 0x01
	bool bWrapWithInvalidationPanel; // Offset: 0x265 // Size: 0x01
	char pad_0x266[0x12]; // Offset: 0x266 // Size: 0x12

	// Functions

	// Object Name: Function UMG.TextBlock.SetVerticalJustification
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalJustification(enum class ETextVerticalJustify InJustification); // Offset: 0x1048dcdf8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.TextBlock.SetText
	// Flags: [Native|Public|BlueprintCallable]
	void SetText(struct FText InText); // Offset: 0x1048dcd30 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.TextBlock.SetShadowOffset
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetShadowOffset(struct FVector2D InShadowOffset); // Offset: 0x1048dccb8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.TextBlock.SetShadowColorAndOpacity
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetShadowColorAndOpacity(struct FLinearColor InShadowColorAndOpacity); // Offset: 0x1048dcc3c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.TextBlock.SetSelectColor
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSelectColor(bool bIsSelect); // Offset: 0x1048dcbb8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.TextBlock.SetOpacity
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetOpacity(float InOpacity); // Offset: 0x1048dcb3c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.TextBlock.SetMinDesiredWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMinDesiredWidth(float InMinDesiredWidth); // Offset: 0x1048dcac0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.TextBlock.SetJustification
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetJustification(enum class ETextJustify InJustification); // Offset: 0x1048dca44 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.TextBlock.SetFont
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFont(struct FSlateFontInfo InFontInfo); // Offset: 0x1048dc938 // Return & Params: Num(1) Size(0x58)

	// Object Name: Function UMG.TextBlock.SetColorAndOpacity
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetColorAndOpacity(struct FSlateColor InColorAndOpacity); // Offset: 0x1048dc834 // Return & Params: Num(1) Size(0x28)

	// Object Name: Function UMG.TextBlock.SetAutoEllipsisText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAutoEllipsisText(bool InAutoEllipsisText); // Offset: 0x1048dc7b0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.TextBlock.GetText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FText GetText(); // Offset: 0x1048dc74c // Return & Params: Num(1) Size(0x18)
};

// Object Name: Class UMG.Throbber
// Size: 0x1d8 // Inherited bytes: 0x100
struct UThrobber : UWidget {
	// Fields
	int NumberOfPieces; // Offset: 0x100 // Size: 0x04
	bool bAnimateHorizontally; // Offset: 0x104 // Size: 0x01
	bool bAnimateVertically; // Offset: 0x105 // Size: 0x01
	bool bAnimateOpacity; // Offset: 0x106 // Size: 0x01
	char pad_0x107[0x1]; // Offset: 0x107 // Size: 0x01
	struct USlateBrushAsset* PieceImage; // Offset: 0x108 // Size: 0x08
	struct FSlateBrush Image; // Offset: 0x110 // Size: 0xb8
	char pad_0x1C8[0x10]; // Offset: 0x1c8 // Size: 0x10

	// Functions

	// Object Name: Function UMG.Throbber.SetNumberOfPieces
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetNumberOfPieces(int InNumberOfPieces); // Offset: 0x1048dd640 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.Throbber.SetAnimateVertically
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAnimateVertically(bool bInAnimateVertically); // Offset: 0x1048dd5bc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Throbber.SetAnimateOpacity
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAnimateOpacity(bool bInAnimateOpacity); // Offset: 0x1048dd538 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Throbber.SetAnimateHorizontally
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAnimateHorizontally(bool bInAnimateHorizontally); // Offset: 0x1048dd4b4 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.TileView
// Size: 0x140 // Inherited bytes: 0x100
struct UTileView : UTableViewBase {
	// Fields
	float ItemWidth; // Offset: 0x100 // Size: 0x04
	float ItemHeight; // Offset: 0x104 // Size: 0x04
	struct TArray<struct UObject*> Items; // Offset: 0x108 // Size: 0x10
	enum class ESelectionMode SelectionMode; // Offset: 0x118 // Size: 0x01
	char pad_0x119[0x7]; // Offset: 0x119 // Size: 0x07
	DelegateProperty OnGenerateTileEvent; // Offset: 0x120 // Size: 0x10
	char pad_0x130[0x10]; // Offset: 0x130 // Size: 0x10

	// Functions

	// Object Name: Function UMG.TileView.SetItemWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetItemWidth(float Width); // Offset: 0x1048dd9a8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.TileView.SetItemHeight
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetItemHeight(float Height); // Offset: 0x1048dd92c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.TileView.RequestListRefresh
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RequestListRefresh(); // Offset: 0x1048dd918 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class UMG.UMGSequencePlayer
// Size: 0x6c0 // Inherited bytes: 0x28
struct UUMGSequencePlayer : UObject {
	// Fields
	char pad_0x28[0x348]; // Offset: 0x28 // Size: 0x348
	struct UWidgetAnimation* Animation; // Offset: 0x370 // Size: 0x08
	char pad_0x378[0x348]; // Offset: 0x378 // Size: 0x348
};

// Object Name: Class UMG.UniformGridPanel
// Size: 0x140 // Inherited bytes: 0x118
struct UUniformGridPanel : UPanelWidget {
	// Fields
	struct FMargin SlotPadding; // Offset: 0x114 // Size: 0x10
	float MinDesiredSlotWidth; // Offset: 0x124 // Size: 0x04
	float MinDesiredSlotHeight; // Offset: 0x128 // Size: 0x04
	char pad_0x130[0x10]; // Offset: 0x130 // Size: 0x10

	// Functions

	// Object Name: Function UMG.UniformGridPanel.SetSlotPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSlotPadding(struct FMargin InSlotPadding); // Offset: 0x1048ddef4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.UniformGridPanel.SetMinDesiredSlotWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMinDesiredSlotWidth(float InMinDesiredSlotWidth); // Offset: 0x1048dde78 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.UniformGridPanel.SetMinDesiredSlotHeight
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMinDesiredSlotHeight(float InMinDesiredSlotHeight); // Offset: 0x1048dddfc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.UniformGridPanel.AddChildToUniformGrid
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UUniformGridSlot* AddChildToUniformGrid(struct UWidget* Content); // Offset: 0x1048ddd70 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class UMG.UniformGridSlot
// Size: 0x50 // Inherited bytes: 0x38
struct UUniformGridSlot : UPanelSlot {
	// Fields
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x38 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x39 // Size: 0x01
	char pad_0x3A[0x2]; // Offset: 0x3a // Size: 0x02
	int Row; // Offset: 0x3c // Size: 0x04
	int Column; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0xc]; // Offset: 0x44 // Size: 0x0c

	// Functions

	// Object Name: Function UMG.UniformGridSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x1048de300 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.UniformGridSlot.SetRow
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetRow(int InRow); // Offset: 0x1048de284 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.UniformGridSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x1048de208 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.UniformGridSlot.SetColumn
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetColumn(int InColumn); // Offset: 0x1048de18c // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class UMG.VerticalBox
// Size: 0x128 // Inherited bytes: 0x118
struct UVerticalBox : UPanelWidget {
	// Fields
	bool bDontPaintWhenChildEmpty; // Offset: 0x111 // Size: 0x01
	char pad_0x119[0xf]; // Offset: 0x119 // Size: 0x0f

	// Functions

	// Object Name: Function UMG.VerticalBox.SetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void SetDontPaintWhenChildEmpty(bool Enable); // Offset: 0x1048e2e70 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.VerticalBox.GetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Protected|BlueprintCallable]
	bool GetDontPaintWhenChildEmpty(); // Offset: 0x1048e2e3c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.VerticalBox.AddChildToVerticalBox
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UVerticalBoxSlot* AddChildToVerticalBox(struct UWidget* Content); // Offset: 0x1048e2db0 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class UMG.VerticalBoxSlot
// Size: 0x60 // Inherited bytes: 0x38
struct UVerticalBoxSlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 // Size: 0x10
	struct FSlateChildSize Size; // Offset: 0x48 // Size: 0x08
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x50 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x51 // Size: 0x01
	char pad_0x52[0xe]; // Offset: 0x52 // Size: 0x0e

	// Functions

	// Object Name: Function UMG.VerticalBoxSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x1048e3284 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.VerticalBoxSlot.SetSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSize(struct FSlateChildSize InSize); // Offset: 0x1048e31ec // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.VerticalBoxSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x1048e316c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.VerticalBoxSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x1048e30f0 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.Viewport
// Size: 0x140 // Inherited bytes: 0x118
struct UViewport : UContentWidget {
	// Fields
	struct FLinearColor BackgroundColor; // Offset: 0x114 // Size: 0x10
	char pad_0x128[0x18]; // Offset: 0x128 // Size: 0x18

	// Functions

	// Object Name: Function UMG.Viewport.Spawn
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct AActor* Spawn(struct AActor* ActorClass); // Offset: 0x1048e5240 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.Viewport.SetViewRotation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetViewRotation(struct FRotator Rotation); // Offset: 0x1048e51c4 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function UMG.Viewport.SetViewLocation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetViewLocation(struct FVector Location); // Offset: 0x1048e5148 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function UMG.Viewport.GetViewRotation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FRotator GetViewRotation(); // Offset: 0x1048e5110 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function UMG.Viewport.GetViewportWorld
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UWorld* GetViewportWorld(); // Offset: 0x1048e50dc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Viewport.GetViewLocation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector GetViewLocation(); // Offset: 0x1048e50a4 // Return & Params: Num(1) Size(0xc)
};

// Object Name: Class UMG.VisibilityBinding
// Size: 0x48 // Inherited bytes: 0x48
struct UVisibilityBinding : UPropertyBinding {
	// Functions

	// Object Name: Function UMG.VisibilityBinding.GetValue
	// Flags: [Final|Native|Public|Const]
	enum class ESlateVisibility GetValue(); // Offset: 0x1048e5560 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.WeakRefImage
// Size: 0x268 // Inherited bytes: 0x248
struct UWeakRefImage : UImage {
	// Fields
	char pad_0x248[0x20]; // Offset: 0x248 // Size: 0x20

	// Functions

	// Object Name: Function UMG.WeakRefImage.UnloadTextureResource
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UnloadTextureResource(); // Offset: 0x1048e5858 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.WeakRefImage.LoadTextureResource
	// Flags: [Final|Native|Public|BlueprintCallable]
	void LoadTextureResource(bool bAsync); // Offset: 0x1048e57d4 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.WidgetAnimation
// Size: 0x318 // Inherited bytes: 0x2e0
struct UWidgetAnimation : UMovieSceneSequence {
	// Fields
	struct FScriptMulticastDelegate OnAnimationStarted; // Offset: 0x2e0 // Size: 0x10
	struct FScriptMulticastDelegate OnAnimationFinished; // Offset: 0x2f0 // Size: 0x10
	struct UMovieScene* MovieScene; // Offset: 0x300 // Size: 0x08
	struct TArray<struct FWidgetAnimationBinding> AnimationBindings; // Offset: 0x308 // Size: 0x10

	// Functions

	// Object Name: Function UMG.WidgetAnimation.GetStartTime
	// Flags: [Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetStartTime(); // Offset: 0x1048e79dc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.WidgetAnimation.GetEndTime
	// Flags: [Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetEndTime(); // Offset: 0x1048e79a8 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class UMG.WidgetBinding
// Size: 0x48 // Inherited bytes: 0x48
struct UWidgetBinding : UPropertyBinding {
	// Functions

	// Object Name: Function UMG.WidgetBinding.GetValue
	// Flags: [Final|Native|Public|Const]
	struct UWidget* GetValue(); // Offset: 0x1048e7c74 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class UMG.WidgetBlueprintGeneratedClass
// Size: 0x440 // Inherited bytes: 0x3d0
struct UWidgetBlueprintGeneratedClass : UBlueprintGeneratedClass {
	// Fields
	struct UWidgetTree* WidgetTree; // Offset: 0x3d0 // Size: 0x08
	char bAllowTemplate : 1; // Offset: 0x3d8 // Size: 0x01
	char bValidTemplate : 1; // Offset: 0x3d8 // Size: 0x01
	char bTemplateInitialized : 1; // Offset: 0x3d8 // Size: 0x01
	char bCookedTemplate : 1; // Offset: 0x3d8 // Size: 0x01
	char pad_0x3D8_4 : 4; // Offset: 0x3d8 // Size: 0x01
	char pad_0x3D9[0x7]; // Offset: 0x3d9 // Size: 0x07
	struct TArray<struct FDelegateRuntimeBinding> Bindings; // Offset: 0x3e0 // Size: 0x10
	struct TArray<struct UWidgetAnimation*> Animations; // Offset: 0x3f0 // Size: 0x10
	struct TArray<struct FName> NamedSlots; // Offset: 0x400 // Size: 0x10
	struct UUserWidget* TemplateAsset; // Offset: 0x410 // Size: 0x28
	struct UUserWidget* Template; // Offset: 0x438 // Size: 0x08
};

// Object Name: Class UMG.WidgetBlueprintLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UWidgetBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function UMG.WidgetBlueprintLibrary.UnlockMouse
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FEventReply UnlockMouse(struct FEventReply& Reply); // Offset: 0x1048eb17c // Return & Params: Num(2) Size(0x170)

	// Object Name: Function UMG.WidgetBlueprintLibrary.Unhandled
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FEventReply Unhandled(); // Offset: 0x1048eb0ec // Return & Params: Num(1) Size(0xb8)

	// Object Name: Function UMG.WidgetBlueprintLibrary.SetUserFocus
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FEventReply SetUserFocus(struct FEventReply& Reply, struct UWidget* FocusWidget, bool bInAllUsers); // Offset: 0x1048eaf58 // Return & Params: Num(4) Size(0x180)

	// Object Name: Function UMG.WidgetBlueprintLibrary.SetMousePosition
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FEventReply SetMousePosition(struct FEventReply& Reply, struct FVector2D NewMousePosition); // Offset: 0x1048eae10 // Return & Params: Num(3) Size(0x178)

	// Object Name: Function UMG.WidgetBlueprintLibrary.SetInputMode_UIOnlyEx
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void SetInputMode_UIOnlyEx(struct APlayerController* Target, struct UWidget* InWidgetToFocus, enum class EMouseLockMode InMouseLockMode); // Offset: 0x1048ead28 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function UMG.WidgetBlueprintLibrary.SetInputMode_UIOnly
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void SetInputMode_UIOnly(struct APlayerController* Target, struct UWidget* InWidgetToFocus, bool bLockMouseToViewport); // Offset: 0x1048eac38 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function UMG.WidgetBlueprintLibrary.SetInputMode_GameOnly
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void SetInputMode_GameOnly(struct APlayerController* Target); // Offset: 0x1048eabc4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WidgetBlueprintLibrary.SetInputMode_GameAndUIEx
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void SetInputMode_GameAndUIEx(struct APlayerController* Target, struct UWidget* InWidgetToFocus, enum class EMouseLockMode InMouseLockMode, bool bHideCursorDuringCapture); // Offset: 0x1048eaa98 // Return & Params: Num(4) Size(0x12)

	// Object Name: Function UMG.WidgetBlueprintLibrary.SetInputMode_GameAndUI
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void SetInputMode_GameAndUI(struct APlayerController* Target, struct UWidget* InWidgetToFocus, bool bLockMouseToViewport, bool bHideCursorDuringCapture); // Offset: 0x1048ea964 // Return & Params: Num(4) Size(0x12)

	// Object Name: Function UMG.WidgetBlueprintLibrary.SetHardwareCursor
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	bool SetHardwareCursor(struct UObject* WorldContextObject, enum class EMouseCursor CursorShape, struct FName CursorName, struct FVector2D HotSpot); // Offset: 0x1048ea838 // Return & Params: Num(5) Size(0x21)

	// Object Name: Function UMG.WidgetBlueprintLibrary.SetFocusToGameViewport
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void SetFocusToGameViewport(); // Offset: 0x1048ea824 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.WidgetBlueprintLibrary.SetBrushResourceToTexture
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetBrushResourceToTexture(struct FSlateBrush& Brush, struct UTexture2D* Texture); // Offset: 0x1048ea73c // Return & Params: Num(2) Size(0xc0)

	// Object Name: Function UMG.WidgetBlueprintLibrary.SetBrushResourceToMaterial
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetBrushResourceToMaterial(struct FSlateBrush& Brush, struct UMaterialInterface* Material); // Offset: 0x1048ea654 // Return & Params: Num(2) Size(0xc0)

	// Object Name: Function UMG.WidgetBlueprintLibrary.ReleaseMouseCapture
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FEventReply ReleaseMouseCapture(struct FEventReply& Reply); // Offset: 0x1048ea54c // Return & Params: Num(2) Size(0x170)

	// Object Name: Function UMG.WidgetBlueprintLibrary.ReleaseJoystickCapture
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FEventReply ReleaseJoystickCapture(struct FEventReply& Reply, bool bInAllJoysticks); // Offset: 0x1048ea3f8 // Return & Params: Num(3) Size(0x178)

	// Object Name: Function UMG.WidgetBlueprintLibrary.NoResourceBrush
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FSlateBrush NoResourceBrush(); // Offset: 0x1048ea394 // Return & Params: Num(1) Size(0xb8)

	// Object Name: Function UMG.WidgetBlueprintLibrary.MakeBrushFromTexture
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FSlateBrush MakeBrushFromTexture(struct UTexture2D* Texture, int Width, int Height); // Offset: 0x1048ea27c // Return & Params: Num(4) Size(0xc8)

	// Object Name: Function UMG.WidgetBlueprintLibrary.MakeBrushFromMaterial
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FSlateBrush MakeBrushFromMaterial(struct UMaterialInterface* Material, int Width, int Height); // Offset: 0x1048ea164 // Return & Params: Num(4) Size(0xc8)

	// Object Name: Function UMG.WidgetBlueprintLibrary.MakeBrushFromAsset
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FSlateBrush MakeBrushFromAsset(struct USlateBrushAsset* BrushAsset); // Offset: 0x1048ea0c0 // Return & Params: Num(2) Size(0xc0)

	// Object Name: Function UMG.WidgetBlueprintLibrary.LockMouse
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FEventReply LockMouse(struct FEventReply& Reply, struct UWidget* CapturingWidget); // Offset: 0x1048e9f74 // Return & Params: Num(3) Size(0x178)

	// Object Name: Function UMG.WidgetBlueprintLibrary.IsDragDropping
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable|BlueprintPure]
	bool IsDragDropping(); // Offset: 0x1048e9f40 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WidgetBlueprintLibrary.Handled
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FEventReply Handled(); // Offset: 0x1048e9eb0 // Return & Params: Num(1) Size(0xb8)

	// Object Name: Function UMG.WidgetBlueprintLibrary.GetSafeZonePadding
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void GetSafeZonePadding(struct UObject* WorldContextObject, struct FVector2D& SafePadding, struct FVector2D& SafePaddingScale, struct FVector2D& SpillOverPadding); // Offset: 0x1048e9d5c // Return & Params: Num(4) Size(0x20)

	// Object Name: Function UMG.WidgetBlueprintLibrary.GetKeyEventFromAnalogInputEvent
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FKeyEvent GetKeyEventFromAnalogInputEvent(struct FAnalogInputEvent& Event); // Offset: 0x1048e9c88 // Return & Params: Num(2) Size(0x88)

	// Object Name: Function UMG.WidgetBlueprintLibrary.GetInputEventFromPointerEvent
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FInputEvent GetInputEventFromPointerEvent(struct FPointerEvent& Event); // Offset: 0x1048e9b84 // Return & Params: Num(2) Size(0x98)

	// Object Name: Function UMG.WidgetBlueprintLibrary.GetInputEventFromNavigationEvent
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FInputEvent GetInputEventFromNavigationEvent(struct FNavigationEvent& Event); // Offset: 0x1048e9ac8 // Return & Params: Num(2) Size(0x48)

	// Object Name: Function UMG.WidgetBlueprintLibrary.GetInputEventFromKeyEvent
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FInputEvent GetInputEventFromKeyEvent(struct FKeyEvent& Event); // Offset: 0x1048e99e8 // Return & Params: Num(2) Size(0x60)

	// Object Name: Function UMG.WidgetBlueprintLibrary.GetInputEventFromCharacterEvent
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FInputEvent GetInputEventFromCharacterEvent(struct FCharacterEvent& Event); // Offset: 0x1048e992c // Return & Params: Num(2) Size(0x48)

	// Object Name: Function UMG.WidgetBlueprintLibrary.GetDynamicMaterial
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct UMaterialInstanceDynamic* GetDynamicMaterial(struct FSlateBrush& Brush); // Offset: 0x1048e9880 // Return & Params: Num(2) Size(0xc0)

	// Object Name: Function UMG.WidgetBlueprintLibrary.GetDragDroppingContent
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UDragDropOperation* GetDragDroppingContent(); // Offset: 0x1048e984c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WidgetBlueprintLibrary.GetBrushResourceAsTexture2D
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct UTexture2D* GetBrushResourceAsTexture2D(struct FSlateBrush& Brush); // Offset: 0x1048e97a0 // Return & Params: Num(2) Size(0xc0)

	// Object Name: Function UMG.WidgetBlueprintLibrary.GetBrushResourceAsMaterial
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct UMaterialInterface* GetBrushResourceAsMaterial(struct FSlateBrush& Brush); // Offset: 0x1048e96f4 // Return & Params: Num(2) Size(0xc0)

	// Object Name: Function UMG.WidgetBlueprintLibrary.GetBrushResource
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct UObject* GetBrushResource(struct FSlateBrush& Brush); // Offset: 0x1048e9648 // Return & Params: Num(2) Size(0xc0)

	// Object Name: Function UMG.WidgetBlueprintLibrary.GetAllWidgetsWithInterface
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetAllWidgetsWithInterface(struct UObject* WorldContextObject, struct UInterface* Interface, struct TArray<struct UUserWidget*>& FoundWidgets, bool TopLevelOnly); // Offset: 0x1048e94e4 // Return & Params: Num(4) Size(0x21)

	// Object Name: Function UMG.WidgetBlueprintLibrary.GetAllWidgetsOfClass
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetAllWidgetsOfClass(struct UObject* WorldContextObject, struct TArray<struct UUserWidget*>& FoundWidgets, struct UUserWidget* WidgetClass, bool TopLevelOnly); // Offset: 0x1048e937c // Return & Params: Num(4) Size(0x21)

	// Object Name: Function UMG.WidgetBlueprintLibrary.EndDragDrop
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FEventReply EndDragDrop(struct FEventReply& Reply); // Offset: 0x1048e9274 // Return & Params: Num(2) Size(0x170)

	// Object Name: Function UMG.WidgetBlueprintLibrary.DrawTextFormatted
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void DrawTextFormatted(struct FPaintContext& Context, struct FText& Text, struct FVector2D Position, struct UFont* Font, int FontSize, struct FName FontTypeFace, struct FLinearColor Tint); // Offset: 0x1048e9034 // Return & Params: Num(7) Size(0x78)

	// Object Name: Function UMG.WidgetBlueprintLibrary.DrawText
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void DrawText(struct FPaintContext& Context, struct FString inString, struct FVector2D Position, struct FLinearColor Tint); // Offset: 0x1048e8ed4 // Return & Params: Num(4) Size(0x58)

	// Object Name: Function UMG.WidgetBlueprintLibrary.DrawLines
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void DrawLines(struct FPaintContext& Context, struct TArray<struct FVector2D>& Points, struct FLinearColor Tint, bool bAntiAlias); // Offset: 0x1048e8d4c // Return & Params: Num(4) Size(0x51)

	// Object Name: Function UMG.WidgetBlueprintLibrary.DrawLine
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void DrawLine(struct FPaintContext& Context, struct FVector2D PositionA, struct FVector2D PositionB, struct FLinearColor Tint, bool bAntiAlias); // Offset: 0x1048e8bd4 // Return & Params: Num(5) Size(0x51)

	// Object Name: Function UMG.WidgetBlueprintLibrary.DrawBox
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void DrawBox(struct FPaintContext& Context, struct FVector2D Position, struct FVector2D Size, struct USlateBrushAsset* Brush, struct FLinearColor Tint); // Offset: 0x1048e8a64 // Return & Params: Num(5) Size(0x58)

	// Object Name: Function UMG.WidgetBlueprintLibrary.DismissAllMenus
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void DismissAllMenus(); // Offset: 0x1048e8a50 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.WidgetBlueprintLibrary.DetectDragIfPressed
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FEventReply DetectDragIfPressed(struct FPointerEvent& PointerEvent, struct UWidget* WidgetDetectingDrag, struct FKey DragKey); // Offset: 0x1048e881c // Return & Params: Num(4) Size(0x150)

	// Object Name: Function UMG.WidgetBlueprintLibrary.DetectDrag
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FEventReply DetectDrag(struct FEventReply& Reply, struct UWidget* WidgetDetectingDrag, struct FKey DragKey); // Offset: 0x1048e8630 // Return & Params: Num(4) Size(0x190)

	// Object Name: Function UMG.WidgetBlueprintLibrary.CreateDragDropOperation
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UDragDropOperation* CreateDragDropOperation(struct UDragDropOperation* OperationClass); // Offset: 0x1048e85b4 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.WidgetBlueprintLibrary.Create
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	struct UUserWidget* Create(struct UObject* WorldContextObject, struct UUserWidget* WidgetType, struct APlayerController* OwningPlayer); // Offset: 0x1048e84c4 // Return & Params: Num(4) Size(0x20)

	// Object Name: Function UMG.WidgetBlueprintLibrary.ClearUserFocus
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FEventReply ClearUserFocus(struct FEventReply& Reply, bool bInAllUsers); // Offset: 0x1048e8370 // Return & Params: Num(3) Size(0x178)

	// Object Name: Function UMG.WidgetBlueprintLibrary.CaptureMouse
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FEventReply CaptureMouse(struct FEventReply& Reply, struct UWidget* CapturingWidget); // Offset: 0x1048e8224 // Return & Params: Num(3) Size(0x178)

	// Object Name: Function UMG.WidgetBlueprintLibrary.CaptureJoystick
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FEventReply CaptureJoystick(struct FEventReply& Reply, struct UWidget* CapturingWidget, bool bInAllJoysticks); // Offset: 0x1048e8090 // Return & Params: Num(4) Size(0x180)

	// Object Name: Function UMG.WidgetBlueprintLibrary.CancelDragDrop
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void CancelDragDrop(); // Offset: 0x1048e807c // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class UMG.WidgetInteractionComponent
// Size: 0x4c0 // Inherited bytes: 0x2d0
struct UWidgetInteractionComponent : USceneComponent {
	// Fields
	struct FScriptMulticastDelegate OnHoveredWidgetChanged; // Offset: 0x2d0 // Size: 0x10
	char pad_0x2E0[0x10]; // Offset: 0x2e0 // Size: 0x10
	int VirtualUserIndex; // Offset: 0x2f0 // Size: 0x04
	float PointerIndex; // Offset: 0x2f4 // Size: 0x04
	enum class ECollisionChannel TraceChannel; // Offset: 0x2f8 // Size: 0x01
	char pad_0x2F9[0x3]; // Offset: 0x2f9 // Size: 0x03
	float InteractionDistance; // Offset: 0x2fc // Size: 0x04
	enum class EWidgetInteractionSource InteractionSource; // Offset: 0x300 // Size: 0x01
	bool bEnableHitTesting; // Offset: 0x301 // Size: 0x01
	bool bShowDebug; // Offset: 0x302 // Size: 0x01
	char pad_0x303[0x1]; // Offset: 0x303 // Size: 0x01
	struct FLinearColor DebugColor; // Offset: 0x304 // Size: 0x10
	char pad_0x314[0x7c]; // Offset: 0x314 // Size: 0x7c
	struct FHitResult CustomHitResult; // Offset: 0x390 // Size: 0x88
	struct FVector2D LocalHitLocation; // Offset: 0x418 // Size: 0x08
	struct FVector2D LastLocalHitLocation; // Offset: 0x420 // Size: 0x08
	struct UWidgetComponent* HoveredWidgetComponent; // Offset: 0x428 // Size: 0x08
	struct FHitResult LastHitResult; // Offset: 0x430 // Size: 0x88
	bool bIsHoveredWidgetInteractable; // Offset: 0x4b8 // Size: 0x01
	bool bIsHoveredWidgetFocusable; // Offset: 0x4b9 // Size: 0x01
	bool bIsHoveredWidgetHitTestVisible; // Offset: 0x4ba // Size: 0x01
	char pad_0x4BB[0x5]; // Offset: 0x4bb // Size: 0x05

	// Functions

	// Object Name: Function UMG.WidgetInteractionComponent.SetCustomHitResult
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetCustomHitResult(struct FHitResult& HitResult); // Offset: 0x1048ee1c0 // Return & Params: Num(1) Size(0x88)

	// Object Name: Function UMG.WidgetInteractionComponent.SendKeyChar
	// Flags: [Native|Public|BlueprintCallable]
	bool SendKeyChar(struct FString Characters, bool bRepeat); // Offset: 0x1048ee0a4 // Return & Params: Num(3) Size(0x12)

	// Object Name: Function UMG.WidgetInteractionComponent.ScrollWheel
	// Flags: [Native|Public|BlueprintCallable]
	void ScrollWheel(float ScrollDelta); // Offset: 0x1048ee020 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.WidgetInteractionComponent.ReleasePointerKey
	// Flags: [Native|Public|BlueprintCallable]
	void ReleasePointerKey(struct FKey Key); // Offset: 0x1048edf30 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.WidgetInteractionComponent.ReleaseKey
	// Flags: [Native|Public|BlueprintCallable]
	bool ReleaseKey(struct FKey Key); // Offset: 0x1048ede30 // Return & Params: Num(2) Size(0x19)

	// Object Name: Function UMG.WidgetInteractionComponent.PressPointerKey
	// Flags: [Native|Public|BlueprintCallable]
	void PressPointerKey(struct FKey Key); // Offset: 0x1048edd40 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.WidgetInteractionComponent.PressKey
	// Flags: [Native|Public|BlueprintCallable]
	bool PressKey(struct FKey Key, bool bRepeat); // Offset: 0x1048edbf8 // Return & Params: Num(3) Size(0x1a)

	// Object Name: Function UMG.WidgetInteractionComponent.PressAndReleaseKey
	// Flags: [Native|Public|BlueprintCallable]
	bool PressAndReleaseKey(struct FKey Key); // Offset: 0x1048edaf8 // Return & Params: Num(2) Size(0x19)

	// Object Name: Function UMG.WidgetInteractionComponent.IsOverInteractableWidget
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsOverInteractableWidget(); // Offset: 0x1048edac4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WidgetInteractionComponent.IsOverHitTestVisibleWidget
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsOverHitTestVisibleWidget(); // Offset: 0x1048eda90 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WidgetInteractionComponent.IsOverFocusableWidget
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsOverFocusableWidget(); // Offset: 0x1048eda5c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WidgetInteractionComponent.GetLastHitResult
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FHitResult GetLastHitResult(); // Offset: 0x1048eda24 // Return & Params: Num(1) Size(0x88)

	// Object Name: Function UMG.WidgetInteractionComponent.GetHoveredWidgetComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UWidgetComponent* GetHoveredWidgetComponent(); // Offset: 0x1048ed9f0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WidgetInteractionComponent.Get2DHitLocation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector2D Get2DHitLocation(); // Offset: 0x1048ed9b8 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class UMG.WidgetLayoutLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UWidgetLayoutLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function UMG.WidgetLayoutLibrary.SlotAsVerticalBoxSlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UVerticalBoxSlot* SlotAsVerticalBoxSlot(struct UWidget* Widget); // Offset: 0x1048ef090 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.WidgetLayoutLibrary.SlotAsUniformGridSlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UUniformGridSlot* SlotAsUniformGridSlot(struct UWidget* Widget); // Offset: 0x1048ef014 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.WidgetLayoutLibrary.SlotAsOverlaySlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UOverlaySlot* SlotAsOverlaySlot(struct UWidget* Widget); // Offset: 0x1048eef98 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.WidgetLayoutLibrary.SlotAsHorizontalBoxSlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UHorizontalBoxSlot* SlotAsHorizontalBoxSlot(struct UWidget* Widget); // Offset: 0x1048eef1c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.WidgetLayoutLibrary.SlotAsGridSlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UGridSlot* SlotAsGridSlot(struct UWidget* Widget); // Offset: 0x1048eeea0 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.WidgetLayoutLibrary.SlotAsCanvasSlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UCanvasPanelSlot* SlotAsCanvasSlot(struct UWidget* Widget); // Offset: 0x1048eee24 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.WidgetLayoutLibrary.SlotAsBorderSlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UBorderSlot* SlotAsBorderSlot(struct UWidget* Widget); // Offset: 0x1048eeda8 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.WidgetLayoutLibrary.RemoveAllWidgets
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void RemoveAllWidgets(struct UObject* WorldContextObject); // Offset: 0x1048eed34 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WidgetLayoutLibrary.ProjectWorldLocationToWidgetPositionReturnValue
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FVector2D ProjectWorldLocationToWidgetPositionReturnValue(struct APlayerController* PlayerController, struct FVector WorldLocation); // Offset: 0x1048eec7c // Return & Params: Num(3) Size(0x1c)

	// Object Name: Function UMG.WidgetLayoutLibrary.ProjectWorldLocationToWidgetPosition
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	bool ProjectWorldLocationToWidgetPosition(struct APlayerController* PlayerController, struct FVector WorldLocation, struct FVector2D& ScreenPosition); // Offset: 0x1048eeb7c // Return & Params: Num(4) Size(0x1d)

	// Object Name: Function UMG.WidgetLayoutLibrary.GetViewportWidgetGeometry
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FGeometry GetViewportWidgetGeometry(struct UObject* WorldContextObject); // Offset: 0x1048eeaf4 // Return & Params: Num(2) Size(0x40)

	// Object Name: Function UMG.WidgetLayoutLibrary.GetViewportSize
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FVector2D GetViewportSize(struct UObject* WorldContextObject); // Offset: 0x1048eea74 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.WidgetLayoutLibrary.GetViewportScale
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable|BlueprintPure]
	float GetViewportScale(struct UObject* WorldContextObject); // Offset: 0x1048ee9f8 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function UMG.WidgetLayoutLibrary.GetPlayerScreenWidgetGeometry
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FGeometry GetPlayerScreenWidgetGeometry(struct APlayerController* PlayerController); // Offset: 0x1048ee970 // Return & Params: Num(2) Size(0x40)

	// Object Name: Function UMG.WidgetLayoutLibrary.GetMousePositionScaledByDPI
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	bool GetMousePositionScaledByDPI(struct APlayerController* Player, float& LocationX, float& LocationY); // Offset: 0x1048ee854 // Return & Params: Num(4) Size(0x11)

	// Object Name: Function UMG.WidgetLayoutLibrary.GetMousePositionOnViewport
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	struct FVector2D GetMousePositionOnViewport(struct UObject* WorldContextObject); // Offset: 0x1048ee7d4 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.WidgetLayoutLibrary.GetMousePositionOnPlatform
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	struct FVector2D GetMousePositionOnPlatform(); // Offset: 0x1048ee79c // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class UMG.WidgetNavigation
// Size: 0xb8 // Inherited bytes: 0x28
struct UWidgetNavigation : UObject {
	// Fields
	struct FWidgetNavigationData Up; // Offset: 0x28 // Size: 0x18
	struct FWidgetNavigationData Down; // Offset: 0x40 // Size: 0x18
	struct FWidgetNavigationData Left; // Offset: 0x58 // Size: 0x18
	struct FWidgetNavigationData Right; // Offset: 0x70 // Size: 0x18
	struct FWidgetNavigationData Next; // Offset: 0x88 // Size: 0x18
	struct FWidgetNavigationData Previous; // Offset: 0xa0 // Size: 0x18
};

// Object Name: Class UMG.WidgetSwitcher
// Size: 0x130 // Inherited bytes: 0x118
struct UWidgetSwitcher : UPanelWidget {
	// Fields
	int ActiveWidgetIndex; // Offset: 0x114 // Size: 0x04
	bool bDontPaintWhenChildEmpty; // Offset: 0x118 // Size: 0x01
	char pad_0x11D[0x13]; // Offset: 0x11d // Size: 0x13

	// Functions

	// Object Name: Function UMG.WidgetSwitcher.SetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDontPaintWhenChildEmpty(bool Enable); // Offset: 0x1048efa90 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WidgetSwitcher.SetActiveWidgetIndex
	// Flags: [Native|Public|BlueprintCallable]
	void SetActiveWidgetIndex(int Index); // Offset: 0x1048efa0c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.WidgetSwitcher.SetActiveWidget
	// Flags: [Native|Public|BlueprintCallable]
	void SetActiveWidget(struct UWidget* Widget); // Offset: 0x1048ef988 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WidgetSwitcher.GetWidgetAtIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UWidget* GetWidgetAtIndex(int Index); // Offset: 0x1048ef8fc // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.WidgetSwitcher.GetNumWidgets
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetNumWidgets(); // Offset: 0x1048ef8c8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.WidgetSwitcher.GetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetDontPaintWhenChildEmpty(); // Offset: 0x1048ef894 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WidgetSwitcher.GetActiveWidgetIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetActiveWidgetIndex(); // Offset: 0x1048ef860 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.WidgetSwitcher.GetActiveWidget
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UWidget* GetActiveWidget(); // Offset: 0x1048ef82c // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class UMG.WidgetSwitcherSlot
// Size: 0x58 // Inherited bytes: 0x38
struct UWidgetSwitcherSlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 // Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x48 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x49 // Size: 0x01
	char pad_0x4A[0xe]; // Offset: 0x4a // Size: 0x0e

	// Functions

	// Object Name: Function UMG.WidgetSwitcherSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x1048eff4c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WidgetSwitcherSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x1048efecc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.WidgetSwitcherSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x1048efe50 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.WidgetTree
// Size: 0x40 // Inherited bytes: 0x28
struct UWidgetTree : UObject {
	// Fields
	struct UWidget* RootWidget; // Offset: 0x28 // Size: 0x08
	struct TArray<struct UWidget*> AllWidgets; // Offset: 0x30 // Size: 0x10
};

// Object Name: Class UMG.WindowTitleBarArea
// Size: 0x130 // Inherited bytes: 0x118
struct UWindowTitleBarArea : UContentWidget {
	// Fields
	bool bDoubleClickTogglesFullscreen; // Offset: 0x111 // Size: 0x01
	char pad_0x119[0x17]; // Offset: 0x119 // Size: 0x17

	// Functions

	// Object Name: Function UMG.WindowTitleBarArea.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x1048f044c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WindowTitleBarArea.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x1048f03cc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.WindowTitleBarArea.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x1048f0350 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.WindowTitleBarAreaSlot
// Size: 0x60 // Inherited bytes: 0x38
struct UWindowTitleBarAreaSlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 // Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x48 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x49 // Size: 0x01
	char pad_0x4A[0x16]; // Offset: 0x4a // Size: 0x16

	// Functions

	// Object Name: Function UMG.WindowTitleBarAreaSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x1048f07a4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WindowTitleBarAreaSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x1048f0724 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.WindowTitleBarAreaSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x1048f06a8 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.WrapBox
// Size: 0x138 // Inherited bytes: 0x118
struct UWrapBox : UPanelWidget {
	// Fields
	struct FVector2D InnerSlotPadding; // Offset: 0x114 // Size: 0x08
	float WrapWidth; // Offset: 0x11c // Size: 0x04
	bool bExplicitWrapWidth; // Offset: 0x120 // Size: 0x01
	char pad_0x125[0x13]; // Offset: 0x125 // Size: 0x13

	// Functions

	// Object Name: Function UMG.WrapBox.SetInnerSlotPadding
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetInnerSlotPadding(struct FVector2D InPadding); // Offset: 0x1048f0a80 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WrapBox.AddChildWrapBox
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UWrapBoxSlot* AddChildWrapBox(struct UWidget* Content); // Offset: 0x1048f09f4 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class UMG.WrapBoxSlot
// Size: 0x60 // Inherited bytes: 0x38
struct UWrapBoxSlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 // Size: 0x10
	bool bFillEmptySpace; // Offset: 0x48 // Size: 0x01
	char pad_0x49[0x3]; // Offset: 0x49 // Size: 0x03
	float FillSpanWhenLessThan; // Offset: 0x4c // Size: 0x04
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x50 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x51 // Size: 0x01
	char pad_0x52[0xe]; // Offset: 0x52 // Size: 0x0e

	// Functions

	// Object Name: Function UMG.WrapBoxSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x1048f0e9c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WrapBoxSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x1048f0e1c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.WrapBoxSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x1048f0da0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WrapBoxSlot.SetFillSpanWhenLessThan
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFillSpanWhenLessThan(float InFillSpanWhenLessThan); // Offset: 0x1048f0d24 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.WrapBoxSlot.SetFillEmptySpace
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFillEmptySpace(bool InbFillEmptySpace); // Offset: 0x1048f0ca0 // Return & Params: Num(1) Size(0x1)
};

