#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UnknowPass_ContinuousBuy_BP.UnknowPass_ContinuousBuy_BP_C
// Size: 0x428 // Inherited bytes: 0x3d0
struct UUnknowPass_ContinuousBuy_BP_C : UUAEUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x3d0 // Size: 0x08
	struct UWidgetAnimation* GetTitle; // Offset: 0x3d8 // Size: 0x08
	struct UButton* Button_1; // Offset: 0x3e0 // Size: 0x08
	struct UCanvasPanel* FX1; // Offset: 0x3e8 // Size: 0x08
	struct UImage* FX2; // Offset: 0x3f0 // Size: 0x08
	struct UImage* Image_2; // Offset: 0x3f8 // Size: 0x08
	struct UImage* Image_24; // Offset: 0x400 // Size: 0x08
	struct UImage* Image_25; // Offset: 0x408 // Size: 0x08
	struct UImage* Image_Elite_vpass; // Offset: 0x410 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher; // Offset: 0x418 // Size: 0x08
	int HighestLevel; // Offset: 0x420 // Size: 0x04
	int thisSeasonId; // Offset: 0x424 // Size: 0x04

	// Functions

	// Object Name: Function UnknowPass_ContinuousBuy_BP.UnknowPass_ContinuousBuy_BP_C.HideFX
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void HideFX(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UnknowPass_ContinuousBuy_BP.UnknowPass_ContinuousBuy_BP_C.SetEliteImage
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetEliteImage(int SeasonID, int Level, int Value, bool isElite); // Offset: 0x103e7af64 // Return & Params: Num(4) Size(0xd)

	// Object Name: Function UnknowPass_ContinuousBuy_BP.UnknowPass_ContinuousBuy_BP_C.SetData
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetData(int SeasonID, int Level, bool isElite, int Online, int Value); // Offset: 0x103e7af64 // Return & Params: Num(5) Size(0x14)

	// Object Name: Function UnknowPass_ContinuousBuy_BP.UnknowPass_ContinuousBuy_BP_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UnknowPass_ContinuousBuy_BP.UnknowPass_ContinuousBuy_BP_C.ExecuteUbergraph_UnknowPass_ContinuousBuy_BP
	// Flags: [None]
	void ExecuteUbergraph_UnknowPass_ContinuousBuy_BP(int EntryPoint); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x4)
};

