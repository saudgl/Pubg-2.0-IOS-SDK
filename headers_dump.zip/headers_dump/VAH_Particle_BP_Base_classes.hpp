#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass VAH_Particle_BP_Base.VAH_Particle_BP_Base_C
// Size: 0x90 // Inherited bytes: 0x90
struct UVAH_Particle_BP_Base_C : UAvatarCustomParticle_BP_C {
};

