#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass VehicleAvatarHandleBase_BP.VehicleAvatarHandleBase_BP_C
// Size: 0x3f8 // Inherited bytes: 0x3f8
struct UVehicleAvatarHandleBase_BP_C : UBackpackVehicleAvatarHandle {
};

