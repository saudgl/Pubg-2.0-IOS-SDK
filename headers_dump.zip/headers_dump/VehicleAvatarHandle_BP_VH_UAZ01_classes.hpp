#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass VehicleAvatarHandle_BP_VH_UAZ01.VehicleAvatarHandle_BP_VH_UAZ01_C
// Size: 0x3f8 // Inherited bytes: 0x3f8
struct UVehicleAvatarHandle_BP_VH_UAZ01_C : UVehicleAvatarHandleBase_BP_C {
};

