#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass VehicleRefitTips.VehicleRefitTips_C
// Size: 0x3ec // Inherited bytes: 0x3c8
struct AVehicleRefitTips_C : AActor {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x3c8 // Size: 0x08
	struct UWidgetComponent* Widget; // Offset: 0x3d0 // Size: 0x08
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x3d8 // Size: 0x08
	struct UVehicleRefitTipsUI_C* tempTipsUI; // Offset: 0x3e0 // Size: 0x08
	int tipState; // Offset: 0x3e8 // Size: 0x04

	// Functions

	// Object Name: Function VehicleRefitTips.VehicleRefitTips_C.UpdateTipImage
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void UpdateTipImage(struct FString imgPath); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function VehicleRefitTips.VehicleRefitTips_C.AttachToRefitSocket
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void AttachToRefitSocket(struct ALobbyModelShowActorBP_C* ShowActor, int SlotID); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function VehicleRefitTips.VehicleRefitTips_C.SetRefitSlot
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetRefitSlot(int SlotID); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function VehicleRefitTips.VehicleRefitTips_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function VehicleRefitTips.VehicleRefitTips_C.HideOutTipFrom1To0
	// Flags: [BlueprintCallable|BlueprintEvent]
	void HideOutTipFrom1To0(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function VehicleRefitTips.VehicleRefitTips_C.HideTip
	// Flags: [BlueprintCallable|BlueprintEvent]
	void HideTip(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function VehicleRefitTips.VehicleRefitTips_C.FadeInToTransparent
	// Flags: [BlueprintCallable|BlueprintEvent]
	void FadeInToTransparent(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function VehicleRefitTips.VehicleRefitTips_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveBeginPlay(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function VehicleRefitTips.VehicleRefitTips_C.FadeOut
	// Flags: [BlueprintCallable|BlueprintEvent]
	void FadeOut(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function VehicleRefitTips.VehicleRefitTips_C.FadeIn
	// Flags: [BlueprintCallable|BlueprintEvent]
	void FadeIn(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function VehicleRefitTips.VehicleRefitTips_C.HideoutTipFromTransparentTo0
	// Flags: [BlueprintCallable|BlueprintEvent]
	void HideoutTipFromTransparentTo0(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function VehicleRefitTips.VehicleRefitTips_C.ExecuteUbergraph_VehicleRefitTips
	// Flags: [None]
	void ExecuteUbergraph_VehicleRefitTips(int EntryPoint); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x4)
};

