#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass WeaponAnimList_Rifle_M416.WeaponAnimList_Rifle_M416_C
// Size: 0x2b8 // Inherited bytes: 0x2b8
struct UWeaponAnimList_Rifle_M416_C : UUAECharacterAnimListComponent {
};

