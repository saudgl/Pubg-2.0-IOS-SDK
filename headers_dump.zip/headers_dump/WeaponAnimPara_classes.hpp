#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass WeaponAnimPara.WeaponAnimPara_C
// Size: 0x28 // Inherited bytes: 0x28
struct UWeaponAnimPara_C : UInterface {
	// Functions

	// Object Name: Function WeaponAnimPara.WeaponAnimPara_C.SetAnimTimeInfo
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetAnimTimeInfo(int DelayTime, int TotalTime); // Offset: 0x103e7af64 // Return & Params: Num(2) Size(0x8)
};

