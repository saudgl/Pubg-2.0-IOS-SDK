#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptBlueprintGeneratedClass bp_setting.bp_setting_C
// Size: 0x688 // Inherited bytes: 0x430
struct Abp_setting_C : ALuaClassObj {
	// Fields
	struct UScriptContextComponent* Generated_ScriptContext; // Offset: 0x430 // Size: 0x08
	bool BP_Is_In_Debug_Mode; // Offset: 0x438 // Size: 0x01
	char pad_0x439[0x7]; // Offset: 0x439 // Size: 0x07
	struct FString BP_Setting_UnbindPlatformName; // Offset: 0x440 // Size: 0x10
	bool BP_IsSensitivitySavedInCloud; // Offset: 0x450 // Size: 0x01
	char pad_0x451[0x3]; // Offset: 0x451 // Size: 0x03
	int BP_SettingIndexOther; // Offset: 0x454 // Size: 0x04
	bool BP_IsInGame; // Offset: 0x458 // Size: 0x01
	char pad_0x459[0x7]; // Offset: 0x459 // Size: 0x07
	struct TArray<struct FString> BP_ARRAY_SettingLoginTypeOrderList; // Offset: 0x460 // Size: 0x10
	int BP_XGPUSH_OFF_TIP_CODE; // Offset: 0x470 // Size: 0x04
	bool BP_BasicSettingForbidFollowJump; // Offset: 0x474 // Size: 0x01
	char pad_0x475[0x3]; // Offset: 0x475 // Size: 0x03
	struct FString BP_UrlStr3; // Offset: 0x478 // Size: 0x10
	int BP_ShapedScreenCurrentSelectType; // Offset: 0x488 // Size: 0x04
	int BP_SettingIndexPickup; // Offset: 0x48c // Size: 0x04
	int BP_SettingFresherType; // Offset: 0x490 // Size: 0x04
	char pad_0x494[0x4]; // Offset: 0x494 // Size: 0x04
	struct FString BP_SettingPlayerUID; // Offset: 0x498 // Size: 0x10
	int BP_SettingIndexBasic; // Offset: 0x4a8 // Size: 0x04
	int HelpshiftRequestCD; // Offset: 0x4ac // Size: 0x04
	bool BP_SettingBattleWatchingDetailOpen; // Offset: 0x4b0 // Size: 0x01
	char pad_0x4B1[0x3]; // Offset: 0x4b1 // Size: 0x03
	int HelpshiftLastRequestTime; // Offset: 0x4b4 // Size: 0x04
	int BP_Setting_UploadType; // Offset: 0x4b8 // Size: 0x04
	bool BP_CanShowOtherTab; // Offset: 0x4bc // Size: 0x01
	char pad_0x4BD[0x3]; // Offset: 0x4bd // Size: 0x03
	int BP_ShapedScreenType; // Offset: 0x4c0 // Size: 0x04
	int BP_SettingIndexAccount; // Offset: 0x4c4 // Size: 0x04
	bool BP_KRJPDelAccountSwitch; // Offset: 0x4c8 // Size: 0x01
	bool BP_Unknow_Pass_Switch_Record_Show; // Offset: 0x4c9 // Size: 0x01
	char pad_0x4CA[0x2]; // Offset: 0x4ca // Size: 0x02
	int BP_SettingMaxLoginTypeNum; // Offset: 0x4cc // Size: 0x04
	int BP_SHOW_XGPUSH_OFF_JK; // Offset: 0x4d0 // Size: 0x04
	bool BP_SettingCanShowRole; // Offset: 0x4d4 // Size: 0x01
	char pad_0x4D5[0x3]; // Offset: 0x4d5 // Size: 0x03
	int BP_ProfiledScreenCurrentSelectValue; // Offset: 0x4d8 // Size: 0x04
	int BP_SettingLobbyBgmID; // Offset: 0x4dc // Size: 0x04
	int BP_SettingBattleWatchingDetailFlag; // Offset: 0x4e0 // Size: 0x04
	int BP_SettingIndexPicture; // Offset: 0x4e4 // Size: 0x04
	bool BP_SettingIsWatchingOpen; // Offset: 0x4e8 // Size: 0x01
	char pad_0x4E9[0x3]; // Offset: 0x4e9 // Size: 0x03
	int BP_CurSettingPage; // Offset: 0x4ec // Size: 0x04
	int BP_OPEN_SECOND_BIND_GLOBAL; // Offset: 0x4f0 // Size: 0x04
	int BP_SettingSelectedPage; // Offset: 0x4f4 // Size: 0x04
	int BP_SettingLobbySkinID; // Offset: 0x4f8 // Size: 0x04
	int BP_SettingCurrentOpenPage; // Offset: 0x4fc // Size: 0x04
	int BP_SettingIndexInfoBinding; // Offset: 0x500 // Size: 0x04
	int BP_SettingIndexSound; // Offset: 0x504 // Size: 0x04
	bool BP_JP_Mirrativ_Show; // Offset: 0x508 // Size: 0x01
	bool BP_Unknow_Pass_Switch_Battle_Show; // Offset: 0x509 // Size: 0x01
	char pad_0x50A[0x2]; // Offset: 0x50a // Size: 0x02
	int BP_SettingIndexAimingMirrior; // Offset: 0x50c // Size: 0x04
	int BP_SettingShowWatchingFlag; // Offset: 0x510 // Size: 0x04
	bool BP_SettingCanShowEscapeNotice; // Offset: 0x514 // Size: 0x01
	char pad_0x515[0x3]; // Offset: 0x515 // Size: 0x03
	int BP_SettingIndexMirrativ; // Offset: 0x518 // Size: 0x04
	int BP_DiyLimitLevel; // Offset: 0x51c // Size: 0x04
	bool BP_WonderfulReplaySwitchIsOpen; // Offset: 0x520 // Size: 0x01
	char pad_0x521[0x3]; // Offset: 0x521 // Size: 0x03
	int BP_SettingIndexLanguage; // Offset: 0x524 // Size: 0x04
	struct FString BP_SettingFirstLoginStrChannel; // Offset: 0x528 // Size: 0x10
	int BP_SettingIndexOBS; // Offset: 0x538 // Size: 0x04
	bool BP_Setting_Social_Stranger_Switch; // Offset: 0x53c // Size: 0x01
	bool BP_SettingCanModify_QualityFPS; // Offset: 0x53d // Size: 0x01
	char pad_0x53E[0x2]; // Offset: 0x53e // Size: 0x02
	struct FString BP_Setting_Region_Set_Time; // Offset: 0x540 // Size: 0x10
	struct FString BP_UrlStr2; // Offset: 0x550 // Size: 0x10
	struct FBP_STRUCT_SettingSensitivity BP_STRUCT_SettingSensitivity; // Offset: 0x560 // Size: 0xb8
	struct FString BP_Setting_Region_Name; // Offset: 0x618 // Size: 0x10
	int BP_SettingIndexEffect; // Offset: 0x628 // Size: 0x04
	bool BP_Setting_Social_Friend_Switch; // Offset: 0x62c // Size: 0x01
	char pad_0x62D[0x3]; // Offset: 0x62d // Size: 0x03
	int BP_SettingIndexOperate; // Offset: 0x630 // Size: 0x04
	int BP_krjp_del_account_left_time; // Offset: 0x634 // Size: 0x04
	int BP_SHOW_XGPUSH_OFF_GLOBAL; // Offset: 0x638 // Size: 0x04
	int BP_ProfiledScreenValue; // Offset: 0x63c // Size: 0x04
	int BP_OPEN_SECOND_BIND_JK; // Offset: 0x640 // Size: 0x04
	int BP_LoginChannel; // Offset: 0x644 // Size: 0x04
	struct FString BP_GradeSeparation_UrlStr; // Offset: 0x648 // Size: 0x10
	int BP_SettingPlayerLevel; // Offset: 0x658 // Size: 0x04
	char pad_0x65C[0x4]; // Offset: 0x65c // Size: 0x04
	struct FString BP_SettingSecondLoginStrChannel; // Offset: 0x660 // Size: 0x10
	bool BP_IsInLobby; // Offset: 0x670 // Size: 0x01
	char pad_0x671[0x3]; // Offset: 0x671 // Size: 0x03
	int BP_SettingIndexDownload; // Offset: 0x674 // Size: 0x04
	int BP_SettingIndexSensibility; // Offset: 0x678 // Size: 0x04
	char pad_0x67C[0x4]; // Offset: 0x67c // Size: 0x04
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x680 // Size: 0x08

	// Functions

	// Object Name: Function bp_setting.bp_setting_C.EventClickSwitchButton_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventClickSwitchButton_NoFetch(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventClickSwitchButton
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventClickSwitchButton(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventShowOBBackToLobbyNotice_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventShowOBBackToLobbyNotice_NoFetch(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventShowOBBackToLobbyNotice
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventShowOBBackToLobbyNotice(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventHelpshiftSetRedPoints_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventHelpshiftSetRedPoints_NoFetch(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventHelpshiftSetRedPoints
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventHelpshiftSetRedPoints(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventResetShapedScreen_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventResetShapedScreen_NoFetch(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventResetShapedScreen
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventResetShapedScreen(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventOnShowHawkEyeWatchEndedTips_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventOnShowHawkEyeWatchEndedTips_NoFetch(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventOnShowHawkEyeWatchEndedTips
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventOnShowHawkEyeWatchEndedTips(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventShowBackToLobbyFromTrainingNotice_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventShowBackToLobbyFromTrainingNotice_NoFetch(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventShowBackToLobbyFromTrainingNotice
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventShowBackToLobbyFromTrainingNotice(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventShowLogOutNoticce_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventShowLogOutNoticce_NoFetch(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventShowLogOutNoticce
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventShowLogOutNoticce(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventShow3dTouchNotSupportQuickThrow_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventShow3dTouchNotSupportQuickThrow_NoFetch(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventShow3dTouchNotSupportQuickThrow
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventShow3dTouchNotSupportQuickThrow(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventRefreshSettingParameter_Push_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventRefreshSettingParameter_Push_NoFetch(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventRefreshSettingParameter_Push
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventRefreshSettingParameter_Push(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventSetBPQualitySettingByLocal_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventSetBPQualitySettingByLocal_NoFetch(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventSetBPQualitySettingByLocal
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventSetBPQualitySettingByLocal(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventUploadSettingConfigToCloud_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventUploadSettingConfigToCloud_NoFetch(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventUploadSettingConfigToCloud
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventUploadSettingConfigToCloud(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventSettingShowCurrentTicket_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventSettingShowCurrentTicket_NoFetch(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventSettingShowCurrentTicket
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventSettingShowCurrentTicket(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventHideLastOpennedPage_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventHideLastOpennedPage_NoFetch(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventHideLastOpennedPage
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventHideLastOpennedPage(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventSettingBasicRedPointChanged_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventSettingBasicRedPointChanged_NoFetch(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventSettingBasicRedPointChanged
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventSettingBasicRedPointChanged(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventShowBackToLobbyNotice_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventShowBackToLobbyNotice_NoFetch(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventShowBackToLobbyNotice
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventShowBackToLobbyNotice(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventShowNoticeFromObserveToLobby_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventShowNoticeFromObserveToLobby_NoFetch(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventShowNoticeFromObserveToLobby
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventShowNoticeFromObserveToLobby(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventSettingPickUpRedPointChanged_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventSettingPickUpRedPointChanged_NoFetch(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventSettingPickUpRedPointChanged
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventSettingPickUpRedPointChanged(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventHelpshiftClearRedPoints_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventHelpshiftClearRedPoints_NoFetch(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventHelpshiftClearRedPoints
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventHelpshiftClearRedPoints(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventSettingShowUIElemUIVehicle_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventSettingShowUIElemUIVehicle_NoFetch(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventSettingShowUIElemUIVehicle
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventSettingShowUIElemUIVehicle(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventSettingShowUIElemUI_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventSettingShowUIElemUI_NoFetch(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventSettingShowUIElemUI
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventSettingShowUIElemUI(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventOpenHawkEyeReportWindow_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventOpenHawkEyeReportWindow_NoFetch(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventOpenHawkEyeReportWindow
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventOpenHawkEyeReportWindow(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventShowSelectedPage_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventShowSelectedPage_NoFetch(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventShowSelectedPage
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventShowSelectedPage(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventShowNoticeFromWatchingBackToLobby_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventShowNoticeFromWatchingBackToLobby_NoFetch(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventShowNoticeFromWatchingBackToLobby
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventShowNoticeFromWatchingBackToLobby(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventSettingWarningLvSixFps_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventSettingWarningLvSixFps_NoFetch(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventSettingWarningLvSixFps
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventSettingWarningLvSixFps(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventShowInturrptGameNotice_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventShowInturrptGameNotice_NoFetch(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventShowInturrptGameNotice
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventShowInturrptGameNotice(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventHideAllSettingPanel_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventHideAllSettingPanel_NoFetch(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventHideAllSettingPanel
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventHideAllSettingPanel(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventShowNoticeFromHawkEyeSpectatingBackToLobby_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventShowNoticeFromHawkEyeSpectatingBackToLobby_NoFetch(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventShowNoticeFromHawkEyeSpectatingBackToLobby
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventShowNoticeFromHawkEyeSpectatingBackToLobby(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventHideAllNoticeFromObserveToLobby_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventHideAllNoticeFromObserveToLobby_NoFetch(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventHideAllNoticeFromObserveToLobby
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventHideAllNoticeFromObserveToLobby(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventRefreshSettingRedPoint_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventRefreshSettingRedPoint_NoFetch(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventRefreshSettingRedPoint
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventRefreshSettingRedPoint(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventSettingPanelUnRegistIMSDKEvents_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventSettingPanelUnRegistIMSDKEvents_NoFetch(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventSettingPanelUnRegistIMSDKEvents
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventSettingPanelUnRegistIMSDKEvents(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventShowOrHideSettingAccountTips_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventShowOrHideSettingAccountTips_NoFetch(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventShowOrHideSettingAccountTips
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventShowOrHideSettingAccountTips(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventSaveShapedScreenToLoacl_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventSaveShapedScreenToLoacl_NoFetch(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventSaveShapedScreenToLoacl
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventSaveShapedScreenToLoacl(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventChatRequestPrivacyInSetting_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventChatRequestPrivacyInSetting_NoFetch(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventChatRequestPrivacyInSetting
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventChatRequestPrivacyInSetting(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventFetchInfo_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventFetchInfo_NoFetch(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.EventFetchInfo
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventFetchInfo(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_setting.bp_setting_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)
};

