#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct iTOP.iTOPResult
// Size: 0x40 // Inherited bytes: 0x00
struct FiTOPResult {
	// Fields
	int imsdkRetCode; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString imsdkRetMsg; // Offset: 0x08 // Size: 0x10
	int thirdRetCode; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct FString thirdRetMsg; // Offset: 0x20 // Size: 0x10
	struct FString retExtraJson; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct iTOP.IMSDKUnifiedAccountResult
// Size: 0xe0 // Inherited bytes: 0x40
struct FIMSDKUnifiedAccountResult : FiTOPResult {
	// Fields
	int Ret; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
	struct FString retMsg; // Offset: 0x48 // Size: 0x10
	struct FString accountToken; // Offset: 0x58 // Size: 0x10
	struct FString UId; // Offset: 0x68 // Size: 0x10
	struct FString ExpireTime; // Offset: 0x78 // Size: 0x10
	int verifyCodeExpire; // Offset: 0x88 // Size: 0x04
	int isRegister; // Offset: 0x8c // Size: 0x04
	int isSetPwd; // Offset: 0x90 // Size: 0x04
	int isReceiveEmail; // Offset: 0x94 // Size: 0x04
	struct FString emailAccount; // Offset: 0x98 // Size: 0x10
	struct FString phoneAccount; // Offset: 0xa8 // Size: 0x10
	struct FString phoneExtra; // Offset: 0xb8 // Size: 0x10
	int accountType; // Offset: 0xc8 // Size: 0x04
	char pad_0xCC[0x4]; // Offset: 0xcc // Size: 0x04
	struct FString phoneArea; // Offset: 0xd0 // Size: 0x10
};

// Object Name: ScriptStruct iTOP.IMSDKShortUrlResult
// Size: 0x50 // Inherited bytes: 0x40
struct FIMSDKShortUrlResult : FiTOPResult {
	// Fields
	struct FString ShortUrl; // Offset: 0x40 // Size: 0x10
};

// Object Name: ScriptStruct iTOP.iTOPFriendResult
// Size: 0x50 // Inherited bytes: 0x40
struct FiTOPFriendResult : FiTOPResult {
	// Fields
	struct TArray<struct FiTOPFriendInfo> sameGameFriendList; // Offset: 0x40 // Size: 0x10
};

// Object Name: ScriptStruct iTOP.iTOPFriendInfo
// Size: 0x78 // Inherited bytes: 0x00
struct FiTOPFriendInfo {
	// Fields
	struct FString OpenID; // Offset: 0x00 // Size: 0x10
	struct FString channelUserId; // Offset: 0x10 // Size: 0x10
	struct FString channelId; // Offset: 0x20 // Size: 0x10
	struct FString UserName; // Offset: 0x30 // Size: 0x10
	int gender; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
	struct FString pictureUrl; // Offset: 0x48 // Size: 0x10
	struct FString email; // Offset: 0x58 // Size: 0x10
	struct FString phone; // Offset: 0x68 // Size: 0x10
};

// Object Name: ScriptStruct iTOP.iTOPLoginResult
// Size: 0xf8 // Inherited bytes: 0x40
struct FiTOPLoginResult : FiTOPResult {
	// Fields
	struct FString Channel; // Offset: 0x40 // Size: 0x10
	int channelId; // Offset: 0x50 // Size: 0x04
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
	struct FString channelToken; // Offset: 0x58 // Size: 0x10
	int channelTokenExpire; // Offset: 0x68 // Size: 0x04
	char pad_0x6C[0x4]; // Offset: 0x6c // Size: 0x04
	struct FString channelUserId; // Offset: 0x70 // Size: 0x10
	int GameID; // Offset: 0x80 // Size: 0x04
	char pad_0x84[0x4]; // Offset: 0x84 // Size: 0x04
	struct FString Guid; // Offset: 0x88 // Size: 0x10
	struct FString guidUserBirthday; // Offset: 0x98 // Size: 0x10
	struct FString guidUserNick; // Offset: 0xa8 // Size: 0x10
	struct FString guidUserPortrait; // Offset: 0xb8 // Size: 0x10
	int guidUserSex; // Offset: 0xc8 // Size: 0x04
	int innerTokenExpire; // Offset: 0xcc // Size: 0x04
	int isFirstLogin; // Offset: 0xd0 // Size: 0x04
	char pad_0xD4[0x4]; // Offset: 0xd4 // Size: 0x04
	struct FString innerToken; // Offset: 0xd8 // Size: 0x10
	struct FString OpenID; // Offset: 0xe8 // Size: 0x10
};

// Object Name: ScriptStruct iTOP.iTOPBindResult
// Size: 0x108 // Inherited bytes: 0xf8
struct FiTOPBindResult : FiTOPLoginResult {
	// Fields
	struct TArray<struct FiTOPChannelInfo> bindInfoList; // Offset: 0xf8 // Size: 0x10
};

// Object Name: ScriptStruct iTOP.iTOPChannelInfo
// Size: 0x68 // Inherited bytes: 0x40
struct FiTOPChannelInfo : FiTOPResult {
	// Fields
	int channelId; // Offset: 0x40 // Size: 0x04
	int gender; // Offset: 0x44 // Size: 0x04
	struct FString pictureUrl; // Offset: 0x48 // Size: 0x10
	struct FString UserName; // Offset: 0x58 // Size: 0x10
};

// Object Name: ScriptStruct iTOP.iTOPNoticeResult
// Size: 0x58 // Inherited bytes: 0x40
struct FiTOPNoticeResult : FiTOPResult {
	// Fields
	struct TArray<struct FiTOPNoticeInfo> noticesList; // Offset: 0x40 // Size: 0x10
	int noticesNum; // Offset: 0x50 // Size: 0x04
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
};

// Object Name: ScriptStruct iTOP.iTOPNoticeInfo
// Size: 0xd0 // Inherited bytes: 0x00
struct FiTOPNoticeInfo {
	// Fields
	struct FString stateCode; // Offset: 0x00 // Size: 0x10
	int noticeId; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FString AppID; // Offset: 0x18 // Size: 0x10
	struct FString OpenID; // Offset: 0x28 // Size: 0x10
	struct FString noticeUrl; // Offset: 0x38 // Size: 0x10
	int noticeScene; // Offset: 0x48 // Size: 0x04
	int noticeUpdateTime; // Offset: 0x4c // Size: 0x04
	int noticeEndTime; // Offset: 0x50 // Size: 0x04
	int noticeStartTime; // Offset: 0x54 // Size: 0x04
	struct FString screenName; // Offset: 0x58 // Size: 0x10
	struct FString noticeLanguage; // Offset: 0x68 // Size: 0x10
	int noticeContentType; // Offset: 0x78 // Size: 0x04
	char pad_0x7C[0x4]; // Offset: 0x7c // Size: 0x04
	struct FString noticeTitle; // Offset: 0x80 // Size: 0x10
	struct FString noticeContent; // Offset: 0x90 // Size: 0x10
	struct TArray<struct FiTOPNoticePicInfo> noticePics; // Offset: 0xa0 // Size: 0x10
	struct FString noticeContentWebUrl; // Offset: 0xb0 // Size: 0x10
	struct FString ExtraJson; // Offset: 0xc0 // Size: 0x10
};

// Object Name: ScriptStruct iTOP.iTOPNoticePicInfo
// Size: 0x58 // Inherited bytes: 0x00
struct FiTOPNoticePicInfo {
	// Fields
	int noticeId; // Offset: 0x00 // Size: 0x04
	int screenDir; // Offset: 0x04 // Size: 0x04
	struct FString PicUrl; // Offset: 0x08 // Size: 0x10
	struct FString picHash; // Offset: 0x18 // Size: 0x10
	struct FString picTitle; // Offset: 0x28 // Size: 0x10
	struct FString picSize; // Offset: 0x38 // Size: 0x10
	struct FString ExtraJson; // Offset: 0x48 // Size: 0x10
};

// Object Name: ScriptStruct iTOP.iTOPAuthMigrateResult
// Size: 0x68 // Inherited bytes: 0x40
struct FiTOPAuthMigrateResult : FiTOPResult {
	// Fields
	struct FString migrateCode; // Offset: 0x40 // Size: 0x10
	int validTime; // Offset: 0x50 // Size: 0x04
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
	struct TArray<struct FiTOPAuthSNSInfo> snsInfoList; // Offset: 0x58 // Size: 0x10
};

// Object Name: ScriptStruct iTOP.iTOPAuthSNSInfo
// Size: 0x40 // Inherited bytes: 0x00
struct FiTOPAuthSNSInfo {
	// Fields
	struct FString OpenID; // Offset: 0x00 // Size: 0x10
	int channelId; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FString UserName; // Offset: 0x18 // Size: 0x10
	int gender; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct FString pictureUrl; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct iTOP.iTOPGPSInfoResult
// Size: 0x70 // Inherited bytes: 0x40
struct FiTOPGPSInfoResult : FiTOPResult {
	// Fields
	double longitude; // Offset: 0x40 // Size: 0x08
	double latitude; // Offset: 0x48 // Size: 0x08
	double horizontalAccuracyMeters; // Offset: 0x50 // Size: 0x08
	double verticalAccuracyMeters; // Offset: 0x58 // Size: 0x08
	struct FString locationProvider; // Offset: 0x60 // Size: 0x10
};

// Object Name: ScriptStruct iTOP.iTOPLbsResult
// Size: 0x100 // Inherited bytes: 0x40
struct FiTOPLbsResult : FiTOPResult {
	// Fields
	int channelId; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
	struct FString cityName; // Offset: 0x48 // Size: 0x10
	int cityNumber; // Offset: 0x58 // Size: 0x04
	char pad_0x5C[0x4]; // Offset: 0x5c // Size: 0x04
	struct FString countryName; // Offset: 0x60 // Size: 0x10
	int countryNumber; // Offset: 0x70 // Size: 0x04
	int GameID; // Offset: 0x74 // Size: 0x04
	struct FString Guid; // Offset: 0x78 // Size: 0x10
	struct FString guidToken; // Offset: 0x88 // Size: 0x10
	int guidTokenExpire; // Offset: 0x98 // Size: 0x04
	char pad_0x9C[0x4]; // Offset: 0x9c // Size: 0x04
	struct FString guidUserBirthday; // Offset: 0xa0 // Size: 0x10
	struct FString guidUserNick; // Offset: 0xb0 // Size: 0x10
	struct FString guidUserPortrait; // Offset: 0xc0 // Size: 0x10
	int guidUserSex; // Offset: 0xd0 // Size: 0x04
	char pad_0xD4[0x4]; // Offset: 0xd4 // Size: 0x04
	struct FString provinceName; // Offset: 0xd8 // Size: 0x10
	struct FString OpenID; // Offset: 0xe8 // Size: 0x10
	int provinceNumber; // Offset: 0xf8 // Size: 0x04
	char pad_0xFC[0x4]; // Offset: 0xfc // Size: 0x04
};

// Object Name: ScriptStruct iTOP.iTOPAuthResult
// Size: 0xb0 // Inherited bytes: 0x40
struct FiTOPAuthResult : FiTOPResult {
	// Fields
	struct FString Channel; // Offset: 0x40 // Size: 0x10
	int channelId; // Offset: 0x50 // Size: 0x04
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
	struct FString DeviceID; // Offset: 0x58 // Size: 0x10
	int GameID; // Offset: 0x68 // Size: 0x04
	char pad_0x6C[0x4]; // Offset: 0x6c // Size: 0x04
	struct FString innerToken; // Offset: 0x70 // Size: 0x10
	int isFirstLogin; // Offset: 0x80 // Size: 0x04
	char pad_0x84[0x4]; // Offset: 0x84 // Size: 0x04
	struct FString OpenID; // Offset: 0x88 // Size: 0x10
	int tokenExpireTime; // Offset: 0x98 // Size: 0x04
	char pad_0x9C[0x4]; // Offset: 0x9c // Size: 0x04
	struct TArray<struct FiTOPAuthSNSInfo> snsInfoList; // Offset: 0xa0 // Size: 0x10
};

// Object Name: ScriptStruct iTOP.iTOPAuthConnectResult
// Size: 0x90 // Inherited bytes: 0x40
struct FiTOPAuthConnectResult : FiTOPResult {
	// Fields
	struct FString confirmCode; // Offset: 0x40 // Size: 0x10
	int channelId; // Offset: 0x50 // Size: 0x04
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
	struct FString OpenID; // Offset: 0x58 // Size: 0x10
	int gender; // Offset: 0x68 // Size: 0x04
	char pad_0x6C[0x4]; // Offset: 0x6c // Size: 0x04
	struct FString UserName; // Offset: 0x70 // Size: 0x10
	struct FString pictureUrl; // Offset: 0x80 // Size: 0x10
};

// Object Name: ScriptStruct iTOP.iTOPWebViewStatusResult
// Size: 0x48 // Inherited bytes: 0x40
struct FiTOPWebViewStatusResult : FiTOPResult {
	// Fields
	int stateCode; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
};

// Object Name: ScriptStruct iTOP.iTOPWebViewTicketResult
// Size: 0x60 // Inherited bytes: 0x40
struct FiTOPWebViewTicketResult : FiTOPResult {
	// Fields
	struct FString Ticket; // Offset: 0x40 // Size: 0x10
	struct FString domain; // Offset: 0x50 // Size: 0x10
};

