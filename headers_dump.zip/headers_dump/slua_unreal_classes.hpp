#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class slua_unreal.LuaActor
// Size: 0x490 // Inherited bytes: 0x3c8
struct ALuaActor : AActor {
	// Fields
	char pad_0x3C8[0x60]; // Offset: 0x3c8 // Size: 0x60
	struct FLuaNetSerialization LuaNetSerialization; // Offset: 0x428 // Size: 0x50
	struct FString LuaFilePath; // Offset: 0x478 // Size: 0x10
	char pad_0x488[0x8]; // Offset: 0x488 // Size: 0x08

	// Functions

	// Object Name: Function slua_unreal.LuaActor.UnRegistLuaTick
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UnRegistLuaTick(); // Offset: 0x102498904 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function slua_unreal.LuaActor.RegistLuaTick
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegistLuaTick(float TickInterval); // Offset: 0x102498888 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class slua_unreal.LuaActorComponent
// Size: 0x1d8 // Inherited bytes: 0x110
struct ULuaActorComponent : UActorComponent {
	// Fields
	char pad_0x110[0x60]; // Offset: 0x110 // Size: 0x60
	struct FLuaNetSerialization LuaNetSerialization; // Offset: 0x170 // Size: 0x50
	struct FString LuaFilePath; // Offset: 0x1c0 // Size: 0x10
	char pad_0x1D0[0x8]; // Offset: 0x1d0 // Size: 0x08

	// Functions

	// Object Name: Function slua_unreal.LuaActorComponent.UnRegistLuaTick
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UnRegistLuaTick(); // Offset: 0x102498b6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function slua_unreal.LuaActorComponent.RegistLuaTick
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegistLuaTick(float TickInterval); // Offset: 0x102498af0 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class slua_unreal.LatentDelegate
// Size: 0x30 // Inherited bytes: 0x28
struct ULatentDelegate : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08

	// Functions

	// Object Name: Function slua_unreal.LatentDelegate.OnLatentCallback
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OnLatentCallback(int threadRef); // Offset: 0x102498684 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class slua_unreal.LuaDelegate
// Size: 0x38 // Inherited bytes: 0x28
struct ULuaDelegate : UObject {
	// Fields
	char pad_0x28[0x10]; // Offset: 0x28 // Size: 0x10

	// Functions

	// Object Name: Function slua_unreal.LuaDelegate.EventTrigger
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EventTrigger(); // Offset: 0x102498d14 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class slua_unreal.LuaGameMode
// Size: 0x508 // Inherited bytes: 0x498
struct ALuaGameMode : AGameMode {
	// Fields
	char pad_0x498[0x60]; // Offset: 0x498 // Size: 0x60
	struct FString LuaFilePath; // Offset: 0x4f8 // Size: 0x10
};

// Object Name: Class slua_unreal.LuaGameState
// Size: 0x4e8 // Inherited bytes: 0x428
struct ALuaGameState : AGameState {
	// Fields
	char pad_0x428[0x60]; // Offset: 0x428 // Size: 0x60
	struct FLuaNetSerialization LuaNetSerialization; // Offset: 0x488 // Size: 0x50
	struct FString LuaFilePath; // Offset: 0x4d8 // Size: 0x10
};

// Object Name: Class slua_unreal.LuaInstancedActorComponent
// Size: 0x190 // Inherited bytes: 0x110
struct ULuaInstancedActorComponent : UActorComponent {
	// Fields
	char pad_0x110[0x68]; // Offset: 0x110 // Size: 0x68
	struct FString LuaFilePath; // Offset: 0x178 // Size: 0x10
	char pad_0x188[0x8]; // Offset: 0x188 // Size: 0x08

	// Functions

	// Object Name: Function slua_unreal.LuaInstancedActorComponent.UnRegistLuaTick
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UnRegistLuaTick(); // Offset: 0x1024990d8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function slua_unreal.LuaInstancedActorComponent.RegistLuaTick
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegistLuaTick(float TickInterval); // Offset: 0x10249905c // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class slua_unreal.LuaLevelScriptActor
// Size: 0x440 // Inherited bytes: 0x3d0
struct ALuaLevelScriptActor : ALevelScriptActor {
	// Fields
	char pad_0x3D0[0x60]; // Offset: 0x3d0 // Size: 0x60
	struct FString LuaFilePath; // Offset: 0x430 // Size: 0x10
};

// Object Name: Class slua_unreal.LuaOverrider
// Size: 0x28 // Inherited bytes: 0x28
struct ULuaOverrider : UObject {
	// Functions

	// Object Name: Function slua_unreal.LuaOverrider.TriggerAnimNotify
	// Flags: [Event|Public|BlueprintEvent]
	void TriggerAnimNotify(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class slua_unreal.InstancedLuaInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UInstancedLuaInterface : UInterface {
};

// Object Name: Class slua_unreal.LuaOverriderInterface
// Size: 0x28 // Inherited bytes: 0x28
struct ULuaOverriderInterface : UInterface {
	// Functions

	// Object Name: Function slua_unreal.LuaOverriderInterface.GetLuaFilePath
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	struct FString GetLuaFilePath(); // Offset: 0x102499628 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class slua_unreal.LuaPlayerController
// Size: 0x7f0 // Inherited bytes: 0x730
struct ALuaPlayerController : APlayerController {
	// Fields
	char pad_0x730[0x60]; // Offset: 0x730 // Size: 0x60
	struct FLuaNetSerialization LuaNetSerialization; // Offset: 0x790 // Size: 0x50
	struct FString LuaFilePath; // Offset: 0x7e0 // Size: 0x10
};

// Object Name: Class slua_unreal.LuaPlayerState
// Size: 0x510 // Inherited bytes: 0x450
struct ALuaPlayerState : APlayerState {
	// Fields
	char pad_0x450[0x60]; // Offset: 0x450 // Size: 0x60
	struct FLuaNetSerialization LuaNetSerialization; // Offset: 0x4b0 // Size: 0x50
	struct FString LuaFilePath; // Offset: 0x500 // Size: 0x10
};

// Object Name: Class slua_unreal.LuaObject
// Size: 0xa0 // Inherited bytes: 0x28
struct ULuaObject : UObject {
	// Fields
	char pad_0x28[0x68]; // Offset: 0x28 // Size: 0x68
	struct FString LuaFilePath; // Offset: 0x90 // Size: 0x10
};

// Object Name: Class slua_unreal.LuaUserWidget
// Size: 0x288 // Inherited bytes: 0x218
struct ULuaUserWidget : UUserWidget {
	// Fields
	char pad_0x218[0x60]; // Offset: 0x218 // Size: 0x60
	struct FString LuaFilePath; // Offset: 0x278 // Size: 0x10
};

