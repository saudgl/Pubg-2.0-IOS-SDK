#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: AnimBlueprintGeneratedClass wingmanAnimationBP_DT.wingmanAnimationBP_DT_C
// Size: 0x508 // Inherited bytes: 0x3d0
struct UwingmanAnimationBP_DT_C : UAnimInstance {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x3d0 // Size: 0x08
	struct FAnimNode_Root AnimGraphNode_Root_558D03F941037608EE8AC29556AC48ED; // Offset: 0x3d8 // Size: 0x50
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_09D693444DB79A046261159F5DAABF71; // Offset: 0x428 // Size: 0x70
	struct FAnimNode_Slot AnimGraphNode_Slot_EBB0C6444B7150C9DE626EB3B35FFDC8; // Offset: 0x498 // Size: 0x70

	// Functions

	// Object Name: Function wingmanAnimationBP_DT.wingmanAnimationBP_DT_C.OnNotifyEnd_00FA334F47E0294ABC96DE97990B929A
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnNotifyEnd_00FA334F47E0294ABC96DE97990B929A(struct FName NotifyName); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function wingmanAnimationBP_DT.wingmanAnimationBP_DT_C.OnNotifyBegin_00FA334F47E0294ABC96DE97990B929A
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnNotifyBegin_00FA334F47E0294ABC96DE97990B929A(struct FName NotifyName); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function wingmanAnimationBP_DT.wingmanAnimationBP_DT_C.OnInterrupted_00FA334F47E0294ABC96DE97990B929A
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnInterrupted_00FA334F47E0294ABC96DE97990B929A(struct FName NotifyName); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function wingmanAnimationBP_DT.wingmanAnimationBP_DT_C.OnBlendOut_00FA334F47E0294ABC96DE97990B929A
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnBlendOut_00FA334F47E0294ABC96DE97990B929A(struct FName NotifyName); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function wingmanAnimationBP_DT.wingmanAnimationBP_DT_C.OnCompleted_00FA334F47E0294ABC96DE97990B929A
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnCompleted_00FA334F47E0294ABC96DE97990B929A(struct FName NotifyName); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function wingmanAnimationBP_DT.wingmanAnimationBP_DT_C.BlueprintBeginPlay
	// Flags: [Event|Public|BlueprintEvent]
	void BlueprintBeginPlay(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function wingmanAnimationBP_DT.wingmanAnimationBP_DT_C.OnHallWingmanAnimPlay_Event_1
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnHallWingmanAnimPlay_Event_1(); // Offset: 0x103e7af64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function wingmanAnimationBP_DT.wingmanAnimationBP_DT_C.ExecuteUbergraph_wingmanAnimationBP_DT
	// Flags: [None]
	void ExecuteUbergraph_wingmanAnimationBP_DT(int EntryPoint); // Offset: 0x103e7af64 // Return & Params: Num(1) Size(0x4)
};

